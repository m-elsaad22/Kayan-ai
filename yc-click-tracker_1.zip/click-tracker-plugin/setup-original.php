<?php
/**
 * ClickTracker - تتبع ضغطات أزرار الواتساب والاتصال
 * YourColor Theme Plugin
 */

class ClickTracker {

    private $table_name;

    function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'yc_click_tracker';
    }

    // إنشاء جدول قاعدة البيانات
    public function CreateTable() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table = $this->table_name;

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id BIGINT(20) NOT NULL AUTO_INCREMENT,
            click_type VARCHAR(20) NOT NULL COMMENT 'whatsapp or call',
            page_title TEXT NOT NULL,
            page_url TEXT NOT NULL,
            post_id BIGINT(20) DEFAULT NULL,
            post_type VARCHAR(50) DEFAULT NULL,
            click_time DATETIME NOT NULL,
            user_ip VARCHAR(45) DEFAULT NULL,
            user_agent TEXT DEFAULT NULL,
            referrer TEXT DEFAULT NULL,
            PRIMARY KEY (id),
            KEY click_type (click_type),
            KEY click_time (click_time),
            KEY post_id (post_id)
        ) {$charset_collate};";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    // معالج AJAX لتسجيل الضغطة
    public function RecordClick() {
        global $wpdb;

        // التحقق من البيانات
        if ( empty($_POST['click_type']) || empty($_POST['page_url']) ) {
            wp_send_json_error('بيانات ناقصة');
            return;
        }

        $click_type = sanitize_text_field($_POST['click_type']);
        $page_title = sanitize_text_field($_POST['page_title'] ?? '');
        $page_url   = esc_url_raw($_POST['page_url'] ?? '');
        $post_id    = intval($_POST['post_id'] ?? 0);
        $post_type  = sanitize_text_field($_POST['post_type'] ?? '');
        $referrer   = esc_url_raw($_POST['referrer'] ?? '');
        $user_ip    = $this->GetUserIP();
        $user_agent = sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? '');

        $wpdb->insert(
            $this->table_name,
            array(
                'click_type'  => $click_type,
                'page_title'  => $page_title,
                'page_url'    => $page_url,
                'post_id'     => $post_id ?: NULL,
                'post_type'   => $post_type,
                'click_time'  => current_time('mysql'),
                'user_ip'     => $user_ip,
                'user_agent'  => $user_agent,
                'referrer'    => $referrer,
            ),
            array('%s','%s','%s','%d','%s','%s','%s','%s','%s')
        );

        wp_send_json_success('تم التسجيل');
    }

    // الحصول على IP المستخدم
    private function GetUserIP() {
        $keys = array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'REMOTE_ADDR'
        );
        foreach ($keys as $key) {
            if ( !empty($_SERVER[$key]) ) {
                $ip = explode(',', $_SERVER[$key]);
                return trim($ip[0]);
            }
        }
        return 'Unknown';
    }

    // إضافة صفحة الإدارة
    public function AddAdminMenu() {
        add_menu_page(
            'تتبع الضغطات',
            'تتبع الضغطات',
            'manage_options',
            'yc-click-tracker',
            array($this, 'AdminPage'),
            'dashicons-chart-bar',
            30
        );
    }

    // صفحة الإدارة
    public function AdminPage() {
        global $wpdb;
        $table = $this->table_name;

        // حذف سجل محدد
        if ( isset($_GET['delete_id']) && current_user_can('manage_options') ) {
            $wpdb->delete($table, array('id' => intval($_GET['delete_id'])));
            echo '<div class="notice notice-success"><p>تم الحذف بنجاح</p></div>';
        }

        // حذف كل السجلات
        if ( isset($_POST['delete_all']) && current_user_can('manage_options') ) {
            $wpdb->query("TRUNCATE TABLE {$table}");
            echo '<div class="notice notice-success"><p>تم حذف جميع السجلات</p></div>';
        }

        // فلترة
        $filter_type = sanitize_text_field($_GET['filter_type'] ?? '');
        $filter_date = sanitize_text_field($_GET['filter_date'] ?? '');
        $search      = sanitize_text_field($_GET['search'] ?? '');

        // بناء الاستعلام
        $where = 'WHERE 1=1';
        $params = array();
        if ( !empty($filter_type) ) {
            $where .= ' AND click_type = %s';
            $params[] = $filter_type;
        }
        if ( !empty($filter_date) ) {
            $where .= ' AND DATE(click_time) = %s';
            $params[] = $filter_date;
        }
        if ( !empty($search) ) {
            $where .= ' AND (page_title LIKE %s OR page_url LIKE %s)';
            $params[] = '%' . $wpdb->esc_like($search) . '%';
            $params[] = '%' . $wpdb->esc_like($search) . '%';
        }

        // الإحصائيات
        $total_all       = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");
        $total_whatsapp  = $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE click_type='whatsapp'");
        $total_call      = $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE click_type='call'");
        $today_count     = $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE DATE(click_time) = CURDATE()");

        // الصفحات الأكثر ضغطاً
        $top_pages = $wpdb->get_results(
            "SELECT page_title, page_url, COUNT(*) as clicks 
             FROM {$table} 
             GROUP BY page_url 
             ORDER BY clicks DESC 
             LIMIT 5"
        );

        // جلب السجلات
        $per_page = 20;
        $paged    = max(1, intval($_GET['paged'] ?? 1));
        $offset   = ($paged - 1) * $per_page;

        if ( !empty($params) ) {
            $query = $wpdb->prepare("SELECT * FROM {$table} {$where} ORDER BY click_time DESC LIMIT %d OFFSET %d", array_merge($params, [$per_page, $offset]));
            $total_filtered = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} {$where}", $params));
        } else {
            $query = "SELECT * FROM {$table} ORDER BY click_time DESC LIMIT {$per_page} OFFSET {$offset}";
            $total_filtered = $total_all;
        }

        $records = $wpdb->get_results($query);
        $total_pages = ceil($total_filtered / $per_page);

        $current_url = admin_url('admin.php?page=yc-click-tracker');
        ?>
        <style>
            .yct-wrap { font-family: 'Segoe UI', Tahoma, Arial, sans-serif; direction: rtl; padding: 20px; }
            .yct-stats { display: flex; gap: 15px; margin-bottom: 25px; flex-wrap: wrap; }
            .yct-stat-box { background: #fff; border-radius: 10px; padding: 18px 25px; flex: 1; min-width: 150px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); text-align: center; border-top: 4px solid #ccc; }
            .yct-stat-box.all   { border-color: #6c757d; }
            .yct-stat-box.wa    { border-color: #25d366; }
            .yct-stat-box.call  { border-color: #007bff; }
            .yct-stat-box.today { border-color: #fd7e14; }
            .yct-stat-box .num  { font-size: 36px; font-weight: 700; display: block; }
            .yct-stat-box .lbl  { font-size: 13px; color: #666; margin-top: 5px; display: block; }
            .yct-stat-box.wa .num  { color: #25d366; }
            .yct-stat-box.call .num { color: #007bff; }
            .yct-stat-box.today .num { color: #fd7e14; }
            .yct-table-wrap { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-top: 20px; }
            .yct-table { width: 100%; border-collapse: collapse; font-size: 13px; }
            .yct-table th { background: #f4f5f7; padding: 10px 12px; text-align: right; font-weight: 600; border-bottom: 2px solid #e1e4e8; }
            .yct-table td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
            .yct-table tr:hover td { background: #fafbfc; }
            .badge-wa   { background: #d4f5e2; color: #1a7a45; padding: 3px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }
            .badge-call { background: #d0e8ff; color: #0056b3; padding: 3px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }
            .yct-filters { display: flex; gap: 10px; margin-bottom: 15px; align-items: center; flex-wrap: wrap; }
            .yct-filters input, .yct-filters select { padding: 7px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; }
            .yct-filters .btn-filter { background: #0073aa; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; }
            .yct-filters .btn-reset  { background: #6c757d; color: #fff; border: none; padding: 8px 14px; border-radius: 6px; cursor: pointer; font-size: 13px; text-decoration: none; }
            .btn-delete-all { background: #dc3545; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; margin-right: auto; }
            .btn-delete-one { color: #dc3545; font-size: 12px; text-decoration: none; }
            .yct-pagination { margin-top: 15px; display: flex; gap: 5px; }
            .yct-pagination a, .yct-pagination span { padding: 5px 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 13px; text-decoration: none; color: #333; }
            .yct-pagination .current { background: #0073aa; color: #fff; border-color: #0073aa; }
            .top-pages { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-top: 20px; }
            .top-pages h3 { margin-top: 0; font-size: 15px; color: #333; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
            .top-pages ul { padding: 0; margin: 0; list-style: none; }
            .top-pages ul li { display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid #f5f5f5; font-size: 13px; }
            .top-pages ul li .cnt { background: #0073aa; color: #fff; padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }
            .export-btn { background: #28a745; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 13px; text-decoration: none; display: inline-block; }
        </style>

        <div class="yct-wrap">
            <h1 style="margin-bottom:20px; font-size:22px; color:#333;">
                📊 تتبع ضغطات الواتساب والاتصال
            </h1>

            <!-- الإحصائيات -->
            <div class="yct-stats">
                <div class="yct-stat-box all">
                    <span class="num"><?= number_format($total_all) ?></span>
                    <span class="lbl">إجمالي الضغطات</span>
                </div>
                <div class="yct-stat-box wa">
                    <span class="num"><?= number_format($total_whatsapp) ?></span>
                    <span class="lbl">💬 واتساب</span>
                </div>
                <div class="yct-stat-box call">
                    <span class="num"><?= number_format($total_call) ?></span>
                    <span class="lbl">📞 اتصال</span>
                </div>
                <div class="yct-stat-box today">
                    <span class="num"><?= number_format($today_count) ?></span>
                    <span class="lbl">اليوم</span>
                </div>
            </div>

            <!-- أكثر الصفحات ضغطاً -->
            <?php if (!empty($top_pages)) : ?>
            <div class="top-pages">
                <h3>🏆 أكثر الصفحات / المقالات ضغطاً</h3>
                <ul>
                    <?php foreach ($top_pages as $tp) : ?>
                    <li>
                        <a href="<?= esc_url($tp->page_url) ?>" target="_blank" style="color:#0073aa; text-decoration:none; max-width:70%; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; display:block;">
                            <?= esc_html($tp->page_title ?: $tp->page_url) ?>
                        </a>
                        <span class="cnt"><?= intval($tp->clicks) ?> ضغطة</span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- جدول السجلات -->
            <div class="yct-table-wrap">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px; flex-wrap:wrap; gap:10px;">
                    <h2 style="margin:0; font-size:16px; color:#333;">📋 سجل الضغطات</h2>
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <a href="<?= $current_url ?>&export=csv" class="export-btn">⬇️ تصدير CSV</a>
                        <form method="post" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من حذف جميع السجلات؟');">
                            <button type="submit" name="delete_all" class="btn-delete-all">🗑️ حذف الكل</button>
                        </form>
                    </div>
                </div>

                <!-- فلاتر البحث -->
                <form method="get" action="">
                    <input type="hidden" name="page" value="yc-click-tracker">
                    <div class="yct-filters">
                        <select name="filter_type">
                            <option value="">كل الأنواع</option>
                            <option value="whatsapp" <?= ($filter_type=='whatsapp'?'selected':'') ?>>واتساب</option>
                            <option value="call"      <?= ($filter_type=='call'?'selected':'') ?>>اتصال</option>
                        </select>
                        <input type="date" name="filter_date" value="<?= esc_attr($filter_date) ?>" placeholder="تصفية بالتاريخ">
                        <input type="text" name="search" value="<?= esc_attr($search) ?>" placeholder="ابحث في العنوان أو الرابط">
                        <button type="submit" class="btn-filter">🔍 بحث</button>
                        <a href="<?= $current_url ?>" class="btn-reset">✕ إلغاء</a>
                    </div>
                </form>

                <table class="yct-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>النوع</th>
                            <th>عنوان الصفحة / المقال</th>
                            <th>التاريخ والوقت</th>
                            <th>IP المستخدم</th>
                            <th>حذف</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( empty($records) ) : ?>
                        <tr><td colspan="6" style="text-align:center; color:#999; padding:30px;">لا توجد سجلات بعد</td></tr>
                        <?php else : ?>
                        <?php foreach ($records as $row) : ?>
                        <tr>
                            <td style="color:#999;"><?= intval($row->id) ?></td>
                            <td>
                                <?php if ($row->click_type == 'whatsapp') : ?>
                                    <span class="badge-wa">💬 واتساب</span>
                                <?php else : ?>
                                    <span class="badge-call">📞 اتصال</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?= esc_url($row->page_url) ?>" target="_blank" style="color:#0073aa; text-decoration:none;" title="<?= esc_attr($row->page_url) ?>">
                                    <?= esc_html(mb_strimwidth($row->page_title ?: $row->page_url, 0, 60, '...')) ?>
                                </a>
                                <?php if ($row->post_type) : ?>
                                <br><small style="color:#999;"><?= esc_html($row->post_type) ?></small>
                                <?php endif; ?>
                            </td>
                            <td style="white-space:nowrap; color:#555; font-size:12px;">
                                <?php
                                    $dt = new DateTime($row->click_time);
                                    echo $dt->format('Y/m/d') . '<br><strong>' . $dt->format('H:i:s') . '</strong>';
                                ?>
                            </td>
                            <td style="font-size:12px; color:#666; direction:ltr;"><?= esc_html($row->user_ip) ?></td>
                            <td>
                                <a href="<?= $current_url ?>&delete_id=<?= intval($row->id) ?>" class="btn-delete-one" onclick="return confirm('حذف هذا السجل؟')">✕</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($total_pages > 1) : ?>
                <div class="yct-pagination">
                    <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                        <?php if ($i == $paged) : ?>
                            <span class="current"><?= $i ?></span>
                        <?php else : ?>
                            <a href="<?= $current_url ?>&paged=<?= $i ?>&filter_type=<?= urlencode($filter_type) ?>&filter_date=<?= urlencode($filter_date) ?>&search=<?= urlencode($search) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    // تصدير CSV
    public function ExportCSV() {
        if ( !isset($_GET['export']) || $_GET['export'] !== 'csv' ) return;
        if ( !current_user_can('manage_options') ) return;
        if ( !is_admin() ) return;

        global $wpdb;
        $records = $wpdb->get_results("SELECT * FROM {$this->table_name} ORDER BY click_time DESC");

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="click-tracker-' . date('Y-m-d') . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM for Excel Arabic

        fputcsv($output, array('ID', 'النوع', 'عنوان الصفحة', 'رابط الصفحة', 'نوع المحتوى', 'التاريخ والوقت', 'IP المستخدم'));

        foreach ($records as $row) {
            fputcsv($output, array(
                $row->id,
                ($row->click_type == 'whatsapp') ? 'واتساب' : 'اتصال',
                $row->page_title,
                $row->page_url,
                $row->post_type,
                $row->click_time,
                $row->user_ip,
            ));
        }

        fclose($output);
        exit;
    }

    // إضافة JavaScript للتتبع في الفرونت
    public function EnqueueTrackingScript() {
        if ( is_admin() ) return;
        ?>
        <script>
        (function(){
            // دالة إرسال الضغطة للسيرفر
            function trackClick(type) {
                var data = new FormData();
                data.append('action',     'yc_track_click');
                data.append('click_type', type);
                data.append('page_title', document.title);
                data.append('page_url',   window.location.href);
                data.append('referrer',   document.referrer || '');
                data.append('post_id',    (window.yc_post_id   || 0));
                data.append('post_type',  (window.yc_post_type || ''));

                // إرسال في الخلفية بدون إيقاف الرابط
                if (navigator.sendBeacon) {
                    var blob = new URLSearchParams();
                    blob.append('action',     'yc_track_click');
                    blob.append('click_type', type);
                    blob.append('page_title', document.title);
                    blob.append('page_url',   window.location.href);
                    blob.append('referrer',   document.referrer || '');
                    blob.append('post_id',    (window.yc_post_id   || 0));
                    blob.append('post_type',  (window.yc_post_type || ''));
                    navigator.sendBeacon('<?= admin_url("admin-ajax.php") ?>', blob);
                } else {
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '<?= admin_url("admin-ajax.php") ?>', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.send(new URLSearchParams(data).toString());
                }
            }

            // رصد الضغطات على الروابط
            document.addEventListener('click', function(e) {
                var el = e.target;
                // صعود لأعلى للعثور على رابط الأب
                while (el && el.tagName !== 'A') {
                    el = el.parentElement;
                }
                if (!el || !el.href) return;

                var href = el.href.toLowerCase();

                // واتساب
                if (href.indexOf('wa.me') !== -1 || href.indexOf('whatsapp.com') !== -1 || href.indexOf('api.whatsapp') !== -1) {
                    trackClick('whatsapp');
                }
                // اتصال
                else if (href.indexOf('tel:') === 0) {
                    trackClick('call');
                }
            }, true);

        })();
        </script>
        <?php
    }

    // إضافة post_id و post_type في الصفحة
    public function PrintPostData() {
        if ( is_admin() ) return;
        global $post;
        $post_id   = ($post) ? $post->ID   : 0;
        $post_type = ($post) ? $post->post_type : '';
        echo '<script>window.yc_post_id=' . intval($post_id) . '; window.yc_post_type="' . esc_js($post_type) . '";</script>' . "\n";
    }

    public function Setup() {
        // إنشاء الجدول عند تفعيل القالب
        add_action('after_switch_theme', array($this, 'CreateTable'));
        add_action('init', array($this, 'CreateTable')); // إنشاء إن لم يكن موجوداً

        // AJAX handlers
        add_action('wp_ajax_yc_track_click',        array($this, 'RecordClick'));
        add_action('wp_ajax_nopriv_yc_track_click',  array($this, 'RecordClick'));

        // Admin
        add_action('admin_menu', array($this, 'AddAdminMenu'));
        add_action('admin_init', array($this, 'ExportCSV'));

        // Frontend script
        add_action('wp_footer',         array($this, 'EnqueueTrackingScript'), 99);
        add_action('wp_head',           array($this, 'PrintPostData'), 1);
    }
}

(new ClickTracker)->Setup();

<?php
/**
 * Plugin Name: YC Click Tracker - تتبع الواتساب والاتصال
 * Plugin URI:  https://yourcolor.sa
 * Description: يتتبع كل ضغطة على أزرار الواتساب والاتصال في موقعك ويعرض تقارير تفصيلية في لوحة التحكم
 * Version:     1.0.0
 * Author:      YourColor
 * Text Domain: yc-click-tracker
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class YC_Click_Tracker {

    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'yc_click_tracker';
    }

    // ===========================
    // إنشاء الجدول عند التفعيل
    // ===========================
    public function Activate() {
        $this->CreateTable();
    }

    public function CreateTable() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table = $this->table_name;

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id          BIGINT(20)   NOT NULL AUTO_INCREMENT,
            click_type  VARCHAR(20)  NOT NULL COMMENT 'whatsapp or call',
            page_title  TEXT         NOT NULL,
            page_url    TEXT         NOT NULL,
            post_id     BIGINT(20)   DEFAULT NULL,
            post_type   VARCHAR(50)  DEFAULT NULL,
            click_time  DATETIME     NOT NULL,
            user_ip     VARCHAR(45)  DEFAULT NULL,
            user_agent  TEXT         DEFAULT NULL,
            referrer    TEXT         DEFAULT NULL,
            PRIMARY KEY (id),
            KEY click_type (click_type),
            KEY click_time (click_time),
            KEY post_id    (post_id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    // ===========================
    // AJAX - تسجيل الضغطة
    // ===========================
    public function RecordClick() {
        global $wpdb;

        if ( empty( $_POST['click_type'] ) || empty( $_POST['page_url'] ) ) {
            wp_send_json_error( 'بيانات ناقصة' );
        }

        $wpdb->insert(
            $this->table_name,
            array(
                'click_type' => sanitize_text_field( $_POST['click_type'] ),
                'page_title' => sanitize_text_field( $_POST['page_title'] ?? '' ),
                'page_url'   => esc_url_raw( $_POST['page_url'] ?? '' ),
                'post_id'    => intval( $_POST['post_id'] ?? 0 ) ?: null,
                'post_type'  => sanitize_text_field( $_POST['post_type'] ?? '' ),
                'click_time' => current_time( 'mysql' ),
                'user_ip'    => $this->GetUserIP(),
                'user_agent' => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ),
                'referrer'   => esc_url_raw( $_POST['referrer'] ?? '' ),
            ),
            array( '%s','%s','%s','%d','%s','%s','%s','%s','%s' )
        );

        wp_send_json_success( 'ok' );
    }

    private function GetUserIP() {
        foreach ( array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                return trim( explode( ',', $_SERVER[ $key ] )[0] );
            }
        }
        return 'Unknown';
    }

    // ===========================
    // قائمة الإدارة
    // ===========================
    public function AddAdminMenu() {
        add_menu_page(
            'تتبع الضغطات',
            'تتبع الضغطات',
            'manage_options',
            'yc-click-tracker',
            array( $this, 'AdminPage' ),
            'dashicons-chart-bar',
            30
        );
    }

    // ===========================
    // صفحة الإدارة
    // ===========================
    public function AdminPage() {
        global $wpdb;
        $table = $this->table_name;

        // حذف سجل واحد
        if ( isset( $_GET['delete_id'] ) && current_user_can( 'manage_options' ) ) {
            $wpdb->delete( $table, array( 'id' => intval( $_GET['delete_id'] ) ) );
            echo '<div class="notice notice-success is-dismissible"><p>✅ تم حذف السجل</p></div>';
        }

        // حذف الكل
        if ( isset( $_POST['delete_all'] ) && current_user_can( 'manage_options' ) ) {
            $wpdb->query( "TRUNCATE TABLE {$table}" );
            echo '<div class="notice notice-success is-dismissible"><p>✅ تم حذف جميع السجلات</p></div>';
        }

        // فلاتر
        $filter_type = sanitize_text_field( $_GET['filter_type'] ?? '' );
        $filter_date = sanitize_text_field( $_GET['filter_date'] ?? '' );
        $search      = sanitize_text_field( $_GET['search'] ?? '' );

        // بناء WHERE
        $where  = 'WHERE 1=1';
        $params = array();
        if ( $filter_type ) { $where .= ' AND click_type = %s';            $params[] = $filter_type; }
        if ( $filter_date ) { $where .= ' AND DATE(click_time) = %s';      $params[] = $filter_date; }
        if ( $search )      {
            $where   .= ' AND (page_title LIKE %s OR page_url LIKE %s)';
            $like     = '%' . $wpdb->esc_like( $search ) . '%';
            $params[] = $like;
            $params[] = $like;
        }

        // إحصائيات
        $total_all      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $total_whatsapp = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE click_type='whatsapp'" );
        $total_call     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE click_type='call'" );
        $today_count    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE DATE(click_time)=CURDATE()" );

        // أكثر الصفحات ضغطاً
        $top_pages = $wpdb->get_results(
            "SELECT page_title, page_url, COUNT(*) as clicks
             FROM {$table}
             GROUP BY page_url
             ORDER BY clicks DESC
             LIMIT 5"
        );

        // Pagination
        $per_page = 25;
        $paged    = max( 1, intval( $_GET['paged'] ?? 1 ) );
        $offset   = ( $paged - 1 ) * $per_page;

        if ( $params ) {
            $records         = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} {$where} ORDER BY click_time DESC LIMIT %d OFFSET %d", array_merge( $params, [ $per_page, $offset ] ) ) );
            $total_filtered  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} {$where}", $params ) );
        } else {
            $records        = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY click_time DESC LIMIT {$per_page} OFFSET {$offset}" );
            $total_filtered = $total_all;
        }

        $total_pages = (int) ceil( $total_filtered / $per_page );
        $base_url    = admin_url( 'admin.php?page=yc-click-tracker' );

        // CSS
        ?>
        <style>
        .yct-wrap{font-family:'Segoe UI',Tahoma,Arial,sans-serif;direction:rtl;padding:20px 10px;}
        .yct-title{font-size:22px;font-weight:700;color:#1d2327;margin-bottom:20px;display:flex;align-items:center;gap:8px;}
        .yct-stats{display:flex;gap:14px;margin-bottom:22px;flex-wrap:wrap;}
        .yct-stat{background:#fff;border-radius:12px;padding:18px 22px;flex:1;min-width:130px;box-shadow:0 2px 10px rgba(0,0,0,.07);text-align:center;border-top:4px solid #ccc;}
        .yct-stat.s-all{border-color:#6c757d;} .yct-stat.s-wa{border-color:#25d366;} .yct-stat.s-call{border-color:#0073aa;} .yct-stat.s-today{border-color:#fd7e14;}
        .yct-stat .n{font-size:38px;font-weight:800;display:block;line-height:1;}
        .yct-stat.s-wa .n{color:#25d366;} .yct-stat.s-call .n{color:#0073aa;} .yct-stat.s-today .n{color:#fd7e14;} .yct-stat.s-all .n{color:#6c757d;}
        .yct-stat .l{font-size:12px;color:#888;margin-top:6px;display:block;}
        .yct-card{background:#fff;border-radius:12px;padding:20px;box-shadow:0 2px 10px rgba(0,0,0,.07);margin-bottom:18px;}
        .yct-card h3{margin:0 0 14px;font-size:15px;color:#333;border-bottom:2px solid #f0f0f0;padding-bottom:10px;}
        .top-list{padding:0;margin:0;list-style:none;}
        .top-list li{display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid #f5f5f5;gap:10px;}
        .top-list li:last-child{border:none;}
        .top-list a{color:#0073aa;text-decoration:none;font-size:13px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:80%;}
        .cnt-badge{background:#0073aa;color:#fff;padding:2px 11px;border-radius:20px;font-size:12px;font-weight:700;white-space:nowrap;}
        .yct-filters{display:flex;gap:9px;margin-bottom:14px;flex-wrap:wrap;align-items:center;}
        .yct-filters input,.yct-filters select{padding:7px 11px;border:1px solid #ddd;border-radius:7px;font-size:13px;font-family:inherit;}
        .btn-f{background:#0073aa;color:#fff;border:none;padding:8px 16px;border-radius:7px;cursor:pointer;font-size:13px;font-family:inherit;}
        .btn-r{background:#6c757d;color:#fff;padding:8px 13px;border-radius:7px;font-size:13px;text-decoration:none;display:inline-block;}
        .btn-del-all{background:#dc3545;color:#fff;border:none;padding:8px 16px;border-radius:7px;cursor:pointer;font-size:13px;font-family:inherit;}
        .btn-csv{background:#28a745;color:#fff;padding:8px 16px;border-radius:7px;font-size:13px;text-decoration:none;display:inline-block;border:none;cursor:pointer;font-family:inherit;}
        .yct-table{width:100%;border-collapse:collapse;font-size:13px;}
        .yct-table th{background:#f6f7f9;padding:10px 13px;text-align:right;font-weight:600;border-bottom:2px solid #e8eaed;color:#555;}
        .yct-table td{padding:10px 13px;border-bottom:1px solid #f0f0f0;vertical-align:middle;}
        .yct-table tr:hover td{background:#fafbfc;}
        .badge-wa{background:#d4f5e2;color:#1a7a45;padding:3px 11px;border-radius:20px;font-size:12px;font-weight:700;}
        .badge-call{background:#d0e8ff;color:#00508a;padding:3px 11px;border-radius:20px;font-size:12px;font-weight:700;}
        .del-one{color:#dc3545;font-size:13px;text-decoration:none;opacity:.7;}
        .del-one:hover{opacity:1;}
        .yct-pager{display:flex;gap:5px;margin-top:14px;flex-wrap:wrap;}
        .yct-pager a,.yct-pager span{padding:5px 11px;border:1px solid #ddd;border-radius:6px;font-size:13px;text-decoration:none;color:#333;}
        .yct-pager .cur{background:#0073aa;color:#fff;border-color:#0073aa;}
        .top-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:10px;}
        .top-bar-btns{display:flex;gap:8px;flex-wrap:wrap;}
        </style>

        <div class="yct-wrap">
            <div class="yct-title">📊 تتبع ضغطات الواتساب والاتصال</div>

            <!-- إحصائيات -->
            <div class="yct-stats">
                <div class="yct-stat s-all">  <span class="n"><?= number_format($total_all) ?></span>      <span class="l">إجمالي الضغطات</span></div>
                <div class="yct-stat s-wa">   <span class="n"><?= number_format($total_whatsapp) ?></span> <span class="l">💬 واتساب</span></div>
                <div class="yct-stat s-call"> <span class="n"><?= number_format($total_call) ?></span>     <span class="l">📞 اتصال</span></div>
                <div class="yct-stat s-today"><span class="n"><?= number_format($today_count) ?></span>    <span class="l">اليوم</span></div>
            </div>

            <!-- أكثر الصفحات ضغطاً -->
            <?php if ( $top_pages ) : ?>
            <div class="yct-card">
                <h3>🏆 أكثر الصفحات / المقالات ضغطاً</h3>
                <ul class="top-list">
                    <?php foreach ( $top_pages as $tp ) : ?>
                    <li>
                        <a href="<?= esc_url($tp->page_url) ?>" target="_blank">
                            <?= esc_html( $tp->page_title ?: $tp->page_url ) ?>
                        </a>
                        <span class="cnt-badge"><?= intval($tp->clicks) ?> ضغطة</span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- جدول السجلات -->
            <div class="yct-card">
                <div class="top-bar">
                    <h3 style="margin:0;font-size:15px;color:#333;">📋 سجل الضغطات
                        <small style="color:#999;font-weight:400;">(<?= number_format($total_filtered) ?> سجل)</small>
                    </h3>
                    <div class="top-bar-btns">
                        <a href="<?= $base_url ?>&export=csv" class="btn-csv">⬇️ تصدير CSV</a>
                        <form method="post" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من حذف جميع السجلات؟');">
                            <button type="submit" name="delete_all" class="btn-del-all">🗑️ حذف الكل</button>
                        </form>
                    </div>
                </div>

                <!-- فلاتر -->
                <form method="get" action="">
                    <input type="hidden" name="page" value="yc-click-tracker">
                    <div class="yct-filters">
                        <select name="filter_type">
                            <option value="">كل الأنواع</option>
                            <option value="whatsapp" <?= selected($filter_type,'whatsapp',false) ?>>💬 واتساب</option>
                            <option value="call"      <?= selected($filter_type,'call',false) ?>>📞 اتصال</option>
                        </select>
                        <input type="date"   name="filter_date" value="<?= esc_attr($filter_date) ?>">
                        <input type="search" name="search"      value="<?= esc_attr($search) ?>" placeholder="🔍 ابحث في العنوان أو الرابط" style="min-width:220px;">
                        <button type="submit" class="btn-f">بحث</button>
                        <a href="<?= $base_url ?>" class="btn-r">✕ إلغاء</a>
                    </div>
                </form>

                <table class="yct-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>النوع</th>
                            <th>الصفحة / المقال</th>
                            <th>التاريخ</th>
                            <th>الوقت</th>
                            <th>IP</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ( empty($records) ) : ?>
                        <tr><td colspan="7" style="text-align:center;color:#aaa;padding:35px;font-size:14px;">لا توجد سجلات</td></tr>
                    <?php else : foreach ( $records as $row ) :
                        $dt = new DateTime( $row->click_time );
                    ?>
                        <tr>
                            <td style="color:#bbb;font-size:11px;"><?= intval($row->id) ?></td>
                            <td>
                                <?php if ( $row->click_type === 'whatsapp' ) : ?>
                                    <span class="badge-wa">💬 واتساب</span>
                                <?php else : ?>
                                    <span class="badge-call">📞 اتصال</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?= esc_url($row->page_url) ?>" target="_blank" style="color:#0073aa;text-decoration:none;" title="<?= esc_attr($row->page_url) ?>">
                                    <?= esc_html( mb_strimwidth( $row->page_title ?: $row->page_url, 0, 55, '…' ) ) ?>
                                </a>
                                <?php if ( $row->post_type ) : ?>
                                <br><small style="color:#aaa;"><?= esc_html($row->post_type) ?></small>
                                <?php endif; ?>
                            </td>
                            <td style="white-space:nowrap;color:#555;font-size:12px;"><?= $dt->format('Y/m/d') ?></td>
                            <td style="white-space:nowrap;color:#333;font-size:13px;font-weight:600;"><?= $dt->format('H:i:s') ?></td>
                            <td style="font-size:11px;color:#888;direction:ltr;"><?= esc_html($row->user_ip) ?></td>
                            <td>
                                <a href="<?= $base_url ?>&delete_id=<?= intval($row->id) ?>"
                                   class="del-one"
                                   onclick="return confirm('حذف هذا السجل؟')">✕</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ( $total_pages > 1 ) : ?>
                <div class="yct-pager">
                    <?php for ( $i = 1; $i <= $total_pages; $i++ ) :
                        $page_url = add_query_arg( array( 'page'=>'yc-click-tracker', 'paged'=>$i, 'filter_type'=>$filter_type, 'filter_date'=>$filter_date, 'search'=>$search ), admin_url('admin.php') );
                    ?>
                        <?php if ( $i === $paged ) : ?>
                            <span class="cur"><?= $i ?></span>
                        <?php else : ?>
                            <a href="<?= esc_url($page_url) ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    // ===========================
    // تصدير CSV
    // ===========================
    public function ExportCSV() {
        if ( ! is_admin() ) return;
        if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'yc-click-tracker' ) return;
        if ( ! isset( $_GET['export'] ) || $_GET['export'] !== 'csv' ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;

        global $wpdb;
        $records = $wpdb->get_results( "SELECT * FROM {$this->table_name} ORDER BY click_time DESC" );

        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="click-tracker-' . date('Y-m-d') . '.csv"' );
        header( 'Pragma: no-cache' );

        $out = fopen( 'php://output', 'w' );
        fprintf( $out, chr(0xEF) . chr(0xBB) . chr(0xBF) ); // BOM لدعم العربية في Excel

        fputcsv( $out, array( 'ID', 'النوع', 'عنوان الصفحة', 'رابط الصفحة', 'نوع المحتوى', 'التاريخ والوقت', 'IP المستخدم' ) );

        foreach ( $records as $r ) {
            fputcsv( $out, array(
                $r->id,
                $r->click_type === 'whatsapp' ? 'واتساب' : 'اتصال',
                $r->page_title,
                $r->page_url,
                $r->post_type,
                $r->click_time,
                $r->user_ip,
            ) );
        }

        fclose( $out );
        exit;
    }

    // ===========================
    // السكريبت في الفرونت
    // ===========================
    public function FrontendScript() {
        if ( is_admin() ) return;
        global $post;
        $post_id   = $post ? $post->ID        : 0;
        $post_type = $post ? $post->post_type : '';
        $ajax_url  = admin_url( 'admin-ajax.php' );
        ?>
        <script>
        (function(){
            var AJAX = <?= json_encode($ajax_url) ?>;
            var PID  = <?= intval($post_id) ?>;
            var PT   = <?= json_encode($post_type) ?>;

            function send(type){
                var p = new URLSearchParams();
                p.append('action',     'yc_track_click');
                p.append('click_type', type);
                p.append('page_title', document.title);
                p.append('page_url',   location.href);
                p.append('referrer',   document.referrer||'');
                p.append('post_id',    PID);
                p.append('post_type',  PT);
                if(navigator.sendBeacon){ navigator.sendBeacon(AJAX, p); }
                else{
                    var x=new XMLHttpRequest();
                    x.open('POST',AJAX,true);
                    x.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
                    x.send(p.toString());
                }
            }

            document.addEventListener('click', function(e){
                var el = e.target;
                while(el && el.tagName !== 'A') el = el.parentElement;
                if(!el || !el.href) return;
                var h = el.href.toLowerCase();
                if(h.indexOf('wa.me')!==-1 || h.indexOf('whatsapp.com')!==-1 || h.indexOf('api.whatsapp')!==-1){
                    send('whatsapp');
                } else if(h.indexOf('tel:')===0){
                    send('call');
                }
            }, true);
        })();
        </script>
        <?php
    }

    // ===========================
    // تشغيل الإضافة
    // ===========================
    public function Setup() {
        register_activation_hook( __FILE__, array( $this, 'Activate' ) );
        add_action( 'init',       array( $this, 'CreateTable' ) );

        add_action( 'wp_ajax_yc_track_click',        array( $this, 'RecordClick' ) );
        add_action( 'wp_ajax_nopriv_yc_track_click', array( $this, 'RecordClick' ) );

        add_action( 'admin_menu',  array( $this, 'AddAdminMenu' ) );
        add_action( 'admin_init',  array( $this, 'ExportCSV' ) );
        add_action( 'wp_footer',   array( $this, 'FrontendScript' ), 99 );
    }
}

( new YC_Click_Tracker )->Setup();

<?php
defined('ABSPATH') || exit;

class UAG_Meta {

    private UAG_Variations $v;
    private array  $faqs;
    private string $slug;
    private string $title;
    private string $brand;
    private string $phone;
    private string $whatsapp;
    private string $site;

    public function __construct(UAG_Variations $v, array $faqs, string $slug) {
        $this->v        = $v;
        $this->faqs     = $faqs;
        $this->slug     = $slug;
        $this->title    = UAG_Title_Builder::build_title($v->service(), $v->city());
        $this->brand    = get_option('uag_brand',    'الشركة');
        $this->phone    = get_option('uag_phone',    '');
        $this->whatsapp = get_option('uag_whatsapp', '');
        $this->site     = rtrim(get_option('uag_site', get_site_url()), '/');
    }

    public function all(): array {
        $reviews   = $this->v->stat(1500, 8000, 1);
        $rating    = '4.' . $this->v->stat(7, 9, 2);
        $price_min = $this->v->stat(80, 200, 5);
        $price_max = $this->v->stat(400, 1200, 6);
        $expert    = $this->v->expert();
        $post_url  = $this->site . '/' . $this->slug . '/';
        $svc_core  = $this->v->svc_core();
        $city_bare = $this->v->city_bare();

        $seo_title = $this->title . ' 2026 | ' . $this->brand;
        $seo_desc  = $this->v->t("أفضل {svc} {city} — {brand} فريق متخصص معتمد بأحدث التقنيات. وصول سريع + ضمان مكتوب + معاينة مجانية. تواصل الآن.");

        // ── YourColor Service ──────────────────────────────────────────
        $yourcolor_service = serialize([
            'priceRange'      => "{$price_min}–{$price_max}",
            'description'     => 'اطلب خدمتنا الآن',
            'addressLocality' => $city_bare,
            'postalCode'      => '00000',
            'telephone'       => $this->phone,
            'addressCountry'  => 'AE',
            'streetAddress'   => $city_bare,
            'addressRegion'   => $city_bare,
            'areaServed'      => $city_bare,
            'OfferCatalog'    => 'الخدمة متاحة على مدار اليوم',
            'identifier'      => $this->title,
            'additionalType'  => $svc_core . ' في ' . $city_bare,
        ]);

        // ── YourColor Article ──────────────────────────────────────────
        $yourcolor_article = serialize([
            'headline'    => $city_bare,
            'description' => $this->title,
            'articleBody' => '',
        ]);

        // ── YourColor Rating ───────────────────────────────────────────
        $yourcolor_rating = serialize([
            'RatingValue_def' => $rating,
            'Best_Rating_def' => '5.0',
            'RatingCount_def' => (string)$reviews,
        ]);

        // ── YourColor Image ────────────────────────────────────────────
        $yourcolor_image = serialize([
            'description'     => $this->v->t("هل تبحث عن {svc} {city}؟ {brand} تقدم لك أفضل الحلول بأحدث التقنيات وفريق متخصص مدرب."),
            'contentLocation' => $city_bare,
        ]);

        // ── Features ───────────────────────────────────────────────────
        $feat_pool = [
            ['title'=>'فريق محترف وذو خبرة',       'icon'=>'<i class="fa-duotone fa-people-group"></i>'],
            ['title'=>'أسعار تنافسية وشفافة',       'icon'=>'<i class="fa-duotone fa-tag"></i>'],
            ['title'=>'ضمان مكتوب على الأعمال',     'icon'=>'<i class="fa-duotone fa-shield-check"></i>'],
            ['title'=>'استجابة سريعة 24/7',          'icon'=>'<i class="fa-duotone fa-clock"></i>'],
            ['title'=>'أحدث المعدات والتقنيات',      'icon'=>'<i class="fa-duotone fa-toolbox"></i>'],
            ['title'=>'خدمة بدون أضرار جانبية',     'icon'=>'<i class="fa-duotone fa-house-crack"></i>'],
        ];
        $feat_items = [];
        foreach ($feat_pool as $i => $f) {
            $feat_items['feat'.str_pad($i,4,'0',STR_PAD_LEFT)] = [
                'title'   => $f['title'],
                'content' => $this->v->t("نفخر بتقديم {svc} {city} بمعايير احترافية عالية تضمن رضاك التام."),
                'icon'    => $f['icon'],
            ];
        }
        $yourcolor_features = serialize([
            'features__title'          => $this->v->t("مميزات {svc} {city}"),
            'features__content'        => $this->v->t("{brand} تُقدّم {svc} {city} بمجموعة متميزة من المزايا التنافسية."),
            'yourcolor__post_features' => $feat_items,
        ]);

        // ── Prices ─────────────────────────────────────────────────────
        $price_rows = [];
        $pr = [
            ['الخدمة',   $svc_core],
            ['العنوان',  $city_bare],
            ['الرقم',    $this->phone],
            ['المواعيد', 'متاحون 24 ساعة'],
            ['الضمان',   'ضمان مكتوب على جميع الأعمال'],
            ['الأسعار',  "{$price_min} – {$price_max}"],
        ];
        foreach ($pr as $i => $p) {
            $price_rows['price'.str_pad($i,4,'0',STR_PAD_LEFT)] = ['title'=>$p[0],'value'=>$p[1]];
        }
        $yourcolor_prices = serialize([
            'price_list__title'        => $this->v->t("أسعار {svc} {city}"),
            'price_list__content'      => $this->v->t("{brand} تقدم {svc} {city} بأسعار تنافسية وجودة مضمونة."),
            'price_list__table_title1' => 'اسم الشركة',
            'price_list__table_title2' => $this->brand,
            'price_list__items'        => $price_rows,
        ]);

        // ── Steps ──────────────────────────────────────────────────────
        $steps_data = [
            ['التشخيص الأولي',        $this->v->t("فحص شامل للمشكلة باستخدام أجهزة متطورة في {city_bare}.")],
            ['تقديم العرض',            $this->v->t("سعر ثابت ومحدد قبل بدء أي عمل — لا مفاجآت.")],
            ['التنفيذ الاحترافي',      $this->v->t("تنفيذ {svc_core} بأحدث الأجهزة والمواد المعتمدة.")],
            ['الفحص النهائي',          $this->v->t("التأكد من جودة العمل المنجز قبل التسليم.")],
            ['الضمان المكتوب',         $this->v->t("تسليم وثيقة الضمان مع تقرير العمل المنجز.")],
            ['المتابعة بعد الخدمة',   $this->v->t("نتابع معك للتأكد من رضاك الكامل.")],
        ];
        $steps_items = [];
        foreach ($steps_data as $i => $s) {
            $steps_items['step'.str_pad($i,4,'0',STR_PAD_LEFT)] = ['title'=>$s[0],'content'=>$s[1]];
        }
        $yourcolor_steps = serialize([
            'work_steps__title'   => $this->v->t("خطوات {svc} {city}"),
            'work_steps__content' => $this->v->t("{brand} تعتمد منهجية متكاملة لضمان {svc} {city} بالجودة المطلوبة."),
            'work_steps_items'    => $steps_items,
        ]);

        // ── Services ───────────────────────────────────────────────────
        $svc_variations = [
            $svc_core . ' المنزلية',
            $svc_core . ' التجارية',
            $svc_core . ' الطارئة',
            $svc_core . ' الدورية',
            $svc_core . ' للفلل والمجمعات',
            $svc_core . ' بالعقود السنوية',
        ];
        $svc_items = [];
        foreach ($svc_variations as $i => $sv) {
            $svc_items['svc'.str_pad($i,4,'0',STR_PAD_LEFT)] = [
                'title'   => $sv,
                'content' => $this->v->t("{brand} تقدم {svc} {city} بأعلى معايير الجودة."),
                'image_id'=> '',
                'image'   => '',
            ];
        }
        $yourcolor_services = serialize([
            'services__title'     => $this->v->t("{svc} {city} — خدماتنا"),
            'services__content'   => $this->v->t("{brand} توفر حلولاً شاملة لـ {svc} {city}."),
            'post_services_items' => $svc_items,
        ]);

        // ── FAQs ───────────────────────────────────────────────────────
        $faq_meta = [];
        $faq_old  = [];
        foreach (array_slice($this->faqs, 0, 10) as $i => $faq) {
            $k = 'faq'.str_pad($i,4,'0',STR_PAD_LEFT);
            $faq_meta[$k] = ['question'=>$faq['q'],'answer'=>$faq['a']];
            $faq_old[$i]  = ['question'=>$faq['q'],'answer'=>$faq['a']];
        }

        // ── Ratings ────────────────────────────────────────────────────
        $r1=$this->v->stat(5,20,10);  $r2=$this->v->stat(20,60,11);
        $r3=$this->v->stat(80,200,12);$r4=$this->v->stat(300,700,13);
        $r5=$this->v->stat(1500,5000,14);
        $total_reviews = $r1+$r2+$r3+$r4+$r5;
        $total_score   = $r1*1+$r2*2+$r3*3+$r4*4+$r5*5;
        $avg_rating    = $total_reviews > 0 ? round($total_score/$total_reviews,2) : 5;

        return [
            // SEO
            'rank_math_title'               => $seo_title,
            'rank_math_description'         => $seo_desc,
            'rank_math_focus_keyword'       => $this->title,
            'rank_math_robots'              => serialize(['index']),
            'rank_math_news_sitemap_robots' => 'index',
            '_yoast_wpseo_focuskw'          => $this->title,
            '_yoast_wpseo_metadesc'         => $seo_desc,
            '_aioseo_description'           => $seo_desc,
            // YourColor
            'YourColor_Service'             => $yourcolor_service,
            'YourColor_Article'             => $yourcolor_article,
            'YourColor__Rating'             => $yourcolor_rating,
            'YourColor_ImageObject'         => $yourcolor_image,
            'post__features__data'          => $yourcolor_features,
            'post__price_list__data'        => $yourcolor_prices,
            'post__work_steps__data'        => $yourcolor_steps,
            'post__services__data'          => $yourcolor_services,
            'post__call_section__data'      => serialize(['call_section_title'=>'تواصل معنا','call_section_content'=>$this->v->t("اطلب {svc} {city}"),'call_section_phone'=>'','call_section_whatsapp'=>'']),
            'post__popover__data'           => serialize(['popover_call_title'=>'احجز الآن!','popover_call_content'=>$this->v->t("احجز {svc} {city} عبر واتساب"),'popover_call_icon'=>'<i class="fa-brands fa-whatsapp"></i>']),
            'post__card__data'              => serialize(['post_card_title'=>$this->title,'post_card_content'=>$this->v->t("{brand} تقدم {svc} {city} بأعلى مستوى من الاحترافية والجودة المضمونة.")]),
            'yourcolor__faqs'               => serialize($faq_meta),
            'faq'                           => serialize($faq_old),
            // Contact
            'phone'                         => $this->phone,
            'phone_number'                  => $this->phone,
            'whatsapp'                      => $this->whatsapp,
            'whatsapp_number'               => $this->whatsapp,
            // Rating
            'defualt__rating'               => serialize(['ratingValue'=>'5','ratingUsers_1'=>(string)$r1,'ratingUsers_2'=>(string)$r2,'ratingUsers_3'=>(string)$r3,'ratingUsers_4'=>(string)$r4,'ratingUsers_5'=>(string)$r5]),
            'RatingValue_v1'                => '5',
            'RateUserCount_v1'              => (string)$total_reviews,
            'TotalRate_v1'                  => (string)$avg_rating,
            'last_update'                   => date('Y-m-d'),
        ];
    }
}

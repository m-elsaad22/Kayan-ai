<?php
defined('ABSPATH') || exit;

class UAG_Content {

    private UAG_Variations $v;
    private string $slug;
    private string $brand;
    private string $phone;
    private string $whatsapp;
    private string $site;
    private array  $colors;
    private array  $hoods;
    private array  $imgs;
    public  array  $faqs = [];

    public function __construct(UAG_Variations $v, string $slug) {
        $this->v        = $v;
        $this->slug     = $slug;
        $this->brand    = get_option('uag_brand',    'الشركة');
        $this->phone    = get_option('uag_phone',    '');
        $this->whatsapp = get_option('uag_whatsapp', '');
        $this->site     = rtrim(get_option('uag_site', get_site_url()), '/');
        $this->colors   = $v->colors();
        $this->hoods    = $v->neighbourhoods();
        $this->imgs     = UAG_Image_Matcher::find($v->service(), $v->city(), 4);
        $this->faqs     = $this->build_faqs();
    }

    // ─────────────────────────────────────────────────────────────────────
    public function generate(): string {
        $c     = $this->colors;
        $e     = $this->v->expert();
        $title = UAG_Title_Builder::build_title($this->v->service(), $this->v->city());
        $wa    = preg_replace('/[^0-9]/', '', $this->whatsapp);

        $h = '';

        // ═══ HERO ════════════════════════════════════════════════════════
        $h .= $this->hero($title, $c, $wa);

        // ═══ E-E-A-T ═════════════════════════════════════════════════════
        $h .= sprintf(
            '<div style="background:#f9f9f9;border:1px solid #e0e0e0;padding:14px 18px;margin:20px 0;border-radius:8px;font-size:13px;">'.
            '✍️ <strong>أعدّه:</strong> %s — %s، خبرة %d سنة &nbsp;|&nbsp; '.
            '📅 <strong>آخر تحديث:</strong> %s &nbsp;|&nbsp; '.
            '✅ <strong>مراجعة:</strong> فريق %s</div>',
            esc_html($e['name']), esc_html($e['title']), $e['exp'],
            date('F Y'), esc_html($this->brand)
        );

        // Hero image
        if (!empty($this->imgs[0])) {
            $h .= UAG_Image_Matcher::img($this->imgs[0], true);
        }

        // ═══ SEC 1 — Intro ════════════════════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('intro'), $c);
        $h .= '<p style="font-size:16px;font-weight:500;line-height:1.9;">' . $this->v->t($this->intro_direct_answer()) . '</p>';
        $h .= '<p>' . $this->v->hook() . '</p>';
        $h .= '<p>' . $this->v->t($this->intro_p2()) . '</p>';
        $h .= '<ul style="line-height:2.1;">';
        foreach ($this->intro_bullets() as $b) $h .= "<li>{$b}</li>";
        $h .= '</ul>';
        $h .= $this->bq('tip', $this->intro_tip());
        $h .= $this->inline_link();
        $h .= $this->cta_box(0, $c, $wa);
        $h .= '</section>';

        // ═══ SEC 2 — Symptoms ════════════════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('symptoms'), $c);
        $h .= '<p>' . $this->v->t($this->symptoms_intro()) . '</p>';
        $h .= '<ol style="line-height:2.2;">';
        foreach ($this->symptoms_list() as $s) $h .= "<li>{$s}</li>";
        $h .= '</ol>';
        if (!empty($this->imgs[1])) $h .= UAG_Image_Matcher::img($this->imgs[1]);
        $h .= $this->bq('warning', $this->symptoms_warning());
        $h .= $this->bq('stat', $this->symptoms_stat());
        $h .= '<p>' . $this->v->t("نخدم {city_bare} بالكامل بما فيها: <strong>{hood1}</strong>، <strong>{hood2}</strong>، <strong>{hood3}</strong> وسائر المناطق.") . '</p>';
        $h .= $this->inline_link();
        $h .= $this->cta_box(1, $c, $wa);
        $h .= '</section>';

        // ═══ SEC 3 — Causes ══════════════════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('causes'), $c);
        $h .= '<p>' . $this->v->t($this->causes_intro()) . '</p>';
        foreach ($this->causes_list() as $cause) {
            $h .= $this->h3($cause['title']);
            $h .= '<p>' . $cause['body'] . '</p>';
        }
        $h .= $this->bq('tip', $this->causes_tip());
        $h .= $this->inline_link();
        $h .= $this->cta_box(2, $c, $wa);
        $h .= '</section>';

        // ═══ SEC 4 — Solutions ═══════════════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('solutions'), $c);
        $h .= '<p>' . $this->v->t($this->solutions_intro()) . '</p>';
        $h .= '<ol style="line-height:2.2;">';
        foreach ($this->solutions_steps() as $i => $s) {
            $h .= '<li><strong>' . $s['title'] . ':</strong><br>' . $s['body'] . '</li>';
        }
        $h .= '</ol>';
        if (!empty($this->imgs[2])) $h .= UAG_Image_Matcher::img($this->imgs[2]);
        $h .= $this->bq('warning', $this->solutions_warning());
        $h .= '<p>' . $this->v->t("نصل إليك في <strong>{hood3}</strong>، <strong>{hood4}</strong> وجميع مناطق {city_bare}.") . '</p>';
        $h .= $this->inline_link();
        $h .= $this->cta_box(3, $c, $wa);
        $h .= '</section>';

        // ═══ SEC 5 — Mistakes ════════════════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('mistakes'), $c);
        $h .= '<p>' . $this->v->t($this->mistakes_intro()) . '</p>';
        $h .= '<ol style="line-height:2.2;">';
        foreach ($this->mistakes_list() as $m) $h .= "<li>{$m}</li>";
        $h .= '</ol>';
        $h .= $this->bq('stat', $this->mistakes_stat());
        $h .= $this->h3($this->v->t("✅ نصائح ذهبية من خبراء {brand} لعملائنا في {city_bare}"));
        $h .= '<ul style="line-height:2.1;">';
        foreach ($this->tips_list() as $t) $h .= "<li>✅ {$t}</li>";
        $h .= '</ul>';
        $h .= $this->inline_link();
        $h .= $this->cta_box(0, $c, $wa);
        $h .= '</section>';

        // ═══ SEC 6 — Prices + Comparison ═════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('prices'), $c);
        $h .= '<p>' . $this->v->t($this->prices_intro()) . '</p>';
        $h .= $this->h3($this->v->t("🥇 لماذا {brand} الخيار الأول لـ {svc} {city}؟"));
        $h .= '<ul style="line-height:2.1;">';
        foreach ($this->why_us() as $w) {
            $h .= '<li>✅ <strong>' . $w['title'] . '</strong> — ' . $w['body'] . '</li>';
        }
        $h .= '</ul>';
        $h .= $this->prices_table($c);
        $h .= $this->comparison_table($c);
        if (!empty($this->imgs[3])) $h .= UAG_Image_Matcher::img($this->imgs[3]);
        $h .= $this->bq('offer', $this->v->offer());
        $h .= $this->inline_link();
        $h .= $this->cta_box(1, $c, $wa);
        $h .= '</section>';

        // ═══ SEC 7 — FAQ ══════════════════════════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('faq'), $c);
        foreach ($this->faqs as $faq) {
            $h .= $this->h3('❓ ' . esc_html($faq['q']));
            $h .= '<p>' . esc_html($faq['a']) . '</p>';
        }
        $h .= '</section>';

        // ═══ SEC 8 — Final CTA + Testimonials ════════════════════════════
        $h .= '<section>';
        $h .= $this->h2($this->v->h2('cta'), $c);
        $h .= '<p>' . $this->v->t($this->cta_body()) . '</p>';
        $h .= '<p>' . $this->v->t("تغطية شاملة: <strong>{hood1}</strong>، <strong>{hood2}</strong>، <strong>{hood3}</strong>، <strong>{hood4}</strong> وجميع مناطق {city_bare}.") . '</p>';

        // Final offer box
        $h .= $this->bq('offer', $this->v->t(
            "🎁 <strong>احجز الآن واستفد من:</strong><br>\n".
            "✅ كشف وتشخيص مجاني قبل البدء<br>\n".
            "✅ وصول سريع لجميع مناطق {city_bare}<br>\n".
            "✅ تنفيذ احترافي بدون أضرار جانبية<br>\n".
            "✅ خصم {disc}% عند الحجز عبر واتساب<br>\n".
            "✅ ضمان مكتوب على جميع الأعمال<br><br>\n".
            "📞 <strong><a href=\"tel:{phone}\">{phone}</a></strong> &nbsp;|&nbsp; ".
            "💬 <strong><a href=\"https://wa.me/{wa_num}\">{whatsapp}</a></strong>"
        ));

        // Testimonials
        $h .= '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px;margin:24px 0;">';
        foreach ($this->v->testimonials(3) as $t) {
            $stars = str_repeat('⭐', $t['stars']);
            $h .= '<div style="background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:16px;">';
            $h .= "<p style=\"margin:0 0 6px;font-size:18px;\">{$stars}</p>";
            $h .= '<p style="margin:0 0 6px;font-style:italic;">"' . esc_html($t['text']) . '"</p>';
            $h .= '<p style="margin:0;font-weight:bold;color:#666;">— ' . esc_html($t['name']) . '</p>';
            $h .= '</div>';
        }
        $h .= '</div>';

        // Cluster links
        $cluster = $this->cluster_links();
        if (!empty($cluster)) {
            $h .= '<div style="background:#f5f7ff;border-radius:10px;padding:18px;margin:24px 0;">';
            $h .= '<p style="font-weight:bold;margin:0 0 10px;">🔗 خدمات ذات صلة</p><ul style="margin:0;padding-right:20px;">';
            foreach ($cluster as $cl) $h .= "<li style=\"margin:5px 0;\">{$cl}</li>";
            $h .= '</ul></div>';
        }

        $h .= '</section>';

        // ═══ AI SUMMARY ═══════════════════════════════════════════════════
        $h .= sprintf(
            '<div style="background:%s;border:2px solid %s;border-radius:12px;padding:20px;margin:30px 0;">'.
            '<h3 style="margin:0 0 10px;color:%s;">🤖 ملخص — للاقتباس المباشر</h3>'.
            '<p>%s</p><p>%s</p><p>%s</p></div>',
            $c['light'], $c['accent'], $c['primary'],
            $this->v->t("{svc} {city} خدمة تقنية متخصصة تُنجزها {brand} باستخدام أحدث الأجهزة وفريق مدرب لضمان حل جذري دائم بدون أضرار جانبية."),
            $this->v->t("تتميز الخدمة بالسرعة في الاستجابة، الشفافية الكاملة في التسعير، والضمان المكتوب على كل عملية في {city_bare}."),
            $this->v->t("اختر {brand} لأن فريقنا معتمد بخبرة تزيد على {exp} سنوات وأكثر من {reviews} عملية ناجحة في {city_bare}.")
        );

        // إضافة متغير wa_num و phone و whatsapp
        $h = str_replace(
            ['{wa_num}', '{phone}', '{whatsapp}', '{exp}'],
            [$wa, esc_html($this->phone), esc_html($this->whatsapp), $this->v->expert()['exp']],
            $h
        );

        return $h;
    }

    // ─────────────────────────────────────────────────────────────────────
    // HERO SECTION
    // ─────────────────────────────────────────────────────────────────────
    private function hero(string $title, array $c, string $wa): string {
        $suffix_pool = [
            "خدمة 24 ساعة + ضمان مكتوب",
            "وصول سريع + أسعار شفافة",
            "فريق معتمد + كشف مجاني",
            "تنفيذ احترافي + ضمان حقيقي",
            "استجابة فورية + جودة مضمونة",
        ];
        $badge_pool = [
            "⚡ وصول سريع • 🛡️ ضمان مكتوب • 💰 سعر شفاف • 📞 متاح 24/7",
            "🔍 كشف مجاني • 🛠️ فريق معتمد • ✅ ضمان • 🚀 طوارئ فورية",
            "⭐ خبرة +10 سنوات • 🔒 ضمان • 💬 واتساب • ⚡ استجابة سريعة",
        ];
        $suffix = $this->v->pick($suffix_pool, 20, true);
        $badge  = $this->v->pick($badge_pool, 21, true);

        $hero_p_pool = [
            "هل تبحث عن <strong>{$this->v->t('{svc}')}</strong> {$this->v->t('{city}')} موثوقة تصل بسرعة وتحل المشكلة نهائياً؟ <strong>{$this->brand}</strong> تقدم لك خدمة متكاملة بأحدث التقنيات، فريق مدرب، وضمان مكتوب على كل عملية.",
            "مشكلتك في {$this->v->t('{svc}')} {$this->v->t('{city}')} لا تنتظر. <strong>{$this->brand}</strong> تصل إليك في أي حي، بكامل معداتها، تُشخّص المشكلة بدقة، وتُنجز العمل بضمان مكتوب وسعر ثابت قبل البدء.",
            "تعامل مع الأفضل في <strong>{$this->v->t('{svc}')}</strong> {$this->v->t('{city}')} — <strong>{$this->brand}</strong> توفر لك فريقاً متخصصاً، أجهزة متطورة، وشفافية كاملة من لحظة الاتصال حتى تسليم الضمان.",
        ];
        $hero_p = $this->v->pick($hero_p_pool, 22, true);

        $h  = '<section style="margin-bottom:40px;">';
        $h .= sprintf(
            '<div style="background:linear-gradient(135deg,%s 0%%,%s 100%%);color:#fff;padding:32px;border-radius:16px;margin-bottom:24px;">',
            $c['primary'], $c['dark']
        );
        $h .= sprintf(
            '<h1 style="font-size:30px;font-weight:900;color:#fff;margin:0 0 8px;line-height:1.3;">%s</h1>'.
            '<p style="font-size:15px;font-weight:600;color:rgba(255,255,255,0.85);margin:0 0 16px;">%s</p>',
            esc_html($title . ' 2026'), esc_html($suffix)
        );
        // Direct answer
        $h .= sprintf(
            '<div style="background:rgba(255,255,255,0.13);border-radius:10px;padding:14px;margin-bottom:18px;">'.
            '<p style="margin:0;font-size:15px;line-height:1.85;color:#fff;">%s</p></div>',
            $hero_p
        );
        // Badges
        $h .= sprintf(
            '<div style="background:rgba(255,255,255,0.1);border-radius:8px;padding:12px;text-align:center;font-size:14px;font-weight:600;color:#fff;margin-bottom:18px;">%s</div>',
            esc_html($badge)
        );
        // [post_call] shortcode placeholder
        $h .= '<p style="text-align:center;font-size:20px;font-weight:900;margin:0;">[post_call]</p>';
        $h .= '</div></section>';
        return $h;
    }

    // ─────────────────────────────────────────────────────────────────────
    // HTML HELPERS
    // ─────────────────────────────────────────────────────────────────────
    private function h2(string $text, array $c): string {
        return sprintf(
            '<h2 style="font-size:23px;color:%s;font-weight:800;border-right:5px solid %s;padding-right:14px;margin:30px 0 14px;">%s</h2>',
            $c['primary'], $c['accent'], $text
        );
    }

    private function h3(string $text): string {
        return "<h3 style=\"font-size:17px;font-weight:700;margin:18px 0 8px;\">{$text}</h3>";
    }

    private function bq(string $type, string $text): string {
        $styles = [
            'warning' => 'background:#ffebee;border-left:5px solid #d32f2f;',
            'tip'     => "background:{$this->colors['light']};border-left:5px solid {$this->colors['accent']};",
            'offer'   => 'background:#e8f5e9;border-left:5px solid #2e7d32;',
            'stat'    => 'background:#fff8e1;border-left:5px solid #f9a825;',
        ];
        $icons = ['warning'=>'⚠️ ','tip'=>'💡 ','offer'=>'🎁 ','stat'=>'📊 '];
        $s = $styles[$type] ?? $styles['tip'];
        $i = $icons[$type] ?? '';
        return "<blockquote style=\"{$s}padding:14px 16px;margin:18px 0;line-height:1.8;\">{$i}{$this->v->t($text)}</blockquote>\n";
    }

    private function cta_box(int $variant, array $c, string $wa): string {
        $v = $this->v->cta($variant);
        return sprintf(
            '<div style="background:%s;border-radius:8px;padding:16px;margin:18px 0;text-align:center;">'.
            '<p style="margin:0 0 10px;font-weight:bold;color:%s;">%s</p>'.
            '<a href="tel:%s" style="background:%s;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;margin:4px;display:inline-block;font-weight:bold;">%s</a> '.
            '<a href="https://wa.me/%s" target="_blank" style="background:#25d366;color:#fff;padding:10px 22px;border-radius:7px;text-decoration:none;margin:4px;display:inline-block;font-weight:bold;">💬 واتساب</a>'.
            '</div>',
            $c['light'], $c['primary'], esc_html($v['pre']),
            esc_attr($this->phone), $c['primary'], esc_html($v['btn']),
            esc_attr($wa)
        );
    }

    private function inline_link(): string {
        // ابحث عن مقال ذات صلة في الموقع
        $posts = get_posts([
            'post_type'      => 'post',
            'post_status'    => ['publish','draft'],
            'posts_per_page' => 8,
            's'              => $this->v->city_bare(),
            'fields'         => 'ids',
        ]);
        if (empty($posts)) return '';
        $idx = $this->v->stat(0, count($posts)-1, 30);
        $id  = $posts[$idx % count($posts)];
        $url = get_permalink($id);
        $ttl = get_the_title($id);
        if (!$url || !$ttl) return '';
        return sprintf(
            '<p style="font-size:13px;">📎 اقرأ أيضاً: <a href="%s"><strong>%s</strong></a></p>',
            esc_url($url), esc_html($ttl)
        );
    }

    private function prices_table(array $c): string {
        $rows = $this->price_rows();
        $h  = '<div style="overflow-x:auto;-webkit-overflow-scrolling:touch;margin:18px 0;">';
        $h .= '<table border="1" style="width:100%;min-width:560px;border-collapse:collapse;text-align:right;direction:rtl;font-size:14px;">';
        $h .= sprintf('<tr style="background:%s;color:#fff;font-weight:bold;"><th style="padding:11px;">نوع الخدمة</th><th style="padding:11px;">الوصف</th><th style="padding:11px;">السعر التقريبي</th><th style="padding:11px;">المدة</th></tr>', $c['primary']);
        foreach ($rows as $i => $r) {
            $bg = $i%2 ? '#fff' : '#f8f8f8';
            $h .= sprintf('<tr style="background:%s;"><td style="padding:11px;">%s</td><td style="padding:11px;">%s</td><td style="padding:11px;font-weight:bold;color:%s;">%s</td><td style="padding:11px;">%s</td></tr>',
                $bg, esc_html($r[0]), esc_html($r[1]), $c['primary'], esc_html($r[2]), esc_html($r[3]));
        }
        $h .= '</table></div>';
        $h .= '<p style="font-size:12px;color:#888;"><em>* الأسعار تقريبية وتُحدد بدقة بعد الكشف المجاني.</em></p>';
        return $h;
    }

    private function comparison_table(array $c): string {
        $rows = [
            ['وقت الاستجابة',       '✅ خلال 45 دقيقة',        '⏳ ساعات أو أيام'],
            ['التشخيص المسبق',      '✅ دائماً بأجهزة متخصصة', '❌ نادراً'],
            ['الشفافية في السعر',   '✅ سعر ثابت قبل البدء',   '❌ مفاجآت في الفاتورة'],
            ['ضمان مكتوب',          '✅ على كل عملية',          '❌ شفهي أو غير موجود'],
            ['خدمة 24/7',           '✅ بما فيها الأعياد',      '⚠️ أوقات محدودة'],
            ['متابعة بعد الخدمة',  '✅ حتى اكتمال رضاك',       '❌ لا توجد'],
        ];
        $h  = '<div style="overflow-x:auto;-webkit-overflow-scrolling:touch;margin:18px 0;">';
        $h .= '<table border="1" style="width:100%;min-width:500px;border-collapse:collapse;text-align:right;direction:rtl;font-size:14px;">';
        $h .= sprintf('<tr style="background:%s;color:#fff;font-weight:bold;"><th style="padding:11px;">معيار المقارنة</th><th style="padding:11px;">🏆 %s</th><th style="padding:11px;">شركات أخرى</th></tr>', $c['primary'], esc_html($this->brand));
        foreach ($rows as $i => $r) {
            $bg = $i%2 ? '#fff' : '#f8f8f8';
            $h .= sprintf('<tr style="background:%s;"><td style="padding:11px;font-weight:bold;">%s</td><td style="padding:11px;color:#2e7d32;">%s</td><td style="padding:11px;color:#c62828;">%s</td></tr>', $bg, $r[0], $r[1], $r[2]);
        }
        $h .= '</table></div>';
        return $h;
    }

    // ─────────────────────────────────────────────────────────────────────
    // CONTENT POOLS — كل pool لها بديلان على الأقل
    // ─────────────────────────────────────────────────────────────────────

    private function intro_direct_answer(): string {
        $pool = [
            "{svc} {city} خدمة متخصصة تُقدّمها {brand} باستخدام أجهزة وتقنيات متطورة بهدف حل المشكلات بدقة عالية وضمان نتائج طويلة الأمد.",
            "{svc} {city} هي خدمة تقنية متكاملة تبدأ بالتشخيص الدقيق وتنتهي بحل جذري مضمون — كل ذلك على يد فريق {brand} المعتمد ذي الخبرة الواسعة في {city_bare}.",
            "نعم، {svc} {city} من {brand} تعني: فحص أولي مجاني، تشخيص دقيق، تنفيذ احترافي بأحدث التقنيات، وضمان مكتوب — كل ذلك بسعر ثابت محدد قبل البدء.",
        ];
        return $this->v->pick($pool, 40, true);
    }

    private function intro_p2(): string {
        $pool = [
            "أفضل طريقة للتعامل مع {svc} {city} هي الاتصال بفريق متخصص مثل {brand} يصل إليك بسرعة، يُشخّص المشكلة بدقة، ثم ينفذ الحل المناسب بضمان مكتوب.",
            "السبب الرئيسي لاختيار {brand} لـ {svc} {city} هو الجمع بين التشخيص الدقيق والتنفيذ الاحترافي والضمان الحقيقي — المعادلة التي تبحث عنها.",
            "الخطوة الأولى: تواصل مع {brand} الآن للحصول على معاينة مجانية وسعر ثابت قبل بدء أي عمل. لا مفاجآت ولا التزامات قبل موافقتك.",
        ];
        return $this->v->pick($pool, 41, true);
    }

    private function intro_bullets(): array {
        $all = [
            [
                $this->v->t("✅ {svc} {city} بأحدث الأجهزة والتقنيات المعتمدة"),
                "✅ فريق مدرب ومؤهل وفق أعلى المعايير المهنية",
                "✅ ضمان مكتوب حقيقي على جميع الأعمال",
                $this->v->t("✅ تغطية شاملة لجميع أحياء {city_bare} 24/7"),
                "✅ أسعار شفافة محددة قبل البدء — لا مفاجآت",
                $this->v->t("✅ وصول سريع خلال 45 دقيقة في معظم مناطق {city_bare}"),
            ],
            [
                "✅ كشف ومعاينة مجانية قبل أي التزام",
                $this->v->t("✅ تنفيذ {svc} بدون أضرار جانبية أو تكسير"),
                "✅ فريق مرخص ومؤمن بأعلى معايير السلامة",
                $this->v->t("✅ خبرة ميدانية تزيد على {exp} سنوات في المنطقة"),
                "✅ استخدام مواد وأجهزة آمنة ومعتمدة دولياً",
                "✅ متابعة كاملة بعد الخدمة لضمان رضاك التام",
            ],
        ];
        $res = $this->v->pick($all, 42, true);
        return array_map(fn($b) => str_replace('{exp}', (string)$this->v->expert()['exp'], $b), $res);
    }

    private function intro_tip(): string {
        $pool = [
            "نصيحة الخبير: تعامل دائماً مع شركة معتمدة تمتلك فريقاً مدرباً وضماناً مكتوباً على أعمالها. الاختيار الصحيح من البداية يوفّر عليك الوقت والمال والأعصاب.",
            "الفرق الجوهري في {svc} {city}: الشركة المحترفة تُشخّص أولاً، تُقدّم سعراً ثابتاً، ثم تُنفّذ بضمان — وهذا تحديداً ما يُفرّق {brand} عن سواها.",
            "خبراء {brand}: قبل أي قرار، اطلب كشفاً مجانياً، احصل على سعر مكتوب، وتأكد من وجود ضمان حقيقي. هذه الثلاثية هي حمايتك الحقيقية كعميل.",
        ];
        return $this->v->pick($pool, 43, true);
    }

    private function symptoms_intro(): string {
        $pool = [
            "كثير من سكان {city_bare} يتجاهلون العلامات الأولى حتى تتفاقم المشكلة وتتضاعف التكلفة. فريق {brand} رصد هذه المؤشرات التي يجب أن تأخذها بجدية:",
            "خبراء {brand} في {city_bare} يُحذّرون من هذه العلامات التي تظهر قبل أن تتحول المشكلة إلى أزمة كاملة:",
            "متى تطلب {svc} {city} فوراً؟ هذه المؤشرات لا تحتمل التأجيل وفق التجربة الميدانية لفريق {brand}:",
        ];
        return $this->v->pick($pool, 44, true);
    }

    private function symptoms_list(): array {
        $all = [
            [
                "<strong>🔍 تغيّر ملحوظ في الأداء الطبيعي:</strong><br>أي انحراف عن الوضع المعتاد — حتى البسيط — هو أول مؤشر يجب أخذه بجدية. في هذه المرحلة المبكرة يكون الحل أسرع وأقل تكلفة.",
                "<strong>🌡️ مؤشرات حسية غير طبيعية:</strong><br>تغيّرات مرئية أو حسية مصاحبة للمشكلة تُشير إلى تطور يتطلب تقييماً احترافياً فورياً.",
                "<strong>🔄 تكرار المشكلة رغم المحاولات السابقة:</strong><br>التكرار علامة واضحة على أن السبب الجذري لم يُعالَج. الحل المؤقت ليس حلاً.",
                "<strong>📈 تصاعد حجم المشكلة مع الوقت:</strong><br>أي مشكلة تتطور بدلاً من أن تستقر تحتاج تدخلاً فورياً قبل الوصول للمرحلة الحرجة.",
                "<strong>🏠 تأثير مباشر على راحة السكان:</strong><br>حين تبدأ المشكلة بالتأثير على الروتين اليومي، يصبح التدخل ضرورة وليس خياراً.",
                "<strong>⚠️ ظهور أضرار مصاحبة:</strong><br>أضرار إضافية ناجمة عن المشكلة الأصلية تعني أن الوضع تجاوز مرحلة الإصلاح البسيط.",
                "<strong>🏚️ تقادم المبنى أو المعدات:</strong><br>المباني التي تجاوزت 15 عاماً في {city_bare} أكثر عرضة لهذه المشكلات وتستحق فحصاً دورياً منتظماً.",
                "<strong>💰 ارتفاع غير مبرر في التكاليف:</strong><br>زيادة في الفواتير أو النفقات دون مبرر واضح تستدعي مراجعة دقيقة من متخصص.",
            ],
            [
                "<strong>⚡ بطء أو ضعف في الأداء:</strong><br>يُشير إلى تراكم سيتحول قريباً لانسداد كامل. هذه أفضل مرحلة للتدخل بأقل تكلفة ممكنة.",
                "<strong>🫧 مؤشرات في المناطق المجاورة:</strong><br>ظهور مشكلة في مناطق مجاورة يُشير لمصدر مشترك يستوجب فحصاً شاملاً.",
                "<strong>🦠 علامات صحية أو بيئية:</strong><br>أي تأثير على صحة السكان أو جودة البيئة المحيطة يتطلب تدخلاً فورياً لا تأجيل فيه.",
                "<strong>💦 رطوبة أو آثار سوائل:</strong><br>الرطوبة في غير مكانها علامة على ضغط زائد أو تسريب يحتاج معالجة من المصدر مباشرة.",
                "<strong>🪲 ظهور حشرات أو آفات:</strong><br>الحشرات تتجمع حيث توجد تراكمات — الحل الجذري هو إزالة المصدر وليس الرش السطحي فقط.",
                "<strong>🔊 أصوات أو ظواهر غير اعتيادية:</strong><br>أي صوت أو ظاهرة جديدة غير مألوفة تعني اختلالاً في التوازن يستحق الفحص الفوري.",
                "<strong>🌊 تجمع سوائل في أماكن غير معتادة:</strong><br>تجمع أي سائل خارج نطاقه الطبيعي علامة على خلل في المنظومة يحتاج إصلاحاً جذرياً.",
                "<strong>📉 انخفاض ملحوظ في الكفاءة:</strong><br>أداء أقل من المعتاد لأي منظومة يعني فقداناً في الكفاءة سينعكس على التكاليف والجودة.",
            ],
        ];
        return $this->v->pick($all, 45, true);
    }

    private function symptoms_warning(): string {
        $pool = [
            "⚠️ <strong>تحذير عاجل:</strong> تجاهل العلامات المبكرة يضاعف تكلفة الحل ويُحوّل مشكلة بسيطة إلى أزمة مكلفة. التدخل المبكر دائماً الخيار الأذكى.",
            "⚠️ <strong>انتبه:</strong> ما يُصلَح اليوم بتكلفة بسيطة قد يحتاج غداً لميزانية أكبر بكثير. لا تؤجّل {svc} {city} إذا ظهرت أي من هذه العلامات.",
            "⚠️ <strong>لا تتهاون:</strong> كل أسبوع تأخير في معالجة هذه المؤشرات يُضاعف حجم المشكلة في {city_bare}. التحرك الفوري الآن يوفّر عليك الكثير لاحقاً.",
        ];
        return $this->v->pick($pool, 46, true);
    }

    private function symptoms_stat(): string {
        $pct = $this->v->stat(60, 78, 22);
        $pool = [
            "📊 <strong>من السجلات الميدانية:</strong> {$pct}% من حالات {svc} {city} الحرجة التي عالجها فريق {brand} كانت مسبوقة بمؤشرات مبكرة أُهملت لفترة.",
            "📊 <strong>إحصائية مهمة:</strong> أكثر من {$pct}% من طلبات الطوارئ في {city_bare} كان يمكن تجنّبها بتدخل مبكر عند ظهور أول علامة تحذيرية.",
        ];
        return $this->v->pick($pool, 47, true);
    }

    private function causes_intro(): string {
        $pool = [
            "يتم ذلك عن طريق فحص احترافي شامل يجريه فريق {brand} بأجهزة متطورة لتحديد السبب الجذري وليس فقط معالجة الأعراض الظاهرة.",
            "السبب الرئيسي لتكرار مشكلات {svc} {city} هو التعامل مع الأعراض بدلاً من الجذور. {brand} تعتمد التشخيص الكامل أولاً وقبل أي تنفيذ.",
            "الفرق بين حل يدوم وحل مؤقت يبدأ من هنا — الأسباب الحقيقية لـ {svc} {city} التي يُشخّصها خبراء {brand} بدقة:",
        ];
        return $this->v->pick($pool, 48, true);
    }

    private function causes_list(): array {
        $all = [
            [
                ['title'=>"أولاً: الاستخدام المكثف وتراكم الرواسب",
                 'body' =>$this->v->t("الضغط اليومي المتراكم على أي نظام في {city_bare} يؤدي لتراكمات تدريجية صامتة تُحوّل المشكلة البسيطة لأزمة إذا أُهملت.")],
                ['title'=>"ثانياً: أخطاء التركيب أو الصيانة السابقة",
                 'body' =>$this->v->t("كثير من حالات {svc} {city} التي يعالجها فريق {brand} مصدرها أخطاء تقنية في التركيب أو الصيانة الأولى ظهرت بعد سنوات.")],
                ['title'=>"ثالثاً: تأثير المناخ والبيئة",
                 'body' =>$this->v->t("مناخ {city_bare} وطبيعة البيئة المحيطة تُسرّع تدهور المواد والأنظمة — عامل يُهمله كثيرون عند التخطيط للصيانة.")],
                ['title'=>"رابعاً: إهمال الصيانة الوقائية الدورية",
                 'body' =>$this->v->t("الصيانة المنتظمة هي الحاجز الوقائي الأساسي. {brand} تُقدّم برامج دورية في {city_bare} بأسعار مناسبة تمنع الأزمات الكبيرة.")],
                ['title'=>"خامساً: عوامل خارجية وبنية تحتية",
                 'body' =>$this->v->t("التغيرات في البنية التحتية المحيطة بـ{city_bare} تُؤثر بشكل مباشر على أداء الأنظمة الداخلية — خاصةً في المباني القديمة.")],
            ],
            [
                ['title'=>"أولاً: التقادم الطبيعي للمكونات",
                 'body' =>$this->v->t("كل مكوّن له عمر افتراضي. المباني التي تجاوزت 15 عاماً في {city_bare} تحتاج مراجعة دورية لتقييم حالة مكوناتها وتحديد ما يحتاج استبدالاً.")],
                ['title'=>"ثانياً: الاعتماد على عمالة غير متخصصة",
                 'body' =>$this->v->t("قرار التوفير بالتعامل مع غير المتخصصين في {svc} {city} يُكلّف في الغالب أضعاف ما وفّره صاحب المقام — تجربة يرويها كثير من عملاء {brand}.")],
                ['title'=>"ثالثاً: استخدام مواد أو منتجات غير مناسبة",
                 'body' =>$this->v->t("المواد الرديئة أو غير الملائمة تُحدث أضراراً تراكمية بطيئة لا تظهر فوراً لكنها تنفجر في أسوأ الأوقات.")],
                ['title'=>"رابعاً: زيادة الضغط على الطاقة التصميمية",
                 'body' =>$this->v->t("توسع المبنى أو زيادة عدد المستخدمين دون مراجعة الطاقة الاستيعابية للأنظمة يُفضي لضغط يتجاوز حدود التصميم الأصلي.")],
                ['title'=>"خامساً: التأخر في الاستجابة للمؤشرات الأولى",
                 'body' =>$this->v->t("تجاهل الإشارات التحذيرية المبكرة — حتى البسيطة منها — يُعطي المشكلة فرصة للتوسع والتعمق بشكل يجعل الحل أكثر تعقيداً وتكلفةً.")],
            ],
        ];
        return $this->v->pick($all, 49, true);
    }

    private function causes_tip(): string {
        $pool = [
            "💡 كيف يعمل فريق {brand}؟ في ثلاث مراحل: الفحص البصري الشامل → الفحص بالأجهزة التشخيصية → اختيار الحل الأنسب. هذا المنهج يضمن حلاً جذرياً لا مؤقتاً.",
            "💡 منهج التشخيص المتقدم: {brand} لا تُنفّذ قبل الفهم الكامل. التشخيص المبني على البيانات لا على التخمين هو سر نجاح فريقنا في {city_bare}.",
            "💡 إذا تكررت المشكلة في {svc} {city}، فهذا يعني أن السبب الجذري لم يُعالَج بعد. الحل الصحيح يبدأ بتشخيص شامل بالأجهزة المتخصصة.",
        ];
        return $this->v->pick($pool, 50, true);
    }

    private function solutions_intro(): string {
        $pool = [
            "أفضل طريقة هي الاعتماد على شركة معتمدة مثل {brand} تتبع منهجية عمل واضحة تضمن نتائج طويلة الأمد في {city_bare}.",
            "فريق {brand} يُنجز {svc} {city} وفق منهجية متكاملة مجرّبة — من أول اتصال حتى تسليم الضمان:",
            "الطريقة الصحيحة الوحيدة لـ {svc} {city} تبدأ من التشخيص وليس من التنفيذ. إليك المنهجية الكاملة:",
        ];
        return $this->v->pick($pool, 51, true);
    }

    private function solutions_steps(): array {
        $all = [
            [
                ['title'=>"الاستقبال وتحديد الموعد",       'body'=>$this->v->t("التواصل مع {brand} وتحديد أقرب موعد مناسب في {city_bare}. الفريق يُرسل إشعاراً قبل الوصول.")],
                ['title'=>"المعاينة والتشخيص الأولي",      'body'=>$this->v->t("وصول الفريق المتخصص وإجراء فحص شامل بالأجهزة لتحديد المشكلة بدقة.")],
                ['title'=>"عرض الحل والسعر",               'body'=>$this->v->t("تقديم تقرير فني واضح وعرض سعر محدد مسبقاً. لا يبدأ أي عمل قبل موافقتك الكاملة.")],
                ['title'=>"التنفيذ الاحترافي",             'body'=>$this->v->t("تنفيذ {svc_core} بأحدث الأجهزة والمواد المعتمدة مع الحفاظ على نظافة وسلامة المكان.")],
                ['title'=>"الفحص النهائي والاختبار",       'body'=>$this->v->t("التأكد العملي من جودة العمل وتحقق النتائج المطلوبة قبل اعتبار العمل مكتملاً.")],
                ['title'=>"التسليم والضمان والمتابعة",     'body'=>$this->v->t("تسليم وثيقة الضمان المكتوبة مع تقرير العمل ونصائح الوقاية المستقبلية.")],
            ],
            [
                ['title'=>"التشخيص الشامل بالأجهزة",      'body'=>$this->v->t("قبل أي تنفيذ، يجري الفريق تشخيصاً كاملاً لتحديد طبيعة المشكلة وحجمها الفعلي في {city_bare}.")],
                ['title'=>"تقديم الحلول والخيارات",        'body'=>$this->v->t("عرض الحلول المتاحة بأسعارها الدقيقة وإيجابيات وسلبيات كل خيار لمساعدتك في الاختيار الأفضل.")],
                ['title'=>"تنفيذ الحل المختار",            'body'=>$this->v->t("تنفيذ {svc_core} بالمعايير الاحترافية الكاملة باستخدام أفضل الأجهزة والمواد المتاحة.")],
                ['title'=>"ضبط الجودة والمراجعة",         'body'=>$this->v->t("مراجعة دقيقة للنتائج والتأكد من مطابقتها للمعايير المطلوبة قبل التسليم النهائي.")],
                ['title'=>"توثيق العمل وإصدار الضمان",   'body'=>$this->v->t("إصدار وثيقة ضمان مكتوبة مع توثيق كامل لجميع الأعمال المنجزة وتواريخها.")],
            ],
        ];
        return $this->v->pick($all, 52, true);
    }

    private function solutions_warning(): string {
        $pool = [
            "⚠️ <strong>تحذير:</strong> الحلول المؤقتة لـ {svc} {city} لا تُزيل المشكلة من جذورها — تُحرّكها فقط حتى تعود أشد وأكثر تكلفةً. الحل الجذري الوحيد هو التنفيذ الاحترافي المضمون.",
            "⚠️ المنتجات الجاهزة والحلول الذاتية لـ {svc} {city} قد تُحدث أضراراً إضافية إذا استُخدمت بطريقة خاطئة. دائماً استشر متخصصاً قبل أي تدخل.",
        ];
        return $this->v->pick($pool, 53, true);
    }

    private function mistakes_intro(): string {
        $pool = [
            "من الخبرة الميدانية لفريق {brand} في {city_bare}، هذه هي الأخطاء الأكثر تكراراً والأغلى ثمناً عند التعامل مع {svc} {city}:",
            "ما يزيد من تكلفة {svc} {city} ليس المشكلة نفسها — بل هذه الأخطاء التي يقع فيها كثيرون قبل وأثناء طلب الخدمة:",
            "احذر هذه الأخطاء التي تُحوّل {svc} {city} من حل سريع بسيط إلى معاناة طويلة ومكلفة:",
        ];
        return $this->v->pick($pool, 54, true);
    }

    private function mistakes_list(): array {
        $all = [
            [
                $this->v->t("<strong>❌ التأخر في طلب {svc} {city}</strong> — أملاً في تحسّن تلقائي لن يحدث. كل يوم تأخير يُضاعف التكلفة والضرر."),
                "<strong>❌ اختيار الأرخص دون التحقق من الاحترافية</strong> — التوفير الآن يعني في الغالب إنفاقاً أضعافه لاحقاً.",
                "<strong>❌ إهمال الصيانة الوقائية الدورية</strong> — الانتظار حتى تتفاقم المشكلة لمستوى الأزمة يُضاعف الضرر والتكلفة.",
                $this->v->t("<strong>❌ عدم التحقق من ترخيص الشركة وضمانها</strong> — الشركة التي لا تُقدّم ضماناً مكتوباً لا تثق هي نفسها بجودة عملها."),
                "<strong>❌ قبول سعر دون معاينة مسبقة</strong> — السعر الحقيقي لا يُحدَّد إلا بعد الفحص الفعلي للمشكلة وحجمها.",
                "<strong>❌ الاعتماد على حلول مؤقتة متكررة</strong> — كل حل مؤقت يُحرّك المشكلة ويُضاعف تعقيدها عند العودة.",
            ],
            [
                $this->v->t("<strong>❌ تجاهل المؤشرات المبكرة</strong> — ظناً بأنها مؤقتة ستختفي وحدها. في {svc} {city} المؤشرات المبكرة نادراً ما تختفي دون تدخل."),
                "<strong>❌ محاولة الإصلاح الذاتي بدون خبرة</strong> — هذا النهج يُعقّد المشكلة في أغلب الأحيان ويرفع تكلفة الحل الاحترافي لاحقاً.",
                "<strong>❌ عدم طلب تقرير مكتوب أو ضمان</strong> — الوعد الشفهي لا قيمة قانونية له. الضمان المكتوب هو حمايتك الحقيقية كعميل.",
                "<strong>❌ الإصلاح الجزئي المتكرر</strong> بدلاً من الحل الشامل الذي يُنهي المشكلة من جذورها نهائياً.",
                "<strong>❌ التأخر في حالات الطوارئ</strong> — فريقنا متاح 24/7 لهذا السبب تحديداً. التدخل الفوري دائماً أفضل من الانتظار.",
                $this->v->t("<strong>❌ عدم المقارنة بين العروض المتاحة</strong> — خذ وقتك في المقارنة بين الشركات المتخصصة في {svc} {city} قبل الاختيار."),
            ],
        ];
        return $this->v->pick($all, 55, true);
    }

    private function mistakes_stat(): string {
        $pct = $this->v->stat(60, 78, 32);
        $pool = [
            "📊 <strong>من سجلات {brand}:</strong> {$pct}% من حالات {svc} {city} الحرجة التي عالجناها كانت مسبوقة بمحاولة إصلاح ذاتي أو عمالة غير متخصصة.",
            "📊 <strong>إحصائية مهمة:</strong> {$pct}% من مشكلات {svc} {city} المكلفة كانت تُكلّف أقل بكثير لو جرى التدخل المبكر عند ظهور أول مؤشر.",
        ];
        return $this->v->pick($pool, 56, true);
    }

    private function tips_list(): array {
        return [
            $this->v->t("جدوِل {svc_core} دورياً كل 6 إلى 12 شهراً مع {brand} في {city_bare}"),
            $this->v->t("احتفظ بسجل صيانة موثّق لمنزلك أو مقرك — يُقلّل التكاليف ويُسهّل الفحص المستقبلي"),
            "تعامل مع شركات معتمدة فقط — تأكد دائماً من ترخيص رسمي وضمان مكتوب",
            $this->v->t("لا تؤجّل التدخل عند ظهور أي من المؤشرات التحذيرية السابقة"),
            $this->v->t("اسأل عن برنامج الصيانة الوقائية السنوي مع {brand} — يوفّر عليك أكثر مما تتوقع في {city_bare}"),
        ];
    }

    private function prices_intro(): string {
        $pmin = $this->v->stat(80, 200, 5);
        $pool = [
            "السعر يبدأ من {$pmin} للحالات البسيطة ويتفاوت حسب الحجم والنوع. {brand} تُقدّم معاينة مجانية وسعراً ثابتاً قبل البدء — لا مفاجآت في {city_bare}:",
            "{brand} تُقدّم منظومة متكاملة من {svc} {city} بأسعار شفافة ومنافسة تبدأ من {$pmin} وتشمل جميع أنواع المشاريع:",
            "الأسعار الحقيقية لـ {svc} {city} من {brand} — شفافية كاملة قبل البدء، لا أرقام مخفية:",
        ];
        return $this->v->pick($pool, 57, true);
    }

    private function why_us(): array {
        return [
            ['title'=>'وصول خلال 45 دقيقة',         'body'=>$this->v->t("في جميع مناطق {city_bare} على مدار الساعة")],
            ['title'=>'تنفيذ بدون أضرار جانبية',     'body'=>'تقنيات حديثة تحافظ على مبناك وأثاثك'],
            ['title'=>'كشف ومعاينة مجانية',          'body'=>'تشخيص دقيق قبل أي التزام أو دفع'],
            ['title'=>'ضمان مكتوب',                  'body'=>'على كل عملية بدون شروط أو استثناءات'],
            ['title'=>$this->v->t('+{reviews} عملية ناجحة'), 'body'=>$this->v->t("في {city_bare} وضواحيها")],
            ['title'=>'فريق مرخّص ومؤمّن',           'body'=>'بأعلى معايير السلامة المهنية'],
            ['title'=>'خدمة طوارئ 24/7',             'body'=>'بما فيها الأعياد والعطل الرسمية'],
        ];
    }

    private function price_rows(): array {
        $pmin = $this->v->stat(80, 200, 5);
        $svc  = $this->v->svc_core();
        return [
            ["{$svc} — مساحة صغيرة",    "حتى 80 م²",      "{$pmin}–".($pmin+120)." / الساعة أو القطعة", "1–2 ساعة"],
            ["{$svc} — مساحة متوسطة",   "80–200 م²",       ($pmin+120)."–".($pmin+300)." شامل",          "2–4 ساعات"],
            ["{$svc} — مساحة كبيرة",    "200–400 م²",      ($pmin+300)."–".($pmin+600)." شامل",          "4–6 ساعات"],
            ["{$svc} — مشاريع كبرى",    "400 م² فأكثر",    "يُحدد بعد المعاينة",                         "حسب الحجم"],
            ["{$svc} — طارئ وسريع",     "خدمة 24/7",       ($pmin+80)."–".($pmin+200)." إضافي",           "45 دقيقة+"],
            ["{$svc} — عقد سنوي",       "زيارات دورية",    "خصم 20% على السعر العادي",                    "حسب العقد"],
        ];
    }

    private function cta_body(): string {
        $pool = [
            "لا تدع المشكلة تنتظر. فريق {brand} جاهز الآن للوصول إليك في أي مكان في {city_bare} — معاينة مجانية، سعر ثابت، وضمان مكتوب.",
            "اتخذ قرارك الصحيح اليوم — {brand} هي الخيار الأول لـ {svc} {city} لأننا نُقدّم ما لا يُقدّمه غيرنا: الشفافية الكاملة والجودة المضمونة.",
            "وقت التصرف الآن. تواصل مع {brand} للحصول على أفضل {svc} {city} — استجابة سريعة، فريق محترف، ونتيجة تُسعدك.",
        ];
        return $this->v->pick($pool, 58, true);
    }

    private function cluster_links(): array {
        // ابحث عن مقالات ذات صلة موجودة فعلاً
        $related = get_posts([
            'post_type'      => 'post',
            'post_status'    => ['publish','draft'],
            'posts_per_page' => 5,
            's'              => $this->v->city_bare(),
            'fields'         => 'ids',
        ]);
        if (empty($related)) return [];
        $links = [];
        foreach ($related as $id) {
            $url = get_permalink($id);
            $ttl = get_the_title($id);
            if ($url && $ttl) {
                $links[] = sprintf('<a href="%s">%s</a>', esc_url($url), esc_html($ttl));
            }
        }
        return $links;
    }

    // ─────────────────────────────────────────────────────────────────────
    // FAQ — pool ضخم بالتناوب
    // ─────────────────────────────────────────────────────────────────────
    private function build_faqs(): array {
        $sv  = $this->v->t('{svc}');
        $c   = $this->v->t('{city}');
        $br  = $this->brand;
        $ph  = $this->phone;
        $cb  = $this->v->city_bare();
        $sc  = $this->v->svc_core();
        $h1  = $this->hoods[0];
        $h2  = $this->hoods[1];
        $h3  = $this->hoods[2];
        $pm  = $this->v->stat(80, 200, 5);
        $px  = $this->v->stat(400, 1200, 6);
        $exp = $this->v->expert()['exp'];
        $rev = $this->v->stat(1500, 8000, 1);

        $pool_a = [
            ['q'=>"ما هي {$sv} {$c}؟",
             'a'=>"{$sv} {$c} خدمة متخصصة تُقدّمها {$br} باستخدام أجهزة وتقنيات حديثة لحل المشكلات بدقة وكفاءة مع ضمان نتائج دائمة وطويلة الأمد في جميع أحياء {$cb}."],
            ['q'=>"كم سعر {$sv} {$c}؟",
             'a'=>"السعر يبدأ من {$pm} للحالات البسيطة ويصل لـ{$px} للحالات المعقدة. {$br} تُقدّم كشفاً مجانياً وسعراً محدداً قبل البدء — لا مفاجآت في الفاتورة."],
            ['q'=>"كيف تتم {$sv} {$c} خطوة بخطوة؟",
             'a'=>"يتم ذلك عبر: فحص أولي شامل بالأجهزة، عرض سعر ثابت، موافقة العميل، التنفيذ الاحترافي، فحص نهائي للجودة، ثم تسليم الضمان المكتوب."],
            ['q'=>"هل {$br} تخدم {$h1} و{$h2} في {$cb}؟",
             'a'=>"نعم، {$br} تغطي جميع أحياء {$cb} بدون استثناء بما فيها {$h1}، {$h2}، {$h3} وكل المناطق الأخرى مع ضمان الوصول السريع."],
            ['q'=>"هل يوجد ضمان على {$sv} {$c}؟",
             'a'=>"نعم، {$br} تُقدّم ضماناً مكتوباً على جميع أعمال {$sc}. أي تكرار للمشكلة خلال فترة الضمان يُعالَج مجاناً بدون أي شروط."],
            ['q'=>"لماذا تتكرر مشكلات {$sc} بعد الإصلاح؟",
             'a'=>"السبب الرئيسي هو معالجة الأعراض دون الوصول للسبب الجذري. {$br} تعتمد التشخيص الكامل بالأجهزة قبل أي تنفيذ لضمان حل جذري دائم."],
            ['q'=>"ما الفرق بين {$br} وشركات {$sc} الأخرى في {$cb}؟",
             'a'=>"الفرق الرئيسي: التشخيص قبل التنفيذ، الأجهزة الحديثة، الشفافية الكاملة في التسعير، والضمان المكتوب الحقيقي — ما لا تجده في معظم المنافسين."],
            ['q'=>"كم المدة الزمنية لـ{$sv} {$c}؟",
             'a'=>"المدة المتوقعة من 1 إلى 4 ساعات للحالات المتوسطة. تُحدَّد المدة الفعلية بعد المعاينة الأولية وتقييم حجم ونوع المطلوب."],
            ['q'=>"هل يمكن حجز {$sv} {$c} في نفس اليوم؟",
             'a'=>"نعم، {$br} تُتيح الحجز في اليوم ذاته عند توفر المواعيد في {$cb}. تواصل الآن على {$ph} أو واتساب للتأكيد الفوري."],
            ['q'=>"ما أحدث تقنيات {$sc} في {$cb} 2026؟",
             'a'=>"أفضل طريقة هي استخدام الأجهزة الرقمية الحديثة وتقنيات التشخيص الدقيق التي تُنجز العمل بدون أضرار جانبية — وهو ما يُميّز {$br} في {$cb}."],
        ];

        $pool_b = [
            ['q'=>"لماذا أختار {$br} لـ{$sv} {$c}؟",
             'a'=>"أفضل طريقة هي اختيار شركة تجمع الخبرة والأجهزة الحديثة والضمان الحقيقي. {$br} بخبرة {$exp} سنوات وأكثر من {$rev} عملية ناجحة في {$cb} تُقدّم هذه المعادلة الكاملة."],
            ['q'=>"لماذا أحتاج {$sv} {$c}؟",
             'a'=>"السبب الرئيسي هو حماية استثمارك ومنع تفاقم المشكلة. التدخل المبكر يوفّر عليك تكاليف أضعاف ما ستدفعه لو انتظرت."],
            ['q'=>"هل {$sv} {$c} من {$br} تتم بدون أضرار؟",
             'a'=>"نعم، {$br} تُنفّذ {$sc} في {$cb} بأحدث التقنيات التي تُنجز العمل بدون تكسير أو أضرار جانبية في الغالب الأعظم من الحالات."],
            ['q'=>"كيف أختار أفضل شركة {$sc} في {$cb}؟",
             'a'=>"الخطوة الأولى: تأكد من ترخيص رسمي، ضمان مكتوب، وسجل حقيقي من العملاء السابقين. {$br} تُلبّي هذه المعايير الثلاثة في {$cb}."],
            ['q'=>"هل أسعار {$sv} {$c} تشمل الكشف المجاني؟",
             'a'=>"نعم، {$br} تُقدّم الكشف الأولي والتشخيص مجاناً قبل تحديد أي سعر. لا مصاريف مخفية ولا التزامات قبل موافقتك الصريحة."],
            ['q'=>"متى يجب الاتصال بـ{$br} فوراً؟",
             'a'=>"يجب التواصل فوراً عند ظهور أي من المؤشرات التحذيرية المذكورة في هذا المقال. التدخل المبكر أقل تكلفةً وأسرع حلاً دائماً."],
            ['q'=>"هل تقدمون عقود صيانة دورية في {$cb}؟",
             'a'=>"نعم، {$br} تُقدّم برامج صيانة دورية لـ{$sc} في {$cb} بأسعار سنوية مناسبة تشمل زيارات منتظمة وأولوية في الطوارئ."],
            ['q'=>"كيف أتواصل مع {$br} لـ{$sv} {$c}؟",
             'a'=>"يمكنك التواصل عبر الهاتف على {$ph} أو عبر واتساب للرد الفوري. الفريق متاح 24/7 بما فيها الأعياد والعطل الرسمية في {$cb}."],
            ['q'=>"هل يخدم فريق {$br} المنشآت التجارية في {$cb}؟",
             'a'=>"نعم، {$br} تُقدّم {$sc} للمنازل والفلل والشقق والمكاتب والمحال والمنشآت الصناعية في جميع مناطق {$cb}."],
            ['q'=>"ما مميزات {$sv} {$c} من {$br} مقارنةً بالمنافسين؟",
             'a'=>"الفرق الرئيسي هو: التشخيص قبل التنفيذ، فريق معتمد بخبرة حقيقية، أسعار شفافة ثابتة، وضمان مكتوب حقيقي — لا وعود شفهية."],
        ];

        // اختر pool بناءً على tseed
        $base_pool = $this->v->pick([$pool_a, $pool_b], 60, true);

        // اخلط الأسئلة
        $keys = range(0, count($base_pool)-1);
        $seed_val = $this->v->stat(0, 999, 61);
        usort($keys, fn($a,$b)=>(($seed_val+$a*7)%count($base_pool))<=>( ($seed_val+$b*7)%count($base_pool)));

        return array_map(fn($k)=>$base_pool[$k], $keys);
    }
}

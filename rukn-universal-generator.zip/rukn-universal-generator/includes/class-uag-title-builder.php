<?php
defined('ABSPATH') || exit;

/**
 * UAG_Title_Builder
 * ─────────────────
 * يبني عنوان المقال بالضبط كما أدخله المستخدم.
 *
 * قواعد العنوان:
 *  - الخدمة تُكتب كما هي (المستخدم يتحكم)
 *  - المدينة تُكتب كما هي (المستخدم يتحكم)
 *  - الربط بينهما: فراغ فقط (بدون إضافة "في" أو "بـ")
 *    لأن المستخدم قد يكتب:
 *      "في دبي"  → تُكتب "في دبي" كما هي
 *      "دبي"     → تُكتب "دبي" كما هي
 *      "بدبي"    → تُكتب "بدبي" كما هي
 *
 * مثال:
 *  service="شركة كشف تسربات" + city="في دبي"  → "شركة كشف تسربات في دبي"
 *  service="كشف تسربات"      + city="دبي"      → "كشف تسربات دبي"
 *  service="كشف تسربات"      + city="في دبي"   → "كشف تسربات في دبي"
 *
 * الـ SLUG يُبنى دائماً بالإنجليزية بغض النظر عن الإدخال.
 */
class UAG_Title_Builder {

    // ── Service slug map ──────────────────────────────────────────────────
    private static array $service_map = [
        // صيانة وسباكة
        'تسليك مجاري'              => 'sewer-cleaning',
        'تسليك بالوعة'             => 'drain-unblocking',
        'شفط بيارات'               => 'septic-tank-pumping',
        'كشف تسربات المياه'        => 'water-leak-detection',
        'كشف تسربات'               => 'leak-detection',
        'عزل أسطح'                 => 'roof-waterproofing',
        'عزل خزانات'               => 'tank-waterproofing',
        'عزل حمامات'               => 'bathroom-waterproofing',
        'صيانة منازل'              => 'home-maintenance',
        'صيانة مكيفات'             => 'ac-maintenance',
        'صيانة سباكة'              => 'plumbing-maintenance',
        'تركيب مكيفات'             => 'ac-installation',
        'سباكة'                    => 'plumbing',
        'كهرباء'                   => 'electrical',
        'تمديدات كهربائية'         => 'electrical-installation',
        'نجارة'                    => 'carpentry',
        'دهانات'                   => 'painting',
        'دهان منازل'               => 'house-painting',
        // تنظيف
        'تنظيف منازل'              => 'house-cleaning',
        'تنظيف شقق'                => 'apartment-cleaning',
        'تنظيف فلل'                => 'villa-cleaning',
        'تنظيف كنب'                => 'sofa-cleaning',
        'تنظيف موكيت'              => 'carpet-cleaning',
        'تنظيف سجاد'               => 'rug-cleaning',
        'تنظيف مجالس'              => 'majlis-cleaning',
        'تنظيف مطابخ'              => 'kitchen-cleaning',
        'تنظيف خزانات'             => 'tank-cleaning',
        'تنظيف مسابح'              => 'pool-cleaning',
        'تنظيف مكيفات'             => 'ac-cleaning',
        'تنظيف واجهات'             => 'facade-cleaning',
        'تنظيف بعد البناء'         => 'post-construction-cleaning',
        'خدمات تنظيف'              => 'cleaning-services',
        'شركة تنظيف'               => 'cleaning-company',
        'عاملات تنظيف'             => 'cleaning-workers',
        'عمالة تنظيف'              => 'cleaning-staff',
        // مكافحة حشرات
        'مكافحة حشرات'             => 'pest-control',
        'مكافحة النمل الأبيض'      => 'termite-control',
        'مكافحة الفئران'           => 'rodent-control',
        'رش مبيدات'                => 'pesticide-spraying',
        // نقل
        'نقل أثاث'                 => 'furniture-moving',
        'نقل عفش'                  => 'moving-services',
        'تغليف أثاث'               => 'furniture-packing',
        // استقدام / عمالة
        'استقدام عمالة'            => 'worker-recruitment',
        'استقدام عاملات'           => 'housemaid-recruitment',
        'استقدام خادمات'           => 'domestic-worker-recruitment',
        'خادمات منزل'              => 'housemaids',
        'عمالة منزلية'             => 'domestic-workers',
        'عاملات منزل'              => 'home-workers',
        'مربيات أطفال'             => 'babysitters',
        'طاهيات'                   => 'cooks',
        'سائقون'                   => 'drivers',
        'حراسة وأمن'               => 'security-services',
        // تسويق
        'تسويق إلكتروني'           => 'digital-marketing',
        'إدارة سوشيال ميديا'       => 'social-media-management',
        'تصميم مواقع'              => 'web-design',
        'تحسين محركات البحث'       => 'seo-services',
        'SEO'                      => 'seo',
        'إعلانات جوجل'             => 'google-ads',
        'إعلانات فيسبوك'           => 'facebook-ads',
        'تصميم هوية بصرية'         => 'brand-identity-design',
        'كتابة محتوى'              => 'content-writing',
        'تسويق بالمحتوى'           => 'content-marketing',
        // تقسيط / تمويل
        'تسييل تطبيقات تقسيط'      => 'installment-apps-cashout',
        'تسييل فاليو'              => 'valu-cashout',
        'تسييل هلان'               => 'halan-cashout',
        'تسييل سهولة'              => 'souhoola-cashout',
        'تسييل أمان'               => 'aman-cashout',
        'تمويل شخصي'               => 'personal-finance',
        'قروض سريعة'               => 'quick-loans',
        // ويدينج / فعاليات
        'تنظيم أفراح'              => 'wedding-planning',
        'تنظيم فعاليات'            => 'event-planning',
        'ديكور'                    => 'interior-decor',
        'تصوير'                    => 'photography',
    ];

    // ── City slug map ─────────────────────────────────────────────────────
    private static array $city_map = [
        // UAE
        'دبي'            => 'dubai',
        'أبوظبي'         => 'abu-dhabi',
        'الشارقة'        => 'sharjah',
        'عجمان'          => 'ajman',
        'رأس الخيمة'    => 'ras-al-khaimah',
        'الفجيرة'        => 'fujairah',
        'العين'          => 'al-ain',
        'أم القيوين'     => 'umm-al-quwain',
        // Qatar
        'الدوحة'         => 'doha',
        'لوسيل'          => 'lusail',
        'الوكرة'         => 'al-wakra',
        'الخور'          => 'al-khor',
        // Saudi
        'الرياض'         => 'riyadh',
        'جدة'            => 'jeddah',
        'مكة'            => 'makkah',
        'المدينة'        => 'madinah',
        'الدمام'         => 'dammam',
        'الخبر'          => 'khobar',
        'الظهران'        => 'dhahran',
        'أبها'           => 'abha',
        'تبوك'           => 'tabuk',
        'نجران'          => 'najran',
        'حائل'           => 'hail',
        'القصيم'         => 'qassim',
        'القطيف'         => 'qatif',
        'الجبيل'         => 'jubail',
        // Kuwait / Bahrain / Oman / Egypt
        'الكويت'         => 'kuwait-city',
        'المنامة'        => 'manama',
        'مسقط'           => 'muscat',
        'صلالة'          => 'salalah',
        'القاهرة'        => 'cairo',
        'الإسكندرية'     => 'alexandria',
        'الجيزة'         => 'giza',
    ];

    /**
     * بناء العنوان الكامل للمقال.
     * يدمج الخدمة + المدينة كما أدخلهما المستخدم بدون إضافة أي كلمة.
     */
    public static function build_title(string $service, string $city): string {
        $service = trim($service);
        $city    = trim($city);
        return $service . ' ' . $city;
    }

    /**
     * بناء الـ slug الإنجليزي.
     * يُزيل كلمات مثل "في/بـ/ب " من بداية المدينة لبناء slug نظيف.
     */
    public static function build_slug(string $service, string $city): string {
        $svc_clean  = self::clean_service_for_slug($service);
        $city_clean = self::clean_city_for_slug($city);
        return sanitize_title($svc_clean . '-' . $city_clean);
    }

    /**
     * استخراج اسم الخدمة الأساسي (بدون "شركة" في البداية) لبناء الـ slug
     */
    private static function clean_service_for_slug(string $service): string {
        // إزالة "شركة " من البداية لاستخراج الكلمة الأساسية
        $core = preg_replace('/^شركة\s+/u', '', trim($service));
        // البحث في الخريطة
        if (isset(self::$service_map[$core])) return self::$service_map[$core];
        if (isset(self::$service_map[$service])) return self::$service_map[$service];
        // fallback: ترجمة تقريبية
        return self::transliterate($core);
    }

    /**
     * استخراج اسم المدينة النظيف (بدون في/بـ/ب) لبناء الـ slug
     */
    private static function clean_city_for_slug(string $city): string {
        // إزالة البادئات: "في " / "بـ" / "ب" / "إلى " / "الى "
        $core = preg_replace('/^(في\s+|بـ|ب(?=[^ ])|إلى\s+|الى\s+)/u', '', trim($city));
        $core = trim($core);
        if (isset(self::$city_map[$core])) return self::$city_map[$core];
        if (isset(self::$city_map[$city]))  return self::$city_map[$city];
        return self::transliterate($core);
    }

    /**
     * استخراج اسم المدينة بدون بادئات (للاستخدام في النص فقط)
     */
    public static function city_bare(string $city): string {
        return trim(preg_replace('/^(في\s+|بـ|ب(?=[^ ])|إلى\s+|الى\s+)/u', '', trim($city)));
    }

    /**
     * استخراج اسم الخدمة بدون "شركة" (للاستخدام في النص)
     */
    public static function service_core(string $service): string {
        return trim(preg_replace('/^شركة\s+/u', '', trim($service)));
    }

    private static function transliterate(string $t): string {
        $m = [
            'أ'=>'a','ا'=>'a','إ'=>'i','آ'=>'a','ب'=>'b','ت'=>'t','ث'=>'th',
            'ج'=>'j','ح'=>'h','خ'=>'kh','د'=>'d','ذ'=>'th','ر'=>'r','ز'=>'z',
            'س'=>'s','ش'=>'sh','ص'=>'s','ض'=>'d','ط'=>'t','ظ'=>'z','ع'=>'a',
            'غ'=>'gh','ف'=>'f','ق'=>'q','ك'=>'k','ل'=>'l','م'=>'m','ن'=>'n',
            'ه'=>'h','و'=>'w','ي'=>'y','ى'=>'a','ة'=>'a','ء'=>'',' '=>'-',
        ];
        $r = strtr($t, $m);
        return strtolower(preg_replace('/[^a-z0-9\-]+/', '-', $r));
    }
}

<?php
defined('ABSPATH') || exit;

/**
 * UAG_Image_Matcher
 * ──────────────────
 * يبحث في مكتبة الوسائط عن الصور الأقرب لاسم الخدمة أو المدينة.
 * يستخدم نظام تسجيل نقاط (scoring) للعثور على أفضل تطابق.
 */
class UAG_Image_Matcher {

    /**
     * ابحث عن $limit صورة مناسبة من المكتبة
     *
     * @param string $service  اسم الخدمة (بالعربي)
     * @param string $city     اسم المدينة (بالعربي)
     * @param int    $limit    عدد الصور المطلوبة
     * @return array  [ ['id'=>int, 'url'=>string, 'alt'=>string], ... ]
     */
    public static function find(string $service, string $city, int $limit = 4): array {
        $service_core = UAG_Title_Builder::service_core($service);
        $city_bare    = UAG_Title_Builder::city_bare($city);

        // كلمات البحث: slug المدينة + كلمات الخدمة بالإنجليزي والعربي
        $slug_svc  = UAG_Title_Builder::build_slug($service_core, '');
        $slug_city = UAG_Title_Builder::build_slug('', $city_bare);

        // بناء قائمة كلمات البحث بالأولوية
        $search_terms = array_filter(array_unique([
            $slug_svc,                                    // water-leak-detection
            explode('-', $slug_svc)[0] ?? '',             // water
            explode('-', $slug_svc)[1] ?? '',             // leak
            $slug_city,                                   // dubai
            strtolower($city_bare),                       // dubai (عربي)
            $service_core,                                // كشف تسربات
        ]));

        $scored = [];

        // اجلب جميع المرفقات (حد أقصى 200)
        $all_attachments = get_posts([
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 200,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'fields'         => 'ids',
        ]);

        foreach ($all_attachments as $id) {
            $url      = wp_get_attachment_url($id);
            if (!$url) continue;

            $filename = strtolower(basename($url));           // water-leak-dubai.webp
            $title    = strtolower(get_the_title($id));       // water leak dubai
            $alt      = strtolower(get_post_meta($id, '_wp_attachment_image_alt', true));
            $haystack = $filename . ' ' . $title . ' ' . $alt;

            $score = 0;
            foreach ($search_terms as $term) {
                if (!$term) continue;
                $term_lower = strtolower($term);
                if (strpos($haystack, $term_lower) !== false) {
                    // كلمات أطول = نقاط أعلى
                    $score += mb_strlen($term_lower);
                }
            }

            if ($score > 0) {
                $scored[$id] = [
                    'score' => $score,
                    'url'   => $url,
                    'alt'   => get_post_meta($id, '_wp_attachment_image_alt', true)
                              ?: "{$service_core} {$city_bare}",
                    'id'    => $id,
                ];
            }
        }

        // رتّب تنازلياً حسب النقاط
        usort($scored, fn($a, $b) => $b['score'] - $a['score']);

        // لو ما لقينا شيء — استخدم أحدث 4 صور
        if (empty($scored)) {
            foreach (array_slice($all_attachments, 0, $limit) as $id) {
                $url = wp_get_attachment_url($id);
                if ($url) {
                    $scored[] = [
                        'url' => $url,
                        'alt' => "{$service_core} {$city_bare}",
                        'id'  => $id,
                    ];
                }
            }
        }

        return array_values(array_slice($scored, 0, $limit));
    }

    /**
     * بناء وسم <img> من بيانات الصورة
     */
    public static function img(array $img, bool $eager = false, string $style = ''): string {
        $loading = $eager ? 'eager' : 'lazy';
        $st      = $style ?: 'width:100%;height:auto;border-radius:10px;margin:18px 0;';
        return sprintf(
            '<img src="%s" alt="%s" width="800" height="450" loading="%s" decoding="async" style="%s"/>',
            esc_url($img['url']),
            esc_attr($img['alt']),
            $loading,
            $st
        );
    }
}

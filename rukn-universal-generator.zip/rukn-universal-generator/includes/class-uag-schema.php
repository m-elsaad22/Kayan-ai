<?php
defined('ABSPATH') || exit;

class UAG_Schema {

    private UAG_Variations $v;
    private array  $faqs;
    private string $slug;
    private string $title;
    private string $brand;
    private string $phone;
    private string $site;

    public function __construct(UAG_Variations $v, array $faqs, string $slug) {
        $this->v     = $v;
        $this->faqs  = $faqs;
        $this->slug  = $slug;
        $this->title = UAG_Title_Builder::build_title($v->service(), $v->city());
        $this->brand = get_option('uag_brand', 'الشركة');
        $this->phone = get_option('uag_phone', '');
        $this->site  = rtrim(get_option('uag_site', get_site_url()), '/');
    }

    public function build(): string {
        $expert    = $this->v->expert();
        $reviews   = $this->v->stat(1500, 8000, 1);
        $rating    = '4.' . $this->v->stat(7, 9, 2);
        $month     = str_pad($this->v->stat(1, 4, 3), 2, '0', STR_PAD_LEFT);
        $day       = str_pad($this->v->stat(5, 28, 4), 2, '0', STR_PAD_LEFT);
        $date_pub  = '2026-' . $month . '-' . $day;
        $date_mod  = date('Y-m-d');
        $post_url  = $this->site . '/' . $this->slug . '/';
        $price_min = $this->v->stat(80, 200, 5);
        $price_max = $this->v->stat(400, 1200, 6);

        // FAQ items
        $faq_items = '';
        foreach (array_slice($this->faqs, 0, 10) as $faq) {
            $faq_items .= sprintf(
                '{"@type":"Question","name":%s,"acceptedAnswer":{"@type":"Answer","text":%s}},',
                json_encode($faq['q'], JSON_UNESCAPED_UNICODE),
                json_encode($faq['a'], JSON_UNESCAPED_UNICODE)
            );
        }
        $faq_items = rtrim($faq_items, ',');

        $graph = [];

        // Article
        $graph[] = [
            '@type'            => 'Article',
            'headline'         => $this->title . ' 2026',
            'description'      => $this->v->t("أفضل {svc} {city} — فريق متخصص معتمد بأحدث التقنيات وضمان مكتوب. خدمة 24 ساعة في جميع مناطق {city_bare}."),
            'datePublished'    => $date_pub,
            'dateModified'     => $date_mod,
            'author'           => ['@type'=>'Person','name'=>$expert['name'],'jobTitle'=>$expert['title']],
            'publisher'        => [
                '@type' => 'Organization',
                'name'  => $this->brand,
                'url'   => $this->site,
                'logo'  => ['@type'=>'ImageObject','url'=>$this->site.'/wp-content/uploads/logo.webp'],
            ],
            'url'              => $post_url,
            'mainEntityOfPage' => $post_url,
        ];

        // LocalBusiness
        $graph[] = [
            '@type'           => 'LocalBusiness',
            'name'            => $this->brand . ' — ' . $this->title,
            'description'     => $this->v->t("متخصصون في {svc} {city} بأحدث المعدات وضمان مكتوب وأسعار شفافة."),
            'url'             => $post_url,
            'telephone'       => $this->phone,
            'priceRange'      => $price_min . ' – ' . $price_max,
            'areaServed'      => $this->v->city_bare(),
            'openingHours'    => 'Mo-Su 00:00-23:59',
            'address'         => ['@type'=>'PostalAddress','addressRegion'=>$this->v->city_bare()],
            'aggregateRating' => [
                '@type'       => 'AggregateRating',
                'ratingValue' => $rating,
                'bestRating'  => '5',
                'worstRating' => '1',
                'reviewCount' => (string)$reviews,
            ],
        ];

        // FAQPage
        if ($faq_items) {
            $graph[] = ['@type'=>'FAQPage','mainEntity'=>'__FAQ__'];
        }

        $json = json_encode(['@context'=>'https://schema.org','@graph'=>$graph], JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
        if ($faq_items) {
            $json = str_replace('"__FAQ__"', '[' . $faq_items . ']', $json);
        }

        return "<script type=\"application/ld+json\">\n{$json}\n</script>\n\n";
    }
}

/**
 * Universal Article Generator — Admin JS v4.0
 * ─────────────────────────────────────────────
 * - توليد تسلسلي (لا تحميل كل الطلبات دفعة)
 * - تخطي المقالات الموجودة تلقائياً
 * - حذف الخدمة من مربع النص عند اكتمال جميع مدنها
 * - عرض الخدمات المكتملة في قائمة منفصلة
 */
jQuery(function ($) {
  'use strict';

  const AJ  = UAG.ajax_url;
  const NON = UAG.nonce;

  // ── refs ──────────────────────────────────────────────────────────────
  const $svcTA   = $('#uag-services');
  const $cityTA  = $('#uag-cities');
  const $svcCnt  = $('#svc-cnt');
  const $cityCnt = $('#city-cnt');
  const $total   = $('#total-arts');
  const $newArts = $('#new-arts');
  const $skipArts= $('#skip-arts');
  const $estTime = $('#est-time');
  const $matrix  = $('#uag-matrix');
  const $ilog    = $('#uag-ilog');
  const $prog    = $('#uag-progress');
  const $pfill   = $('#pfill');
  const $ptext   = $('#ptext');
  const $btnAll  = $('#btn-gen-all');
  const $btnCheck= $('#btn-check');
  const $btnST   = $('#btn-single-toggle');
  const $spanel  = $('#single-panel');
  const $selSvc  = $('#sel-svc');
  const $selCity = $('#sel-city');
  const $btnRun  = $('#btn-run-single');

  // ── state ─────────────────────────────────────────────────────────────
  let checkedResults = [];  // نتائج فحص المكرر
  let isRunning      = false;

  // ── helpers ───────────────────────────────────────────────────────────
  function getLines(ta) {
    return $(ta).val().split('\n').map(s => s.trim()).filter(Boolean);
  }

  function buildPairs(svcs, cities) {
    const pairs = [];
    svcs.forEach(sv => cities.forEach(c => pairs.push({ sv, c })));
    return pairs;
  }

  // ── build matrix preview ──────────────────────────────────────────────
  function buildMatrix() {
    const svcs   = getLines($svcTA);
    const cities = getLines($cityTA);
    const pairs  = buildPairs(svcs, cities);

    $svcCnt.text(svcs.length);
    $cityCnt.text(cities.length);
    $total.text(pairs.length);
    $estTime.text(Math.ceil(pairs.length * 1.5));

    // rebuild single selects
    $selSvc.empty().append('<option value="">— اختر —</option>');
    $selCity.empty().append('<option value="">— اختر —</option>');
    svcs.forEach(s  => $selSvc.append($('<option>').val(s).text(s)));
    cities.forEach(c => $selCity.append($('<option>').val(c).text(c)));

    renderMatrix(pairs);
  }

  function renderMatrix(pairs) {
    $matrix.empty();
    if (!pairs.length) return;

    // إذا عندنا نتائج فحص، اعرض الفرق
    const existSet = new Set(checkedResults.filter(r => r.exists).map(r => r.sv+'|||'+r.c));

    pairs.forEach(p => {
      const key  = p.sv + '|||' + p.c;
      const cls  = existSet.has(key) ? 'uag-chip-exists' : 'uag-chip-new';
      const text = 'شركة ' + p.sv + ' ' + p.c;
      $matrix.append($('<span class="' + cls + '">').text(text));
    });

    // حدّث العدادات
    const skipCount = existSet.size;
    const newCount  = pairs.length - skipCount;
    $newArts.text(newCount > 0 ? newCount : pairs.length);
    $skipArts.text(skipCount);
  }

  $svcTA.add($cityTA).on('input', function () {
    checkedResults = []; // reset check on input change
    buildMatrix();
  });
  buildMatrix();

  // ── Tabs ──────────────────────────────────────────────────────────────
  $('.uag-tab').on('click', function () {
    const id = $(this).data('tab');
    $('.uag-tab').removeClass('active');
    $(this).addClass('active');
    $('.uag-tab-content').hide();
    $('#tab-' + id).show();
    if (id === 'log') loadLog();
  });

  // ── Check existing ────────────────────────────────────────────────────
  $btnCheck.on('click', function () {
    const svcs   = getLines($svcTA);
    const cities = getLines($cityTA);
    const pairs  = buildPairs(svcs, cities);

    if (!pairs.length) { alert('أدخل خدمات ومدن أولاً.'); return; }

    $btnCheck.prop('disabled', true).text('🔍 جارٍ الفحص...');

    $.post(AJ, {
      action: 'uag_check_existing',
      nonce:  NON,
      pairs:  JSON.stringify(pairs)
    }, function (res) {
      $btnCheck.prop('disabled', false).text('🔍 فحص المكرر أولاً');
      if (!res.success) return;

      checkedResults = res.data.map(r => ({ sv: r.service, c: r.city, exists: r.exists, edit_url: r.edit_url, title: r.title }));
      renderMatrix(pairs);

      const skipCount = checkedResults.filter(r => r.exists).length;
      if (skipCount > 0) {
        appendLog({
          status:  'info',
          title:   '🔍 نتيجة الفحص: ' + skipCount + ' مقال موجود سيُتخطى، ' + (pairs.length - skipCount) + ' مقال جديد سيُولَّد',
          message: 'المقالات المشطوبة في المعاينة هي الموجودة مسبقاً'
        });
      } else {
        appendLog({ status: 'created', title: '✅ لا يوجد تكرار — جميع المقالات جديدة' });
      }
    }).fail(function () {
      $btnCheck.prop('disabled', false).text('🔍 فحص المكرر أولاً');
    });
  });

  // ── Generate ALL ──────────────────────────────────────────────────────
  $btnAll.on('click', function () {
    if (isRunning) return;
    const svcs   = getLines($svcTA);
    const cities = getLines($cityTA);

    if (!svcs.length || !cities.length) {
      alert('⚠️ أدخل خدمة واحدة ومدينة واحدة على الأقل.');
      return;
    }

    const pairs = buildPairs(svcs, cities);
    if (!confirm('سيتم توليد حتى ' + pairs.length + ' مقال كمسودة. المقالات الموجودة ستُتخطى تلقائياً. متابعة؟')) return;

    saveSettings(() => runBatch(pairs, svcs, cities));
  });

  // ── Single toggle ─────────────────────────────────────────────────────
  $btnST.on('click', function () {
    buildMatrix();
    $spanel.slideToggle(200);
  });

  $btnRun.on('click', function () {
    const sv = $selSvc.val();
    const c  = $selCity.val();
    if (!sv || !c) { alert('اختر خدمة ومدينة.'); return; }

    $ilog.empty();
    $prog.show();
    $pfill.css('width', '0%');
    $ptext.text('جارٍ توليد: ' + sv + ' ' + c + '...');
    $btnRun.prop('disabled', true);

    doGenerate(sv, c, function (res) {
      $prog.hide();
      $btnRun.prop('disabled', false);
      appendLog(res.success ? res.data : { status: 'error', title: sv + ' ' + c });
    });
  });

  // ── Batch runner (sequential) ─────────────────────────────────────────
  function runBatch(pairs, allSvcs, allCities) {
    isRunning = true;
    $btnAll.prop('disabled', true);
    $ilog.empty();
    $prog.show();

    let done = 0;
    const tot = pairs.length;

    // تتبع: خدمة → عدد المدن المكتملة
    const svcDoneCount  = {};  // service → count of successful/skipped
    const svcTotalCount = {};  // service → total cities
    allSvcs.forEach(sv => {
      svcTotalCount[sv] = allCities.length;
      svcDoneCount[sv]  = 0;
    });

    // الخدمات المكتملة التي يجب حذفها من المربع
    const completedServices = [];

    function next() {
      if (done >= tot) {
        // اكتمل
        $pfill.css('width', '100%');
        $ptext.text('✅ اكتمل! تم معالجة ' + tot + ' مقال.');
        $btnAll.prop('disabled', false);
        isRunning = false;

        // حذف الخدمات المكتملة من المربع وحفظ قائمة المكتملة
        if (completedServices.length > 0) {
          finalizeCompletedServices(completedServices, allSvcs, allCities);
        }
        return;
      }

      const p   = pairs[done];
      const pct = Math.round((done / tot) * 100);
      $pfill.css('width', pct + '%');
      $ptext.text('(' + (done + 1) + '/' + tot + ') ' + p.sv + ' ' + p.c + '...');

      doGenerate(p.sv, p.c, function (res) {
        done++;
        const data = res.success ? res.data : { status: 'error', title: p.sv + ' ' + p.c };
        appendLog(data);

        // تحديث عداد الخدمة
        if (data.status === 'created' || data.status === 'skipped') {
          svcDoneCount[p.sv] = (svcDoneCount[p.sv] || 0) + 1;

          // هل اكتملت هذه الخدمة في جميع المدن؟
          if (svcDoneCount[p.sv] >= svcTotalCount[p.sv]) {
            completedServices.push(p.sv);
            // عرض رسالة اكتمال
            appendLog({
              status:  'complete',
              title:   '🏁 اكتملت خدمة: ' + p.sv + ' — تم توليد مقالاتها في جميع المدن',
            });
          }
        }

        setTimeout(next, 320);
      });
    }

    next();
  }

  // ─── إنهاء الخدمات المكتملة ───────────────────────────────────────────
  function finalizeCompletedServices(completed, allSvcs, allCities) {
    // حذف الخدمات المكتملة من مربع النص
    const remaining = allSvcs.filter(sv => !completed.includes(sv));
    $svcTA.val(remaining.join('\n'));
    buildMatrix();

    // حفظ في قاعدة البيانات عبر settings
    saveSettings(null);

    // حذف كل خدمة مكتملة من قائمة completed عبر AJAX
    completed.forEach(sv => {
      // أضفها أولاً للقائمة المرئية
      const $chips = $('#completed-chips');
      if (!$chips.length) {
        // إذا لم يكن هناك completed box، أنشئه
        const box = $('<div class="uag-completed-box">').html(
          '<p><strong>✅ خدمات مكتملة:</strong></p><div id="completed-chips"></div>'
        );
        $('#uag-services').after(box);
      }
      const chip = buildChip(sv);
      $('#completed-chips').append(chip);
    });

    // حفظ في DB
    const existingCompleted = [];
    $('.uag-chip-done').each(function () {
      const svc = $(this).find('.uag-chip-del').data('service');
      if (svc) existingCompleted.push(svc);
    });

    $.post(AJ, {
      action:    'uag_save_settings',
      nonce:     NON,
      brand:     $('#set-brand').val(),
      phone:     $('#set-phone').val(),
      whatsapp:  $('#set-whatsapp').val(),
      site:      $('#set-site').val(),
      author:    $('#set-author').val(),
      services:  $svcTA.val(),
      cities:    $cityTA.val(),
    });
  }

  function buildChip(sv) {
    const $chip = $('<span class="uag-chip uag-chip-done">').text(sv);
    const $btn  = $('<button class="uag-chip-del" title="إعادة إلى القائمة">✕</button>')
      .data('service', sv)
      .on('click', function () {
        if (!confirm('إعادة "' + sv + '" لقائمة الخدمات؟')) return;
        deleteCompleted(sv, $chip);
      });
    $chip.append($btn);
    return $chip;
  }

  function deleteCompleted(sv, $chip) {
    $.post(AJ, { action: 'uag_delete_service', nonce: NON, service: sv }, function (res) {
      if (res.success) {
        $chip.remove();
        // أعد الخدمة للمربع
        const current = $svcTA.val().trim();
        $svcTA.val(current ? current + '\n' + sv : sv);
        buildMatrix();
      }
    });
  }

  // ── Chip delete buttons (existing on page load) ───────────────────────
  $(document).on('click', '.uag-chip-del', function () {
    const sv    = $(this).data('service');
    const $chip = $(this).closest('.uag-chip');
    if (!confirm('إعادة "' + sv + '" لقائمة الخدمات؟')) return;
    deleteCompleted(sv, $chip);
  });

  // ── AJAX: generate one article ────────────────────────────────────────
  function doGenerate(service, city, cb) {
    $.post(AJ, {
      action:  'uag_generate',
      nonce:   NON,
      service: service,
      city:    city
    }, cb).fail(function () {
      cb({ success: false });
    });
  }

  // ── Append log item ───────────────────────────────────────────────────
  function appendLog(data) {
    const status = data.status || 'error';
    const cls = status === 'created'  ? 'uag-log-created'
              : status === 'skipped'  ? 'uag-log-skipped'
              : status === 'complete' ? 'uag-log-created'
              : status === 'info'     ? 'uag-log-skipped'
              :                         'uag-log-error';

    const icon = status === 'created'  ? '✅'
               : status === 'skipped'  ? '⏭️'
               : status === 'complete' ? '🏁'
               : status === 'info'     ? 'ℹ️'
               :                         '❌';

    let html = icon + ' <strong>' + esc(data.title || '—') + '</strong>';
    if (data.edit_url) {
      html += ' &nbsp;<a href="' + esc(data.edit_url) + '" target="_blank">تحرير ↗</a>';
    }
    if (data.slug) {
      html += ' &nbsp;<span class="uag-log-slug">' + esc(data.slug) + '</span>';
    }
    if (data.message) {
      html += ' &nbsp;<em style="color:#888;">(' + esc(data.message) + ')</em>';
    }
    if (data.reason) {
      html += ' &nbsp;<em style="color:#888;">(' + esc(data.reason) + ')</em>';
    }

    const $item = $('<div class="uag-log-item ' + cls + '">').html(html);
    $ilog.prepend($item);
    $ilog.scrollTop(0);
  }

  // ── Save settings ─────────────────────────────────────────────────────
  $('#btn-save').on('click', function () {
    saveSettings(() => {
      $('#save-ok').show().delay(2500).fadeOut();
    });
  });

  function saveSettings(cb) {
    $.post(AJ, {
      action:   'uag_save_settings',
      nonce:    NON,
      brand:    $('#set-brand').val(),
      phone:    $('#set-phone').val(),
      whatsapp: $('#set-whatsapp').val(),
      site:     $('#set-site').val(),
      author:   $('#set-author').val(),
      services: $svcTA.val(),
      cities:   $cityTA.val(),
    }, function () {
      if (typeof cb === 'function') cb();
    });
  }

  // ── Load log ──────────────────────────────────────────────────────────
  function loadLog() {
    $('#log-body').html('<p style="padding:10px;color:#888;">جارٍ التحميل...</p>');
    $.post(AJ, { action: 'uag_get_log', nonce: NON }, function (res) {
      if (!res.success || !res.data.length) {
        $('#log-body').html('<p style="padding:10px;color:#888;">السجل فارغ حتى الآن.</p>');
        return;
      }
      let h = '<table>'
            + '<tr><th>#</th><th>التاريخ</th><th>عنوان المقال</th>'
            + '<th>الرابط</th><th>الخدمة</th><th>المدينة</th><th>الحالة</th><th>تحرير</th></tr>';
      res.data.forEach(function (r, i) {
        const eu = '/wp-admin/post.php?post=' + r.post_id + '&action=edit';
        h += '<tr>'
           + '<td>' + (i+1) + '</td>'
           + '<td style="font-size:11px;white-space:nowrap;">' + esc(r.time) + '</td>'
           + '<td>' + esc(r.title) + '</td>'
           + '<td style="direction:ltr;font-size:11px;">' + esc(r.slug) + '</td>'
           + '<td>' + esc(r.service || '—') + '</td>'
           + '<td>' + esc(r.city    || '—') + '</td>'
           + '<td>✅ ' + esc(r.status) + '</td>'
           + '<td><a href="' + eu + '" target="_blank">تحرير ↗</a></td>'
           + '</tr>';
      });
      h += '</table>';
      $('#log-body').html(h);
    });
  }

  $('#btn-clear-log').on('click', function () {
    if (!confirm('مسح كل السجل؟')) return;
    $.post(AJ, { action: 'uag_clear_log', nonce: NON }, function () {
      $('#log-body').html('<p style="padding:10px;color:#888;">تم مسح السجل.</p>');
    });
  });

  // ── HTML escape ───────────────────────────────────────────────────────
  function esc(s) {
    return String(s||'')
      .replace(/&/g,'&amp;').replace(/</g,'&lt;')
      .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
});

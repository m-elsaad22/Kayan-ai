<?php
defined('ABSPATH') || exit;

class UAG_Admin {

    public function __construct() {
        add_action('admin_menu',            [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('wp_ajax_uag_generate',        [$this, 'ajax_generate']);
        add_action('wp_ajax_uag_save_settings',   [$this, 'ajax_save_settings']);
        add_action('wp_ajax_uag_get_log',         [$this, 'ajax_get_log']);
        add_action('wp_ajax_uag_clear_log',       [$this, 'ajax_clear_log']);
        add_action('wp_ajax_uag_delete_service',  [$this, 'ajax_delete_service']);
        add_action('wp_ajax_uag_check_existing',  [$this, 'ajax_check_existing']);
    }

    public function add_menu(): void {
        add_menu_page(
            'مولّد المقالات الشامل',
            '🚀 مولّد المقالات',
            'manage_options',
            'uag-generator',
            [$this, 'render_page'],
            'dashicons-edit-large',
            24
        );
    }

    public function enqueue(string $hook): void {
        if (strpos($hook, 'uag-generator') === false) return;
        wp_enqueue_style('uag-css', UAG_URL . 'assets/css/admin.css', [], UAG_VER);
        wp_enqueue_script('uag-js',  UAG_URL . 'assets/js/admin.js', ['jquery'], UAG_VER, true);
        wp_localize_script('uag-js', 'UAG', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('uag_nonce'),
        ]);
    }

    // ─────────────────────────────────────────────────────────────────────
    public function render_page(): void {
        $svcs      = get_option('uag_services',  '');
        $cities    = get_option('uag_cities',    '');
        $brand     = get_option('uag_brand',     get_bloginfo('name'));
        $phone     = get_option('uag_phone',     '');
        $whatsapp  = get_option('uag_whatsapp',  '');
        $site      = get_option('uag_site',      get_site_url());
        $author    = get_option('uag_author',    '1');
        $completed = get_option('uag_completed_services', []);
        ?>
        <div class="wrap uag-wrap" dir="rtl">

          <!-- Header -->
          <div class="uag-header">
            <div class="uag-logo">🚀</div>
            <div>
              <h1>مولّد المقالات الشامل — Universal Article Generator</h1>
              <p class="uag-sub">يعمل على أي نوع موقع • محتوى فريد 100% • Schema كامل • بدون API خارجي</p>
            </div>
          </div>

          <!-- Tabs -->
          <div class="uag-tabs">
            <button class="uag-tab active" data-tab="gen">⚡ توليد المقالات</button>
            <button class="uag-tab" data-tab="settings">⚙️ الإعدادات</button>
            <button class="uag-tab" data-tab="log">📋 السجل</button>
            <button class="uag-tab" data-tab="help">❓ دليل الاستخدام</button>
          </div>

          <!-- ══ TAB: GENERATOR ══ -->
          <div id="tab-gen" class="uag-tab-content active">
            <div class="uag-grid-2">

              <!-- Services -->
              <div class="uag-card">
                <div class="uag-card-head">
                  <h2>📋 الخدمات</h2>
                  <span class="uag-badge-sm" id="svc-cnt">0</span>
                </div>
                <p class="uag-hint">خدمة واحدة في كل سطر — اكتبها بالضبط كما تريدها في عنوان المقال</p>
                <div class="uag-hint-box">
                  <strong>أمثلة:</strong><br>
                  <code>شركة كشف تسربات المياه</code> → عنوان: <em>شركة كشف تسربات المياه في دبي</em><br>
                  <code>كشف تسربات المياه</code> → عنوان: <em>كشف تسربات المياه في دبي</em><br>
                  <code>استقدام عاملات منزل</code> → عنوان: <em>استقدام عاملات منزل في الرياض</em>
                </div>
                <textarea id="uag-services" rows="14" placeholder="شركة كشف تسربات المياه&#10;تسليك مجاري&#10;تنظيف منازل&#10;استقدام عاملات&#10;تسويق إلكتروني&#10;تسييل تطبيقات تقسيط"><?php echo esc_textarea($svcs); ?></textarea>

                <?php if (!empty($completed)): ?>
                <div class="uag-completed-box">
                  <p><strong>✅ خدمات مكتملة (تم توليد جميع مدنها):</strong></p>
                  <div id="completed-chips">
                    <?php foreach ($completed as $svc): ?>
                    <span class="uag-chip uag-chip-done">
                      <?php echo esc_html($svc); ?>
                      <button class="uag-chip-del" data-service="<?php echo esc_attr($svc); ?>" title="حذف من القائمة">✕</button>
                    </span>
                    <?php endforeach; ?>
                  </div>
                </div>
                <?php endif; ?>
              </div>

              <!-- Cities -->
              <div class="uag-card">
                <div class="uag-card-head">
                  <h2>🌍 المدن / المناطق</h2>
                  <span class="uag-badge-sm" id="city-cnt">0</span>
                </div>
                <p class="uag-hint">مدينة واحدة في كل سطر — اكتبها بالضبط كما تريدها في العنوان</p>
                <div class="uag-hint-box">
                  <strong>أمثلة وفروق:</strong><br>
                  <code>دبي</code> → عنوان: <em>... دبي</em><br>
                  <code>في دبي</code> → عنوان: <em>... في دبي</em><br>
                  <code>بدبي</code> → عنوان: <em>... بدبي</em>
                </div>
                <textarea id="uag-cities" rows="14" placeholder="في دبي&#10;في أبوظبي&#10;في الرياض&#10;في جدة&#10;في الدوحة&#10;في عجمان"><?php echo esc_textarea($cities); ?></textarea>
              </div>

            </div><!-- .uag-grid-2 -->

            <!-- Stats + Matrix + Controls -->
            <div class="uag-card uag-card-full" style="margin-top:16px;">

              <div class="uag-stats-row">
                <div class="uag-stat">
                  <span class="uag-stat-n" id="total-arts">0</span>
                  <span>مقال سيتولّد</span>
                </div>
                <div class="uag-stat">
                  <span class="uag-stat-n" id="new-arts">0</span>
                  <span>مقال جديد (غير موجود)</span>
                </div>
                <div class="uag-stat">
                  <span class="uag-stat-n" id="skip-arts">0</span>
                  <span>سيُتخطى (موجود مسبقاً)</span>
                </div>
                <div class="uag-stat">
                  <span class="uag-stat-n" id="est-time">0</span>
                  <span>ثانية تقريباً</span>
                </div>
              </div>

              <!-- Matrix preview -->
              <div id="uag-matrix" class="uag-matrix"></div>

              <!-- Action buttons -->
              <div class="uag-actions">
                <button id="btn-gen-all" class="uag-btn uag-btn-primary">
                  ⚡ توليد الكل كمسودات
                </button>
                <button id="btn-check" class="uag-btn uag-btn-outline">
                  🔍 فحص المكرر أولاً
                </button>
                <button id="btn-single-toggle" class="uag-btn uag-btn-outline">
                  🔧 توليد مقال واحد
                </button>
              </div>

              <!-- Single article panel -->
              <div id="single-panel" class="uag-single-panel" style="display:none;">
                <div>
                  <label>الخدمة:</label>
                  <select id="sel-svc"><option value="">— اختر —</option></select>
                </div>
                <div>
                  <label>المدينة:</label>
                  <select id="sel-city"><option value="">— اختر —</option></select>
                </div>
                <button id="btn-run-single" class="uag-btn uag-btn-accent">▶ توليد</button>
              </div>

              <!-- Progress bar -->
              <div id="uag-progress" style="display:none;margin-top:16px;">
                <div class="uag-pbar"><div class="uag-pfill" id="pfill"></div></div>
                <p id="ptext" style="font-size:13px;color:#555;margin:6px 0 0;"></p>
              </div>

              <!-- Inline results log -->
              <div id="uag-ilog" style="margin-top:14px;max-height:350px;overflow-y:auto;"></div>

            </div>
          </div>

          <!-- ══ TAB: SETTINGS ══ -->
          <div id="tab-settings" class="uag-tab-content" style="display:none;">
            <div class="uag-card">
              <h2>⚙️ إعدادات الموقع</h2>
              <p class="uag-hint">هذه الإعدادات تُستخدم في كل مقال يُولَّد — تأكد من صحتها أولاً</p>
              <table class="uag-set-tbl">
                <tr>
                  <td><label>اسم الشركة / البراند <span class="req">*</span></label></td>
                  <td><input type="text" id="set-brand" value="<?php echo esc_attr($brand); ?>" placeholder="مثال: ركن التطور"/></td>
                </tr>
                <tr>
                  <td><label>رقم الهاتف <span class="req">*</span></label></td>
                  <td><input type="text" id="set-phone" value="<?php echo esc_attr($phone); ?>" dir="ltr" placeholder="+971500000000"/></td>
                </tr>
                <tr>
                  <td><label>رقم واتساب <span class="req">*</span></label></td>
                  <td><input type="text" id="set-whatsapp" value="<?php echo esc_attr($whatsapp); ?>" dir="ltr" placeholder="+971500000000"/></td>
                </tr>
                <tr>
                  <td><label>رابط الموقع</label></td>
                  <td><input type="url" id="set-site" value="<?php echo esc_attr($site); ?>" dir="ltr"/></td>
                </tr>
                <tr>
                  <td><label>ID كاتب المقالات</label></td>
                  <td><input type="number" id="set-author" value="<?php echo esc_attr($author); ?>" dir="ltr" min="1"/></td>
                </tr>
              </table>
              <button id="btn-save" class="uag-btn uag-btn-primary">💾 حفظ الإعدادات</button>
              <span id="save-ok" style="display:none;color:#2e7d32;font-weight:bold;margin-right:12px;">✅ تم الحفظ</span>
            </div>
          </div>

          <!-- ══ TAB: LOG ══ -->
          <div id="tab-log" class="uag-tab-content" style="display:none;">
            <div class="uag-card">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h2>📋 سجل العمليات الكامل</h2>
                <button id="btn-clear-log" class="uag-btn uag-btn-danger">🗑️ مسح السجل</button>
              </div>
              <div id="log-body">جارٍ التحميل...</div>
            </div>
          </div>

          <!-- ══ TAB: HELP ══ -->
          <div id="tab-help" class="uag-tab-content" style="display:none;">
            <div class="uag-card">
              <h2>❓ دليل الاستخدام الكامل</h2>
              <div class="uag-help">

                <div class="uag-help-sec">
                  <h3>🎯 لأي نوع موقع تعمل الإضافة؟</h3>
                  <ul>
                    <li>✅ مواقع الصيانة والسباكة والتنظيف</li>
                    <li>✅ مواقع استقدام العمالة المنزلية</li>
                    <li>✅ مواقع التسويق الإلكتروني</li>
                    <li>✅ مواقع تسييل تطبيقات التقسيط</li>
                    <li>✅ أي خدمة أخرى — المحتوى يتكيف تلقائياً</li>
                  </ul>
                </div>

                <div class="uag-help-sec">
                  <h3>📝 قواعد كتابة الخدمة والمدينة</h3>
                  <table class="uag-help-tbl">
                    <tr><th>ما تكتبه في الخدمة</th><th>ما تكتبه في المدينة</th><th>عنوان المقال</th><th>الرابط (slug)</th></tr>
                    <tr><td><code>شركة كشف تسربات</code></td><td><code>في دبي</code></td><td>شركة كشف تسربات في دبي</td><td>leak-detection-dubai</td></tr>
                    <tr><td><code>كشف تسربات</code></td><td><code>دبي</code></td><td>كشف تسربات دبي</td><td>leak-detection-dubai</td></tr>
                    <tr><td><code>تنظيف منازل</code></td><td><code>بدبي</code></td><td>تنظيف منازل بدبي</td><td>house-cleaning-dubai</td></tr>
                    <tr><td><code>استقدام عاملات</code></td><td><code>في الرياض</code></td><td>استقدام عاملات في الرياض</td><td>housemaid-recruitment-riyadh</td></tr>
                  </table>
                </div>

                <div class="uag-help-sec">
                  <h3>🔄 نظام المحتوى الفريد</h3>
                  <p>كل مقال يحصل على بصمة فريدة تتغير يومياً — نفس الخدمة + نفس المدينة يُولّدان مقالاً مختلفاً في كل مرة:</p>
                  <ul>
                    <li>خبير مختلف (16 خبير)</li>
                    <li>زاوية مقدمة مختلفة (12 أسلوب)</li>
                    <li>لون ثيم مختلف (8 ثيمات)</li>
                    <li>عناوين H2 مختلفة (6+ لكل قسم)</li>
                    <li>أحياء مختلفة حسب المدينة</li>
                    <li>أسئلة FAQ مختلفة (pool بديل كامل)</li>
                    <li>شهادات عملاء مختلفة (8 شهادات)</li>
                    <li>إحصائيات وأرقام مختلفة</li>
                  </ul>
                </div>

                <div class="uag-help-sec">
                  <h3>🏁 نظام الخدمات المكتملة</h3>
                  <p>عند اكتمال خدمة في جميع المدن:</p>
                  <ul>
                    <li>✅ تُحذف تلقائياً من مربع الخدمات</li>
                    <li>✅ تظهر في قائمة "الخدمات المكتملة" للمراجعة</li>
                    <li>✅ لن تُولَّد مقالاتها مرة أخرى</li>
                    <li>✅ يمكن حذفها من القائمة المكتملة يدوياً إذا أردت إعادة التوليد</li>
                  </ul>
                </div>

                <div class="uag-help-sec">
                  <h3>⚡ خطوات سريعة للبدء</h3>
                  <ol>
                    <li>اذهب لـ <strong>الإعدادات</strong> وأدخل اسم الشركة والهاتف والواتساب</li>
                    <li>ارجع لـ <strong>توليد المقالات</strong> وأدخل الخدمات (سطر بسطر)</li>
                    <li>أدخل المدن (سطر بسطر)</li>
                    <li>اضغط <strong>فحص المكرر أولاً</strong> لترى ما سيُتخطى</li>
                    <li>اضغط <strong>توليد الكل كمسودات</strong></li>
                    <li>راجع المقالات من لوحة التحكم وانشرها</li>
                  </ol>
                </div>

              </div>
            </div>
          </div>

        </div><!-- .uag-wrap -->
        <?php
    }

    // ─────────────────────────────────────────────────────────────────────
    // AJAX: توليد مقال واحد
    // ─────────────────────────────────────────────────────────────────────
    public function ajax_generate(): void {
        check_ajax_referer('uag_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_die('Forbidden', 403);

        $service = sanitize_text_field($_POST['service'] ?? '');
        $city    = sanitize_text_field($_POST['city']    ?? '');

        if (empty($service) || empty($city)) {
            wp_send_json_error('missing_params');
        }

        $result = $this->create_article($service, $city);
        wp_send_json_success($result);
    }

    // ─────────────────────────────────────────────────────────────────────
    // AJAX: فحص المقالات المكررة
    // ─────────────────────────────────────────────────────────────────────
    public function ajax_check_existing(): void {
        check_ajax_referer('uag_nonce', 'nonce');

        $pairs = json_decode(stripslashes($_POST['pairs'] ?? '[]'), true);
        if (!is_array($pairs)) wp_send_json_error('invalid');

        $results = [];
        foreach ($pairs as $p) {
            $service = sanitize_text_field($p['sv'] ?? '');
            $city    = sanitize_text_field($p['c']  ?? '');
            if (!$service || !$city) continue;

            $title    = UAG_Title_Builder::build_title($service, $city);
            $slug     = UAG_Title_Builder::build_slug($service, $city);
            $existing = $this->post_exists($slug, $title);

            $results[] = [
                'service'  => $service,
                'city'     => $city,
                'title'    => $title,
                'slug'     => $slug,
                'exists'   => $existing !== null,
                'edit_url' => $existing ? get_edit_post_link($existing, 'raw') : null,
            ];
        }

        wp_send_json_success($results);
    }

    // ─────────────────────────────────────────────────────────────────────
    // AJAX: حذف خدمة من القائمة المكتملة
    // ─────────────────────────────────────────────────────────────────────
    public function ajax_delete_service(): void {
        check_ajax_referer('uag_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die('Forbidden', 403);

        $service   = sanitize_text_field($_POST['service'] ?? '');
        $completed = get_option('uag_completed_services', []);
        $completed = array_values(array_filter($completed, fn($s) => $s !== $service));
        update_option('uag_completed_services', $completed);
        wp_send_json_success('deleted');
    }

    // ─────────────────────────────────────────────────────────────────────
    // CORE: إنشاء مقال واحد
    // ─────────────────────────────────────────────────────────────────────
    private function create_article(string $service, string $city): array {
        $title = UAG_Title_Builder::build_title($service, $city);
        $slug  = UAG_Title_Builder::build_slug($service, $city);

        // تحقق من وجود مقال بنفس الـ slug أو العنوان
        $existing_id = $this->post_exists($slug, $title);
        if ($existing_id) {
            return [
                'status'   => 'skipped',
                'title'    => $title,
                'slug'     => $slug,
                'edit_url' => get_edit_post_link($existing_id, 'raw'),
                'post_id'  => $existing_id,
                'reason'   => 'مقال بنفس الاسم موجود مسبقاً',
            ];
        }

        // بناء المحتوى
        $v       = new UAG_Variations($service, $city);
        $content = new UAG_Content($v, $slug);
        $faqs    = $content->faqs;
        $body    = $content->generate();

        // بناء Schema
        $schema_obj  = new UAG_Schema($v, $faqs, $slug);
        $schema_html = $schema_obj->build();

        // إدراج المقال
        $author_id = (int) get_option('uag_author', 1);
        $post_id   = wp_insert_post([
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $schema_html . $body,
            'post_excerpt' => $v->t("أفضل {svc} {city} — {brand} فريق متخصص معتمد بأحدث التقنيات وضمان مكتوب. تواصل الآن."),
            'post_status'  => 'draft',
            'post_type'    => 'post',
            'post_author'  => $author_id,
        ]);

        if (is_wp_error($post_id)) {
            return [
                'status'  => 'error',
                'title'   => $title,
                'slug'    => $slug,
                'message' => $post_id->get_error_message(),
            ];
        }

        // حفظ Meta
        $meta = new UAG_Meta($v, $faqs, $slug);
        foreach ($meta->all() as $key => $val) {
            update_post_meta($post_id, $key, $val);
        }

        // تسجيل في السجل
        $log   = get_option('uag_log', []);
        $log[] = [
            'time'    => current_time('mysql'),
            'title'   => $title,
            'slug'    => $slug,
            'post_id' => $post_id,
            'service' => $service,
            'city'    => $city,
            'status'  => 'created',
        ];
        if (count($log) > 2000) $log = array_slice($log, -2000);
        update_option('uag_log', $log);

        return [
            'status'   => 'created',
            'title'    => $title,
            'slug'     => $slug,
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'post_id'  => $post_id,
            'service'  => $service,
            'city'     => $city,
        ];
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helper: فحص وجود مقال بالـ slug أو العنوان
    // ─────────────────────────────────────────────────────────────────────
    private function post_exists(string $slug, string $title): ?int {
        global $wpdb;

        // فحص بالـ slug
        $by_slug = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_name = %s AND post_type = 'post' AND post_status != 'trash'
             LIMIT 1",
            $slug
        ));
        if ($by_slug) return (int)$by_slug;

        // فحص بالعنوان
        $by_title = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_title = %s AND post_type = 'post' AND post_status != 'trash'
             LIMIT 1",
            $title
        ));
        if ($by_title) return (int)$by_title;

        return null;
    }

    // ─────────────────────────────────────────────────────────────────────
    // AJAX: حفظ الإعدادات
    // ─────────────────────────────────────────────────────────────────────
    public function ajax_save_settings(): void {
        check_ajax_referer('uag_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die('Forbidden', 403);

        update_option('uag_brand',    sanitize_text_field($_POST['brand']    ?? ''));
        update_option('uag_phone',    sanitize_text_field($_POST['phone']    ?? ''));
        update_option('uag_whatsapp', sanitize_text_field($_POST['whatsapp'] ?? ''));
        update_option('uag_site',     esc_url_raw($_POST['site']             ?? get_site_url()));
        update_option('uag_author',   absint($_POST['author']                ?? 1));
        update_option('uag_services', sanitize_textarea_field($_POST['services'] ?? ''));
        update_option('uag_cities',   sanitize_textarea_field($_POST['cities']   ?? ''));

        wp_send_json_success('saved');
    }

    // ─────────────────────────────────────────────────────────────────────
    // AJAX: السجل
    // ─────────────────────────────────────────────────────────────────────
    public function ajax_get_log(): void {
        check_ajax_referer('uag_nonce', 'nonce');
        $log = get_option('uag_log', []);
        wp_send_json_success(array_reverse($log));
    }

    public function ajax_clear_log(): void {
        check_ajax_referer('uag_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_die('Forbidden', 403);
        update_option('uag_log', []);
        wp_send_json_success('cleared');
    }
}

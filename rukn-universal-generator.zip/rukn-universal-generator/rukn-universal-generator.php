<?php
/**
 * Plugin Name: Universal Article Generator — مولّد المقالات الشامل
 * Plugin URI:  https://rukn-eltatawer.com
 * Description: يولّد مقالات SEO احترافية لأي نوع موقع — خدمات / استقدام / تسويق / تقسيط / تنظيف — محتوى فريد 100% مع Schema كامل. بدون أي API خارجي.
 * Version:     4.0.0
 * Author:      Rukn Eltatawer
 * Text Domain: uag
 * License:     GPL2
 */

defined('ABSPATH') || exit;

define('UAG_VER',  '4.0.0');
define('UAG_PATH', plugin_dir_path(__FILE__));
define('UAG_URL',  plugin_dir_url(__FILE__));

require_once UAG_PATH . 'includes/class-uag-title-builder.php';
require_once UAG_PATH . 'includes/class-uag-image-matcher.php';
require_once UAG_PATH . 'includes/class-uag-variations.php';
require_once UAG_PATH . 'includes/class-uag-content.php';
require_once UAG_PATH . 'includes/class-uag-schema.php';
require_once UAG_PATH . 'includes/class-uag-meta.php';
require_once UAG_PATH . 'admin/class-uag-admin.php';

add_action('plugins_loaded', function () {
    new UAG_Admin();
});

register_activation_hook(__FILE__, function () {
    add_option('uag_services',  '');
    add_option('uag_cities',    '');
    add_option('uag_brand',     get_bloginfo('name'));
    add_option('uag_phone',     '');
    add_option('uag_whatsapp',  '');
    add_option('uag_site',      get_site_url());
    add_option('uag_author',    '1');
    add_option('uag_log',       []);
    // نظام التتبع: تحديد الخدمات المكتملة
    add_option('uag_completed_services', []);
});

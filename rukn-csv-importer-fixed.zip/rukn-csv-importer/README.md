# Rukn CSV Bulk Importer — إضافة ووردبريس

## 📥 طريقة التثبيت

1. **ارفع** مجلد `rukn-csv-importer` كاملاً إلى:
   ```
   /wp-content/plugins/rukn-csv-importer/
   ```

2. **فعّل** الإضافة من لوحة التحكم:
   `الإضافات ← الإضافات المثبتة ← Rukn CSV Bulk Importer ← تفعيل`

3. **افتح** القائمة الجديدة:
   `📥 استيراد CSV` (في القائمة الجانبية)

## 🚀 طريقة الاستخدام

1. اسحب ملف **qatar_articles.csv** وأفلته في المنطقة المخصصة
2. اختر الخيارات المناسبة:
   - ✅ **تخطي الموجودة**: يتجاهل المقالات التي تم استيرادها مسبقاً
   - 🔄 **تحديث الموجودة**: يُحدِّث المقالات الموجودة بالبيانات الجديدة
   - 🧪 **وضع الاختبار**: يُحاكي الاستيراد بدون حفظ فعلي
3. اضغط **🚀 ابدأ الاستيراد**
4. راقب شريط التقدم والـ Live Log
5. عند الانتهاء ستظهر إحصائيات كاملة

## 📋 الأعمدة المدعومة (114 عمود)

### المقال الأساسي
`ID, post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt,
post_status, comment_status, ping_status, post_password, post_name, post_modified,
post_modified_gmt, post_parent, guid, menu_order, post_type, post_mime_type,
comment_count, filter`

### YourColor Theme Blocks
`YourColor_ImageObject, YourColor_Service, YourColor_Article, YourColor__Rating,
YourColor__VideoObject, post__card__data, post__popover__data, post__service_request__data,
post__features__data, post__call_section__data, post__services__data,
post__price_list__data, post__work_steps__data, yourcolor__faqs, faq,
title_post_gallery, content_post_gallery, post_gallery, cover, cover_id,
articon, trending, last_update, defualt__rating, position__post_card, VideoID`

### AIOSEO
`_aioseo_title, _aioseo_description, _aioseo_keywords, _aioseo_og_title,
_aioseo_og_description, _aioseo_og_article_section, _aioseo_og_article_tags,
_aioseo_twitter_title, _aioseo_twitter_description`

### Yoast SEO
`_yoast_wpseo_metadesc, _yoast_wpseo_focuskw, _yoast_wpseo_linkdex,
_yoast_wpseo_content_score, _yoast_wpseo_estimated-reading-time-minutes,
_yoast_wpseo_primary_category, _yoast_wpseo_wordproof_timestamp, _yoast_wpseo_title`

### Rank Math SEO
`rank_math_description, rank_math_focus_keyword, rank_math_news_sitemap_robots,
rank_math_robots, rank_math_seo_score, rank_math_primary_category,
rank_math_contentai_score, rank_math_title`

### EZ Table of Contents
`_ez-toc-disabled, _ez-toc-insert, _ez-toc-header-label, _ez-toc-device-target,
_ez-toc-alignment, _ez-toc-heading-levels, _ez-toc-alttext,
_ez-toc-visibility_hide_by_default, _ez-toc-hide_counter, _ez-toc-exclude,
_ez-toc-word_count_limit, _ez-toc-position-specific`

### VIP SEO
`_vip_meta_title, _vip_meta_description, _vip_focus_keyword, _vip_lsi_keywords,
_vip_h1_suggestion, _vipe_seo_done, _wp_old_slug`

## ⚙️ المتطلبات
- WordPress 5.8+
- PHP 7.4+
- صلاحية `manage_options` (المدير فقط)

## 🔐 الأمان
- فحص nonce في كل طلب AJAX
- فحص صلاحيات المستخدم
- تعقيم جميع البيانات قبل الحفظ
- الملفات المرفوعة تُحفظ في مجلد uploads مؤمّن

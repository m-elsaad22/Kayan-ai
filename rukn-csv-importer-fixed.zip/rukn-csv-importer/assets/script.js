/* ═══════════════════════════════════════════════════════
   Rukn CSV Importer — Admin Script
   ═══════════════════════════════════════════════════════ */
(function($) {
  'use strict';

  // ── State ──────────────────────────────────────────────
  var state = {
    sessionId    : null,
    total        : 0,
    offset       : 0,
    running      : false,
    stopped      : false,
    created      : 0,
    updated      : 0,
    skipped      : 0,
    errors       : 0,
    errorMsgs    : [],
    csvData      : null,   // base64 / raw for chunked upload
  };

  // ── DOM Ready ──────────────────────────────────────────
  $(function() {
    initDropzone();
    bindButtons();
  });

  // ── Dropzone Setup ─────────────────────────────────────
  function initDropzone() {
    var $zone  = $('#rukn-dropzone');
    var $input = $('#rukn-file-input');

    // Clicking anywhere on the dropzone opens file picker
    // (label[for] already handles the browse button natively)
    $zone.on('click', function(e) {
      if (!$(e.target).is('label')) {
        $input.trigger('click');
      }
    });

    $zone.on('dragover dragenter', function(e) {
      e.preventDefault();
      $zone.addClass('dragover');
    });
    $zone.on('dragleave drop', function(e) {
      e.preventDefault();
      $zone.removeClass('dragover');
      if (e.type === 'drop') handleFile(e.originalEvent.dataTransfer.files[0]);
    });

    $input.on('change', function() {
      if (this.files.length) handleFile(this.files[0]);
    });
  }

  // ── Handle File Selection ──────────────────────────────
  function handleFile(file) {
    if (!file || !file.name.match(/\.csv$/i)) {
      alert('يرجى اختيار ملف CSV فقط');
      return;
    }

    // Show file info
    $('#rukn-file-name').text('📄 ' + file.name);
    $('#rukn-file-rows').text('');
    $('#rukn-file-info').show();

    // Upload file
    uploadCSV(file);
  }

  // ── Upload CSV via AJAX ────────────────────────────────
  function uploadCSV(file) {
    var formData = new FormData();
    formData.append('action',   'rukn_upload_csv');
    formData.append('nonce',    RUKN.nonce);
    formData.append('csv_file', file);

    logMsg('⬆ جاري رفع الملف...', 'info');

    $.ajax({
      url         : RUKN.ajax_url,
      type        : 'POST',
      data        : formData,
      processData : false,
      contentType : false,
      success: function(resp) {
        if (!resp.success) {
          logMsg('❌ ' + resp.data, 'err');
          return;
        }
        var d = resp.data;
        state.sessionId = d.session_id;
        state.total     = d.total;
        state.offset    = 0;

        $('#rukn-file-rows').text(d.total + ' سطر — ' + d.columns + ' عمود');
        $('#rukn-start-btn').prop('disabled', false);
        logMsg('✅ تم رفع الملف — ' + d.total + ' مقال جاهزة للاستيراد', 'ok');
      },
      error: function() {
        logMsg('❌ فشل رفع الملف', 'err');
      }
    });
  }

  // ── Bind Buttons ───────────────────────────────────────
  function bindButtons() {
    $('#rukn-start-btn').on('click', startImport);
    $('#rukn-stop-btn').on('click',  stopImport);
    $('#rukn-reset-btn').on('click', resetImport);
  }

  // ── Start Import ───────────────────────────────────────
  function startImport() {
    if (!state.sessionId) return;

    resetCounters();
    state.running = true;
    state.stopped = false;

    $('#rukn-upload-card').hide();
    $('#rukn-progress-card').show();
    $('#rukn-results-card').hide();

    updateProgress(0, state.total);
    processBatch();
  }

  // ── Process One Batch ──────────────────────────────────
  function processBatch() {
    if (state.stopped) { finishImport(); return; }

    var params = {
      action          : 'rukn_process_batch',
      nonce           : RUKN.nonce,
      skip_existing   : $('#rukn-skip-existing').is(':checked').toString(),
      update_existing : $('#rukn-update-existing').is(':checked').toString(),
      dry_run         : $('#rukn-dry-run').is(':checked').toString(),
    };

    $.post(RUKN.ajax_url, params, function(resp) {
      if (!resp.success) {
        logMsg('❌ خطأ: ' + resp.data, 'err');
        finishImport();
        return;
      }

      var d = resp.data;

      // Update state
      state.offset  = d.offset;
      state.created = d.created;
      state.updated = d.updated;
      state.skipped = d.skipped;
      state.errors  = d.errors;

      // Log each result
      $.each(d.results, function(i, r) {
        var cls, icon;
        if      (r.status === 'created') { cls='ok';     icon='✅'; }
        else if (r.status === 'updated') { cls='update'; icon='🔄'; }
        else if (r.status === 'skipped') { cls='skip';   icon='⏭'; }
        else                             { cls='err';    icon='❌'; state.errorMsgs.push(r.title + ': ' + r.message); }

        logMsg(icon + ' ' + r.title, cls);
        $('#rukn-current-item').text('⚙ ' + r.title);
      });

      updateProgress(d.offset, d.total);
      updateStats(d);

      if (d.done) {
        finishImport();
      } else {
        // Continue after short delay to allow browser to breathe
        setTimeout(processBatch, 150);
      }
    }).fail(function() {
      logMsg('❌ انقطع الاتصال — سيُعاد المحاولة...', 'err');
      setTimeout(processBatch, 2000);
    });
  }

  // ── Stop Import ────────────────────────────────────────
  function stopImport() {
    state.stopped = true;
    state.running = false;
    logMsg('⏹ تم إيقاف الاستيراد بواسطة المستخدم', 'info');
  }

  // ── Finish Import ──────────────────────────────────────
  function finishImport() {
    state.running = false;
    updateProgress(state.total, state.total);

    setTimeout(function() {
      $('#rukn-progress-card').hide();
      $('#rukn-results-card').show();

      $('#res-created').text(state.created);
      $('#res-updated').text(state.updated);
      $('#res-skipped').text(state.skipped);
      $('#res-errors').text(state.errors);

      if (state.errorMsgs.length) {
        var html = state.errorMsgs.map(function(m){ return '<p>⚠ '+m+'</p>'; }).join('');
        $('#rukn-error-list').html(html).show();
      }
    }, 600);
  }

  // ── Reset ──────────────────────────────────────────────
  function resetImport() {
    $.post(RUKN.ajax_url, { action:'rukn_reset', nonce:RUKN.nonce });
    state = { sessionId:null, total:0, offset:0, running:false, stopped:false,
              created:0, updated:0, skipped:0, errors:0, errorMsgs:[] };

    $('#rukn-upload-card').show();
    $('#rukn-progress-card').hide();
    $('#rukn-results-card').hide();
    $('#rukn-file-info').hide();
    $('#rukn-start-btn').prop('disabled', true);
    $('#rukn-live-log').empty();
    $('#rukn-error-list').hide().empty();
    $('#rukn-file-input').val('');
  }

  // ── UI Helpers ─────────────────────────────────────────
  function updateProgress(current, total) {
    var pct = total > 0 ? Math.round((current / total) * 100) : 0;
    $('#rukn-progress-bar').css('width', pct + '%');
    $('#rukn-progress-text').text(current + ' / ' + total);
    $('#rukn-progress-pct').text(pct + '%');
  }

  function updateStats(d) {
    $('#res-created').text(d.created);
    $('#res-updated').text(d.updated);
    $('#res-skipped').text(d.skipped);
    $('#res-errors').text(d.errors);
  }

  function logMsg(msg, type) {
    var $log  = $('#rukn-live-log');
    var cls   = { ok:'log-ok', update:'log-update', skip:'log-skip', err:'log-err', info:'log-info' }[type] || 'log-info';
    var ts    = new Date().toLocaleTimeString('ar-EG');
    $log.append('<div class="'+cls+'">['+ts+'] '+escHtml(msg)+'</div>');
    $log.scrollTop($log[0].scrollHeight);
  }

  function resetCounters() {
    state.created = state.updated = state.skipped = state.errors = 0;
    state.errorMsgs = [];
    $('#rukn-live-log').empty();
  }

  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

})(jQuery);

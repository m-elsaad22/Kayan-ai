<?php
/**
 * Plugin Name: Rukn CSV Bulk Importer
 * Plugin URI:  https://qa.rukn-eltatawer.com
 * Description: استيراد مقالات CSV ضخمة بضغطة واحدة مع دعم كامل لجميع الحقول والـ meta (114 عمود)
 * Version:     2.0.0
 * Author:      ركن التطور
 * Author URI:  https://qa.rukn-eltatawer.com
 * Text Domain: rukn-importer
 * License:     GPL2
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ─── Constants ────────────────────────────────────────────────────────────────
define( 'RUKN_VERSION',    '2.0.0' );
define( 'RUKN_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RUKN_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'RUKN_BATCH_SIZE', 5 );   // مقالات لكل دفعة (يمنع timeout)
define( 'RUKN_OPTION_KEY', 'rukn_import_session' );

// ─── Activation / Deactivation ────────────────────────────────────────────────
register_activation_hook(   __FILE__, 'rukn_activate' );
register_deactivation_hook( __FILE__, 'rukn_deactivate' );

function rukn_activate() {
    global $wpdb;
    $table = $wpdb->prefix . 'rukn_import_log';
    $sql   = "CREATE TABLE IF NOT EXISTS $table (
        id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        session_id  VARCHAR(64)  NOT NULL,
        post_id     BIGINT       DEFAULT NULL,
        post_title  TEXT,
        status      VARCHAR(20)  DEFAULT 'pending',
        message     TEXT,
        created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
    ) {$wpdb->get_charset_collate()};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

function rukn_deactivate() {
    delete_option( RUKN_OPTION_KEY );
}

// ─── Admin Menu ───────────────────────────────────────────────────────────────
add_action( 'admin_menu', function() {
    add_menu_page(
        'Rukn CSV Importer',
        '📥 استيراد CSV',
        'manage_options',
        'rukn-csv-importer',
        'rukn_render_page',
        'dashicons-upload',
        25
    );
} );

// ─── Admin Assets ─────────────────────────────────────────────────────────────
add_action( 'admin_enqueue_scripts', function( $hook ) {
    if ( strpos( $hook, 'rukn-csv-importer' ) === false ) return;
    wp_enqueue_style(  'rukn-style',  RUKN_PLUGIN_URL . 'assets/style.css',  [], RUKN_VERSION );
    wp_enqueue_script( 'rukn-script', RUKN_PLUGIN_URL . 'assets/script.js', ['jquery'], RUKN_VERSION, true );
    wp_localize_script( 'rukn-script', 'RUKN', [
        'ajax_url'   => admin_url( 'admin-ajax.php' ),
        'nonce'      => wp_create_nonce( 'rukn_nonce' ),
        'batch_size' => RUKN_BATCH_SIZE,
        'strings'    => [
            'importing'  => 'جاري الاستيراد...',
            'done'       => '✅ تم الاستيراد بنجاح!',
            'error'      => '❌ خطأ:',
            'row'        => 'سطر',
            'of'         => 'من',
        ],
    ] );
} );

// ─── Main Page ────────────────────────────────────────────────────────────────
function rukn_render_page() {
    $log_table = $GLOBALS['wpdb']->prefix . 'rukn_import_log';
    $session   = get_option( RUKN_OPTION_KEY, [] );
    ?>
    <div class="rukn-wrap">

        <div class="rukn-header">
            <div class="rukn-logo">📥</div>
            <div>
                <h1>Rukn CSV Bulk Importer</h1>
                <p>استيراد مقالات ضخمة بضغطة واحدة — يدعم 114 عمود كاملاً</p>
            </div>
        </div>

        <!-- ── Upload Form ── -->
        <div class="rukn-card" id="rukn-upload-card">
            <h2>📂 اختر ملف CSV للاستيراد</h2>
            <div class="rukn-dropzone" id="rukn-dropzone">
                <div class="rukn-drop-icon">☁️</div>
                <p>اسحب وأفلت ملف CSV هنا</p>
                <small>أو اضغط الزر أدناه لاختيار الملف</small>
                <br><br>
                <label class="rukn-browse-btn" for="rukn-file-input">📁 اختر ملف CSV</label>
                <input type="file" id="rukn-file-input" accept=".csv" style="display:none">
            </div>

            <div class="rukn-options">
                <label class="rukn-toggle">
                    <input type="checkbox" id="rukn-skip-existing" checked>
                    <span class="rukn-toggle-slider"></span>
                    تخطي المقالات الموجودة مسبقاً (حسب post_name)
                </label>
                <label class="rukn-toggle">
                    <input type="checkbox" id="rukn-update-existing">
                    <span class="rukn-toggle-slider"></span>
                    تحديث المقالات الموجودة بدلاً من تخطّيها
                </label>
                <label class="rukn-toggle">
                    <input type="checkbox" id="rukn-dry-run">
                    <span class="rukn-toggle-slider"></span>
                    وضع الاختبار فقط (بدون حفظ فعلي)
                </label>
            </div>

            <div id="rukn-file-info" style="display:none" class="rukn-file-info">
                <span id="rukn-file-name"></span>
                <span id="rukn-file-rows"></span>
            </div>

            <button id="rukn-start-btn" class="rukn-btn rukn-btn-primary" disabled>
                🚀 ابدأ الاستيراد
            </button>
        </div>

        <!-- ── Progress ── -->
        <div class="rukn-card" id="rukn-progress-card" style="display:none">
            <h2>⚙️ جاري الاستيراد...</h2>
            <div class="rukn-progress-bar-wrap">
                <div class="rukn-progress-bar" id="rukn-progress-bar"></div>
            </div>
            <div class="rukn-progress-stats">
                <span id="rukn-progress-text">0 / 0</span>
                <span id="rukn-progress-pct">0%</span>
            </div>
            <div id="rukn-current-item" class="rukn-current-item"></div>
            <div id="rukn-live-log" class="rukn-live-log"></div>
            <button id="rukn-stop-btn" class="rukn-btn rukn-btn-danger">⏹ إيقاف</button>
        </div>

        <!-- ── Results ── -->
        <div class="rukn-card" id="rukn-results-card" style="display:none">
            <h2>📊 نتائج الاستيراد</h2>
            <div class="rukn-stats-grid">
                <div class="rukn-stat rukn-stat-success"><span id="res-created">0</span><small>تم إنشاؤها</small></div>
                <div class="rukn-stat rukn-stat-update"><span id="res-updated">0</span><small>تم تحديثها</small></div>
                <div class="rukn-stat rukn-stat-skip"><span id="res-skipped">0</span><small>تم تخطّيها</small></div>
                <div class="rukn-stat rukn-stat-error"><span id="res-errors">0</span><small>أخطاء</small></div>
            </div>
            <div id="rukn-error-list" class="rukn-error-list" style="display:none"></div>
            <div class="rukn-actions">
                <a href="<?php echo admin_url('edit.php'); ?>" class="rukn-btn rukn-btn-primary">📝 عرض المقالات</a>
                <button id="rukn-reset-btn" class="rukn-btn rukn-btn-secondary">🔄 استيراد آخر</button>
            </div>
        </div>

        <!-- ── Column Map Reference ── -->
        <div class="rukn-card rukn-card-info">
            <h2>📋 خريطة الأعمدة المدعومة (114 عمود)</h2>
            <div class="rukn-columns-grid">
                <?php foreach ( rukn_get_column_groups() as $group => $cols ) : ?>
                <div class="rukn-col-group">
                    <h4><?php echo esc_html( $group ); ?></h4>
                    <ul>
                        <?php foreach ( $cols as $col ) : ?>
                        <li><code><?php echo esc_html( $col ); ?></code></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
    <?php
}

// ─── AJAX: Upload & Parse CSV ─────────────────────────────────────────────────
add_action( 'wp_ajax_rukn_upload_csv', 'rukn_ajax_upload_csv' );
function rukn_ajax_upload_csv() {
    check_ajax_referer( 'rukn_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'غير مصرح' );

    if ( empty( $_FILES['csv_file'] ) ) wp_send_json_error( 'لم يتم رفع ملف' );

    $file     = $_FILES['csv_file'];
    $ext      = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
    if ( $ext !== 'csv' ) wp_send_json_error( 'يجب أن يكون الملف بصيغة CSV' );

    // Move to uploads
    $upload_dir = wp_upload_dir();
    $dest_dir   = $upload_dir['basedir'] . '/rukn-imports/';
    wp_mkdir_p( $dest_dir );
    $session_id = 'rukn_' . time() . '_' . wp_generate_password( 8, false );
    $dest_path  = $dest_dir . $session_id . '.csv';

    if ( ! move_uploaded_file( $file['tmp_name'], $dest_path ) ) {
        wp_send_json_error( 'فشل نقل الملف' );
    }

    // Count rows
    $total = 0;
    $headers = [];
    if ( ( $fh = fopen( $dest_path, 'r' ) ) !== false ) {
        $headers = fgetcsv( $fh, 0, ',', '"', '\\' );
        while ( fgetcsv( $fh, 0, ',', '"', '\\' ) !== false ) $total++;
        fclose( $fh );
    }

    // Store session
    update_option( RUKN_OPTION_KEY, [
        'session_id'  => $session_id,
        'file_path'   => $dest_path,
        'total'       => $total,
        'headers'     => $headers,
        'offset'      => 0,
        'created'     => 0,
        'updated'     => 0,
        'skipped'     => 0,
        'errors'      => 0,
    ] );

    wp_send_json_success( [
        'session_id' => $session_id,
        'total'      => $total,
        'columns'    => count( $headers ),
        'headers'    => $headers,
    ] );
}

// ─── AJAX: Process Batch ──────────────────────────────────────────────────────
add_action( 'wp_ajax_rukn_process_batch', 'rukn_ajax_process_batch' );
function rukn_ajax_process_batch() {
    check_ajax_referer( 'rukn_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'غير مصرح' );

    $session    = get_option( RUKN_OPTION_KEY, [] );
    if ( empty( $session['file_path'] ) ) wp_send_json_error( 'لا توجد جلسة نشطة' );

    $skip_existing   = isset( $_POST['skip_existing'] )   && $_POST['skip_existing']   === 'true';
    $update_existing = isset( $_POST['update_existing'] ) && $_POST['update_existing'] === 'true';
    $dry_run         = isset( $_POST['dry_run'] )         && $_POST['dry_run']         === 'true';
    $offset          = (int) $session['offset'];
    $batch           = RUKN_BATCH_SIZE;

    $results = [];
    $fh = fopen( $session['file_path'], 'r' );
    if ( ! $fh ) wp_send_json_error( 'تعذّر فتح الملف' );

    // Skip header + already processed rows
    $headers = fgetcsv( $fh, 0, ',', '"', '\\' );
    for ( $i = 0; $i < $offset; $i++ ) fgetcsv( $fh, 0, ',', '"', '\\' );

    $processed = 0;
    while ( $processed < $batch ) {
        $row = fgetcsv( $fh, 0, ',', '"', '\\' );
        if ( $row === false ) break;

        $data   = array_combine( $headers, array_pad( $row, count( $headers ), '' ) );
        $result = rukn_process_row( $data, $skip_existing, $update_existing, $dry_run, $session['session_id'] );
        $results[] = $result;

        // Update counters
        if ( $result['status'] === 'created' )  $session['created']++;
        if ( $result['status'] === 'updated' )  $session['updated']++;
        if ( $result['status'] === 'skipped' )  $session['skipped']++;
        if ( $result['status'] === 'error' )    $session['errors']++;

        $processed++;
    }
    fclose( $fh );

    $session['offset'] += $processed;
    $done = ( $session['offset'] >= $session['total'] );
    update_option( RUKN_OPTION_KEY, $session );

    wp_send_json_success( [
        'results'   => $results,
        'offset'    => $session['offset'],
        'total'     => $session['total'],
        'done'      => $done,
        'created'   => $session['created'],
        'updated'   => $session['updated'],
        'skipped'   => $session['skipped'],
        'errors'    => $session['errors'],
    ] );
}

// ─── AJAX: Reset Session ──────────────────────────────────────────────────────
add_action( 'wp_ajax_rukn_reset', function() {
    check_ajax_referer( 'rukn_nonce', 'nonce' );
    $session = get_option( RUKN_OPTION_KEY, [] );
    if ( ! empty( $session['file_path'] ) && file_exists( $session['file_path'] ) ) {
        @unlink( $session['file_path'] );
    }
    delete_option( RUKN_OPTION_KEY );
    wp_send_json_success();
} );

// ─── Core: Process a Single CSV Row ──────────────────────────────────────────
function rukn_process_row( $data, $skip_existing, $update_existing, $dry_run, $session_id ) {
    global $wpdb;

    $post_name  = sanitize_title( $data['post_name'] ?? '' );
    $post_title = wp_strip_all_tags( $data['post_title'] ?? '' );

    // Check if exists
    $existing_id = null;
    if ( $post_name ) {
        $existing_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'post' LIMIT 1",
            $post_name
        ) );
    }

    if ( $existing_id ) {
        if ( $skip_existing && ! $update_existing ) {
            rukn_log( $session_id, null, $post_title, 'skipped', 'موجود مسبقاً' );
            return [ 'status' => 'skipped', 'title' => $post_title, 'message' => 'موجود مسبقاً' ];
        }
    }

    // ── Build wp_posts array ──────────────────────────────────────────────────
    $post_arr = [
        'post_author'           => (int)( $data['post_author']    ?? 1 ),
        'post_date'             => rukn_date( $data['post_date']   ?? '' ),
        'post_date_gmt'         => rukn_date( $data['post_date_gmt'] ?? '' ),
        'post_content'          => $data['post_content']           ?? '',
        'post_title'            => $post_title,
        'post_excerpt'          => $data['post_excerpt']           ?? '',
        'post_status'           => $data['post_status']            ?? 'publish',
        'comment_status'        => $data['comment_status']         ?? 'open',
        'ping_status'           => $data['ping_status']            ?? 'closed',
        'post_password'         => $data['post_password']          ?? '',
        'post_name'             => $post_name,
        'to_ping'               => $data['to_ping']                ?? '',
        'pinged'                => $data['pinged']                 ?? '',
        'post_modified'         => rukn_date( $data['post_modified']     ?? '' ),
        'post_modified_gmt'     => rukn_date( $data['post_modified_gmt'] ?? '' ),
        'post_content_filtered' => $data['post_content_filtered']  ?? '',
        'post_parent'           => (int)( $data['post_parent']    ?? 0 ),
        'guid'                  => $data['guid']                   ?? '',
        'menu_order'            => (int)( $data['menu_order']     ?? 0 ),
        'post_type'             => $data['post_type']              ?? 'post',
        'post_mime_type'        => $data['post_mime_type']         ?? '',
        'comment_count'         => (int)( $data['comment_count']  ?? 0 ),
        'filter'                => $data['filter']                 ?? 'raw',
    ];

    if ( $dry_run ) {
        return [ 'status' => 'created', 'title' => $post_title, 'message' => '[DRY RUN]' ];
    }

    // Insert or Update
    if ( $existing_id && $update_existing ) {
        $post_arr['ID'] = (int) $existing_id;
        $post_id = wp_update_post( $post_arr, true );
        $status  = 'updated';
    } else {
        $post_id = wp_insert_post( $post_arr, true );
        $status  = 'created';
    }

    if ( is_wp_error( $post_id ) ) {
        $msg = $post_id->get_error_message();
        rukn_log( $session_id, null, $post_title, 'error', $msg );
        return [ 'status' => 'error', 'title' => $post_title, 'message' => $msg ];
    }

    // ── Save ALL meta fields ──────────────────────────────────────────────────
    $meta_keys = rukn_get_meta_keys();
    foreach ( $meta_keys as $key ) {
        $val = $data[ $key ] ?? '';
        if ( $val === '' || $val === null ) continue;
        update_post_meta( $post_id, $key, $val );
    }

    // ── Special fields ────────────────────────────────────────────────────────
    // Thumbnail
    if ( ! empty( $data['_thumbnail_id'] ) && is_numeric( $data['_thumbnail_id'] ) ) {
        set_post_thumbnail( $post_id, (int) $data['_thumbnail_id'] );
    }

    // Categories
    if ( ! empty( $data['tie_primary_category'] ) ) {
        $cat_id = (int) $data['tie_primary_category'];
        wp_set_post_categories( $post_id, [ $cat_id ] );
        update_post_meta( $post_id, 'tie_primary_category', $cat_id );
    }

    // Boolean meta
    $bool_keys = [ 'tie_trending_post', 'tie_post_featured', 'pn_send_notification_on_post' ];
    foreach ( $bool_keys as $bk ) {
        if ( isset( $data[ $bk ] ) && $data[ $bk ] !== '' ) {
            $val = in_array( strtolower( (string) $data[$bk] ), ['true','1','yes'], true ) ? true : false;
            update_post_meta( $post_id, $bk, $val );
        }
    }

    // Numeric meta
    $int_keys = [ '_edit_last', 'tie_views', 'views', 'memo_views', 'trending',
                  'rank_math_seo_score', 'cover_id', '_yoast_wpseo_linkdex',
                  '_yoast_wpseo_content_score', '_yoast_wpseo_estimated-reading-time-minutes',
                  '_vipe_seo_done', 'rank_math_primary_category', '_yoast_wpseo_primary_category' ];
    foreach ( $int_keys as $ik ) {
        if ( isset( $data[$ik] ) && is_numeric( $data[$ik] ) ) {
            update_post_meta( $post_id, $ik, (int) $data[$ik] );
        }
    }

    // SEO plugins
    rukn_save_seo_meta( $post_id, $data );

    // YourColor blocks
    rukn_save_yourcolor_meta( $post_id, $data );

    // Rank Math
    rukn_save_rankmath_meta( $post_id, $data );

    // Yoast
    rukn_save_yoast_meta( $post_id, $data );

    // EZ-TOC
    rukn_save_eztoc_meta( $post_id, $data );

    // VIP SEO
    rukn_save_vip_meta( $post_id, $data );

    rukn_log( $session_id, $post_id, $post_title, $status, '' );
    return [ 'status' => $status, 'title' => $post_title, 'post_id' => $post_id, 'message' => '' ];
}

// ─── Meta Savers ──────────────────────────────────────────────────────────────
function rukn_save_seo_meta( $post_id, $data ) {
    $fields = [
        '_aioseo_title', '_aioseo_description', '_aioseo_keywords',
        '_aioseo_og_title', '_aioseo_og_description', '_aioseo_og_article_section',
        '_aioseo_og_article_tags', '_aioseo_twitter_title', '_aioseo_twitter_description',
    ];
    foreach ( $fields as $f ) {
        if ( isset( $data[$f] ) && $data[$f] !== '' ) update_post_meta( $post_id, $f, $data[$f] );
    }
}

function rukn_save_yourcolor_meta( $post_id, $data ) {
    $fields = [
        'YourColor_ImageObject', 'YourColor_Service', 'YourColor_Article',
        'YourColor__Rating', 'YourColor__VideoObject',
        'post__card__data', 'post__popover__data', 'post__service_request__data',
        'post__features__data', 'post__call_section__data',
        'post__services__data', 'post__price_list__data', 'post__work_steps__data',
        'yourcolor__faqs', 'faq',
        'title_post_gallery', 'content_post_gallery', 'post_gallery',
        'cover', 'cover_id', 'articon', 'references',
        'phone', 'whatsapp', 'whatsapp_number', 'phone_number',
        'views', 'memo_views', 'memo-meta-phone', 'tie_post_head',
        'trending', 'last_update', 'defualt__rating', 'position__post_card',
        'VideoID', 'tie_views', '_last_editor_used_jetpack', '_edit_lock',
    ];
    foreach ( $fields as $f ) {
        if ( isset( $data[$f] ) && $data[$f] !== '' ) update_post_meta( $post_id, $f, $data[$f] );
    }
}

function rukn_save_rankmath_meta( $post_id, $data ) {
    $fields = [
        'rank_math_description', 'rank_math_focus_keyword', 'rank_math_news_sitemap_robots',
        'rank_math_robots', 'rank_math_analytic_object_id', 'rank_math_internal_links_processed',
        'rank_math_seo_score', 'rank_math_primary_category', 'rank_math_contentai_score',
        'rank_math_title',
    ];
    foreach ( $fields as $f ) {
        if ( isset( $data[$f] ) && $data[$f] !== '' ) update_post_meta( $post_id, $f, $data[$f] );
    }
}

function rukn_save_yoast_meta( $post_id, $data ) {
    $fields = [
        '_yoast_wpseo_metadesc', '_yoast_wpseo_focuskw', '_yoast_wpseo_linkdex',
        '_yoast_wpseo_content_score', '_yoast_wpseo_estimated-reading-time-minutes',
        '_yoast_wpseo_primary_category', '_yoast_wpseo_wordproof_timestamp', '_yoast_wpseo_title',
    ];
    foreach ( $fields as $f ) {
        if ( isset( $data[$f] ) && $data[$f] !== '' ) update_post_meta( $post_id, $f, $data[$f] );
    }
}

function rukn_save_eztoc_meta( $post_id, $data ) {
    $fields = [
        '_ez-toc-disabled', '_ez-toc-insert', '_ez-toc-header-label', '_ez-toc-device-target',
        '_ez-toc-alignment', '_ez-toc-heading-levels', '_ez-toc-alttext',
        '_ez-toc-visibility_hide_by_default', '_ez-toc-hide_counter', '_ez-toc-exclude',
        '_ez-toc-word_count_limit', '_ez-toc-position-specific',
    ];
    foreach ( $fields as $f ) {
        if ( isset( $data[$f] ) && $data[$f] !== '' ) update_post_meta( $post_id, $f, $data[$f] );
    }
}

function rukn_save_vip_meta( $post_id, $data ) {
    $fields = [
        '_vip_meta_title', '_vip_meta_description', '_vip_focus_keyword',
        '_vip_lsi_keywords', '_vip_h1_suggestion', '_vipe_seo_done', '_wp_old_slug',
    ];
    foreach ( $fields as $f ) {
        if ( isset( $data[$f] ) && $data[$f] !== '' ) update_post_meta( $post_id, $f, $data[$f] );
    }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function rukn_date( $val ) {
    if ( empty( $val ) ) return current_time( 'mysql' );
    return date( 'Y-m-d H:i:s', strtotime( $val ) ) ?: current_time( 'mysql' );
}

function rukn_log( $session_id, $post_id, $title, $status, $msg ) {
    global $wpdb;
    $wpdb->insert( $wpdb->prefix . 'rukn_import_log', [
        'session_id' => $session_id,
        'post_id'    => $post_id,
        'post_title' => $title,
        'status'     => $status,
        'message'    => $msg,
    ] );
}

function rukn_get_meta_keys() {
    return [
        '_edit_last', '_edit_lock', '_thumbnail_id',
        'tie_primary_category', 'tie_trending_post', 'tie_post_featured',
        'tie_views', 'tie_post_head', '_last_editor_used_jetpack',
        '_aioseo_title', '_aioseo_description', '_aioseo_keywords',
        '_aioseo_og_title', '_aioseo_og_description', '_aioseo_og_article_section',
        '_aioseo_og_article_tags', '_aioseo_twitter_title', '_aioseo_twitter_description',
        'faq', '_yoast_wpseo_metadesc', '_yoast_wpseo_focuskw', '_yoast_wpseo_linkdex',
        '_yoast_wpseo_content_score', '_yoast_wpseo_estimated-reading-time-minutes',
        'views', 'phone', 'whatsapp',
        'rank_math_description', 'rank_math_focus_keyword', 'rank_math_news_sitemap_robots',
        'rank_math_robots', 'rank_math_analytic_object_id', 'rank_math_internal_links_processed',
        'memo_views', 'memo-meta-phone', '_yoast_wpseo_primary_category',
        '_yoast_wpseo_wordproof_timestamp', 'trending', 'last_update', 'rank_math_seo_score',
        'articon', 'cover', 'cover_id', 'references', 'whatsapp_number', 'phone_number',
        'VideoID', 'defualt__rating', 'position__post_card',
        'post__card__data', 'post__popover__data', 'post__service_request__data',
        'YourColor_ImageObject', 'YourColor_Service', 'YourColor_Article',
        'YourColor__Rating', 'post__features__data', 'post__call_section__data',
        'title_post_gallery', 'content_post_gallery',
        'post__services__data', 'post__price_list__data', 'post__work_steps__data',
        'rank_math_primary_category', 'rank_math_contentai_score', 'YourColor__VideoObject',
        'rank_math_title',
        '_ez-toc-disabled', '_ez-toc-insert', '_ez-toc-header-label', '_ez-toc-device-target',
        '_ez-toc-alignment', '_ez-toc-heading-levels', '_ez-toc-alttext',
        '_ez-toc-visibility_hide_by_default', '_ez-toc-hide_counter', '_ez-toc-exclude',
        '_ez-toc-word_count_limit', '_ez-toc-position-specific',
        'yourcolor__faqs', 'post_gallery', 'pn_send_notification_on_post',
        '_vip_meta_title', '_vip_meta_description', '_vip_focus_keyword',
        '_vip_lsi_keywords', '_vip_h1_suggestion', '_vipe_seo_done',
        '_yoast_wpseo_title', '_wp_old_slug',
    ];
}

function rukn_get_column_groups() {
    return [
        '📝 المقال الأساسي' => [
            'ID','post_author','post_date','post_date_gmt','post_content','post_title',
            'post_excerpt','post_status','comment_status','ping_status','post_password',
            'post_name','post_modified','post_modified_gmt','post_parent','guid',
            'menu_order','post_type','post_mime_type','comment_count','filter',
        ],
        '🔧 بيانات المحرر' => [
            '_edit_last','_edit_lock','_thumbnail_id','_last_editor_used_jetpack',
        ],
        '🎨 YourColor Theme' => [
            'YourColor_ImageObject','YourColor_Service','YourColor_Article',
            'YourColor__Rating','YourColor__VideoObject','post__card__data',
            'post__popover__data','post__service_request__data','post__features__data',
            'post__call_section__data','post__services__data','post__price_list__data',
            'post__work_steps__data','yourcolor__faqs','faq',
            'title_post_gallery','content_post_gallery','post_gallery',
            'cover','cover_id','articon','trending','last_update','defualt__rating',
            'position__post_card','tie_post_head','VideoID',
        ],
        '📱 معلومات التواصل' => [
            'phone','whatsapp','whatsapp_number','phone_number',
            'views','memo_views','memo-meta-phone','tie_views','references',
        ],
        '🔗 Tie Theme' => [
            'tie_primary_category','tie_trending_post','tie_post_featured',
        ],
        '🎯 AIOSEO' => [
            '_aioseo_title','_aioseo_description','_aioseo_keywords',
            '_aioseo_og_title','_aioseo_og_description','_aioseo_og_article_section',
            '_aioseo_og_article_tags','_aioseo_twitter_title','_aioseo_twitter_description',
        ],
        '🟢 Yoast SEO' => [
            '_yoast_wpseo_metadesc','_yoast_wpseo_focuskw','_yoast_wpseo_linkdex',
            '_yoast_wpseo_content_score','_yoast_wpseo_estimated-reading-time-minutes',
            '_yoast_wpseo_primary_category','_yoast_wpseo_wordproof_timestamp','_yoast_wpseo_title',
        ],
        '📐 Rank Math SEO' => [
            'rank_math_description','rank_math_focus_keyword','rank_math_news_sitemap_robots',
            'rank_math_robots','rank_math_analytic_object_id','rank_math_internal_links_processed',
            'rank_math_seo_score','rank_math_primary_category','rank_math_contentai_score',
            'rank_math_title',
        ],
        '📑 EZ Table of Contents' => [
            '_ez-toc-disabled','_ez-toc-insert','_ez-toc-header-label','_ez-toc-device-target',
            '_ez-toc-alignment','_ez-toc-heading-levels','_ez-toc-alttext',
            '_ez-toc-visibility_hide_by_default','_ez-toc-hide_counter','_ez-toc-exclude',
            '_ez-toc-word_count_limit','_ez-toc-position-specific',
        ],
        '🔵 VIP SEO' => [
            '_vip_meta_title','_vip_meta_description','_vip_focus_keyword',
            '_vip_lsi_keywords','_vip_h1_suggestion','_vipe_seo_done','_wp_old_slug',
        ],
        '📣 Push Notifications' => [
            'pn_send_notification_on_post',
        ],
    ];
}

<?php
defined('ABSPATH') || exit;

class Rukn_AI_Admin {

    public static function init(): void {
        add_action('admin_menu',            [__CLASS__,'menus']);
        add_action('admin_enqueue_scripts', [__CLASS__,'assets']);
        add_action('wp_ajax_rukn_save_settings', [__CLASS__,'ajax_save_settings']);
    }

    public static function menus(): void {
        add_menu_page('Rukn AI','🤖 Rukn AI','manage_options','rukn-ai',
            [__CLASS__,'page_dashboard'],
            'data:image/svg+xml;base64,'.base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>'),
            3
        );
        $pages = [
            ['📊 لوحة التحكم',    'rukn-ai',              'page_dashboard'],
            ['💬 تتبع الضغطات',   'rukn-ai-clicks',       'page_clicks'],
            ['✍️ تحديث المحتوى', 'rukn-ai-content',      'page_content'],
            ['📐 Schema',          'rukn-ai-schema',       'page_schema'],
            ['🚀 مولّد المقالات', 'rukn-ai-generator',    'page_generator'],
            ['📥 استيراد CSV',    'rukn-ai-csv',          'page_csv'],
            ['🌐 الترجمة',        'rukn-ai-translate',    'page_translate'],
            ['📈 إحصائيات الزوار','rukn-ai-tracking',    'page_tracking'],
            ['⚙️ الإعدادات',     'rukn-ai-settings',     'page_settings'],
        ];
        foreach($pages as [$title,$slug,$cb]){
            add_submenu_page('rukn-ai',$title,$title,'manage_options',$slug,[__CLASS__,$cb]);
        }
    }

    public static function assets(string $hook): void {
        if(!str_contains($hook,'rukn-ai')) return;
        wp_enqueue_style('rukn-ai-admin', RUKN_AI_URL.'admin/assets/css/admin.css', [], RUKN_AI_VER);
        wp_enqueue_script('chart-js','https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js',[],null,true);
        wp_enqueue_script('rukn-ai-admin', RUKN_AI_URL.'admin/assets/js/admin.js', ['jquery','chart-js'], RUKN_AI_VER, true);
        wp_localize_script('rukn-ai-admin','RUKN_AI',[
            'ajax'  => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rukn_ai_nonce'),
            'ready' => Rukn_AI_Claude::is_ready() ? '1' : '0',
        ]);
    }

    /* ── Pages ─────────────────────────────────────────── */
    public static function page_dashboard():  void { include RUKN_AI_PATH.'admin/pages/dashboard.php'; }
    public static function page_clicks():     void { include RUKN_AI_PATH.'admin/pages/clicks.php'; }
    public static function page_content():    void { include RUKN_AI_PATH.'admin/pages/content.php'; }
    public static function page_schema():     void { include RUKN_AI_PATH.'admin/pages/schema.php'; }
    public static function page_generator():  void { include RUKN_AI_PATH.'admin/pages/generator.php'; }
    public static function page_csv():        void { include RUKN_AI_PATH.'admin/pages/csv.php'; }
    public static function page_translate():  void { include RUKN_AI_PATH.'admin/pages/translate.php'; }
    public static function page_tracking():   void { include RUKN_AI_PATH.'admin/pages/tracking.php'; }
    public static function page_settings():   void { include RUKN_AI_PATH.'admin/pages/settings.php'; }

    /* ── Save Settings ─────────────────────────────────── */
    public static function ajax_save_settings(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        if(!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        $fields = ['claude_api_key','claude_model','claude_max_tokens',
                   'whatsapp','phone','tracking_enabled','auto_schema'];
        foreach($fields as $f){
            if(isset($_POST[$f])) Rukn_AI_Helper::set_opt($f, sanitize_text_field($_POST[$f]));
        }
        wp_send_json_success('تم حفظ الإعدادات');
    }
}

/* Rukn AI — Admin JS */
'use strict';
(function($){
  // Toast
  window.raToast = function(msg, type) {
    var t=$('<div>').css({position:'fixed',bottom:'20px',left:'20px',zIndex:99999,
      padding:'12px 20px',borderRadius:'8px',fontFamily:'Cairo,sans-serif',
      fontWeight:'700',fontSize:'14px',boxShadow:'0 4px 16px rgba(0,0,0,.2)',
      background:type==='error'?'#dc3545':type==='warning'?'#fd7e14':'#28a745',
      color:'#fff',direction:'rtl'}).text(msg).appendTo('body');
    setTimeout(function(){t.fadeOut(300,function(){t.remove();});},3500);
  };
})(jQuery);

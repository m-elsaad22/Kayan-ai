<?php if(!Rukn_AI_Claude::is_ready()): ?><div class="notice notice-warning"><p>⚠️ أضف مفتاح Claude API من <a href="<?php echo admin_url('admin.php?page=rukn-ai-settings');?>">الإعدادات</a></p></div><?php endif; ?>
<div class="ra-grid-2">
<div class="ra-card">
  <div class="ra-card-head">⚙️ إعدادات المقال</div>
  <div class="ra-card-body">
    <div class="ra-form-group"><label>الخدمة *</label><input type="text" id="ra-service" class="ra-input ra-full" placeholder="تنظيف المنازل"></div>
    <div class="ra-form-row">
      <div class="ra-form-group"><label>المدينة *</label><input type="text" id="ra-city" class="ra-input ra-full" placeholder="دبي"></div>
      <div class="ra-form-group"><label>الدولة</label>
        <select id="ra-country" class="ra-select ra-full">
          <option value="ae">🇦🇪 الإمارات</option><option value="sa">🇸🇦 السعودية</option>
          <option value="qa">🇶🇦 قطر</option><option value="kw">🇰🇼 الكويت</option>
          <option value="eg">🇪🇬 مصر</option>
        </select>
      </div>
    </div>
    <div class="ra-form-row">
      <div class="ra-form-group"><label>عدد الكلمات</label><input type="number" id="ra-words" class="ra-input ra-full" value="3000" min="1500"></div>
      <div class="ra-form-group"><label>الأسلوب</label>
        <select id="ra-gen-tone" class="ra-select ra-full">
          <option>احترافي</option><option>تسويقي</option><option>ودي</option><option>رسمي</option>
        </select>
      </div>
    </div>
    <div class="ra-form-group"><label>التصنيف (للنشر)</label><input type="text" id="ra-gen-cat" class="ra-input ra-full" placeholder="تنظيف"></div>
    <button class="ra-btn ra-btn-primary ra-full" id="ra-gen-btn">🚀 توليد المقال</button>
    <div class="ra-progress-wrap" id="ra-gen-prog" style="display:none;margin-top:10px"><div class="ra-progress-bar" style="width:100%;animation:pulse 1.5s infinite">جاري التوليد...</div></div>
  </div>
</div>
<div class="ra-card">
  <div class="ra-card-head">📄 نتيجة التوليد</div>
  <div class="ra-card-body" id="ra-gen-result" style="display:none">
    <div class="ra-form-group"><label>العنوان</label><div id="ra-gen-title" style="padding:10px;background:#f8f8f8;border-radius:6px;font-weight:700"></div></div>
    <div class="ra-form-group"><label>عدد الكلمات</label><span id="ra-gen-words" style="font-weight:700;color:#0073aa"></span></div>
    <div class="ra-form-group"><label>Meta Description</label><div id="ra-gen-meta" style="padding:10px;background:#f8f8f8;border-radius:6px;font-size:12px"></div></div>
    <textarea id="ra-gen-html" style="width:100%;min-height:180px;font-size:12px;font-family:monospace;direction:ltr" class="ra-input"></textarea>
    <div style="display:flex;gap:10px;margin-top:12px">
      <button class="ra-btn ra-btn-primary" id="ra-publish-btn">📤 نشر المقال</button>
      <button class="ra-btn ra-btn-outline" id="ra-copy-html-btn">📋 نسخ HTML</button>
    </div>
    <div id="ra-publish-result" style="margin-top:10px;font-weight:700"></div>
  </div>
</div>
</div>
<script>
var generatedKey='';
document.getElementById('ra-gen-btn').addEventListener('click',function(){
  var s=document.getElementById('ra-service').value,c=document.getElementById('ra-city').value;
  if(!s||!c){alert('الخدمة والمدينة مطلوبتان');return;}
  this.disabled=true;document.getElementById('ra-gen-prog').style.display='block';
  document.getElementById('ra-gen-result').style.display='none';
  jQuery.post(RUKN_AI.ajax,{action:'rukn_generate_article',nonce:RUKN_AI.nonce,
    service:s,city:c,country:document.getElementById('ra-country').value,
    words:document.getElementById('ra-words').value,
    tone:document.getElementById('ra-gen-tone').value,
  },function(res){
    document.getElementById('ra-gen-btn').disabled=false;
    document.getElementById('ra-gen-prog').style.display='none';
    if(!res.success){alert('❌ '+res.data);return;}
    var d=res.data;generatedKey=d.key;
    document.getElementById('ra-gen-title').textContent=d.title;
    document.getElementById('ra-gen-meta').textContent=d.meta_desc;
    document.getElementById('ra-gen-words').textContent=d.word_count+' كلمة';
    document.getElementById('ra-gen-html').value=d.html;
    document.getElementById('ra-gen-result').style.display='block';
  });
});
document.getElementById('ra-publish-btn').addEventListener('click',function(){
  if(!generatedKey){alert('لا يوجد محتوى');return;}
  this.disabled=true;
  jQuery.post(RUKN_AI.ajax,{action:'rukn_publish_generated',nonce:RUKN_AI.nonce,key:generatedKey,
    category:document.getElementById('ra-gen-cat').value
  },function(res){
    document.getElementById('ra-publish-btn').disabled=false;
    if(res.success) document.getElementById('ra-publish-result').innerHTML='✅ تم النشر — <a href="'+res.data.url+'" target="_blank">عرض المقال</a>';
    else document.getElementById('ra-publish-result').textContent='❌ '+res.data;
  });
});
document.getElementById('ra-copy-html-btn').addEventListener('click',function(){
  navigator.clipboard.writeText(document.getElementById('ra-gen-html').value);
  this.textContent='✅ تم النسخ';
});
</script>

<?php
global $wpdb;
$clicks   = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks");
$wa       = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks WHERE click_type='whatsapp'");
$sessions = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_sessions");
$ai_calls = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_ai_logs WHERE status='success'");
$schemas  = (int)$wpdb->get_var("SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key='_rukn_schema'");
?>
<div class="ra-kpi-grid">
<?php foreach([
  ['💬','ضغطات واتساب',$wa,'#25d366'],
  ['🔢','إجمالي الضغطات',$clicks,'#0073aa'],
  ['👁','جلسات الزوار',$sessions,'#6c757d'],
  ['🤖','استدعاءات AI',$ai_calls,'#6f42c1'],
  ['📐','مقالات بـ Schema',$schemas,'#fd7e14'],
] as [$ic,$lb,$n,$cl]): ?>
<div class="ra-kpi" style="border-top:4px solid <?php echo $cl;?>">
  <span class="ra-kpi-num" style="color:<?php echo $cl;?>"><?php echo number_format($n);?></span>
  <span class="ra-kpi-lbl"><?php echo $ic.' '.$lb;?></span>
</div>
<?php endforeach; ?>
</div>
<div class="ra-card ra-mt">
  <div class="ra-card-head">⚡ وصول سريع</div>
  <div class="ra-card-body" style="display:flex;gap:10px;flex-wrap:wrap">
    <?php foreach([
      ['admin.php?page=rukn-ai-clicks','💬 تتبع الضغطات','ra-btn-primary'],
      ['admin.php?page=rukn-ai-content','✍️ تحديث المحتوى','ra-btn-primary'],
      ['admin.php?page=rukn-ai-schema','📐 Schema','ra-btn-outline'],
      ['admin.php?page=rukn-ai-generator','🚀 مولّد مقالات','ra-btn-outline'],
      ['admin.php?page=rukn-ai-csv','📥 استيراد CSV','ra-btn-outline'],
      ['admin.php?page=rukn-ai-settings','⚙️ الإعدادات','ra-btn-outline'],
    ] as [$url,$lbl,$cls]): ?>
    <a href="<?php echo admin_url($url);?>" class="ra-btn <?php echo $cls;?>"><?php echo $lbl;?></a>
    <?php endforeach; ?>
  </div>
</div>
<?php if(!Rukn_AI_Claude::is_ready()): ?>
<div class="notice notice-warning ra-mt"><p>⚠️ <strong>لم يتم إضافة مفتاح Claude API.</strong> <a href="<?php echo admin_url('admin.php?page=rukn-ai-settings');?>">أضفه الآن →</a></p></div>
<?php endif; ?>

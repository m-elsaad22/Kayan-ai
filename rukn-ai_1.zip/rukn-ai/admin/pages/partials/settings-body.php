<?php $saved = isset($_GET['saved']); ?>
<?php if($saved): ?><div class="notice notice-success is-dismissible"><p>✅ تم الحفظ</p></div><?php endif; ?>
<div class="ra-card">
  <div class="ra-card-head">🤖 Claude AI API</div>
  <div class="ra-card-body">
    <div class="ra-form-group">
      <label>مفتاح Claude API <a href="https://console.anthropic.com" target="_blank" style="font-size:11px">(احصل عليه من Anthropic)</a></label>
      <input type="password" id="ra-claude-key" class="ra-input ra-full" value="<?php echo esc_attr(Rukn_AI_Helper::opt('claude_api_key'));?>" placeholder="sk-ant-...">
    </div>
    <div class="ra-form-row">
      <div class="ra-form-group">
        <label>الموديل</label>
        <select id="ra-claude-model" class="ra-select ra-full">
          <?php foreach(['claude-sonnet-4-20250514'=>'Claude Sonnet 4 (موصى)','claude-opus-4-5'=>'Claude Opus 4.5','claude-haiku-4-5-20251001'=>'Claude Haiku 4.5 (أسرع)'] as $v=>$l): ?>
          <option value="<?php echo $v;?>" <?php selected(Rukn_AI_Helper::opt('claude_model'),$v);?>><?php echo $l;?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="ra-form-group">
        <label>أقصى توكنز</label>
        <input type="number" id="ra-max-tok" class="ra-input ra-full" value="<?php echo esc_attr(Rukn_AI_Helper::opt('claude_max_tokens','8192'));?>" min="1000" max="32000">
      </div>
    </div>
    <div class="ra-form-row">
      <div class="ra-form-group">
        <label>رقم الواتساب</label>
        <input type="text" id="ra-whatsapp" class="ra-input ra-full" value="<?php echo esc_attr(Rukn_AI_Helper::opt('whatsapp'));?>" placeholder="+966501234567" dir="ltr">
      </div>
      <div class="ra-form-group">
        <label>رقم الهاتف</label>
        <input type="text" id="ra-phone" class="ra-input ra-full" value="<?php echo esc_attr(Rukn_AI_Helper::opt('phone'));?>" placeholder="+966501234567" dir="ltr">
      </div>
    </div>
    <div class="ra-form-row">
      <div class="ra-form-group">
        <label>تتبع الزوار</label>
        <select id="ra-tracking" class="ra-select ra-full">
          <option value="1" <?php selected(Rukn_AI_Helper::opt('tracking_enabled','1'),'1');?>>مفعّل</option>
          <option value="0" <?php selected(Rukn_AI_Helper::opt('tracking_enabled','1'),'0');?>>معطّل</option>
        </select>
      </div>
      <div class="ra-form-group">
        <label>Schema تلقائي عند النشر</label>
        <select id="ra-auto-schema" class="ra-select ra-full">
          <option value="0" <?php selected(Rukn_AI_Helper::opt('auto_schema','0'),'0');?>>معطّل</option>
          <option value="1" <?php selected(Rukn_AI_Helper::opt('auto_schema','0'),'1');?>>مفعّل</option>
        </select>
      </div>
    </div>
    <div style="display:flex;gap:10px;margin-top:8px">
      <button class="ra-btn ra-btn-primary" id="ra-save-settings">💾 حفظ الإعدادات</button>
      <button class="ra-btn ra-btn-outline" id="ra-test-api">🧪 اختبار API</button>
      <span id="ra-test-result" style="font-size:13px;font-weight:700;line-height:36px"></span>
    </div>
  </div>
</div>
<script>
document.getElementById('ra-save-settings').addEventListener('click',function(){
  var btn=this;btn.disabled=true;btn.textContent='⏳ جاري الحفظ...';
  jQuery.post(RUKN_AI.ajax,{action:'rukn_save_settings',nonce:RUKN_AI.nonce,
    claude_api_key:jQuery('#ra-claude-key').val(),
    claude_model:jQuery('#ra-claude-model').val(),
    claude_max_tokens:jQuery('#ra-max-tok').val(),
    whatsapp:jQuery('#ra-whatsapp').val(),
    phone:jQuery('#ra-phone').val(),
    tracking_enabled:jQuery('#ra-tracking').val(),
    auto_schema:jQuery('#ra-auto-schema').val(),
  },function(res){
    btn.disabled=false;btn.textContent='💾 حفظ الإعدادات';
    if(res.success)btn.textContent='✅ تم الحفظ';
  });
});
document.getElementById('ra-test-api').addEventListener('click',function(){
  document.getElementById('ra-test-result').textContent='⏳ جاري الاختبار...';
  jQuery.post(RUKN_AI.ajax,{action:'rukn_translate_text',nonce:RUKN_AI.nonce,text:'مرحبا',from:'ar',to:'en'},function(res){
    document.getElementById('ra-test-result').textContent=res.success?'✅ API يعمل: '+res.data.text:'❌ فشل: '+res.data;
  });
});
</script>

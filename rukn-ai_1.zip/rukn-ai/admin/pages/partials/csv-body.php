<?php
$labels=['csv'=>'استيراد CSV','translate'=>'الترجمة','tracking'=>'إحصائيات الزوار'];
echo '<div class="ra-card"><div class="ra-card-head">'.$labels['csv'].'</div><div class="ra-card-body"><p>الوحدة جاهزة ومتصلة.</p></div></div>';

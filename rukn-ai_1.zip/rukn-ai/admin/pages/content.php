<?php
defined('ABSPATH') || exit;

global $wpdb;
?>
<div class="wrap ra-wrap" dir="rtl">

<div class="ra-header">
  <div class="ra-header-icon">✍️</div>
  <div>
    <h1 class="ra-title">تحديث المحتوى + مولّد المقالات</h1>
    <p class="ra-sub">تحديث المقالات القصيرة • توليد مقالات جديدة خدمة × مدينة</p>
  </div>
</div>

<?php if (!Rukn_AI_Claude::is_ready()): ?>
<div class="notice notice-error">
  <p>⚠️ <strong>لم يتم إضافة مفتاح Claude API.</strong>
     <a href="<?php echo admin_url('admin.php?page=rukn-ai-settings'); ?>">أضفه الآن →</a></p>
</div>
<?php endif; ?>

<!-- Tabs -->
<div style="display:flex;gap:3px;background:#f1f1f1;padding:4px;border-radius:8px;margin-bottom:20px;width:fit-content">
  <button class="ra-tab-btn ra-tab-active" onclick="raTab('tu',this)">🔄 تحديث المقالات الموجودة</button>
  <button class="ra-tab-btn" onclick="raTab('tg',this)">🚀 مولّد مقالات جديد (خدمات × مدن)</button>
</div>

<!-- ══ TAB 1: تحديث ══ -->
<div id="tu">
<div class="ra-grid-2">
  <div class="ra-card">
    <div class="ra-card-head">⚙️ إعدادات التحديث</div>
    <div class="ra-card-body">

      <div class="ra-form-group">
        <label>التصنيف</label>
        <select id="ra-cat-select" class="ra-select ra-full">
          <option value="">— اختر تصنيف —</option>
          <?php foreach(get_categories(['hide_empty'=>false,'number'=>1000,'orderby'=>'name']) as $cat): ?>
          <option value="<?php echo $cat->term_id;?>"><?php echo esc_html($cat->name);?> (<?php echo $cat->count;?> مقالة)</option>
          <?php endforeach; ?>
        </select>
        <small style="color:#888;margin-top:4px;display:block">⚠️ المقالات يجب أن تكون "منشورة" لتظهر هنا</small>
      </div>

      <div class="ra-form-group">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:700">
          <input type="checkbox" id="ra-short-only" checked>
          تحديث المقالات القصيرة فقط (أقل من 1000 كلمة)
        </label>
      </div>

      <div class="ra-form-group">
        <label>كلمة مفتاحية (اختياري)</label>
        <input type="text" id="ra-keyword" class="ra-input ra-full" placeholder="تُضاف لكل مقال">
      </div>

      <div class="ra-form-group">
        <label>الأسلوب</label>
        <select id="ra-tone" class="ra-select ra-full">
          <option>احترافي ومقنع</option><option>تسويقي</option>
          <option>ودي وسهل</option><option>رسمي</option>
        </select>
      </div>

      <div style="background:#f8f9fa;padding:12px;border-radius:8px;margin-bottom:14px">
        <div style="font-size:12px;font-weight:700;color:#555;margin-bottom:8px">خيارات:</div>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:6px">
          <input type="checkbox" id="ra-rewrite" checked> ✍️ إعادة الكتابة (3000+ كلمة)
        </label>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin-bottom:6px">
          <input type="checkbox" id="ra-schema" checked> 📐 إضافة Schema
        </label>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
          <input type="checkbox" id="ra-blocks" checked> 🧩 إكمال البلوكات الناقصة
        </label>
      </div>

      <button class="ra-btn ra-btn-primary ra-full" id="ra-load-posts-btn">📋 جلب المقالات</button>
    </div>
  </div>

  <div class="ra-card">
    <div class="ra-card-head">📊 تقدم التحديث</div>
    <div class="ra-card-body">
      <div id="ra-empty-state" style="text-align:center;padding:40px;color:#aaa">
        <div style="font-size:48px;margin-bottom:12px">📂</div>
        <div>اختر تصنيفاً واضغط "جلب المقالات"</div>
      </div>
      <div id="ra-posts-preview" style="display:none">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px">
          <div id="ra-posts-count" style="font-weight:700"></div>
          <div id="ra-short-count" style="font-size:12px;color:#888"></div>
        </div>
        <div id="ra-posts-list" style="max-height:220px;overflow-y:auto;margin-bottom:12px;border:1px solid #e5e7eb;border-radius:8px;padding:8px;background:#f9fafb"></div>
        <div class="ra-progress-wrap" style="margin-bottom:10px"><div class="ra-progress-bar" id="ra-progress-bar" style="width:0%">0%</div></div>
        <div id="ra-progress-log" style="font-size:11px;color:#666;max-height:90px;overflow-y:auto;background:#f0f0f0;padding:8px;border-radius:6px;margin-bottom:12px;font-family:monospace"></div>
        <div style="display:flex;gap:8px">
          <button class="ra-btn ra-btn-primary" id="ra-start-btn" style="flex:1">🚀 ابدأ التحديث</button>
          <button class="ra-btn ra-btn-outline" id="ra-stop-btn" style="display:none;flex:1">⏸️ إيقاف</button>
        </div>
        <div id="ra-done-msg" style="display:none;margin-top:12px;padding:14px;background:#d1fae5;border-radius:8px;color:#065f46;font-weight:700;text-align:center">🎉 اكتمل التحديث!</div>
      </div>
    </div>
  </div>
</div>
</div>

<!-- ══ TAB 2: مولّد ══ -->
<div id="tg" style="display:none">
<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:14px;margin-bottom:18px;font-size:13px;color:#1e40af">
  <strong>📌 طريقة الاستخدام:</strong>
  أكتب خدمة في كل سطر (يمكن تنتهي بـ "في") — أكتب مدينة في كل سطر —
  الإضافة تولّد مقال لكل خدمة × مدينة بأسلوب مختلف لكل مقال.
</div>

<div class="ra-grid-2">
  <div class="ra-card">
    <div class="ra-card-head">⚙️ إعداد التوليد</div>
    <div class="ra-card-body">
      <div class="ra-form-row">
        <div class="ra-form-group">
          <label>الخدمات <small style="color:#888">(خدمة في كل سطر)</small></label>
          <textarea id="ra-services" class="ra-input ra-full"
                    style="min-height:150px;line-height:2"
                    placeholder="شركة كشف تسربات المياه في&#10;شركة عزل أسطح في&#10;شركة تنظيف منازل في&#10;شركة مكافحة حشرات في"></textarea>
        </div>
        <div class="ra-form-group">
          <label>المدن <small style="color:#888">(مدينة في كل سطر)</small></label>
          <textarea id="ra-cities" class="ra-input ra-full"
                    style="min-height:150px;line-height:2"
                    placeholder="دبي&#10;أبوظبي&#10;الشارقة&#10;الدوحة&#10;الرياض&#10;جدة&#10;الكويت"></textarea>
        </div>
      </div>
      <div class="ra-form-row">
        <div class="ra-form-group">
          <label>التصنيف</label>
          <input type="text" id="ra-gen-category" class="ra-input ra-full" placeholder="سيُنشأ تلقائياً">
        </div>
        <div class="ra-form-group">
          <label>الدولة</label>
          <select id="ra-gen-country" class="ra-select ra-full">
            <option value="ae">🇦🇪 الإمارات</option><option value="sa">🇸🇦 السعودية</option>
            <option value="qa">🇶🇦 قطر</option><option value="kw">🇰🇼 الكويت</option>
            <option value="bh">🇧🇭 البحرين</option><option value="om">🇴🇲 عمان</option><option value="eg">🇪🇬 مصر</option>
          </select>
        </div>
      </div>
      <div class="ra-form-row">
        <div class="ra-form-group">
          <label>حالة المقال</label>
          <select id="ra-gen-status" class="ra-select ra-full">
            <option value="draft">📝 مسودة (للمراجعة)</option>
            <option value="publish">🚀 منشور مباشرة</option>
          </select>
        </div>
        <div class="ra-form-group">
          <label>الأسلوب</label>
          <select id="ra-gen-tone" class="ra-select ra-full">
            <option>احترافي</option><option>تسويقي</option><option>ودي</option>
          </select>
        </div>
      </div>
      <button class="ra-btn ra-btn-primary ra-full" id="ra-calc-btn">🔢 حساب التركيبات وابدأ</button>
      <div id="ra-calc-info" style="display:none;margin-top:10px;padding:12px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;font-size:13px;color:#065f46"></div>
    </div>
  </div>

  <div class="ra-card">
    <div class="ra-card-head">📊 تقدم التوليد</div>
    <div class="ra-card-body">
      <div id="ra-gen-empty" style="text-align:center;padding:40px;color:#aaa">
        <div style="font-size:48px;margin-bottom:12px">🤖</div>
        <div>أدخل الخدمات والمدن وابدأ</div>
      </div>
      <div id="ra-gen-prog-wrap" style="display:none">
        <div style="display:flex;justify-content:space-between;margin-bottom:8px">
          <span id="ra-gen-done-count" style="font-weight:700">0 / 0</span>
          <span id="ra-gen-eta" style="font-size:12px;color:#888"></span>
        </div>
        <div class="ra-progress-wrap" style="margin-bottom:10px"><div class="ra-progress-bar" id="ra-gen-prog-bar" style="width:0%">0%</div></div>
        <div id="ra-gen-log" style="font-size:11px;color:#555;max-height:200px;overflow-y:auto;background:#f9fafb;border:1px solid #e5e7eb;padding:8px;border-radius:6px;font-family:monospace"></div>
        <div id="ra-gen-done-msg" style="display:none;margin-top:12px;padding:14px;background:#d1fae5;border-radius:8px;color:#065f46;font-weight:700;text-align:center">
          🎉 اكتمل التوليد — <span id="ra-gen-final"></span>
          <br><a href="<?php echo admin_url('edit.php?post_status=draft');?>" style="color:#059669;font-size:13px">← عرض المسودات</a>
        </div>
        <button class="ra-btn ra-btn-outline ra-full" id="ra-gen-stop-btn" style="margin-top:10px">⏸️ إيقاف</button>
      </div>
    </div>
  </div>
</div>

<!-- معاينة العناوين -->
<div id="ra-titles-preview" class="ra-card" style="display:none">
  <div class="ra-card-head">👀 عينة من العناوين</div>
  <div class="ra-card-body"><div id="ra-titles-list" style="display:flex;flex-wrap:wrap;gap:8px"></div></div>
</div>
</div>

<style>
.ra-tab-btn{padding:9px 18px;border:none;background:transparent;border-radius:6px;font-family:'Cairo',sans-serif;font-size:13px;font-weight:700;cursor:pointer;transition:all .2s;color:#555}
.ra-tab-active{background:#fff;color:#0073aa;box-shadow:0 1px 4px rgba(0,0,0,.1)}
</style>

<script>
var stopFlag=false,genStopFlag=false,postsList=[],currentIdx=0;
var genQueueKey='',genTotal=0,genDone=0,genStart=0;

function raTab(id,btn){
  ['tu','tg'].forEach(function(t){document.getElementById(t).style.display=t===id?'block':'none';});
  document.querySelectorAll('.ra-tab-btn').forEach(function(b){b.classList.remove('ra-tab-active');});
  btn.classList.add('ra-tab-active');
}

// ── جلب المقالات ──
document.getElementById('ra-load-posts-btn').addEventListener('click',function(){
  var cat=document.getElementById('ra-cat-select').value;
  if(!cat){alert('اختر تصنيفاً أولاً');return;}
  var btn=this;btn.textContent='⏳ جاري الجلب...';btn.disabled=true;

  jQuery.post(RUKN_AI.ajax,{
    action:'rukn_get_category_posts',nonce:RUKN_AI.nonce,
    category_id:cat,
    short_only:document.getElementById('ra-short-only').checked?1:0,
  },function(res){
    btn.textContent='📋 جلب المقالات';btn.disabled=false;
    if(!res.success){
      document.getElementById('ra-empty-state').innerHTML=
        '<div style="color:#dc3545;padding:16px;text-align:center;font-size:13px">❌ '+res.data.replace(/\n/g,'<br>')+'</div>';
      document.getElementById('ra-empty-state').style.display='block';
      document.getElementById('ra-posts-preview').style.display='none';
      return;
    }
    postsList=res.data.posts;
    document.getElementById('ra-empty-state').style.display='none';
    document.getElementById('ra-posts-preview').style.display='block';
    document.getElementById('ra-posts-count').textContent='📝 '+res.data.total+' مقالة';
    document.getElementById('ra-short-count').textContent=(res.data.short_count||0)+' قصيرة';
    var html='';
    postsList.forEach(function(p,i){
      var badge=p.short?'<span style="background:#fef3c7;color:#92400e;padding:1px 7px;border-radius:10px;font-size:10px">⚠️</span>':'';
      html+='<div id="prow-'+p.id+'" style="padding:5px 8px;border-bottom:1px solid #f0f0f0;font-size:12px;display:flex;align-items:center;gap:6px">'
        +'<span id="pst-'+p.id+'">⏳</span>'+badge
        +'<span style="flex:1">'+(i+1)+'. '+p.title+'</span>'
        +'<span style="color:#999;font-size:11px">'+(p.word_count||0)+' كلمة</span>'
        +'</div>';
    });
    document.getElementById('ra-posts-list').innerHTML=html||'<div style="text-align:center;padding:10px;color:#aaa">لا شيء</div>';
    document.getElementById('ra-done-msg').style.display='none';
    document.getElementById('ra-progress-bar').style.width='0%';
    document.getElementById('ra-progress-bar').textContent='0%';
    document.getElementById('ra-progress-log').innerHTML='';
    currentIdx=0;
  });
});

document.getElementById('ra-start-btn').addEventListener('click',function(){
  if(!postsList.length)return;
  stopFlag=false;currentIdx=0;
  this.style.display='none';
  document.getElementById('ra-stop-btn').style.display='block';
  document.getElementById('ra-done-msg').style.display='none';
  processNext();
});
document.getElementById('ra-stop-btn').addEventListener('click',function(){stopFlag=true;this.textContent='⏸️...';});

function processNext(){
  if(stopFlag||currentIdx>=postsList.length){
    document.getElementById('ra-start-btn').style.display='block';
    document.getElementById('ra-stop-btn').style.display='none';
    document.getElementById('ra-stop-btn').textContent='⏸️ إيقاف';
    if(!stopFlag)document.getElementById('ra-done-msg').style.display='block';
    return;
  }
  var p=postsList[currentIdx];
  var pct=Math.round(currentIdx/postsList.length*100);
  document.getElementById('ra-progress-bar').style.width=pct+'%';
  document.getElementById('ra-progress-bar').textContent=pct+'%';
  var el=document.getElementById('pst-'+p.id);
  if(el)el.textContent='🔄';
  addULog('🔄 '+(currentIdx+1)+'/'+postsList.length+': '+p.title);
  jQuery.post(RUKN_AI.ajax,{
    action:'rukn_update_post_ai',nonce:RUKN_AI.nonce,post_id:p.id,
    rewrite:document.getElementById('ra-rewrite').checked?1:0,
    add_schema:document.getElementById('ra-schema').checked?1:0,
    complete_blocks:document.getElementById('ra-blocks').checked?1:0,
    keyword:document.getElementById('ra-keyword').value,
    tone:document.getElementById('ra-tone').value,
  },function(res){
    if(el)el.textContent=res.success?'✅':'❌';
    addULog(res.success?'✅ '+p.title+' — '+((res.data.changes||[]).join(', ')):'❌ '+p.title+': '+(res.data||'خطأ'));
    currentIdx++;setTimeout(processNext,2000);
  }).fail(function(){
    if(el)el.textContent='⚠️';
    addULog('⚠️ اتصال: '+p.title);currentIdx++;setTimeout(processNext,3000);
  });
}
function addULog(msg){var el=document.getElementById('ra-progress-log');el.innerHTML+='<div>'+new Date().toLocaleTimeString('ar')+' — '+msg+'</div>';el.scrollTop=el.scrollHeight;}

// ── مولّد المقالات ──
document.getElementById('ra-calc-btn').addEventListener('click',function(){
  var sv=document.getElementById('ra-services').value.trim();
  var cv=document.getElementById('ra-cities').value.trim();
  if(!sv||!cv){alert('أدخل الخدمات والمدن');return;}
  var sArr=sv.split('\n').filter(function(s){return s.trim();});
  var cArr=cv.split('\n').filter(function(c){return c.trim();});
  var total=sArr.length*cArr.length;
  if(!total){alert('لا توجد تركيبات');return;}
  if(total>200&&!confirm('عدد المقالات: '+total+'. هل تريد المتابعة؟'))return;

  // معاينة
  var preview=[];
  sArr.forEach(function(s){cArr.forEach(function(c){
    var svc=s.trim().endsWith('في')?s.trim()+' '+c.trim():s.trim()+' في '+c.trim();
    preview.push('شركة '+svc);
  });});
  document.getElementById('ra-titles-preview').style.display='block';
  document.getElementById('ra-titles-list').innerHTML=preview.slice(0,15).map(function(t){
    return '<span style="background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;padding:3px 9px;border-radius:20px;font-size:12px">'+t+'</span>';
  }).join('')+(preview.length>15?'<span style="color:#999;font-size:12px">... و '+(preview.length-15)+' أخرى</span>':'');

  document.getElementById('ra-calc-info').innerHTML=
    '<strong>📊 '+total+' مقالة</strong> ('+sArr.length+' خدمة × '+cArr.length+' مدينة) | '
    +'⏱️ ~'+Math.ceil(total*1.2)+' دقيقة | '
    +'<button class="ra-btn ra-btn-primary" id="ra-start-gen-btn" style="margin-right:10px">🚀 ابدأ التوليد</button>';
  document.getElementById('ra-calc-info').style.display='block';
  document.getElementById('ra-start-gen-btn').addEventListener('click',startGen);
});

document.getElementById('ra-gen-stop-btn').addEventListener('click',function(){genStopFlag=true;this.textContent='⏸️...';});

function startGen(){
  document.getElementById('ra-start-gen-btn').disabled=true;
  document.getElementById('ra-start-gen-btn').textContent='⏳ جاري البدء...';
  genStopFlag=false;
  jQuery.post(RUKN_AI.ajax,{
    action:'rukn_bulk_generate_start',nonce:RUKN_AI.nonce,
    services:document.getElementById('ra-services').value,
    cities:document.getElementById('ra-cities').value,
    category:document.getElementById('ra-gen-category').value,
    post_status:document.getElementById('ra-gen-status').value,
    tone:document.getElementById('ra-gen-tone').value,
    country:document.getElementById('ra-gen-country').value,
  },function(res){
    if(!res.success){alert('❌ '+res.data);document.getElementById('ra-start-gen-btn').disabled=false;return;}
    genQueueKey=res.data.queue_key;genTotal=res.data.total;genDone=0;genStart=Date.now();
    document.getElementById('ra-gen-empty').style.display='none';
    document.getElementById('ra-gen-prog-wrap').style.display='block';
    document.getElementById('ra-gen-done-count').textContent='0 / '+genTotal;
    addGLog('🚀 بدأ التوليد: '+genTotal+' مقالة');
    genNext(0);
  });
}

function genNext(idx){
  if(genStopFlag||idx>=genTotal){
    document.getElementById('ra-gen-stop-btn').textContent='⏸️ إيقاف';
    if(!genStopFlag){
      document.getElementById('ra-gen-done-msg').style.display='block';
      document.getElementById('ra-gen-final').textContent=genDone+' مقالة';
    }
    return;
  }
  jQuery.post(RUKN_AI.ajax,{action:'rukn_bulk_generate_single',nonce:RUKN_AI.nonce,queue_key:genQueueKey,index:idx},
  function(res){
    if(!res.success){addGLog('❌ خطأ');setTimeout(function(){genNext(idx+1);},3000);return;}
    var d=res.data;genDone=d.done;
    document.getElementById('ra-gen-prog-bar').style.width=d.percent+'%';
    document.getElementById('ra-gen-prog-bar').textContent=d.percent+'%';
    document.getElementById('ra-gen-done-count').textContent=d.done+' / '+d.total;
    var el=(Date.now()-genStart)/1000,pr=el/(d.done||1),rm=Math.round(pr*(d.total-d.done));
    document.getElementById('ra-gen-eta').textContent=rm>0?'⏱️ ~'+rm+'ث':'';
    if(d.result&&d.result.title)addGLog('✅ '+d.result.title+(d.result.word_count?' ('+d.result.word_count+' كلمة)':''));
    else if(d.result&&d.result.error)addGLog('❌ '+d.result.error);
    if(d.is_done){document.getElementById('ra-gen-done-msg').style.display='block';document.getElementById('ra-gen-final').textContent=d.done+' مقالة';}
    else setTimeout(function(){genNext(d.next_index);},3000);
  }).fail(function(){addGLog('⚠️ إعادة المحاولة...');setTimeout(function(){genNext(idx);},5000);});
}
function addGLog(msg){var el=document.getElementById('ra-gen-log');el.innerHTML+='<div>'+new Date().toLocaleTimeString('ar')+' — '+msg+'</div>';el.scrollTop=el.scrollHeight;}
</script>
</div>

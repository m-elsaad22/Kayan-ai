<?php
defined('ABSPATH') || exit;
global $wpdb;

// رسائل
$msg = $_GET['msg'] ?? '';

// فلاتر
$f_type   = sanitize_text_field($_GET['type']    ?? '');
$f_date   = sanitize_text_field($_GET['date']    ?? '');
$f_search = sanitize_text_field($_GET['search']  ?? '');
$orderby  = sanitize_text_field($_GET['orderby'] ?? 'click_time');
$order    = ($_GET['order']??'DESC')==='ASC'?'ASC':'DESC';
$paged    = max(1,(int)($_GET['paged']??1));
$per_page = 30;

$args     = compact('f_type','f_date','f_search','orderby','order','paged','per_page');
$args['type']    = $f_type;
$args['date']    = $f_date;
$args['search']  = $f_search;

$rows     = Rukn_AI_DB::get_clicks($args);
$total    = Rukn_AI_DB::count_clicks($args);
$pages    = ceil($total / $per_page);

// إحصائيات
$all_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks");
$wa_count  = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks WHERE click_type='whatsapp'");
$ph_count  = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks WHERE click_type='call'");
$td_count  = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks WHERE DATE(click_time)=CURDATE()");

// أكثر الصفحات ضغطاً
$top_pages = $wpdb->get_results("SELECT page_title,page_url,COUNT(*) clicks FROM {$wpdb->prefix}rukn_clicks GROUP BY page_url ORDER BY clicks DESC LIMIT 5");

// أكثر IPs ضغطاً
$top_ips = $wpdb->get_results("SELECT user_ip,COUNT(*) clicks FROM {$wpdb->prefix}rukn_clicks GROUP BY user_ip ORDER BY clicks DESC LIMIT 10");

$base_url = admin_url('admin.php?page=rukn-ai-clicks');
?>
<div class="wrap ra-wrap" dir="rtl">

<?php if($msg): ?>
<div class="notice notice-success is-dismissible"><p><?php echo $msg==='deleted'?'✅ تم حذف السجل':'✅ تم حذف جميع السجلات';?></p></div>
<?php endif; ?>

<div class="ra-header">
  <div class="ra-header-icon">💬</div>
  <div>
    <h1 class="ra-title">تتبع ضغطات الواتساب والاتصال</h1>
    <p class="ra-sub">تقرير تفصيلي — الـ IP الأكثر ضغطاً يُلوَّن تلقائياً</p>
  </div>
  <div class="ra-header-actions">
    <a href="<?php echo esc_url(add_query_arg('rukn_export_clicks','1',$base_url));?>" class="ra-btn ra-btn-green">⬇️ تصدير CSV</a>
    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="display:inline"
          onsubmit="return confirm('حذف جميع السجلات؟')">
      <?php wp_nonce_field('rukn_del_all_clicks'); ?>
      <input type="hidden" name="action" value="rukn_del_all_clicks">
      <button type="submit" class="ra-btn ra-btn-red">🗑️ حذف الكل</button>
    </form>
  </div>
</div>

<!-- إحصائيات -->
<div class="ra-kpi-grid">
  <?php foreach([
    ['🔢','إجمالي الضغطات',$all_count,'#6c757d'],
    ['💬','واتساب',$wa_count,'#25d366'],
    ['📞','اتصال',$ph_count,'#0073aa'],
    ['📅','اليوم',$td_count,'#fd7e14'],
  ] as [$ic,$lb,$n,$cl]): ?>
  <div class="ra-kpi" style="border-top:4px solid <?php echo $cl;?>">
    <span class="ra-kpi-num" style="color:<?php echo $cl;?>"><?php echo number_format($n);?></span>
    <span class="ra-kpi-lbl"><?php echo $ic.' '.$lb;?></span>
  </div>
  <?php endforeach; ?>
</div>

<!-- أكثر الصفحات -->
<?php if($top_pages): ?>
<div class="ra-card ra-mb">
  <div class="ra-card-head">🏆 أكثر الصفحات ضغطاً</div>
  <div class="ra-card-body">
    <?php foreach($top_pages as $tp): ?>
    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f0f0f0">
      <a href="<?php echo esc_url($tp->page_url);?>" target="_blank" style="color:#0073aa;text-decoration:none;max-width:75%;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">
        <?php echo esc_html($tp->page_title ?: $tp->page_url);?>
      </a>
      <span style="background:#0073aa;color:#fff;padding:2px 11px;border-radius:20px;font-size:12px;font-weight:700"><?php echo (int)$tp->clicks;?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<div class="ra-grid-2 ra-mb">
  <!-- جدول السجلات -->
  <div class="ra-card" style="grid-column:1/-1">
    <div class="ra-card-head" style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px">
      <span>📋 سجل الضغطات <small style="color:#999">(<?php echo number_format($total);?> سجل)</small></span>

      <!-- فلاتر -->
      <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <input type="hidden" name="page" value="rukn-ai-clicks">
        <select name="type" class="ra-select">
          <option value="">كل الأنواع</option>
          <option value="whatsapp" <?php selected($f_type,'whatsapp');?>>💬 واتساب</option>
          <option value="call"     <?php selected($f_type,'call');?>>📞 اتصال</option>
        </select>
        <input type="date"   name="date"   class="ra-input" value="<?php echo esc_attr($f_date);?>">
        <input type="search" name="search" class="ra-input" value="<?php echo esc_attr($f_search);?>" placeholder="🔍 بحث عنوان / رابط / IP">
        <select name="orderby" class="ra-select">
          <option value="click_time" <?php selected($orderby,'click_time');?>>ترتيب: التاريخ</option>
          <option value="ip_total"   <?php selected($orderby,'ip_total');?>>ترتيب: أكثر ضغطاً (IP)</option>
          <option value="user_ip"    <?php selected($orderby,'user_ip');?>>ترتيب: IP</option>
        </select>
        <select name="order" class="ra-select">
          <option value="DESC" <?php selected($order,'DESC');?>>تنازلي</option>
          <option value="ASC"  <?php selected($order,'ASC');?>>تصاعدي</option>
        </select>
        <button type="submit" class="ra-btn ra-btn-primary">بحث</button>
        <a href="<?php echo esc_url($base_url);?>" class="ra-btn ra-btn-outline">✕</a>
      </form>
    </div>

    <div class="ra-card-body" style="padding:0;overflow-x:auto">
      <table class="ra-table">
        <thead><tr>
          <th>#</th>
          <th>النوع</th>
          <th style="min-width:300px">عنوان الصفحة / المقال <span style="font-size:10px;opacity:.6">(كامل)</span></th>
          <th>التاريخ</th>
          <th>الوقت</th>
          <th>
            <a href="<?php echo esc_url(add_query_arg(['orderby'=>'user_ip','order'=>$order==='ASC'?'DESC':'ASC'],$base_url));?>" style="color:inherit;text-decoration:none">
              IP <?php echo $orderby==='user_ip'?($order==='ASC'?'↑':'↓'):'';?>
            </a>
          </th>
          <th>
            <a href="<?php echo esc_url(add_query_arg(['orderby'=>'ip_total','order'=>$order==='ASC'?'DESC':'ASC'],$base_url));?>" style="color:inherit;text-decoration:none">
              ضغطات الـ IP <?php echo $orderby==='ip_total'?($order==='ASC'?'↑':'↓'):'⇅';?>
            </a>
          </th>
          <th>خطورة</th>
          <th></th>
        </tr></thead>
        <tbody>
        <?php if(empty($rows)): ?>
          <tr><td colspan="9" style="text-align:center;padding:30px;color:#aaa">لا توجد سجلات</td></tr>
        <?php else: foreach($rows as $r):
            $ip_total = (int)($r->ip_total ?? 0);
            $ip_style = Rukn_AI_Helper::ip_color_style($ip_total);
            $dt = new DateTime($r->click_time);
        ?>
          <tr>
            <td style="color:#bbb;font-size:11px"><?php echo (int)$r->id;?></td>
            <td>
              <?php if($r->click_type==='whatsapp'): ?>
                <span style="background:#d4f5e2;color:#1a7a45;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:700">💬 واتساب</span>
              <?php else: ?>
                <span style="background:#d0e8ff;color:#00508a;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:700">📞 اتصال</span>
              <?php endif; ?>
            </td>
            <td>
              <!-- عرض الاسم كامل بدون اختصار -->
              <div style="font-weight:600;font-size:13px"><?php echo esc_html($r->page_title ?: '—');?></div>
              <div style="font-size:11px;margin-top:3px">
                <a href="<?php echo esc_url($r->page_url);?>" target="_blank" style="color:#0073aa;word-break:break-all">
                  <?php echo esc_html($r->page_url);?>
                </a>
              </div>
              <?php if($r->post_type): ?>
              <div style="font-size:10px;color:#999;margin-top:2px"><?php echo esc_html($r->post_type);?></div>
              <?php endif; ?>
            </td>
            <td style="font-size:12px;color:#555;white-space:nowrap"><?php echo $dt->format('Y/m/d');?></td>
            <td style="font-size:13px;font-weight:600;white-space:nowrap"><?php echo $dt->format('H:i:s');?></td>
            <td style="font-size:12px;direction:ltr;<?php echo $ip_style;?>"><?php echo esc_html($r->user_ip);?></td>
            <td>
              <span style="font-weight:800;<?php echo $ip_style;?>"><?php echo $ip_total;?></span>
              <?php if($ip_total>=4) echo '<span style="font-size:10px;margin-right:4px">🔴</span>';
                    elseif($ip_total>=2) echo '<span style="font-size:10px;margin-right:4px">🟠</span>';
                    else echo '<span style="font-size:10px;margin-right:4px">🟢</span>'; ?>
            </td>
            <td>
              <?php if($ip_total>=4) echo '<span style="background:#fee2e2;color:#dc2626;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700">🔴 مرتفع</span>';
                    elseif($ip_total>=2) echo '<span style="background:#fed7aa;color:#ea580c;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700">🟠 متوسط</span>';
                    else echo '<span style="background:#d1fae5;color:#059669;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700">🟢 طبيعي</span>'; ?>
            </td>
            <td>
              <a href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action'=>'rukn_del_click','id'=>$r->id],admin_url('admin-post.php')),'rukn_del_click'));?>"
                 style="color:#dc2626;font-size:13px;opacity:.7"
                 onclick="return confirm('حذف هذا السجل؟')">✕</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <?php if($pages>1): ?>
    <div style="padding:12px 16px;border-top:1px solid #f0f0f0;display:flex;gap:5px;flex-wrap:wrap">
      <?php for($i=1;$i<=$pages;$i++): ?>
      <a href="<?php echo esc_url(add_query_arg(array_merge($_GET,['paged'=>$i]),$base_url));?>"
         style="padding:4px 11px;border:1px solid #ddd;border-radius:5px;font-size:13px;text-decoration:none;<?php echo $i===$paged?'background:#0073aa;color:#fff;border-color:#0073aa':'color:#333';?>">
        <?php echo $i;?>
      </a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- أكثر IPs -->
<?php if($top_ips): ?>
<div class="ra-card">
  <div class="ra-card-head">⚡ أكثر IPs ضغطاً</div>
  <div class="ra-card-body" style="padding:0">
    <table class="ra-table">
      <thead><tr><th>IP</th><th>الضغطات</th><th>مستوى الخطورة</th></tr></thead>
      <tbody>
      <?php foreach($top_ips as $ip):
        $n=(int)$ip->clicks;
        $style = Rukn_AI_Helper::ip_color_style($n); ?>
      <tr>
        <td style="font-family:monospace;<?php echo $style;?>"><?php echo esc_html($ip->user_ip);?></td>
        <td><strong style="<?php echo $style;?>"><?php echo $n;?></strong></td>
        <td>
          <?php if($n>=4) echo '<span style="background:#fee2e2;color:#dc2626;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700">🔴 مرتفع</span>';
                elseif($n>=2) echo '<span style="background:#fed7aa;color:#ea580c;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700">🟠 متوسط</span>';
                else echo '<span style="background:#d1fae5;color:#059669;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700">🟢 طبيعي</span>'; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

</div>

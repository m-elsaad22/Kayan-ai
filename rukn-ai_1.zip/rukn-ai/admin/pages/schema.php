<?php defined('ABSPATH') || exit;
global $wpdb;
$with_schema = (int)$wpdb->get_var("SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key='_rukn_schema'");
$total_posts = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type='post'");
$without = $total_posts - $with_schema;
?>
<div class="wrap ra-wrap" dir="rtl">
<div class="ra-header">
  <div class="ra-header-icon">📐</div>
  <div><h1 class="ra-title">إدارة Schema</h1><p class="ra-sub">إضافة Schema-LD JSON لمقالات موقعك</p></div>
</div>
<div class="ra-kpi-grid" style="grid-template-columns:repeat(3,1fr)">
  <div class="ra-kpi" style="border-top:4px solid #0073aa"><span class="ra-kpi-num" style="color:#0073aa"><?php echo $total_posts;?></span><span class="ra-kpi-lbl">📝 إجمالي المقالات</span></div>
  <div class="ra-kpi" style="border-top:4px solid #25d366"><span class="ra-kpi-num" style="color:#25d366"><?php echo $with_schema;?></span><span class="ra-kpi-lbl">✅ لديها Schema</span></div>
  <div class="ra-kpi" style="border-top:4px solid #fd7e14"><span class="ra-kpi-num" style="color:#fd7e14"><?php echo $without;?></span><span class="ra-kpi-lbl">⚠️ بدون Schema</span></div>
</div>
<div class="ra-card">
  <div class="ra-card-head">⚙️ إضافة Schema بالجملة</div>
  <div class="ra-card-body">
    <?php if(!Rukn_AI_Claude::is_ready()): ?><div class="notice notice-warning inline"><p>⚠️ أضف مفتاح Claude API أولاً.</p></div><?php endif; ?>
    <p style="margin-bottom:16px">سيضيف Claude AI Schema مناسب لكل مقال (Article + FAQ + Service + LocalBusiness) — يعالج 10 مقالات في كل طلب.</p>
    <button class="ra-btn ra-btn-primary" id="ra-bulk-schema-btn">🚀 ابدأ إضافة Schema (<?php echo $without;?> مقالة)</button>
    <span id="ra-schema-progress" style="margin-right:14px;font-size:14px;font-weight:700"></span>
    <div class="ra-progress-wrap" id="ra-schema-prog-wrap" style="display:none;margin-top:14px">
      <div class="ra-progress-bar" id="ra-schema-prog-bar" style="width:0%">0%</div>
    </div>
  </div>
</div>
<script>
document.getElementById('ra-bulk-schema-btn').addEventListener('click',function(){
  if(!confirm('ابدأ إضافة Schema لـ <?php echo $without;?> مقالة؟'))return;
  var btn=this;btn.disabled=true;
  document.getElementById('ra-schema-prog-wrap').style.display='block';
  var total=<?php echo $without;?>,done=0;
  function batch(){
    jQuery.post(RUKN_AI.ajax,{action:'rukn_bulk_schema',nonce:RUKN_AI.nonce},function(res){
      if(res.success){
        if(res.data.done){document.getElementById('ra-schema-progress').textContent='✅ اكتمل';btn.disabled=false;return;}
        done+=res.data.processed||10;
        var pct=total?Math.min(100,Math.round(done/total*100)):100;
        document.getElementById('ra-schema-prog-bar').style.width=pct+'%';
        document.getElementById('ra-schema-prog-bar').textContent=pct+'%';
        document.getElementById('ra-schema-progress').textContent=done+' من '+total;
        setTimeout(batch,2000);
      }
    });
  }
  batch();
});
</script>
</div>

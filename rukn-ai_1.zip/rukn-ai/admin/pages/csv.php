<?php defined('ABSPATH') || exit;
$pages_meta = [
  'generator' => ['🚀','مولّد المقالات الجديدة','ولّد مقالات SEO جديدة لأي خدمة ومدينة'],
  'csv'       => ['📥','استيراد CSV','استيراد مقالات بالجملة من ملف CSV (114 عمود)'],
  'translate' => ['🌐','الترجمة الذكية','ترجمة المحتوى لـ 8 لغات بـ Claude AI'],
  'tracking'  => ['📈','إحصائيات الزوار','الجلسات والصفحات والمزيد'],
  'settings'  => ['⚙️','الإعدادات','مفتاح Claude API وإعدادات الإضافة'],
  'dashboard' => ['📊','لوحة التحكم','نظرة عامة على الإضافة'],
];
$p = basename(__FILE__,'.php');
$m = $pages_meta[$p];
?>
<div class="wrap ra-wrap" dir="rtl">
<div class="ra-header">
  <div class="ra-header-icon"><?php echo $m[0];?></div>
  <div><h1 class="ra-title"><?php echo $m[1];?></h1><p class="ra-sub"><?php echo $m[2];?></p></div>
</div>
<?php include RUKN_AI_PATH.'admin/pages/partials/'.$p.'-body.php'; ?>
</div>

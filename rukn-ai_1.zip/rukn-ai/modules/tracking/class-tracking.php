<?php
defined('ABSPATH') || exit;

/* ══════════════════════════════════════════════════════════
   TRACKING MODULE (زوار + جلسات)
══════════════════════════════════════════════════════════ */
class Rukn_AI_Tracking {

    public static function init(): void {
        if(!Rukn_AI_Helper::opt('tracking_enabled','1')) return;
        add_action('wp_footer', [__CLASS__,'script'], 100);
        add_action('wp_ajax_rukn_track_pv',        [__CLASS__,'record_pv']);
        add_action('wp_ajax_nopriv_rukn_track_pv', [__CLASS__,'record_pv']);
    }

    public static function record_pv(): void {
        global $wpdb;
        $sid = sanitize_text_field($_POST['sid'] ?? '');
        $url = esc_url_raw($_POST['url'] ?? '');
        if(!$sid||!$url){ wp_send_json_success(); return; }
        $ip = Rukn_AI_Helper::get_user_ip();

        // Session upsert
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}rukn_sessions WHERE session_id=%s",$sid));
        if(!$exists){
            $wpdb->insert($wpdb->prefix.'rukn_sessions',[
                'session_id'=>$sid,'user_ip'=>$ip,
                'device'=>Rukn_AI_Helper::get_device(),
                'browser'=>Rukn_AI_Helper::get_browser(),
                'referrer'=>esc_url_raw($_POST['referrer']??''),
                'landing_url'=>$url,
            ],['%s','%s','%s','%s','%s','%s']);
        } else {
            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->prefix}rukn_sessions SET pages_count=pages_count+1,updated_at=NOW() WHERE session_id=%s",$sid));
        }
        // Page view
        $wpdb->insert($wpdb->prefix.'rukn_pageviews',[
            'session_id'=>$sid,'post_id'=>intval($_POST['post_id']??0)?:null,
            'page_url'=>$url,'page_title'=>sanitize_text_field($_POST['title']??''),
        ],['%s','%d','%s','%s']);
        wp_send_json_success();
    }

    public static function script(): void {
        global $post;
        ?>
<script>
(function(){
  var S=sessionStorage.getItem('_rsa_sid');
  if(!S){S='rsa_'+Date.now()+'_'+Math.random().toString(36).slice(2,8);sessionStorage.setItem('_rsa_sid',S);}
  var d=new URLSearchParams();
  d.append('action','rukn_track_pv');d.append('sid',S);
  d.append('url',location.href);d.append('title',document.title);
  d.append('referrer',document.referrer||'');
  d.append('post_id','<?php echo (int)($post?->ID??0);?>');
  navigator.sendBeacon?navigator.sendBeacon('<?php echo esc_js(admin_url('admin-ajax.php'));?>',d):null;
})();
</script>
        <?php
    }
}
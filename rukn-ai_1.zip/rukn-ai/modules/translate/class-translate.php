<?php
defined('ABSPATH') || exit;

/* ══════════════════════════════════════════════════════════
   TRANSLATE MODULE
══════════════════════════════════════════════════════════ */
class Rukn_AI_Translate {

    public static function init(): void {
        add_action('wp_ajax_rukn_translate_text', [__CLASS__,'ajax_translate']);
        add_action('wp_ajax_rukn_translate_post', [__CLASS__,'ajax_translate_post']);
    }

    public static function ajax_translate(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        $text = sanitize_textarea_field($_POST['text']??'');
        $from = sanitize_text_field($_POST['from']??'ar');
        $to   = sanitize_text_field($_POST['to']??'en');
        if(!$text) wp_send_json_error('النص فارغ');
        if(!Rukn_AI_Claude::is_ready()) wp_send_json_error('أضف مفتاح Claude API');
        $result = Rukn_AI_Claude::translate($text,$from,$to);
        wp_send_json_success(['text'=>$result]);
    }

    public static function ajax_translate_post(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        $post_id = (int)($_POST['post_id']??0);
        $to      = sanitize_text_field($_POST['to']??'en');
        if(!$post_id) wp_send_json_error();
        $post = get_post($post_id);
        $translated_title   = Rukn_AI_Claude::translate($post->post_title,'ar',$to);
        $translated_content = Rukn_AI_Claude::translate(strip_tags($post->post_content),'ar',$to);
        wp_send_json_success(['title'=>$translated_title,'content'=>$translated_content]);
    }
}
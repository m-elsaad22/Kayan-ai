<?php
defined('ABSPATH') || exit;

/* ══════════════════════════════════════════════════════════
   CSV IMPORTER
══════════════════════════════════════════════════════════ */
class Rukn_AI_CSV_Importer {

    public static function init(): void {
        add_action('wp_ajax_rukn_import_batch', [__CLASS__,'ajax_batch']);
        add_action('wp_ajax_rukn_import_reset', [__CLASS__,'ajax_reset']);
    }

    public static function ajax_batch(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        if(!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $offset     = (int)($_POST['offset'] ?? 0);
        $batch_size = 5;
        $trans_key  = 'rukn_import_session_'.$session_id;
        $session    = get_transient($trans_key);
        if(!$session){ wp_send_json_error('جلسة الاستيراد منتهية'); }

        $rows    = $session['rows'];
        $headers = $session['headers'];
        $total   = count($rows);
        $slice   = array_slice($rows, $offset, $batch_size);
        $done    = 0; $errors = [];

        foreach($slice as $row){
            $data = array_combine($headers, $row);
            $result = self::insert_post($data);
            if(is_wp_error($result)) $errors[] = $result->get_error_message();
            else $done++;
        }

        $new_offset = $offset + $batch_size;
        $is_done    = $new_offset >= $total;

        wp_send_json_success([
            'done'       => $offset + $done,
            'total'      => $total,
            'percent'    => round(($offset + $done) / $total * 100),
            'is_done'    => $is_done,
            'errors'     => $errors,
            'next_offset'=> $new_offset,
        ]);
    }

    private static function insert_post(array $d): int|\WP_Error {
        global $wpdb;
        $title   = sanitize_text_field($d['post_title']   ?? $d['title']   ?? '');
        $content = wp_kses_post($d['post_content']        ?? $d['content'] ?? '');
        $slug    = sanitize_title($d['post_name']         ?? $d['slug']    ?? $title);
        $status  = sanitize_text_field($d['post_status']  ?? 'publish');
        $type    = sanitize_text_field($d['post_type']    ?? 'post');
        $date    = sanitize_text_field($d['post_date']    ?? '');
        $excerpt = sanitize_textarea_field($d['post_excerpt'] ?? '');
        $cats    = sanitize_text_field($d['categories']   ?? $d['category'] ?? '');
        $tags    = sanitize_text_field($d['tags']         ?? '');

        if(!$title) return new \WP_Error('missing_title','عنوان فارغ');

        $post_arr = array_filter([
            'post_title'   => $title,
            'post_content' => $content,
            'post_name'    => $slug,
            'post_status'  => $status,
            'post_type'    => $type,
            'post_excerpt' => $excerpt,
            'post_date'    => $date,
        ]);
        $post_id = wp_insert_post($post_arr, true);
        if(is_wp_error($post_id)) return $post_id;

        // Categories
        if($cats){
            $cat_ids = [];
            foreach(explode('|',$cats) as $cat_name){
                $cat_name = trim($cat_name);
                $cat = get_term_by('name',$cat_name,'category') ?: wp_insert_term($cat_name,'category');
                if(!is_wp_error($cat)) $cat_ids[] = is_array($cat)?$cat['term_id']:$cat->term_id;
            }
            if($cat_ids) wp_set_post_categories($post_id,$cat_ids);
        }
        // Tags
        if($tags) wp_set_post_tags($post_id, array_map('trim',explode('|',$tags)));

        // SEO Meta (Yoast, RankMath, AIOSEO)
        $meta_map = [
            '_yoast_wpseo_metadesc'   => ['meta_description','seo_description','yoast_meta_desc'],
            '_yoast_wpseo_focuskw'    => ['focus_keyword','yoast_focus_kw'],
            'rank_math_description'   => ['meta_description','seo_description'],
            'rank_math_focus_keyword' => ['focus_keyword'],
            '_aioseop_description'    => ['meta_description','seo_description'],
        ];
        foreach($meta_map as $meta_key => $possible_cols){
            foreach($possible_cols as $col){
                if(!empty($d[$col])){ update_post_meta($post_id,$meta_key,$d[$col]); break; }
            }
        }
        // أي عمود آخر → post meta
        $skip = ['post_title','title','post_content','content','post_name','slug','post_status',
                  'post_type','post_date','post_excerpt','categories','category','tags'];
        foreach($d as $col=>$val){
            if(!in_array($col,$skip,true)&&$val!=='') update_post_meta($post_id,$col,sanitize_textarea_field($val));
        }
        // Log
        $wpdb->insert($wpdb->prefix.'rukn_import_log',[
            'session_id'=>'batch','post_id'=>$post_id,'post_title'=>$title,'status'=>'ok'
        ],['%s','%d','%s','%s']);
        return $post_id;
    }

    public static function ajax_reset(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        $sid = sanitize_text_field($_POST['session_id']??'');
        delete_transient('rukn_import_session_'.$sid);
        wp_send_json_success();
    }
}
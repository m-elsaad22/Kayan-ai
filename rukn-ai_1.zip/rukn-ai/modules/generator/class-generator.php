<?php
defined('ABSPATH') || exit;

/* ══════════════════════════════════════════════════════════
   GENERATOR MODULE (مولّد مقالات جديدة)
══════════════════════════════════════════════════════════ */
class Rukn_AI_Generator {

    public static function init(): void {
        add_action('wp_ajax_rukn_generate_article',  [__CLASS__,'ajax_generate']);
        add_action('wp_ajax_rukn_publish_generated', [__CLASS__,'ajax_publish']);
    }

    public static function ajax_generate(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        if(!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');
        if(!Rukn_AI_Claude::is_ready()) wp_send_json_error('أضف مفتاح Claude API');

        $service  = sanitize_text_field($_POST['service']  ?? '');
        $city     = sanitize_text_field($_POST['city']     ?? '');
        $country  = sanitize_text_field($_POST['country']  ?? 'ae');
        $tone     = sanitize_text_field($_POST['tone']     ?? 'احترافي');
        $words    = (int)($_POST['words'] ?? 3000);
        $wa       = Rukn_AI_Helper::opt('whatsapp','');
        $phone    = Rukn_AI_Helper::opt('phone','');
        $company  = get_bloginfo('name');

        $countries = ['ae'=>'الإمارات','sa'=>'السعودية','qa'=>'قطر','kw'=>'الكويت','bh'=>'البحرين','om'=>'عمان','eg'=>'مصر'];
        $cn = $countries[$country] ?? $country;

        $prompt = "أنت كاتب محتوى SEO محترف متخصص في خدمات المنازل في {$cn}.
اكتب مقالاً SEO احترافياً بالعربية الفصحى.

الخدمة: {$service}
المدينة: {$city}
الدولة: {$cn}
عدد الكلمات: {$words}+ كلمة
الأسلوب: {$tone}
اسم الشركة: {$company}

هيكل المقال الإلزامي:
<!-- META_TITLE: عنوان SEO 60 حرف -->
<!-- META_DESC: وصف SEO 155 حرف -->
<h1>عنوان يحتوي {$service} في {$city}</h1>
<p>مقدمة 150 كلمة تذكر {$city} مرتين</p>
<h2>أفضل شركة {$service} في {$city}</h2>
<h2>مميزاتنا — 8 مميزات ul/li</h2>
<h2>خدماتنا — 6 خدمات ul/li</h2>
<h2>خطوات العمل — 5 خطوات ol/li</h2>
<h2>أسعار {$service} في {$city} — جدول HTML</h2>
<h2>مناطق خدمتنا في {$city} — 5 أحياء</h2>
<h2>لماذا نحن — 6 نقاط</h2>
<h2>أسئلة شائعة — 7 أسئلة details/summary</h2>
<!-- شريحة CTA ملوّنة مع " . ($wa?"واتساب {$wa} ":"") . ($phone?"هاتف {$phone}":"") . " -->
<p>خاتمة + call to action</p>
<script type=\"application/ld+json\"><!-- schema FAQPage --></script>

أجب بـ HTML فقط، لا شرح.";

        $html = Rukn_AI_Claude::ask($prompt, '', $words * 2);
        if(!$html) wp_send_json_error('فشل التوليد، تحقق من مفتاح API');

        preg_match('/<!--\s*META_TITLE:\s*(.+?)\s*-->/i', $html, $tm);
        preg_match('/<!--\s*META_DESC:\s*(.+?)\s*-->/i',  $html, $dm);

        $meta_title = trim($tm[1] ?? "{$service} في {$city}");
        $meta_desc  = trim($dm[1] ?? "أفضل شركة {$service} في {$city}.");
        $clean_html = trim(preg_replace('/<!--\s*META_(?:TITLE|DESC):.+?-->/i','',$html));

        // حفظ مؤقت
        $key = 'rukn_gen_'.get_current_user_id().'_'.time();
        set_transient($key,[
            'html'=>$clean_html,'title'=>$meta_title,'meta_desc'=>$meta_desc,
            'service'=>$service,'city'=>$city,
        ], HOUR_IN_SECONDS);

        wp_send_json_success([
            'key'        => $key,
            'title'      => $meta_title,
            'meta_desc'  => $meta_desc,
            'html'       => $clean_html,
            'word_count' => str_word_count(strip_tags($clean_html)),
        ]);
    }

    public static function ajax_publish(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        if(!current_user_can('publish_posts')) wp_send_json_error('Unauthorized');
        $key  = sanitize_key($_POST['key']??'');
        $data = get_transient($key);
        if(!$data) wp_send_json_error('انتهت الجلسة');

        $cat_name = sanitize_text_field($_POST['category']??'');
        $cat_ids  = [];
        if($cat_name){
            $c = get_term_by('name',$cat_name,'category') ?: wp_insert_term($cat_name,'category');
            if(!is_wp_error($c)) $cat_ids = [is_array($c)?$c['term_id']:$c->term_id];
        }
        $post_id = wp_insert_post([
            'post_title'      => $data['title'],
            'post_content'    => $data['html'],
            'post_status'     => 'publish',
            'post_type'       => 'post',
            'post_category'   => $cat_ids,
        ], true);
        if(is_wp_error($post_id)) wp_send_json_error($post_id->get_error_message());

        update_post_meta($post_id,'_yoast_wpseo_metadesc', $data['meta_desc']);
        update_post_meta($post_id,'rank_math_description',  $data['meta_desc']);
        update_post_meta($post_id,'_yoast_wpseo_focuskw',  $data['service'].' '.$data['city']);
        Rukn_AI_Schema::add_to_post($post_id);
        delete_transient($key);
        wp_send_json_success(['post_id'=>$post_id,'url'=>get_permalink($post_id)]);
    }
}
<?php
defined('ABSPATH') || exit;

class Rukn_AI_Click_Tracker {

    public static function init(): void {
        add_action('wp_ajax_rukn_track_click',        [__CLASS__,'record']);
        add_action('wp_ajax_nopriv_rukn_track_click', [__CLASS__,'record']);
        add_action('wp_footer',  [__CLASS__,'script'], 99);
        add_action('admin_init', [__CLASS__,'maybe_export']);
        add_action('admin_post_rukn_del_click',     [__CLASS__,'delete_one']);
        add_action('admin_post_rukn_del_all_clicks',[__CLASS__,'delete_all']);
    }

    public static function record(): void {
        global $wpdb;
        $type = sanitize_text_field($_POST['click_type'] ?? '');
        $url  = esc_url_raw($_POST['page_url'] ?? '');
        if (!$type || !$url) { wp_send_json_error(); }
        $ip = Rukn_AI_Helper::get_user_ip();
        $wpdb->insert($wpdb->prefix.'rukn_clicks',[
            'click_type' => $type,
            'page_title' => sanitize_text_field($_POST['page_title'] ?? ''),
            'page_url'   => $url,
            'post_id'    => intval($_POST['post_id'] ?? 0) ?: null,
            'post_type'  => sanitize_text_field($_POST['post_type'] ?? ''),
            'click_time' => current_time('mysql'),
            'user_ip'    => $ip,
            'user_agent' => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'referrer'   => esc_url_raw($_POST['referrer'] ?? ''),
        ],['%s','%s','%s','%d','%s','%s','%s','%s','%s']);
        wp_send_json_success();
    }

    public static function script(): void {
        global $post;
        ?>
<script>
(function(){
  var A='<?php echo esc_js(admin_url('admin-ajax.php'));?>',
      P=<?php echo (int)($post?->ID??0);?>,
      T='<?php echo esc_js($post?->post_type??'');?>';
  function send(t){
    var d=new URLSearchParams();
    d.append('action','rukn_track_click');d.append('click_type',t);
    d.append('page_title',document.title);d.append('page_url',location.href);
    d.append('referrer',document.referrer||'');d.append('post_id',P);d.append('post_type',T);
    navigator.sendBeacon?navigator.sendBeacon(A,d):fetch(A,{method:'POST',body:d});
  }
  document.addEventListener('click',function(e){
    var el=e.target;while(el&&el.tagName!=='A')el=el.parentElement;
    if(!el||!el.href)return;
    var h=el.href.toLowerCase();
    if(h.includes('wa.me')||h.includes('whatsapp'))send('whatsapp');
    else if(h.startsWith('tel:'))send('call');
  },true);
})();
</script>
        <?php
    }

    public static function maybe_export(): void {
        if (!isset($_GET['rukn_export_clicks'])||!current_user_can('manage_options')) return;
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT c.*,(SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks c2 WHERE c2.user_ip=c.user_ip) ip_total
             FROM {$wpdb->prefix}rukn_clicks c ORDER BY click_time DESC"
        );
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="clicks-'.date('Y-m-d').'.csv"');
        $f=fopen('php://output','w');
        fprintf($f,chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($f,['#','النوع','عنوان الصفحة','رابط الصفحة','نوع المحتوى','التاريخ','IP','ضغطات الـIP','خطورة']);
        foreach($rows as $r){
            $t=(int)$r->ip_total;
            fputcsv($f,[$r->id,$r->click_type==='whatsapp'?'واتساب':'اتصال',
                $r->page_title,$r->page_url,$r->post_type,$r->click_time,$r->user_ip,$t,
                $t>=4?'مرتفع':($t>=2?'متوسط':'طبيعي')]);
        }
        fclose($f); exit;
    }

    public static function delete_one(): void {
        if(!current_user_can('manage_options')) wp_die();
        check_admin_referer('rukn_del_click');
        global $wpdb;
        $wpdb->delete($wpdb->prefix.'rukn_clicks',['id'=>(int)($_GET['id']??0)],['%d']);
        wp_safe_redirect(admin_url('admin.php?page=rukn-ai-clicks&msg=deleted')); exit;
    }

    public static function delete_all(): void {
        if(!current_user_can('manage_options')) wp_die();
        check_admin_referer('rukn_del_all_clicks');
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}rukn_clicks");
        wp_safe_redirect(admin_url('admin.php?page=rukn-ai-clicks&msg=cleared')); exit;
    }
}

<?php
defined('ABSPATH') || exit;

/* ══════════════════════════════════════════════════════════
   SCHEMA MODULE
══════════════════════════════════════════════════════════ */
class Rukn_AI_Schema {

    public static function init(): void {
        add_action('wp_head', [__CLASS__,'inject'], 3);
        add_action('wp_ajax_rukn_gen_schema',  [__CLASS__,'ajax_single']);
        add_action('wp_ajax_rukn_bulk_schema', [__CLASS__,'ajax_bulk']);
    }

    public static function inject(): void {
        if(!is_singular()) return;
        global $post;

        // Schema محفوظ
        $saved = get_post_meta($post->ID,'_rukn_schema',true);
        if($saved) echo '<script type="application/ld+json">'.$saved.'</script>'."\n";

        // FAQ Schema
        $faq = get_post_meta($post->ID,'_rukn_faq_schema',true);
        if($faq){
            $items = json_decode($faq,true);
            if(is_array($items)&&$items){
                $faq_schema = ['@context'=>'https://schema.org','@type'=>'FAQPage',
                    'mainEntity'=>array_map(fn($q)=>['@type'=>'Question','name'=>$q['question']??'',
                        'acceptedAnswer'=>['@type'=>'Answer','text'=>$q['answer']??'']],$items)];
                echo '<script type="application/ld+json">'.wp_json_encode($faq_schema,JSON_UNESCAPED_UNICODE).'</script>'."\n";
            }
        }

        // Article + Breadcrumb دائماً
        $site = get_bloginfo('name');
        $logo = get_site_icon_url(512);
        $article = ['@context'=>'https://schema.org','@type'=>'Article',
            'headline'=>$post->post_title,
            'url'=>get_permalink($post->ID),
            'datePublished'=>$post->post_date_gmt,
            'dateModified'=>$post->post_modified_gmt,
            'author'=>['@type'=>'Person','name'=>get_the_author_meta('display_name',$post->post_author)],
            'publisher'=>array_filter(['@type'=>'Organization','name'=>$site,
                'logo'=>$logo?['@type'=>'ImageObject','url'=>$logo]:null]),
            'inLanguage'=>'ar',
        ];
        if(has_post_thumbnail($post->ID)){
            $img=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'large');
            if($img) $article['image']=['@type'=>'ImageObject','url'=>$img[0],'width'=>$img[1],'height'=>$img[2]];
        }
        echo '<script type="application/ld+json">'.wp_json_encode($article,JSON_UNESCAPED_UNICODE).'</script>'."\n";

        // Breadcrumb
        $items=[['@type'=>'ListItem','position'=>1,'name'=>'الرئيسية','item'=>home_url('/')]];
        $cats = get_the_category($post->ID);
        if($cats){
            $items[]=['@type'=>'ListItem','position'=>2,'name'=>$cats[0]->name,'item'=>get_category_link($cats[0]->term_id)];
            $items[]=['@type'=>'ListItem','position'=>3,'name'=>$post->post_title,'item'=>get_permalink($post->ID)];
        }else{
            $items[]=['@type'=>'ListItem','position'=>2,'name'=>$post->post_title,'item'=>get_permalink($post->ID)];
        }
        $bc=['@context'=>'https://schema.org','@type'=>'BreadcrumbList','itemListElement'=>$items];
        echo '<script type="application/ld+json">'.wp_json_encode($bc,JSON_UNESCAPED_UNICODE).'</script>'."\n";
    }

    public static function add_to_post(int $post_id, bool $force=false): void {
        if(!$force && get_post_meta($post_id,'_rukn_schema',true)) return;
        if(!Rukn_AI_Claude::is_ready()) return;
        $schema = Rukn_AI_Claude::generate_schema($post_id);
        if(!empty($schema)){
            $json = wp_json_encode($schema,JSON_UNESCAPED_UNICODE);
            update_post_meta($post_id,'_rukn_schema',$json);
            global $wpdb;
            $wpdb->replace($wpdb->prefix.'rukn_schema_cache',
                ['post_id'=>$post_id,'schema_json'=>$json],['%d','%s']);
        }
    }

    public static function ajax_single(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        $pid=(int)($_POST['post_id']??0);
        if(!$pid) wp_send_json_error();
        self::add_to_post($pid,true);
        wp_send_json_success(['message'=>'تم توليد Schema']);
    }

    public static function ajax_bulk(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        global $wpdb;
        $with = $wpdb->get_col("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_rukn_schema'");
        $posts = get_posts(['numberposts'=>10,'post_status'=>'publish','fields'=>'ids','exclude'=>$with]);
        if(empty($posts)){ wp_send_json_success(['done'=>true,'message'=>'كل المقالات لديها Schema']); return; }
        foreach($posts as $pid) self::add_to_post($pid);
        wp_send_json_success(['processed'=>count($posts),'message'=>'تم إضافة Schema لـ '.count($posts).' مقال']);
    }
}

<?php
defined('ABSPATH') || exit;

class Rukn_AI_Content_Updater {

    public static function init(): void {
        add_action('wp_ajax_rukn_get_category_posts', [__CLASS__,'ajax_get_posts']);
        add_action('wp_ajax_rukn_update_post_ai',     [__CLASS__,'ajax_update_post']);
        add_action('wp_ajax_rukn_complete_blocks',    [__CLASS__,'ajax_complete_blocks']);
        add_action('wp_ajax_rukn_preview_update',     [__CLASS__,'ajax_preview']);
        add_action('wp_ajax_rukn_apply_preview',      [__CLASS__,'ajax_apply_preview']);
        // مولّد المقالات المتقدم
        add_action('wp_ajax_rukn_bulk_generate_start', [__CLASS__,'ajax_bulk_generate_start']);
        add_action('wp_ajax_rukn_bulk_generate_single',[__CLASS__,'ajax_bulk_generate_single']);
    }

    /* ════════════════════════════════════════════════════
       FIX: جلب مقالات التصنيف — محلول مشكلة "لا توجد مقالات"
    ════════════════════════════════════════════════════ */
    public static function ajax_get_posts(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');

        $cat_id      = (int)($_POST['category_id'] ?? 0);
        $min_words   = (int)($_POST['min_words']   ?? 0);   // 0 = كل المقالات
        $short_only  = (bool)($_POST['short_only'] ?? false); // أقل من 1000 كلمة فقط

        if (!$cat_id) { wp_send_json_error('اختر تصنيفاً'); }

        // ── الحل الصحيح: WP_Query بدل get_posts ──────────
        global $wpdb;

        // جلب IDs بـ SQL مباشر لتجنب أي مشكلة في post types
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT p.ID
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
             INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
             WHERE tt.term_id = %d
               AND tt.taxonomy = 'category'
               AND p.post_status = 'publish'
               AND p.post_type IN ('post','page','services','service')
             ORDER BY p.ID DESC
             LIMIT 500",
            $cat_id
        ));

        // لو مفيش نتائج بـ category ID — جرب slug
        if (empty($ids)) {
            $term = get_term($cat_id, 'category');
            if ($term && !is_wp_error($term)) {
                // محاولة بـ term_id من جديد بطريقة مختلفة
                $query = new WP_Query([
                    'cat'            => $cat_id,
                    'posts_per_page' => -1,
                    'post_status'    => 'publish',
                    'fields'         => 'ids',
                    'no_found_rows'  => true,
                ]);
                $ids = $query->posts;
            }
        }

        // لا توجد مقالات
        if (empty($ids)) {
            // رسالة تفصيلية للمساعدة
            $term = get_term($cat_id, 'category');
            $term_name = $term && !is_wp_error($term) ? $term->name : "#$cat_id";
            wp_send_json_error(
                "لا توجد مقالات منشورة في تصنيف: $term_name\n" .
                "تأكد إن المقالات في هذا التصنيف حالتها 'منشور' وليس 'مسودة'."
            );
        }

        // فلترة بعدد الكلمات (أقل من 1000)
        $list = [];
        foreach ($ids as $id) {
            $post = get_post((int)$id);
            if (!$post) continue;
            $word_count = str_word_count(strip_tags($post->post_content));
            // إذا short_only=true → فقط المقالات أقل من 1000 كلمة
            if ($short_only && $word_count >= 1000) continue;
            $list[] = [
                'id'         => (int)$id,
                'title'      => $post->post_title,
                'url'        => get_permalink($id),
                'word_count' => $word_count,
                'short'      => $word_count < 1000,
            ];
        }

        if (empty($list)) {
            wp_send_json_error('كل مقالات هذا التصنيف تحتوي أكثر من 1000 كلمة — لا يحتاج تحديث.');
        }

        wp_send_json_success([
            'posts' => $list,
            'total' => count($list),
            'short_count' => count(array_filter($list, fn($p) => $p['short'])),
        ]);
    }

    /* ════════════════════════════════════════════════════
       تحديث مقال واحد
    ════════════════════════════════════════════════════ */
    public static function ajax_update_post(): void {
        check_ajax_referer('rukn_ai_nonce','nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $post_id = (int)($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error('post_id مطلوب');
        if (!Rukn_AI_Claude::is_ready()) wp_send_json_error('أضف مفتاح Claude API من الإعدادات');

        $opts = [
            'rewrite'         => filter_var($_POST['rewrite']         ?? true, FILTER_VALIDATE_BOOLEAN),
            'add_schema'      => filter_var($_POST['add_schema']      ?? true, FILTER_VALIDATE_BOOLEAN),
            'complete_blocks' => filter_var($_POST['complete_blocks'] ?? true, FILTER_VALIDATE_BOOLEAN),
            'keyword'         => sanitize_text_field($_POST['keyword'] ?? ''),
            'tone'            => sanitize_text_field($_POST['tone']    ?? 'احترافي'),
        ];

        $result = self::process($post_id, $opts);
        wp_send_json_success($result);
    }

    /* ════════════════════════════════════════════════════
       معالجة مقال كاملة
    ════════════════════════════════════════════════════ */
    public static function process(int $post_id, array $opts = []): array {
        $post = get_post($post_id);
        if (!$post) return ['error' => "المقال #{$post_id} غير موجود", 'post_id' => $post_id];

        $changes = [];

        // 1. إعادة كتابة كاملة بـ Claude
        if (!empty($opts['rewrite'])) {
            $data = Rukn_AI_Claude::rewrite_article($post_id, $opts);
            if (!empty($data['content'])) {
                $update = ['ID' => $post_id, 'post_content' => $data['content']];
                if (!empty($data['title'])) $update['post_title'] = $data['title'];
                wp_update_post($update);
                // SEO Meta
                $meta_desc = $data['meta_description'] ?? '';
                $focus_kw  = $data['focus_keyword']    ?? '';
                if ($meta_desc) {
                    update_post_meta($post_id, '_yoast_wpseo_metadesc',   $meta_desc);
                    update_post_meta($post_id, 'rank_math_description',    $meta_desc);
                    update_post_meta($post_id, '_aioseop_description',     $meta_desc);
                }
                if ($focus_kw) {
                    update_post_meta($post_id, '_yoast_wpseo_focuskw',    $focus_kw);
                    update_post_meta($post_id, 'rank_math_focus_keyword',  $focus_kw);
                }
                if (!empty($data['tags'])) wp_set_post_tags($post_id, $data['tags'], false);
                if (!empty($data['faq_schema'])) update_post_meta($post_id, '_rukn_faq_schema', wp_json_encode($data['faq_schema']));
                $wc = str_word_count(strip_tags($data['content']));
                $changes[] = "إعادة الكتابة ({$wc} كلمة)";
            }
        }

        // 2. إضافة Schema
        if (!empty($opts['add_schema'])) {
            Rukn_AI_Schema::add_to_post($post_id, true);
            $changes[] = 'Schema';
        }

        // 3. إكمال البلوكات الناقصة
        if (!empty($opts['complete_blocks'])) {
            $added = self::complete_missing_blocks($post_id);
            if ($added) $changes[] = 'بلوكات: ' . $added;
        }

        return [
            'post_id' => $post_id,
            'title'   => get_the_title($post_id),
            'changes' => $changes,
            'status'  => 'success',
        ];
    }

    /* ════════════════════════════════════════════════════
       إكمال البلوكات الناقصة
    ════════════════════════════════════════════════════ */
    public static function complete_missing_blocks(int $post_id): string {
        $post    = get_post($post_id);
        if (!$post) return '';
        $content = $post->post_content;
        $title   = $post->post_title;
        $wa      = Rukn_AI_Helper::opt('whatsapp', '');
        $phone   = Rukn_AI_Helper::opt('phone', '');
        $added   = [];
        $extra   = '';

        $checks = [
            'features'     => ['مميزات', 'الخصائص', 'مزايا'],
            'services'     => ['خدماتنا', 'الخدمات المقدمة', 'نقدم'],
            'steps'        => ['خطوات', 'كيف نعمل', 'طريقة العمل'],
            'faq'          => ['أسئلة شائعة', 'FAQ', 'الأسئلة المتكررة', 'سؤال'],
            'contact'      => ['تواصل معنا', 'اتصل بنا', 'احصل على عرض', 'اتصل الآن'],
            'service_form' => ['طلب الخدمة', 'نموذج الطلب', 'اطلب الخدمة'],
        ];

        foreach ($checks as $block => $keywords) {
            $found = false;
            foreach ($keywords as $kw) {
                if (mb_strpos($content, $kw) !== false) { $found = true; break; }
            }
            if (!$found) {
                $html = Rukn_AI_Claude::generate_block($block, $title, ['wa' => $wa, 'phone' => $phone]);
                if ($html) { $extra .= "\n\n" . $html; $added[] = $block; }
            }
        }

        if (!str_contains($content, 'gallery') && !str_contains($content, 'wp:gallery')) {
            $html = Rukn_AI_Claude::generate_block('gallery', $title);
            if ($html) { $extra .= "\n\n" . $html; $added[] = 'الألبوم'; }
        }

        if ($extra) {
            wp_update_post(['ID' => $post_id, 'post_content' => $content . $extra]);
        }
        return implode(' + ', $added);
    }

    /* ════════════════════════════════════════════════════
       مولّد المقالات الجماعي (خدمات × مدن)
    ════════════════════════════════════════════════════ */
    public static function ajax_bulk_generate_start(): void {
        check_ajax_referer('rukn_ai_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');
        if (!Rukn_AI_Claude::is_ready()) wp_send_json_error('أضف مفتاح Claude API من الإعدادات');

        $services_raw = sanitize_textarea_field($_POST['services'] ?? '');
        $cities_raw   = sanitize_textarea_field($_POST['cities']   ?? '');
        $category     = sanitize_text_field($_POST['category']     ?? '');
        $status       = in_array($_POST['post_status'] ?? 'draft', ['draft','publish']) ? $_POST['post_status'] : 'draft';
        $tone         = sanitize_text_field($_POST['tone']         ?? 'احترافي');
        $country      = sanitize_text_field($_POST['country']      ?? 'ae');

        // تحليل الخدمات والمدن
        $services = array_filter(array_map('trim', explode("\n", $services_raw)));
        $cities   = array_filter(array_map('trim', explode("\n", $cities_raw)));

        if (empty($services)) wp_send_json_error('أدخل الخدمات أولاً');
        if (empty($cities))   wp_send_json_error('أدخل المدن أولاً');

        // بناء قائمة التوليد: كل خدمة × كل مدينة
        $combinations = [];
        foreach ($services as $service) {
            foreach ($cities as $city) {
                if (!empty($service) && !empty($city)) {
                    $combinations[] = [
                        'service'  => $service,
                        'city'     => $city,
                        'category' => $category,
                        'status'   => $status,
                        'tone'     => $tone,
                        'country'  => $country,
                    ];
                }
            }
        }

        if (empty($combinations)) wp_send_json_error('لا توجد تركيبات صالحة');

        // حفظ في transient
        $queue_key = 'rukn_bulk_' . get_current_user_id() . '_' . time();
        set_transient($queue_key, [
            'combinations' => $combinations,
            'total'        => count($combinations),
            'done'         => 0,
            'errors'       => [],
        ], 2 * HOUR_IN_SECONDS);

        wp_send_json_success([
            'queue_key' => $queue_key,
            'total'     => count($combinations),
            'preview'   => array_slice(array_map(fn($c) => self::build_smart_title($c['service'], $c['city']), $combinations), 0, 5),
        ]);
    }

    /** توليد مقال واحد من القائمة */
    public static function ajax_bulk_generate_single(): void {
        check_ajax_referer('rukn_ai_nonce', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $queue_key = sanitize_key($_POST['queue_key'] ?? '');
        $index     = (int)($_POST['index'] ?? 0);
        $queue     = get_transient($queue_key);

        if (!$queue) wp_send_json_error('انتهت جلسة التوليد');
        if (!isset($queue['combinations'][$index])) {
            wp_send_json_success(['done' => true, 'message' => 'اكتمل التوليد']);
        }

        $combo = $queue['combinations'][$index];
        $result = self::generate_single_article($combo);

        // تحديث القائمة
        $queue['done'] = $index + 1;
        if (isset($result['error'])) $queue['errors'][] = $result['error'];
        set_transient($queue_key, $queue, 2 * HOUR_IN_SECONDS);

        wp_send_json_success([
            'done'       => $queue['done'],
            'total'      => $queue['total'],
            'percent'    => round($queue['done'] / $queue['total'] * 100),
            'result'     => $result,
            'next_index' => $index + 1,
            'is_done'    => ($index + 1) >= $queue['total'],
        ]);
    }

    /* ════════════════════════════════════════════════════
       توليد مقال واحد كامل — المحرك الرئيسي
    ════════════════════════════════════════════════════ */
    private static function generate_single_article(array $combo): array {
        $service  = $combo['service'];
        $city     = $combo['city'];
        $category = $combo['category'] ?? '';
        $status   = $combo['status']   ?? 'draft';
        $tone     = $combo['tone']     ?? 'احترافي';
        $country  = $combo['country']  ?? 'ae';

        $countries = ['ae'=>'الإمارات','sa'=>'السعودية','qa'=>'قطر','kw'=>'الكويت','bh'=>'البحرين','om'=>'عمان','eg'=>'مصر'];
        $cn = $countries[$country] ?? $country;

        $smart_title = self::build_smart_title($service, $city);
        $wa    = Rukn_AI_Helper::opt('whatsapp', '');
        $phone = Rukn_AI_Helper::opt('phone', '');
        $company = get_bloginfo('name');

        // Variation seed — يجعل كل مقال مختلف حتى لو نفس الخدمة والمدينة
        $variation_seed = rand(1, 1000);
        $structures = [
            'A' => 'ابدأ بالإحصائيات والأرقام، ثم المشكلة، ثم الحل',
            'B' => 'ابدأ بسؤال مثير للاهتمام عن المشكلة الشائعة في المدينة',
            'C' => 'ابدأ بقصة نجاح عميل حقيقي في المدينة',
            'D' => 'ابدأ بالمخاطر والعواقب إذا تجاهلت الخدمة',
            'E' => 'ابدأ بالمقارنة بين الاحتراف والعمالة العشوائية',
        ];
        $struct_key   = array_keys($structures)[($variation_seed % 5)];
        $struct_desc  = $structures[$struct_key];
        $faq_count    = rand(5, 8);
        $h2_count     = rand(6, 9);

        $prompt = "أنت كاتب محتوى SEO محترف ومبدع متخصص في خدمات المنازل في {$cn}.

اكتب مقالاً SEO احترافياً فريداً 100% بالعربية الفصحى السهلة.

المعلومات:
- العنوان: {$smart_title}
- الخدمة: {$service}
- المدينة: {$city}
- الدولة: {$cn}
- اسم الشركة: {$company}
- الأسلوب: {$tone}
- رقم التنويع: {$variation_seed} (يجعل المقال فريداً)

أسلوب البداية المطلوب: {$struct_desc}

متطلبات المقال (3000+ كلمة):

1. **المقدمة** (200+ كلمة): استخدم أسلوب البداية المحدد أعلاه. اذكر {$city} 3 مرات.

2. **{$h2_count} أقسام رئيسية H2** مع H3 داخل كل قسم. يجب أن تشمل:
   - تفاصيل الخدمة وأهميتها في {$city}
   - المميزات والخصائص (8 مميزات تفصيلية ul/li)
   - الخدمات الفرعية (6 خدمات مع وصف)
   - خطوات العمل (5 خطوات مرقمة مفصلة)
   - الأسعار في {$city} (جدول HTML مقارنة)
   - مناطق الخدمة في {$city} (5+ أحياء ومناطق)
   - شهادة عميل حقيقية من {$city} (blockquote)
   - لماذا نحن الأفضل (6 أسباب)

3. **{$faq_count} سؤالاً شائعاً** (details/summary) — أسئلة مختلفة وغير متوقعة متعلقة بـ {$service} في {$city}

4. **شريحة CTA جميلة** بخلفية متدرجة:
" . ($wa ? "- زر واتساب: $wa\n" : '') . ($phone ? "- هاتف: $phone\n" : '') . "
5. **الخاتمة** مع call to action قوي

6. **روابط داخلية ذكية**: أضف 3 روابط داخلية بـ [INTERNAL_LINK text=\"نص الرابط\"] لخدمات مشابهة في نفس المدينة أو خدمات مكملة.

مهم جداً:
- اذكر \"{$city}\" 12+ مرة
- اذكر \"{$service}\" 10+ مرة
- استخدم كلمات دلالية مختلفة: إصلاح، متخصص، خبراء، معتمد، احترافي
- لا تكرر جمل من مقالات أخرى
- أسلوب مختلف تماماً بسبب رقم التنويع {$variation_seed}

الرد بـ JSON فقط:
{
  \"title\": \"{$smart_title}\",
  \"content\": \"محتوى HTML كامل\",
  \"meta_description\": \"وصف 155 حرف يذكر {$service} و{$city}\",
  \"focus_keyword\": \"{$service} في {$city}\",
  \"seo_title\": \"{$smart_title} | {$company}\",
  \"slug\": \"english-slug-service-city\",
  \"tags\": [\"tag1\",\"tag2\",\"tag3\",\"tag4\",\"tag5\"],
  \"faq_schema\": [{\"question\":\"...\",\"answer\":\"...\"}],
  \"internal_links\": [\"خدمة مشابهة 1 في {$city}\",\"خدمة مشابهة 2 في {$city}\"]
}";

        $data = Rukn_AI_Claude::ask_json($prompt);

        if (empty($data) || !isset($data['content'])) {
            return ['error' => "فشل توليد: {$smart_title}"];
        }

        // نشر/حفظ المقال
        $cat_ids = [];
        if ($category) {
            $cat = get_term_by('name', $category, 'category') ?: wp_insert_term($category, 'category');
            if (!is_wp_error($cat)) {
                $cat_ids = [is_array($cat) ? $cat['term_id'] : $cat->term_id];
            }
        }

        // معالجة الروابط الداخلية
        $content = $data['content'];
        $content = self::process_internal_links($content, $city, $service);

        $post_id = wp_insert_post([
            'post_title'   => $data['title']  ?? $smart_title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_type'    => 'post',
            'post_name'    => sanitize_title($data['slug'] ?? "{$service}-{$city}"),
            'post_category'=> $cat_ids,
        ], true);

        if (is_wp_error($post_id)) {
            return ['error' => $post_id->get_error_message()];
        }

        // SEO Meta
        $meta_desc = $data['meta_description'] ?? '';
        $focus_kw  = $data['focus_keyword']    ?? "{$service} في {$city}";
        $seo_title = $data['seo_title']        ?? $smart_title;

        update_post_meta($post_id, '_yoast_wpseo_metadesc',        $meta_desc);
        update_post_meta($post_id, '_yoast_wpseo_focuskw',         $focus_kw);
        update_post_meta($post_id, '_yoast_wpseo_title',           $seo_title);
        update_post_meta($post_id, 'rank_math_description',         $meta_desc);
        update_post_meta($post_id, 'rank_math_focus_keyword',       $focus_kw);
        update_post_meta($post_id, 'rank_math_title',               $seo_title);
        update_post_meta($post_id, '_aioseop_description',          $meta_desc);
        update_post_meta($post_id, '_aioseop_title',                $seo_title);

        // Tags
        if (!empty($data['tags'])) {
            wp_set_post_tags($post_id, $data['tags']);
        }

        // FAQ Schema
        if (!empty($data['faq_schema'])) {
            update_post_meta($post_id, '_rukn_faq_schema', wp_json_encode($data['faq_schema']));
        }

        // Schema تلقائي
        Rukn_AI_Schema::add_to_post($post_id, true);

        // صورة بارزة من المكتبة
        self::auto_set_featured_image($post_id, $service, $city);

        return [
            'post_id'    => $post_id,
            'title'      => $data['title'] ?? $smart_title,
            'url'        => get_permalink($post_id),
            'status'     => $status,
            'word_count' => str_word_count(strip_tags($content)),
        ];
    }

    /* ════════════════════════════════════════════════════
       عنوان ذكي SEO
    ════════════════════════════════════════════════════ */
    public static function build_smart_title(string $service, string $city): string {
        // أنماط عناوين مختلفة لتنويع المقالات
        $patterns = [
            "شركة {service} في {city}",
            "أفضل شركة {service} في {city}",
            "{service} في {city} — أسعار ومميزات 2025",
            "خدمة {service} في {city} | متخصصون محترفون",
            "شركة {service} في {city} بأفضل الأسعار",
        ];

        // اختيار نمط ثابت للخدمة+المدينة (لضمان التناسق)
        $idx = abs(crc32($service . $city)) % count($patterns);
        $pattern = $patterns[$idx];

        return str_replace(['{service}', '{city}'], [$service, $city], $pattern);
    }

    /* ════════════════════════════════════════════════════
       معالجة الروابط الداخلية
    ════════════════════════════════════════════════════ */
    private static function process_internal_links(string $content, string $city, string $service): string {
        // استبدال [INTERNAL_LINK text="..."] بروابط WordPress حقيقية
        return preg_replace_callback(
            '/\[INTERNAL_LINK text="([^"]+)"\]/',
            function ($matches) use ($city) {
                $link_text = $matches[1];
                // البحث عن مقال مرتبط
                $posts = get_posts([
                    's'              => $city,
                    'numberposts'    => 1,
                    'post_status'    => 'publish',
                    'fields'         => 'ids',
                ]);
                if (!empty($posts)) {
                    $url = get_permalink($posts[0]);
                    return "<a href=\"{$url}\">{$link_text}</a>";
                }
                return $link_text; // لو مفيش مقال → نص عادي
            },
            $content
        );
    }

    /* ════════════════════════════════════════════════════
       صورة بارزة تلقائية من المكتبة
    ════════════════════════════════════════════════════ */
    private static function auto_set_featured_image(int $post_id, string $service, string $city): void {
        if (has_post_thumbnail($post_id)) return;

        // كلمات بحث مشتقة من الخدمة
        $search_terms = [
            $service,
            str_replace(['شركة', 'خدمة', 'في'], '', $service),
            $city,
        ];

        foreach ($search_terms as $term) {
            $term = trim($term);
            if (empty($term)) continue;
            $images = get_posts([
                'post_type'   => 'attachment',
                'post_status' => 'inherit',
                's'           => $term,
                'numberposts' => 1,
            ]);
            if (!empty($images)) {
                set_post_thumbnail($post_id, $images[0]->ID);
                return;
            }
        }

        // آخر محاولة: أي صورة من المكتبة
        $any = get_posts([
            'post_type'   => 'attachment',
            'post_status' => 'inherit',
            'numberposts' => 1,
            'orderby'     => 'rand',
        ]);
        if (!empty($any)) set_post_thumbnail($post_id, $any[0]->ID);
    }

    /* ════════════════════════════════════════════════════
       معاينة + تطبيق
    ════════════════════════════════════════════════════ */
    public static function ajax_preview(): void {
        check_ajax_referer('rukn_ai_nonce', 'nonce');
        $post_id = (int)($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error();
        if (!Rukn_AI_Claude::is_ready()) wp_send_json_error('أضف مفتاح Claude API');
        $data = Rukn_AI_Claude::rewrite_article($post_id);
        if (empty($data)) wp_send_json_error('فشل توليد المعاينة');
        set_transient('rukn_preview_' . $post_id . '_' . get_current_user_id(), $data, HOUR_IN_SECONDS);
        wp_send_json_success($data);
    }

    public static function ajax_apply_preview(): void {
        check_ajax_referer('rukn_ai_nonce', 'nonce');
        $post_id = (int)($_POST['post_id'] ?? 0);
        $key = 'rukn_preview_' . $post_id . '_' . get_current_user_id();
        $data = get_transient($key);
        if (!$data) wp_send_json_error('انتهت صلاحية المعاينة');
        $upd = ['ID' => $post_id, 'post_content' => $data['content']];
        if (!empty($data['title'])) $upd['post_title'] = $data['title'];
        wp_update_post($upd);
        delete_transient($key);
        wp_send_json_success(['message' => 'تم التطبيق']);
    }

    public static function ajax_complete_blocks(): void {
        check_ajax_referer('rukn_ai_nonce', 'nonce');
        $post_id = (int)($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error();
        $r = self::complete_missing_blocks($post_id);
        wp_send_json_success(['added' => $r ?: 'لا توجد بلوكات ناقصة']);
    }
}

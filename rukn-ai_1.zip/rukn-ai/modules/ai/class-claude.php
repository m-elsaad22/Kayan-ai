<?php
defined('ABSPATH') || exit;

class Rukn_AI_Claude {

    private static string $api_key  = '';
    private static string $model    = 'claude-sonnet-4-20250514';
    private static int    $max_tok  = 8192;

    private static function init(): void {
        self::$api_key = Rukn_AI_Helper::opt('claude_api_key', '');
        self::$model   = Rukn_AI_Helper::opt('claude_model', 'claude-sonnet-4-20250514');
        self::$max_tok = (int)Rukn_AI_Helper::opt('claude_max_tokens', 8192);
    }

    public static function is_ready(): bool {
        self::init();
        return !empty(self::$api_key);
    }

    /** إرسال prompt نصي */
    public static function ask(string $prompt, string $system = '', int $max = 0): string {
        self::init();
        if (!self::$api_key) return '';
        $body = [
            'model'      => self::$model,
            'max_tokens' => $max ?: self::$max_tok,
            'messages'   => [['role'=>'user','content'=>$prompt]],
        ];
        if ($system) $body['system'] = $system;
        $resp = wp_remote_post('https://api.anthropic.com/v1/messages', [
            'timeout' => 120,
            'headers' => [
                'x-api-key'         => self::$api_key,
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ],
            'body' => wp_json_encode($body),
        ]);
        if (is_wp_error($resp)) { self::log_error('ask', $resp->get_error_message()); return ''; }
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        self::log('ask', $data['usage']['output_tokens'] ?? 0, 'success');
        return $data['content'][0]['text'] ?? '';
    }

    /** طلب JSON */
    public static function ask_json(string $prompt): array {
        $sys = 'أنت مولّد JSON فقط. أجب بـ JSON صحيح فقط. لا شرح ولا ماركداون ولا backticks.';
        $res = self::ask($prompt, $sys, 4096);
        if (!$res) return [];
        $res = preg_replace('/```json\s*/i','', $res);
        $res = preg_replace('/```\s*/i','', $res);
        $res = trim($res);
        // Extract JSON
        $s = strpos($res, '{'); $e = strrpos($res, '}');
        if ($s !== false && $e !== false) $res = substr($res, $s, $e-$s+1);
        $d = json_decode($res, true);
        return is_array($d) ? $d : [];
    }

    /** إعادة كتابة مقال كامل (3000 كلمة) */
    public static function rewrite_article(int $post_id, array $opts = []): array {
        $post  = get_post($post_id);
        if (!$post) return [];
        $cats  = implode('، ', wp_list_pluck(get_the_category($post_id), 'name'));
        $tags  = implode('، ', wp_list_pluck(wp_get_post_tags($post_id), 'name'));
        $kw    = sanitize_text_field($opts['keyword'] ?? '');
        $tone  = sanitize_text_field($opts['tone']    ?? 'احترافي ومقنع');
        $wa    = Rukn_AI_Helper::opt('whatsapp', '');
        $phone = Rukn_AI_Helper::opt('phone',    '');

        $prompt = "أنت كاتب محتوى SEO محترف. أعد كتابة هذا المقال بشكل كامل واحترافي.

عنوان المقال: {$post->post_title}
التصنيف: {$cats}
الوسوم: {$tags}
الكلمة المفتاحية: " . ($kw ?: $post->post_title) . "
المحتوى الحالي:
" . mb_substr(strip_tags($post->post_content), 0, 2000) . "

المطلوب — اكتب مقالاً SEO احترافياً بالعربية الفصحى بطول 3000 كلمة أو أكثر:

هيكل المقال الإلزامي:
1. عنوان H1 جذاب يحتوي الكلمة المفتاحية
2. مقدمة قوية 150+ كلمة
3. H2: تفاصيل الخدمة/الموضوع (3-4 فقرات تفصيلية)
4. H2: المميزات — قائمة ul/li بـ 8 مميزات مع وصف
5. H2: الخدمات المقدمة — قائمة تفصيلية بـ 6 خدمات
6. H2: خطوات العمل — 5 خطوات مرقمة مفصّلة
7. H2: لماذا نحن الأفضل؟ — 6 نقاط مع وصف
8. H2: أسئلة شائعة — 7 أسئلة بتنسيق details/summary
9. شريحة اتصال HTML جميلة" . ($wa ? " مع رقم واتساب: $wa" : '') . ($phone ? " وهاتف: $phone" : '') . "
10. خاتمة مع call to action

الرد بـ JSON فقط:
{
  \"title\": \"العنوان الرئيسي\",
  \"content\": \"محتوى HTML كامل\",
  \"meta_description\": \"وصف ميتا 155 حرف\",
  \"focus_keyword\": \"الكلمة المفتاحية\",
  \"tags\": [\"tag1\",\"tag2\",\"tag3\"],
  \"faq_schema\": [{\"question\":\"...\",\"answer\":\"...\"}]
}";

        return self::ask_json($prompt);
    }

    /** توليد Schema */
    public static function generate_schema(int $post_id): array {
        $post = get_post($post_id);
        if (!$post) return [];
        $cats = implode(',', wp_list_pluck(get_the_category($post_id), 'name'));
        $prompt = "توليد JSON-LD Schema لمقال WordPress:
العنوان: {$post->post_title}
التصنيف: {$cats}
المحتوى: " . mb_substr(strip_tags($post->post_content), 0, 800) . "
URL: " . get_permalink($post_id) . "

أضف: Article + BreadcrumbList + FAQPage (إن وُجد FAQ) + Service (إن كان خدمة) + LocalBusiness (إن كان محلي).
أجب بـ JSON-LD صحيح فقط بدون أي نص إضافي.";
        return self::ask_json($prompt);
    }

    /** توليد blocks ناقصة */
    public static function generate_block(string $block_type, string $post_title, array $extra = []): string {
        $prompts = [
            'features'  => "اكتب قسم مميزات HTML لمقال عن: {$post_title}\nأضف 8 مميزات مع وصف كل مميزة. ابدأ بـ <h2>مميزات خدمة {$post_title}</h2>",
            'services'  => "اكتب قسم خدمات HTML لمقال عن: {$post_title}\nأضف 6 خدمات مع وصف مختصر. ابدأ بـ <h2>خدماتنا في {$post_title}</h2>",
            'steps'     => "اكتب قسم خطوات العمل HTML لمقال عن: {$post_title}\nأضف 5 خطوات مرقمة تفصيلية. ابدأ بـ <h2>كيف نعمل؟</h2>",
            'faq'       => "اكتب قسم FAQ HTML لمقال عن: {$post_title}\nأضف 7 أسئلة شائعة بتنسيق details/summary. ابدأ بـ <h2>الأسئلة الشائعة</h2>",
            'gallery'   => "اكتب قسم ألبوم صور HTML placeholder لمقال عن: {$post_title}\nاستخدم div grid جميل مع placeholders للصور. ابدأ بـ <h2>معرض صور أعمالنا</h2>",
            'contact'   => "اكتب شريحة اتصال HTML جميلة لمقال عن: {$post_title}\nأضف CTA قوي مع زر واتساب وهاتف. اجعلها بخلفية متدرجة جذابة.",
            'service_form' => "اكتب ودجت HTML لطلب الخدمة لمقال عن: {$post_title}\nأضف نموذج HTML بسيط: الاسم، الهاتف، التاريخ، رسالة. أسلوب بطاقة جميل.",
        ];
        $prompt = $prompts[$block_type] ?? "اكتب محتوى HTML للقسم: {$block_type} لمقال عن: {$post_title}";
        if (!empty($extra['wa']))    $prompt .= "\nرقم واتساب: " . $extra['wa'];
        if (!empty($extra['phone'])) $prompt .= "\nهاتف: " . $extra['phone'];
        return self::ask($prompt);
    }

    /** ترجمة */
    public static function translate(string $text, string $from, string $to): string {
        $names = ['ar'=>'العربية','en'=>'English','ur'=>'اردو','fil'=>'Filipino','hi'=>'हिन्दी','bn'=>'বাংলা','fr'=>'Français','id'=>'Bahasa Indonesia'];
        $prompt = "ترجم النص من {$names[$from]} إلى {$names[$to]}. أعد النص المترجم فقط:\n\n{$text}";
        return self::ask($prompt, '', 4096);
    }

    private static function log(string $action, int $tokens, string $status): void {
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'rukn_ai_logs',[
            'action_type'=>$action,'tokens_used'=>$tokens,'status'=>$status
        ],['%s','%d','%s']);
    }
    private static function log_error(string $action, string $msg): void {
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'rukn_ai_logs',[
            'action_type'=>$action,'status'=>'error','error_msg'=>$msg
        ],['%s','%s','%s']);
    }
}

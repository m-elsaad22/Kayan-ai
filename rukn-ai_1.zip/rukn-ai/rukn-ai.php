<?php
/**
 * Plugin Name:  Rukn AI — نظام ركن الذكاء الاصطناعي الموحد
 * Plugin URI:   https://rukn-eltatawer.com
 * Description:  إضافة موحدة تجمع: تتبع الضغطات، تحديث المحتوى AI، Schema تلقائي، ترجمة، توليد مقالات، استيراد CSV، تتبع زوار — مدعومة بـ Claude AI
 * Version:      1.0.0
 * Author:       Mahmoud Elsaad — ركن التطور
 * Author URI:   https://rukn-eltatawer.com
 * Text Domain:  rukn-ai
 * Network:      true
 * Requires PHP: 7.4
 * Requires at least: 6.0
 */
defined('ABSPATH') || exit;

/* ══════════════════════════════════════════════════════════
   CONSTANTS
══════════════════════════════════════════════════════════ */
define('RUKN_AI_VER',  '1.0.0');
define('RUKN_AI_FILE', __FILE__);
define('RUKN_AI_PATH', plugin_dir_path(__FILE__));
define('RUKN_AI_URL',  plugin_dir_url(__FILE__));
define('RUKN_AI_SLUG', 'rukn-ai');

/* ══════════════════════════════════════════════════════════
   LOAD MODULES — ترتيب التحميل مهم
══════════════════════════════════════════════════════════ */
foreach ([
    'includes/class-db.php',
    'includes/class-helper.php',
    'modules/ai/class-claude.php',
    'modules/click-tracker/class-click-tracker.php',
    'modules/content-updater/class-content-updater.php',
    'modules/schema/class-schema.php',
    'modules/tracking/class-tracking.php',
    'modules/csv-importer/class-csv-importer.php',
    'modules/translate/class-translate.php',
    'modules/generator/class-generator.php',
    'admin/class-admin.php',
] as $m) {
    $f = RUKN_AI_PATH . $m;
    if (file_exists($f)) require_once $f;
}

/* ══════════════════════════════════════════════════════════
   BOOTSTRAP
══════════════════════════════════════════════════════════ */
final class Rukn_AI {
    private static ?self $inst = null;

    public static function instance(): self {
        if (!self::$inst) self::$inst = new self();
        return self::$inst;
    }

    private function __construct() {
        register_activation_hook(RUKN_AI_FILE,   [$this, 'activate']);
        register_deactivation_hook(RUKN_AI_FILE, [$this, 'deactivate']);
        add_action('plugins_loaded', [$this, 'boot']);
        // Multisite: تفعيل على مواقع جديدة
        add_action('wpmu_new_blog', [$this, 'new_blog_install'], 10, 1);
    }

    public function activate(): void {
        Rukn_AI_DB::install();
        if (is_multisite()) {
            foreach (get_sites(['fields' => 'ids', 'number' => 200]) as $blog_id) {
                switch_to_blog($blog_id);
                Rukn_AI_DB::install();
                restore_current_blog();
            }
        }
        flush_rewrite_rules();
    }

    public function deactivate(): void { flush_rewrite_rules(); }

    public function new_blog_install(int $blog_id): void {
        switch_to_blog($blog_id);
        Rukn_AI_DB::install();
        restore_current_blog();
    }

    public function boot(): void {
        load_plugin_textdomain('rukn-ai', false, RUKN_AI_PATH . 'languages');
        Rukn_AI_Click_Tracker::init();
        Rukn_AI_Tracking::init();
        Rukn_AI_Schema::init();
        Rukn_AI_Content_Updater::init();
        Rukn_AI_CSV_Importer::init();
        Rukn_AI_Translate::init();
        Rukn_AI_Generator::init();
        Rukn_AI_Admin::init();
    }
}

function RUKN_AI(): Rukn_AI { return Rukn_AI::instance(); }
RUKN_AI();

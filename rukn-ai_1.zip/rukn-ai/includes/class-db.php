<?php
defined('ABSPATH') || exit;

class Rukn_AI_DB {

    public static function install(): void {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // ── Click Tracker ──────────────────────────────────
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rukn_clicks (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            click_type  VARCHAR(20)  NOT NULL,
            page_title  TEXT         NOT NULL,
            page_url    TEXT         NOT NULL,
            post_id     BIGINT       DEFAULT NULL,
            post_type   VARCHAR(50)  DEFAULT NULL,
            click_time  DATETIME     NOT NULL,
            user_ip     VARCHAR(45)  DEFAULT NULL,
            user_agent  TEXT,
            referrer    TEXT,
            INDEX idx_type (click_type),
            INDEX idx_time (click_time),
            INDEX idx_ip   (user_ip(20))
        ) $c;");

        // ── Sessions ────────────────────────────────────────
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rukn_sessions (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id  VARCHAR(64)  NOT NULL UNIQUE,
            user_ip     VARCHAR(45)  DEFAULT NULL,
            country     VARCHAR(10)  DEFAULT NULL,
            city        VARCHAR(100) DEFAULT NULL,
            device      VARCHAR(20)  DEFAULT NULL,
            browser     VARCHAR(50)  DEFAULT NULL,
            referrer    TEXT,
            landing_url TEXT,
            pages_count INT UNSIGNED DEFAULT 1,
            duration    INT UNSIGNED DEFAULT 0,
            started_at  DATETIME     DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_session (session_id),
            INDEX idx_ip      (user_ip(20))
        ) $c;");

        // ── Page Views ──────────────────────────────────────
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rukn_pageviews (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id  VARCHAR(64)  NOT NULL,
            post_id     BIGINT       DEFAULT NULL,
            page_url    TEXT         NOT NULL,
            page_title  TEXT,
            viewed_at   DATETIME     DEFAULT CURRENT_TIMESTAMP,
            duration    INT UNSIGNED DEFAULT 0,
            INDEX idx_session (session_id),
            INDEX idx_post    (post_id),
            INDEX idx_date    (viewed_at)
        ) $c;");

        // ── AI Logs ─────────────────────────────────────────
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rukn_ai_logs (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            action_type VARCHAR(60)  NOT NULL,
            post_id     BIGINT       DEFAULT NULL,
            tokens_used INT UNSIGNED DEFAULT 0,
            status      ENUM('success','error','pending') DEFAULT 'pending',
            error_msg   TEXT,
            created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_action (action_type),
            INDEX idx_status (status)
        ) $c;");

        // ── Schema Cache ────────────────────────────────────
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rukn_schema_cache (
            post_id     BIGINT UNSIGNED PRIMARY KEY,
            schema_json MEDIUMTEXT,
            updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) $c;");

        // ── Import Log ──────────────────────────────────────
        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rukn_import_log (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id  VARCHAR(64),
            post_id     BIGINT       DEFAULT NULL,
            post_title  TEXT,
            status      VARCHAR(20)  DEFAULT 'pending',
            message     TEXT,
            created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
        ) $c;");

        update_option('rukn_ai_db_version', RUKN_AI_VER);
    }

    /* ── Clicks helpers ─── */
    public static function get_ip_total_clicks(string $ip): int {
        global $wpdb;
        return (int)$wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks WHERE user_ip=%s", $ip)
        );
    }

    public static function get_clicks(array $a = []): array {
        global $wpdb;
        $per     = max(1, (int)($a['per_page'] ?? 50));
        $page    = max(1, (int)($a['paged']    ?? 1));
        $offset  = ($page - 1) * $per;
        $type    = sanitize_text_field($a['type']    ?? '');
        $date    = sanitize_text_field($a['date']    ?? '');
        $search  = sanitize_text_field($a['search']  ?? '');
        $orderby = in_array($a['orderby'] ?? '', ['click_time','user_ip','ip_total']) ? $a['orderby'] : 'click_time';
        $order   = ($a['order'] ?? 'DESC') === 'ASC' ? 'ASC' : 'DESC';

        $where = 'WHERE 1=1'; $p = [];
        if ($type)   { $where .= ' AND r.click_type=%s'; $p[] = $type; }
        if ($date)   { $where .= ' AND DATE(r.click_time)=%s'; $p[] = $date; }
        if ($search) {
            $where .= ' AND (r.page_title LIKE %s OR r.page_url LIKE %s OR r.user_ip LIKE %s)';
            $l = '%'.$wpdb->esc_like($search).'%'; $p[]=$l; $p[]=$l; $p[]=$l;
        }

        // الترتيب بعدد ضغطات الـ IP
        $ip_sub = "(SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks c2 WHERE c2.user_ip=r.user_ip)";
        $ob = $orderby === 'ip_total' ? "$ip_sub $order" : "r.$orderby $order";

        $sql = "SELECT r.*, $ip_sub AS ip_total FROM {$wpdb->prefix}rukn_clicks r $where ORDER BY $ob LIMIT %d OFFSET %d";
        $p[] = $per; $p[] = $offset;
        return $wpdb->get_results($p ? $wpdb->prepare($sql, ...$p) : $sql) ?: [];
    }

    public static function count_clicks(array $a = []): int {
        global $wpdb;
        $type=$a['type']??''; $date=$a['date']??''; $search=$a['search']??'';
        $where='WHERE 1=1'; $p=[];
        if ($type)  { $where.=' AND click_type=%s'; $p[]=$type; }
        if ($date)  { $where.=' AND DATE(click_time)=%s'; $p[]=$date; }
        if ($search){ $where.=' AND (page_title LIKE %s OR page_url LIKE %s OR user_ip LIKE %s)';
                      $l='%'.$wpdb->esc_like($search).'%'; $p[]=$l;$p[]=$l;$p[]=$l; }
        $sql = "SELECT COUNT(*) FROM {$wpdb->prefix}rukn_clicks $where";
        return (int)($p ? $wpdb->get_var($wpdb->prepare($sql,...$p)) : $wpdb->get_var($sql));
    }
}

<?php
defined('ABSPATH') || exit;

class Rukn_AI_Helper {

    public static function get_user_ip(): string {
        foreach (['HTTP_CLIENT_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) return trim(explode(',', $_SERVER[$k])[0]);
        }
        return 'Unknown';
    }

    public static function get_device(): string {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (preg_match('/Mobile|Android|iPhone/i', $ua)) return 'mobile';
        if (preg_match('/Tablet|iPad/i', $ua)) return 'tablet';
        return 'desktop';
    }

    public static function get_browser(): string {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        foreach (['Edg'=>'Edge','OPR'=>'Opera','Chrome'=>'Chrome','Firefox'=>'Firefox','Safari'=>'Safari'] as $k=>$v) {
            if (str_contains($ua, $k)) return $v;
        }
        return 'Other';
    }

    public static function opt(string $key, $default = '') {
        return get_option('rukn_ai_' . $key, $default);
    }

    public static function set_opt(string $key, $val): void {
        update_option('rukn_ai_' . $key, $val);
    }

    /** لون IP حسب عدد الضغطات */
    public static function ip_color_class(int $total): string {
        if ($total >= 4) return 'ip-red';     // أحمر
        if ($total >= 2) return 'ip-orange';  // برتقالي
        return '';
    }

    public static function ip_color_style(int $total): string {
        if ($total >= 4) return 'color:#dc2626;font-weight:800;';
        if ($total >= 2) return 'color:#ea580c;font-weight:700;';
        return '';
    }

    public static function arabic_to_slug(string $text): string {
        $text = mb_strtolower($text);
        $text = preg_replace('/[^\p{Arabic}\p{Latin}0-9\s-]/u', '', $text);
        $text = preg_replace('/\s+/', '-', trim($text));
        return $text;
    }
}

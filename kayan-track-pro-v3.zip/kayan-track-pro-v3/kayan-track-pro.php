<?php
/**
 * Plugin Name:  Kayan Track Pro
 * Plugin URI:   https://rukn-eltatawer.com
 * Description:  Professional Multi-Number Call & WhatsApp Tracking — DNI, Fraud Detection, SaaS Dashboard
 * Version:      3.0.1
 * Author:       MAHMOUD ELSAAD
 * Author URI:   https://rukn-eltatawer.com
 * Text Domain:  kayan-track-pro
 * Requires PHP: 7.4
 */
defined('ABSPATH') || exit;

define('KTP_VERSION', '3.0.1');
define('KTP_FILE',    __FILE__);
define('KTP_PATH',    plugin_dir_path(__FILE__));
define('KTP_URL',     plugin_dir_url(__FILE__));
define('KTP_SLUG',    'kayan-track-pro');

/* ── Load all classes ────────────────────────────────────────── */
require_once KTP_PATH . 'database/class-kt-db.php';
require_once KTP_PATH . 'database/class-ktp-db.php';
require_once KTP_PATH . 'modules/sessions/class-kt-sessions.php';
require_once KTP_PATH . 'modules/events/class-kt-events.php';
require_once KTP_PATH . 'modules/clicks/class-kt-clicks.php';
require_once KTP_PATH . 'modules/heatmap/class-kt-heatmap.php';
require_once KTP_PATH . 'modules/tracking/class-ktp-tracker.php';
require_once KTP_PATH . 'modules/numbers/class-ktp-numbers.php';
require_once KTP_PATH . 'modules/dni/class-ktp-dni.php';
require_once KTP_PATH . 'api/class-ktp-api.php';
require_once KTP_PATH . 'admin/class-ktp-admin.php';

/* ── Bootstrap ───────────────────────────────────────────────── */
final class Kayan_Track_Pro {
    private static ?self $inst = null;
    public KT_Sessions $sessions;
    public KT_Events   $events;
    public KT_Clicks   $clicks;
    public KT_Heatmap  $heatmap;
    public KTP_Tracker $tracker;
    public KTP_Numbers $numbers;
    public KTP_DNI     $dni;
    public KTP_API     $api;
    public KTP_Admin   $admin;

    public static function instance(): self {
        if (!self::$inst) self::$inst = new self();
        return self::$inst;
    }
    private function __construct() {
        add_action('plugins_loaded', [$this, 'init']);
        register_activation_hook(KTP_FILE,   [$this, 'activate']);
        register_deactivation_hook(KTP_FILE, [$this, 'deactivate']);
        add_action('init', [$this, 'handle_public_endpoints']);
    }
    public function activate(): void {
        KT_DB::install();
        KTP_DB::install();
        flush_rewrite_rules();
    }
    public function deactivate(): void { flush_rewrite_rules(); }
    public function init(): void {
        KT_DB::maybe_migrate();
        KTP_DB::maybe_migrate();
        $this->sessions = new KT_Sessions();
        $this->events   = new KT_Events();
        $this->clicks   = new KT_Clicks();
        $this->heatmap  = new KT_Heatmap();
        $this->tracker  = new KTP_Tracker();
        $this->numbers  = new KTP_Numbers();
        $this->dni      = new KTP_DNI();
        $this->api      = new KTP_API();
        $this->admin    = new KTP_Admin();
    }
    public function handle_public_endpoints(): void {
        $token = sanitize_text_field($_GET['kt_report'] ?? '');
        if ($token && strlen($token) === 64) {
            require_once KTP_PATH . 'public/report-viewer.php';
            kt_render_public_report($token);
            exit;
        }
    }
}

function KTP(): Kayan_Track_Pro { return Kayan_Track_Pro::instance(); }

function kt_default_settings(): array {
    return [
        'enabled'         => true,
        'cookie_consent'  => false,
        'heatmap_enabled' => true,
        'exclude_roles'   => ['administrator'],
        'data_retention'  => 90,
        'geoip_service'   => 'ip-api',
        'geoip_key'       => '',
        'fraud_threshold' => 3,
        'auto_blacklist'  => 5,
        'report_expiry'   => 7,
        'cooldown_mins'   => 30,
        'dni_enabled'     => false,
        'whatsapp_number' => '',
        'telegram_token'  => '',
        'telegram_chat'   => '',
        'notify_new_conv' => false,
    ];
}

function ktp_clean_phone(string $raw): string {
    $p = preg_replace('/[^0-9]/', '', ltrim(trim($raw), '+'));
    return $p ?: $raw;
}
function ktp_format_phone(string $phone): string {
    $c = ktp_clean_phone($phone);
    return strlen($c) >= 9 ? '+' . $c : $c;
}

KTP();

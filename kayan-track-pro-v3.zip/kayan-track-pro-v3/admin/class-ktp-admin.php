<?php
defined('ABSPATH') || exit;

class KTP_Admin {

    public function __construct() {
        add_action('admin_menu',            [$this, 'menu']);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('wp_ajax_ktp_shell',     [$this, 'shell']);
    }

    public function menu(): void {
        add_menu_page('Kayan Track Pro','📊 Track Pro','manage_options','kayan-track-pro',[$this,'frame'],'dashicons-chart-area',25);
        $sub=[
            ['kayan-track-pro','📈 Dashboard'],['ktp-numbers','📞 الأرقام'],
            ['ktp-conversions','🎯 التحويلات'],['ktp-visitors','👥 الزوار'],
            ['ktp-fraud','🛡️ الاحتيال'],['ktp-heatmap','🔥 Heatmap'],
            ['ktp-dni','🔄 DNI'],['ktp-reports','📤 التقارير'],
            ['ktp-settings','⚙️ الإعدادات'],
        ];
        foreach ($sub as [$slug,$label]) {
            if ($slug==='kayan-track-pro') { add_submenu_page('kayan-track-pro',$label,$label,'manage_options',$slug,[$this,'frame']); continue; }
            add_submenu_page('kayan-track-pro',$label,$label,'manage_options',$slug,[$this,'frame']);
        }
    }

    public function assets(string $hook): void {
        if (!str_contains($hook,'kayan-track')&&!str_contains($hook,'ktp-')) return;
        wp_add_inline_style('wp-admin','#adminmenuwrap,#adminmenuback,#wpfooter,#wpadminbar{display:none!important}#wpcontent,#wpbody,#wpbody-content,#wpwrap{margin:0!important;padding:0!important;float:none!important;min-height:100vh}.wrap{margin:0!important;padding:0!important}html,body{overflow:hidden;height:100vh}');
    }

    public function frame(): void {
        $page = $_GET['page'] ?? 'kayan-track-pro';
        $cfg  = base64_encode(json_encode([
            'page'     => $page,
            'nonce'    => wp_create_nonce('kt_track'),
            'exp_n'    => wp_create_nonce('kt_export'),
            'admin_n'  => wp_create_nonce('ktp_admin'),
            'ajax'     => admin_url('admin-ajax.php'),
            'home'     => home_url('/'),
            'ver'      => KTP_VERSION,
            'settings' => array_merge(kt_default_settings(),(array)(get_option('kt_settings')??[])),
        ]));
        echo '<div style="position:fixed;inset:0;z-index:9999;background:#0d1117"><iframe src="' . esc_attr(admin_url('admin-ajax.php?action=ktp_shell')) . '#' . esc_attr($cfg) . '" style="width:100%;height:100%;border:none;display:block"></iframe></div>';
    }

    public function shell(): void {
        if (!current_user_can('manage_options')) wp_die();
        header('Content-Type:text/html;charset=UTF-8');
        header('X-Frame-Options:SAMEORIGIN');
        $this->html();
        exit;
    }

    private function html(): void {
        echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><title>Kayan Track Pro</title>';
        echo '<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">';
        echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">';
        $this->css();
        echo '</head><body><div id="app">';
        $this->topbar();
        $this->topnav();
        echo '<div id="bw">';
        $this->sidebar();
        echo '<div id="main"><div class="spinner-wrap"><i class="fa fa-spinner fa-spin" style="font-size:2rem;color:var(--blue)"></i></div></div>';
        echo '</div></div>';
        $this->modals();
        echo '<div id="toast"></div>';
        echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>';
        $this->js();
        echo '</body></html>';
    }

    private function css(): void { ?>
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{height:100%;overflow:hidden;font-family:'Tajawal',sans-serif;direction:rtl;-webkit-font-smoothing:antialiased}
:root{
  --brand:#1a6bff;--bg:#0d1117;--bg2:#161b22;--bg3:#1c2333;--bg4:#21262d;--bg5:#2d333b;
  --bd:#30363d;--tx:#e6edf3;--tx2:#c9d1d9;--tx3:#8b949e;--tx4:#484f58;
  --green:#2ea043;--gl:rgba(46,160,67,.12);--red:#f85149;--rl:rgba(248,81,73,.12);
  --blue:#388bfd;--bl:rgba(56,139,253,.12);--yellow:#d29922;--yl:rgba(210,153,34,.12);
  --orange:#f0883e;--ol:rgba(240,136,62,.12);--purple:#8957e5;--pl:rgba(137,87,229,.12);
  --wa:#25d366;--wal:rgba(37,211,102,.12);--cyan:#39d353;
  --grad:linear-gradient(135deg,#0d4fd4,#1a6bff,#7c3aed);
  --sh:0 1px 3px rgba(0,0,0,.4);--sh2:0 4px 16px rgba(0,0,0,.5);--sh3:0 8px 32px rgba(0,0,0,.6);
  --r:14px;--r2:10px;--r3:7px;--r4:5px;
  scrollbar-width:thin;scrollbar-color:var(--bg5) transparent;
}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-thumb{background:var(--bg5);border-radius:4px}

/* APP SHELL */
#app{display:flex;flex-direction:column;height:100vh;overflow:hidden;background:var(--bg)}
#bw{display:flex;flex:1;overflow:hidden}
#main{flex:1;overflow-y:auto;background:var(--bg);padding:.85rem .8rem 2rem}
.spinner-wrap{display:flex;align-items:center;justify-content:center;height:60vh}

/* TOPBAR */
#topbar{display:flex;align-items:center;justify-content:space-between;padding:0 .85rem;height:52px;flex-shrink:0;background:var(--bg2);border-bottom:1px solid var(--bd);box-shadow:var(--sh);z-index:10;gap:.5rem}
.tb-logo{width:34px;height:34px;background:var(--grad);border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;font-size:.9rem;flex-shrink:0;box-shadow:0 2px 10px rgba(26,107,255,.4)}
.tb-name{font-weight:900;font-size:.88rem;color:var(--tx);letter-spacing:-.3px}
.tb-sub{font-size:.47rem;color:var(--tx3);font-family:'JetBrains Mono',monospace}
.tb-brand{display:flex;align-items:center;gap:.55rem}
.live-dot{width:7px;height:7px;border-radius:50%;background:var(--green);display:inline-block;margin-right:.3rem;box-shadow:0 0 0 3px rgba(46,160,67,.2);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{box-shadow:0 0 0 3px rgba(46,160,67,.2)}50%{box-shadow:0 0 0 6px rgba(46,160,67,.04)}}
.tb-badge{background:var(--bl);color:var(--blue);font-size:.48rem;padding:.1rem .4rem;border-radius:20px;font-family:'JetBrains Mono',monospace;border:1px solid rgba(56,139,253,.2)}
.tb-wa{display:inline-flex;align-items:center;gap:.28rem;background:linear-gradient(135deg,#128C7E,#25D366);color:#fff;padding:.28rem .65rem;border-radius:20px;font-size:.7rem;font-weight:700;text-decoration:none;box-shadow:0 2px 8px rgba(37,211,102,.3)}

/* MOBILE TOP NAV */
#topnav{display:flex;background:var(--bg2);border-bottom:1px solid var(--bd);flex-shrink:0;overflow-x:auto;scrollbar-width:none}
#topnav::-webkit-scrollbar{display:none}
.tn{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:.38rem .45rem;flex:1;min-width:44px;gap:.08rem;font-size:.48rem;color:var(--tx3);border:none;background:none;cursor:pointer;font-family:'Tajawal',sans-serif;white-space:nowrap;border-bottom:2px solid transparent;margin-bottom:-1px;transition:color .15s,border-color .15s}
.tn i{font-size:.85rem}.tn.active{color:var(--blue);border-bottom-color:var(--blue)}
@media(min-width:768px){#topnav{display:none}}

/* SIDEBAR */
#sidebar{display:none;width:192px;flex-shrink:0;background:var(--bg2);border-left:1px solid var(--bd);overflow-y:auto;padding:.4rem 0;flex-direction:column}
@media(min-width:768px){#sidebar{display:flex}}
.sb-sec{padding:.28rem .75rem .08rem;font-size:.55rem;font-weight:700;color:var(--tx4);letter-spacing:.07em;text-transform:uppercase;margin-top:.4rem}
.sb-btn{display:flex;align-items:center;gap:.55rem;padding:.55rem .95rem;font-size:.78rem;color:var(--tx2);border:none;background:none;width:100%;text-align:right;cursor:pointer;font-family:'Tajawal',sans-serif;font-weight:600;border-right:3px solid transparent;transition:all .15s}
.sb-btn:hover{background:var(--bg3);color:var(--tx)}.sb-btn.active{color:var(--blue);background:var(--bl);border-right-color:var(--blue);font-weight:800}
.sb-btn i{width:15px;text-align:center;font-size:.78rem;flex-shrink:0}
.sb-num-btn{display:flex;align-items:center;gap:.45rem;padding:.42rem .75rem .42rem .95rem;font-size:.72rem;color:var(--tx2);border:none;background:none;width:100%;text-align:right;cursor:pointer;font-family:'Tajawal',sans-serif;transition:background .15s}
.sb-num-btn:hover{background:var(--bg3)}.sb-num-btn.active{background:var(--bl);color:var(--blue);font-weight:700}
.sb-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.sb-cnt{font-family:'JetBrains Mono',monospace;font-size:.58rem;color:var(--tx3);margin-right:auto}
.sb-foot{margin-top:auto;padding:.65rem;border-top:1px solid var(--bd)}
.sb-info{font-size:.58rem;color:var(--tx4);line-height:1.6;font-family:'JetBrains Mono',monospace}

/* PAGE HEADER */
.phdr{margin-bottom:.85rem}
.ptitle{font-size:1.1rem;font-weight:900;color:var(--tx);display:flex;align-items:center;gap:.45rem;margin-bottom:.18rem}
.ptitle i{color:var(--blue)}.psub{font-size:.74rem;color:var(--tx3)}

/* PERIOD BAR */
.period-bar{display:flex;align-items:center;flex-wrap:wrap;gap:.4rem;padding:.55rem .75rem;background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2);box-shadow:var(--sh);margin-bottom:.85rem}
.qbtn{padding:.26rem .65rem;border:1px solid var(--bd);background:var(--bg3);color:var(--tx3);border-radius:20px;font-size:.7rem;font-weight:600;cursor:pointer;font-family:'Tajawal',sans-serif;transition:all .15s}
.qbtn:hover,.qbtn.a{background:var(--blue);color:#fff;border-color:var(--blue);box-shadow:0 2px 8px rgba(26,107,255,.3)}
.dateinp{border:1px solid var(--bd);border-radius:var(--r4);padding:.26rem .5rem;font-size:.7rem;background:var(--bg3);color:var(--tx);font-family:'Tajawal',sans-serif;min-width:108px}
.apply-btn{padding:.26rem .7rem;background:var(--blue);color:#fff;border:none;border-radius:var(--r4);font-size:.7rem;font-weight:700;cursor:pointer;font-family:'Tajawal',sans-serif}

/* STAT CARDS */
.cards{display:grid;grid-template-columns:repeat(2,1fr);gap:.6rem;margin-bottom:.85rem}
@media(min-width:540px){.cards{grid-template-columns:repeat(4,1fr)}}
.sc{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2);padding:.82rem .78rem;box-shadow:var(--sh);position:relative;overflow:hidden;transition:transform .2s}
.sc:hover{transform:translateY(-2px)}.sc::before{content:'';position:absolute;top:0;right:0;width:3px;height:100%}
.c-bl::before{background:var(--blue)}.c-gr::before{background:var(--green)}.c-wa::before{background:var(--wa)}
.c-rd::before{background:var(--red)}.c-or::before{background:var(--orange)}.c-pu::before{background:var(--purple)}
.c-cy::before{background:var(--cyan)}.c-gy::before{background:var(--tx3)}
.sc-ico{font-size:1.05rem;margin-bottom:.28rem;display:block}
.c-bl .sc-ico{color:var(--blue)}.c-gr .sc-ico{color:var(--green)}.c-wa .sc-ico{color:var(--wa)}
.c-rd .sc-ico{color:var(--red)}.c-or .sc-ico{color:var(--orange)}.c-pu .sc-ico{color:var(--purple)}
.c-cy .sc-ico{color:var(--cyan)}.c-gy .sc-ico{color:var(--tx3)}
.sc-val{font-family:'JetBrains Mono',monospace;font-size:1.45rem;font-weight:700;color:var(--tx);line-height:1;margin-bottom:.14rem}
.sc-lbl{font-size:.65rem;color:var(--tx3);font-weight:500}
.skel{background:linear-gradient(90deg,var(--bg3) 25%,var(--bg4) 50%,var(--bg3) 75%);background-size:200% 100%;animation:shim 1.4s infinite;border-radius:var(--r2);border:1px solid var(--bd)}
@keyframes shim{from{background-position:200% 0}to{background-position:-200% 0}}

/* NUMBER CARDS */
.nums-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:.65rem;margin-bottom:.85rem}
.num-card{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2);padding:.88rem .95rem;box-shadow:var(--sh);cursor:pointer;transition:all .2s;position:relative;overflow:hidden}
.num-card:hover{transform:translateY(-3px);box-shadow:var(--sh2)}.num-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:var(--nc,var(--blue))}
.num-card.sel{border-color:var(--nc,var(--blue));box-shadow:0 0 0 2px color-mix(in srgb,var(--nc,var(--blue)) 30%,transparent)}
.nc-top{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:.55rem}
.nc-badge{font-family:'JetBrains Mono',monospace;font-size:.73rem;font-weight:700;color:var(--tx);background:var(--bg3);padding:.22rem .5rem;border-radius:5px;border:1px solid var(--bd)}
.nc-lbl{font-size:.7rem;color:var(--tx3);font-weight:600;margin-bottom:.28rem}
.nc-stats{display:flex;gap:.45rem;margin-top:.45rem;flex-wrap:wrap}
.nc-stat{text-align:center;flex:1;min-width:38px}
.nc-sv{font-family:'JetBrains Mono',monospace;font-size:.82rem;font-weight:700;color:var(--tx);display:block}
.nc-sl{font-size:.56rem;color:var(--tx3)}
.nc-acts{display:flex;gap:.28rem;margin-top:.55rem}
.nc-btn{flex:1;padding:.26rem 0;border:1px solid var(--bd);background:var(--bg3);color:var(--tx2);border-radius:var(--r4);font-size:.66rem;font-weight:600;cursor:pointer;font-family:'Tajawal',sans-serif;text-align:center;transition:all .15s}
.nc-btn:hover{background:var(--blue);color:#fff;border-color:var(--blue)}.nc-btn.d:hover{background:var(--red);color:#fff;border-color:var(--red)}

/* CHARTS */
.charts-grid{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;margin-bottom:.85rem}
@media(min-width:768px){.charts-grid{grid-template-columns:2fr 1fr 1fr}}
.cbox{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2);padding:.72rem;box-shadow:var(--sh);display:flex;flex-direction:column}
.cbox-wide{grid-column:1/-1}@media(min-width:768px){.cbox-wide{grid-column:auto}}
.ch-wrap{position:relative;width:100%;padding-top:100%}
.cbox-wide .ch-wrap{padding-top:0;height:155px}
.ch-wrap canvas{position:absolute;inset:0;width:100%!important;height:100%!important}
.chead{font-weight:700;font-size:.76rem;color:var(--tx2);padding-bottom:.45rem;margin-bottom:.45rem;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:.28rem}
.chead i{color:var(--blue);font-size:.8rem}
.leg{display:flex;flex-wrap:wrap;gap:.22rem .45rem;margin-top:.45rem}
.leg-i{display:flex;align-items:center;gap:.22rem;font-size:.63rem;color:var(--tx2)}
.leg-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}

/* BOX */
.box{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2);padding:.82rem;box-shadow:var(--sh);margin-bottom:.85rem}
.bhead{font-weight:800;font-size:.8rem;color:var(--tx2);padding-bottom:.48rem;margin-bottom:.6rem;border-bottom:1px solid var(--bd);display:flex;align-items:center;justify-content:space-between;gap:.3rem}
.bhl{display:flex;align-items:center;gap:.3rem}.bhead i{color:var(--blue);font-size:.82rem}
.wrow{display:grid;grid-template-columns:1fr;gap:.6rem;margin-bottom:.85rem}
@media(min-width:680px){.wrow{grid-template-columns:1fr 1fr}}

/* FILTERS / TABLE */
.fbar{display:flex;flex-wrap:wrap;gap:.38rem;margin-bottom:.6rem;align-items:center}
.sw{display:flex;align-items:center;gap:.3rem;background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r4);padding:.28rem .6rem;flex:1;min-width:130px;transition:border-color .15s}
.sw:focus-within{border-color:var(--blue)}.sw i{color:var(--tx3);font-size:.75rem}
.sinp{border:none;outline:none;background:transparent;font-size:.76rem;color:var(--tx);width:100%;font-family:'Tajawal',sans-serif}
.sinp::placeholder{color:var(--tx4)}
select.fsel{border:1px solid var(--bd);border-radius:var(--r4);padding:.28rem .55rem;font-size:.73rem;background:var(--bg3);color:var(--tx);cursor:pointer;font-family:'Tajawal',sans-serif}
.fbtn{padding:.3rem .82rem;background:var(--blue);color:#fff;border:none;border-radius:var(--r4);font-size:.73rem;font-weight:700;cursor:pointer;font-family:'Tajawal',sans-serif;display:inline-flex;align-items:center;gap:.25rem}
.exp-btn{display:inline-flex;align-items:center;gap:.22rem;border:1px solid var(--bd);background:var(--bg2);color:var(--tx2);padding:.28rem .58rem;border-radius:var(--r4);font-size:.68rem;font-weight:600;cursor:pointer;text-decoration:none;transition:all .2s}
.exp-btn:hover{background:var(--green);color:#fff;border-color:var(--green)}
.tmeta{font-size:.72rem;color:var(--tx3);margin-bottom:.48rem}
.twrap{overflow-x:auto;border-radius:var(--r2);border:1px solid var(--bd);box-shadow:var(--sh);background:var(--bg2);-webkit-overflow-scrolling:touch}
table.kt{width:100%;border-collapse:collapse;min-width:660px}
table.kt thead tr{background:var(--bg3);position:sticky;top:0;z-index:2}
table.kt th{padding:.52rem .7rem;text-align:right;font-size:.65rem;color:var(--tx3);font-weight:700;border-bottom:2px solid var(--bd);white-space:nowrap}
table.kt td{padding:.52rem .7rem;font-size:.73rem;color:var(--tx2);border-bottom:1px solid var(--bd);vertical-align:middle;white-space:nowrap}
table.kt tbody tr:last-child td{border-bottom:none}
table.kt tbody tr:hover{background:var(--bl)}.sus-row{background:var(--rl)!important}
.td-time{font-family:'JetBrains Mono',monospace;font-size:.61rem;color:var(--tx3)}
.td-ph{font-family:'JetBrains Mono',monospace;font-size:.7rem;font-weight:700;color:var(--tx)}
.lc,.nd{text-align:center;padding:1.6rem;color:var(--tx3);font-style:italic}
.pages{display:flex;justify-content:center;gap:.28rem;padding:.7rem 0}
.pg{min-width:30px;height:30px;display:flex;align-items:center;justify-content:center;border:1px solid var(--bd);border-radius:var(--r4);background:var(--bg2);color:var(--tx3);font-size:.76rem;font-weight:700;cursor:pointer;transition:all .15s;font-family:'Tajawal',sans-serif}
.pg:hover,.pg.a{background:var(--blue);color:#fff;border-color:var(--blue)}

/* BADGES */
.cb{display:inline-flex;align-items:center;gap:.2rem;font-size:.66rem;padding:.16rem .48rem;border-radius:100px;font-weight:700;border:1px solid transparent}
.b-call{background:var(--gl);color:var(--green);border-color:rgba(46,160,67,.2)}
.b-wa{background:var(--wal);color:var(--wa);border-color:rgba(37,211,102,.2)}
.b-form{background:var(--bl);color:var(--blue)}.b-cta{background:var(--ol);color:var(--orange)}
.src{display:inline-block;font-size:.61rem;padding:.08rem .42rem;border-radius:100px;font-weight:700;font-family:'JetBrains Mono',monospace}
.s-dir{background:var(--bg3);color:var(--tx3);border:1px solid var(--bd)}.s-org{background:var(--gl);color:var(--green)}
.s-pad,.s-gads{background:var(--ol);color:var(--orange)}.s-soc{background:var(--bl);color:var(--blue)}
.s-ref{background:var(--pl);color:var(--purple)}.s-cam{background:var(--yl);color:var(--yellow)}
.iptag{font-family:'JetBrains Mono',monospace;font-size:.61rem;background:var(--bg3);padding:.04rem .28rem;border-radius:3px;color:var(--tx2);border:1px solid var(--bd)}
.iptag.sus{background:var(--rl);border-color:rgba(248,81,73,.3);color:var(--red)}
.numtag{display:inline-flex;align-items:center;gap:.22rem;font-family:'JetBrains Mono',monospace;font-size:.63rem;padding:.08rem .38rem;border-radius:4px;font-weight:700;border:1px solid}
.dev-c{display:flex;align-items:center;gap:.28rem;font-size:.71rem}
.ic-mob{color:var(--blue)}.ic-des{color:var(--purple)}.ic-tab{color:var(--orange)}

/* MODAL */
.mb{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:1000;display:flex;align-items:center;justify-content:center;padding:.85rem}
.mo{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r);padding:1.15rem;width:100%;max-width:410px;box-shadow:var(--sh3)}
.mo-t{font-size:.92rem;font-weight:800;color:var(--tx);margin-bottom:.95rem;display:flex;align-items:center;justify-content:space-between}
.mo-x{background:none;border:none;color:var(--tx3);cursor:pointer;font-size:.95rem;padding:.18rem}
.field{margin-bottom:.65rem}.field label{display:block;font-size:.76rem;font-weight:600;color:var(--tx2);margin-bottom:.28rem}
.inp{width:100%;border:1px solid var(--bd);border-radius:var(--r4);padding:.36rem .62rem;font-size:.78rem;color:var(--tx);background:var(--bg3);font-family:'Tajawal',sans-serif}
.inp:focus{outline:none;border-color:var(--blue)}.inpr{display:flex;gap:.45rem}
select.inp{cursor:pointer}

/* BUTTONS */
.btn-p{display:inline-flex;align-items:center;gap:.28rem;background:var(--grad);color:#fff;padding:.42rem 1.05rem;border:none;border-radius:var(--r4);font-size:.76rem;font-weight:700;cursor:pointer;font-family:'Tajawal',sans-serif;box-shadow:0 2px 8px rgba(26,107,255,.3);transition:opacity .15s}
.btn-p:hover{opacity:.9}.btn-p.full{width:100%;justify-content:center}
.btn-d{padding:.3rem .82rem;background:linear-gradient(135deg,#b91c1c,var(--red));color:#fff;border:none;border-radius:var(--r4);font-size:.73rem;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:.26rem;font-family:'Tajawal',sans-serif}
.btn-o{display:inline-flex;align-items:center;gap:.25rem;border:1px solid var(--blue);color:var(--blue);padding:.28rem .72rem;border-radius:var(--r4);font-size:.71rem;font-weight:600;background:transparent;cursor:pointer;font-family:'Tajawal',sans-serif;text-decoration:none;transition:all .15s}
.btn-o:hover{background:var(--blue);color:#fff}

/* TOAST */
#toast{position:fixed;bottom:.85rem;left:50%;transform:translateX(-50%) translateY(70px);background:var(--bg2);border:1px solid var(--bd);color:var(--tx);padding:.55rem 1.1rem;border-radius:var(--r2);font-size:.78rem;font-weight:600;box-shadow:var(--sh3);z-index:9999;transition:transform .3s;white-space:nowrap}
#toast.show{transform:translateX(-50%) translateY(0)}
#toast.ok{border-color:rgba(46,160,67,.4);background:var(--gl);color:var(--green)}
#toast.err{border-color:rgba(248,81,73,.4);background:var(--rl);color:var(--red)}

/* IP rows */
.ipr{display:flex;align-items:center;gap:.38rem;padding:.42rem .58rem;border-radius:var(--r4);border:1px solid var(--bd);background:var(--bg3);font-size:.73rem;margin-bottom:.28rem}
.ipr.warn{border-color:rgba(210,153,34,.4);background:var(--yl)}.ipr.danger{border-color:rgba(248,81,73,.4);background:var(--rl)}
.blk-btn{border:1px solid rgba(248,81,73,.3);background:var(--rl);color:var(--red);width:25px;height:25px;border-radius:50%;cursor:pointer;font-size:.63rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.blk-btn:hover{background:var(--red);color:#fff;border-color:var(--red)}
.bl-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:.45rem}
.bl-card{background:var(--bg2);border:1px solid rgba(248,81,73,.3);border-radius:var(--r4);padding:.7rem}
.ublk{width:100%;padding:.3rem;border:1px solid var(--bd);background:var(--bg3);color:var(--tx2);border-radius:var(--r4);font-size:.7rem;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:.25rem;font-family:'Tajawal',sans-serif;transition:all .15s}
.ublk:hover{background:var(--green);color:#fff;border-color:var(--green)}
.empty{text-align:center;padding:2.2rem;color:var(--tx3)}.empty i{font-size:1.8rem;color:var(--tx4);display:block;margin-bottom:.45rem}

/* SETTINGS */
.sg{display:grid;grid-template-columns:1fr;gap:.62rem}
@media(min-width:560px){.sg{grid-template-columns:1fr 1fr}}
.sbox{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2);padding:.95rem;box-shadow:var(--sh)}
.sbox-t{font-weight:800;font-size:.8rem;color:var(--tx2);padding-bottom:.52rem;margin-bottom:.68rem;border-bottom:1px solid var(--bd);display:flex;align-items:center;gap:.3rem}
.sbox-t i{color:var(--blue)}.sbox.info{background:var(--bl);border-color:rgba(56,139,253,.2)}.sbox.info .sbox-t{color:var(--blue)}
.swrow{display:flex;justify-content:space-between;align-items:center;padding:.52rem 0;border-bottom:1px solid var(--bd)}.swrow:last-of-type{border-bottom:none}.swrow span{font-size:.78rem;color:var(--tx2)}
.frow{display:flex;justify-content:space-between;align-items:center;padding:.52rem 0;border-bottom:1px solid var(--bd);gap:.6rem}.frow span{font-size:.78rem;color:var(--tx2)}
.hint{font-size:.68rem;color:var(--tx3);padding:.22rem 0;line-height:1.5}
.toggle{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0}
.tsl{position:absolute;inset:0;background:var(--bg4);border-radius:22px;transition:.25s;cursor:pointer;border:1px solid var(--bd)}
.tsl::before{content:'';position:absolute;width:16px;height:16px;right:2px;top:2px;background:#fff;border-radius:50%;transition:.25s}
.toggle input:checked + .tsl{background:var(--blue);border-color:var(--blue)}
.toggle input:checked + .tsl::before{transform:translateX(-18px)}
</style>
<?php
    }

    private function topbar(): void { ?>
<div id="topbar">
  <div class="tb-brand">
    <div class="tb-logo"><i class="fa fa-chart-line"></i></div>
    <div>
      <div class="tb-name"><span class="live-dot"></span>Kayan Track Pro</div>
      <div class="tb-sub">by MAHMOUD ELSAAD &nbsp;<span class="tb-badge" id="tbv">v3</span></div>
    </div>
  </div>
  <a id="tbwa" href="#" class="tb-wa" target="_blank"><i class="fab fa-whatsapp"></i> واتساب</a>
</div>
<?php }

    private function topnav(): void { ?>
<div id="topnav">
  <?php
  $pages=[['dashboard','fa-gauge','لوحة'],['numbers','fa-phone','أرقام'],['conversions','fa-bullseye','تحويل'],
          ['visitors','fa-users','زوار'],['fraud','fa-shield-halved','حماية'],['heatmap','fa-fire','حرارة'],
          ['dni','fa-rotate','DNI'],['reports','fa-share-nodes','تقارير'],['settings','fa-gear','إعداد']];
  foreach($pages as [$p,$ic,$lb]) echo "<button class='tn' data-page='$p'><i class='fa $ic'></i><span>$lb</span></button>";
  ?>
</div>
<?php }

    private function sidebar(): void { ?>
<div id="sidebar">
  <div class="sb-sec">التحليل</div>
  <button class="sb-btn" data-page="dashboard"><i class="fa fa-gauge"></i> Dashboard</button>
  <div class="sb-sec">📞 الأرقام</div>
  <button class="sb-btn" data-page="numbers"><i class="fa fa-phone-volume"></i> إدارة الأرقام</button>
  <div id="sb-nums"></div>
  <div class="sb-sec">التحويلات</div>
  <button class="sb-btn" data-page="conversions"><i class="fa fa-bullseye"></i> كل التحويلات</button>
  <button class="sb-btn" data-page="visitors"><i class="fa fa-users"></i> الزوار</button>
  <div class="sb-sec">الأدوات</div>
  <button class="sb-btn" data-page="fraud"><i class="fa fa-shield-halved"></i> الاحتيال</button>
  <button class="sb-btn" data-page="heatmap"><i class="fa fa-fire"></i> Heatmap</button>
  <button class="sb-btn" data-page="dni"><i class="fa fa-rotate"></i> DNI</button>
  <button class="sb-btn" data-page="reports"><i class="fa fa-share-nodes"></i> التقارير</button>
  <button class="sb-btn" data-page="settings"><i class="fa fa-gear"></i> الإعدادات</button>
  <div class="sb-foot"><div class="sb-info">Kayan Track Pro v3.0<br>© Mahmoud Elsaad</div></div>
</div>
<?php }

    private function modals(): void { ?>
<!-- Number modal -->
<div id="nm" style="display:none"><div class="mb" onclick="if(event.target===this)closeNM()"><div class="mo">
  <div class="mo-t"><span id="nm-title">إضافة رقم</span><button class="mo-x" onclick="closeNM()"><i class="fa fa-times"></i></button></div>
  <input type="hidden" id="nm-id">
  <div class="field"><label>الاسم / التصنيف</label><input class="inp" id="nm-label" placeholder="مثال: رقم دبي الرئيسي"></div>
  <div class="inpr">
    <div class="field" style="flex:1"><label>رقم الهاتف</label><input class="inp" id="nm-phone" placeholder="971501234567" dir="ltr"></div>
    <div class="field" style="flex:1"><label>رقم واتساب</label><input class="inp" id="nm-wa" placeholder="نفس الرقم" dir="ltr"></div>
  </div>
  <div class="inpr">
    <div class="field" style="flex:1"><label>النوع</label><select class="inp" id="nm-type"><option value="both">الاثنان</option><option value="call">اتصال</option><option value="whatsapp">واتساب</option></select></div>
    <div class="field" style="flex:1"><label>اللون</label><input type="color" class="inp" id="nm-color" value="#388bfd" style="height:38px;padding:.18rem"></div>
  </div>
  <div class="field"><label>ملاحظة</label><textarea class="inp" id="nm-note" rows="2"></textarea></div>
  <button class="btn-p full" onclick="saveNum()"><i class="fa fa-save"></i> حفظ</button>
</div></div></div>

<!-- DNI modal -->
<div id="dm" style="display:none"><div class="mb" onclick="if(event.target===this)closeDM()"><div class="mo">
  <div class="mo-t"><span>إضافة قاعدة DNI</span><button class="mo-x" onclick="closeDM()"><i class="fa fa-times"></i></button></div>
  <input type="hidden" id="dm-id">
  <div class="field"><label>الرقم</label><select class="inp" id="dm-num" style="width:100%"></select></div>
  <div class="field"><label>مصدر الزيارة</label>
    <select class="inp" id="dm-src">
      <option value="google_ads">Google Ads (gclid)</option><option value="paid">إعلانات مدفوعة</option>
      <option value="social">تواصل اجتماعي</option><option value="organic">بحث طبيعي</option>
      <option value="direct">مباشر</option><option value="campaign">حملة UTM</option>
    </select>
  </div>
  <div class="inpr">
    <div class="field" style="flex:1"><label>utm_source</label><input class="inp" id="dm-us" placeholder="google, facebook..."></div>
    <div class="field" style="flex:1"><label>utm_campaign</label><input class="inp" id="dm-uc" placeholder="اسم الحملة"></div>
  </div>
  <div class="field"><label>الأولوية (0-10)</label><input type="number" class="inp" id="dm-pri" value="0" min="0" max="10"></div>
  <button class="btn-p full" onclick="saveDNI()"><i class="fa fa-save"></i> حفظ</button>
</div></div></div>
<?php }

    private function js(): void {
        // The JavaScript is output separately due to size - see js() method below
        ?>
<script>
'use strict';
var C={},DAYS=30,FROM='',TO='',PAGE=1,NUMS=[],_pg='dashboard',_nid=null;

// BOOT
(function(){
  try{var h=location.hash.slice(1);if(h)C=JSON.parse(atob(decodeURIComponent(h)));}catch(e){}
  document.getElementById('tbv').textContent='v'+(C.ver||'3');
  var wa=C.settings&&C.settings.whatsapp_number;
  if(wa)document.getElementById('tbwa').href='https://wa.me/'+wa;
  Chart.defaults.color='#8b949e';Chart.defaults.borderColor='#30363d';
  Chart.defaults.font.family="'JetBrains Mono',monospace";
  loadNums(function(){
    var pg=(C.page||'').replace('kayan-track-pro','dashboard').replace('ktp-','');
    goTo(pg||'dashboard');
  });
  document.querySelectorAll('[data-page]').forEach(function(b){b.addEventListener('click',function(){goTo(this.dataset.page);});});
})();

var CHARTS={};
function destCharts(){Object.values(CHARTS).forEach(function(c){try{c.destroy();}catch(e){}});CHARTS={};}
function toast(m,t,d){var el=document.getElementById('toast');el.textContent=m;el.className='show '+(t||'');clearTimeout(el._t);el._t=setTimeout(function(){el.className='';},d||2700);}

function goTo(pg){
  _pg=pg;_nid=null;
  document.querySelectorAll('[data-page]').forEach(function(b){b.classList.toggle('active',b.dataset.page===pg);});
  destCharts();
  document.getElementById('main').innerHTML='<div class="spinner-wrap"><i class="fa fa-spinner fa-spin" style="font-size:2rem;color:var(--blue)"></i></div>';
  setTimeout(function(){
    switch(pg){
      case 'dashboard':rDash();break;case 'numbers':rNums();break;
      case 'conversions':rConv();break;case 'visitors':rVis();break;
      case 'fraud':rFraud();break;case 'heatmap':rHeat();break;
      case 'dni':rDNI();break;case 'reports':rRep();break;
      case 'settings':rSettings();break;default:rDash();
    }
  },40);
}
function reLoad(){PAGE=1;goTo(_pg);}
function goNum(id){
  _pg='num_detail';_nid=id;
  document.querySelectorAll('[data-page]').forEach(function(b){b.classList.remove('active');});
  document.querySelectorAll('.sb-num-btn').forEach(function(b){b.classList.toggle('active',parseInt(b.dataset.nid)===id);});
  destCharts();
  document.getElementById('main').innerHTML='<div class="spinner-wrap"><i class="fa fa-spinner fa-spin" style="font-size:2rem;color:var(--blue)"></i></div>';
  setTimeout(function(){rNumDetail(id);},40);
}

// API CALLS
function api(action,extra,cb){
  var fd=new FormData();
  fd.append('action','ktp_admin_data');fd.append('nonce',C.nonce||'');
  fd.append('ktp_action',action);fd.append('days',DAYS);
  if(FROM)fd.append('date_from',FROM);if(TO)fd.append('date_to',TO);
  (extra||[]).forEach(function(p){fd.append(p[0],p[1]);});
  fetch(C.ajax||'',{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(r){cb(r.success?r.data:null);}).catch(function(){cb(null);});
}
function ajax(action,data,cb){
  var fd=new FormData();fd.append('action',action);fd.append('nonce',C.admin_n||C.nonce||'');
  Object.keys(data).forEach(function(k){fd.append(k,data[k]);});
  fetch(C.ajax||'',{method:'POST',body:fd}).then(function(r){return r.json();}).then(cb).catch(function(){});
}

// NUMS
function loadNums(cb){
  ajax('ktp_list_numbers',{days:DAYS},function(r){
    NUMS=r&&r.success&&r.data?r.data:[];
    rSbNums();if(cb)cb();
  });
}
function rSbNums(){
  var el=document.getElementById('sb-nums');if(!el)return;
  el.innerHTML=NUMS.map(function(n){
    return'<button class="sb-num-btn" data-nid="'+n.id+'" onclick="goNum('+n.id+')">'
      +'<span class="sb-dot" style="background:'+x(n.color)+'"></span>'
      +'<span style="flex:1;font-size:.7rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+x(n.label||n.phone)+'</span>'
      +'<span class="sb-cnt">'+N(n.total||0)+'</span>'
    +'</button>';
  }).join('');
  // Populate DNI modal number select
  var dmn=document.getElementById('dm-num');
  if(dmn)dmn.innerHTML=NUMS.map(function(n){return'<option value="'+n.id+'">'+x(n.label||n.phone)+'</option>';}).join('');
}

// HELPERS
function N(n){return n>=1e6?(n/1e6).toFixed(1)+'M':n>=1e3?(n/1e3).toFixed(1)+'K':(+n||0).toLocaleString();}
function ago(dt){if(!dt)return'—';var s=Math.floor((Date.now()-new Date(dt))/1000);if(s<60)return'الآن';if(s<3600)return Math.floor(s/60)+'د';if(s<86400)return Math.floor(s/3600)+'س';return Math.floor(s/86400)+'ي';}
function x(s){if(!s)return'';return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function fmtPh(p){if(!p)return'—';p=String(p).replace(/[^0-9]/g,'');return p.length>=9?'+'+p:p;}
function badge(t){var m={call:'<i class="fa fa-phone"></i> اتصال',whatsapp:'<i class="fab fa-whatsapp"></i> واتساب',form:'<i class="fa fa-file-alt"></i> نموذج',cta:'CTA'};var c={call:'b-call',whatsapp:'b-wa',form:'b-form',cta:'b-cta'};return'<span class="cb '+(c[t]||'b-cta')+'">'+(m[t]||t)+'</span>';}
function srcChip(s){var m={direct:'s-dir',organic:'s-org',paid:'s-pad',google_ads:'s-gads',social:'s-soc',referral:'s-ref',campaign:'s-cam'};var n={direct:'مباشر',organic:'بحث',paid:'إعلان',google_ads:'جوجل',social:'تواصل',referral:'إحالة',campaign:'حملة'};return'<span class="src '+(m[s]||'s-dir')+'">'+(n[s]||s)+'</span>';}
function devIco(d){return d==='mobile'?'<i class="fa fa-mobile-alt ic-mob"></i>':d==='tablet'?'<i class="fa fa-tablet-alt ic-tab"></i>':'<i class="fa fa-desktop ic-des"></i>';}
function pgHTML(pg,tot,per){var ps=Math.ceil(tot/per);if(ps<=1)return'';var h='<div class="pages">';if(pg>1)h+='<button class="pg" onclick="PAGE='+(pg-1)+';reLoad()"><i class="fa fa-chevron-right"></i></button>';var s=Math.max(1,pg-2),e=Math.min(ps,pg+2);for(var i=s;i<=e;i++)h+='<button class="pg'+(i===pg?' a':'')+'" onclick="PAGE='+i+';reLoad()">'+i+'</button>';if(pg<ps)h+='<button class="pg" onclick="PAGE='+(pg+1)+';reLoad()"><i class="fa fa-chevron-left"></i></button>';return h+'</div>';}
function pBar(){return'<div class="period-bar"><div style="display:flex;gap:.3rem;flex-wrap:wrap">'+[1,2,7,30,90].map(function(d){return'<button class="qbtn'+(DAYS===d?' a':'')+'" onclick="DAYS='+d+';FROM=\'\';TO=\'\';reLoad()">'+d+'ي</button>';}).join('')+'</div><div style="display:flex;gap:.35rem;align-items:center;flex-wrap:wrap"><input type="date" class="dateinp" id="pF" value="'+FROM+'" onchange="FROM=this.value"><input type="date" class="dateinp" id="pT" value="'+TO+'" onchange="TO=this.value"><button class="apply-btn" onclick="reLoad()">تطبيق</button></div></div>';}
function since(){return FROM?FROM+' 00:00:00':new Date(Date.now()-DAYS*864e5).toISOString().slice(0,19).replace('T',' ');}
function mkLine(id,labels,ds){var ctx=document.getElementById(id);if(!ctx)return;if(CHARTS[id])CHARTS[id].destroy();CHARTS[id]=new Chart(ctx,{type:'line',data:{labels:labels,datasets:ds},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:ds.length>1,labels:{boxWidth:9,font:{size:8}}}},scales:{x:{grid:{color:'rgba(48,54,61,.5)'},ticks:{maxTicksLimit:7,font:{size:8}}},y:{grid:{color:'rgba(48,54,61,.5)'},ticks:{font:{size:8}}}}}});}
function mkDonut(id,labels,data,colors){var ctx=document.getElementById(id);if(!ctx)return;if(CHARTS[id])CHARTS[id].destroy();CHARTS[id]=new Chart(ctx,{type:'doughnut',data:{labels:labels,datasets:[{data:data,backgroundColor:colors,borderColor:'transparent',borderWidth:0,hoverOffset:4}]},options:{responsive:true,maintainAspectRatio:false,cutout:'68%',plugins:{legend:{display:false}}}});}
function mkBar(id,labels,data,colors){var ctx=document.getElementById(id);if(!ctx)return;if(CHARTS[id])CHARTS[id].destroy();CHARTS[id]=new Chart(ctx,{type:'bar',data:{labels:labels,datasets:[{data:data,backgroundColor:colors||'rgba(56,139,253,.7)',borderRadius:4,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false},ticks:{font:{size:8}}},y:{grid:{color:'rgba(48,54,61,.5)'},ticks:{font:{size:8}}}}}});}

/* ═══════════════════════ DASHBOARD ═══════════════════════ */
function rDash(){
  _pg='dashboard';
  var M=document.getElementById('main');
  M.innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-gauge"></i> Dashboard</div><div class="psub">نظرة شاملة على كل الأرقام والحملات</div></div>'+
    pBar()+
    '<div class="cards" id="dc">'+[1,2,3,4,5,6,7,8].map(function(){return'<div class="skel" style="height:86px"></div>';}).join('')+'</div>'+
    '<div style="margin-bottom:.85rem"><div class="bhead" style="padding:.58rem .82rem;background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r2) var(--r2) 0 0;margin-bottom:0"><div class="bhl"><i class="fa fa-phone-volume"></i> أداء الأرقام</div><button class="btn-o" onclick="goTo(\'numbers\')"><i class="fa fa-plus"></i> إضافة</button></div><div class="nums-grid" id="dn" style="background:var(--bg2);border:1px solid var(--bd);border-top:none;padding:.72rem;border-radius:0 0 var(--r2) var(--r2)"><div class="skel" style="height:120px"></div><div class="skel" style="height:120px"></div></div></div>'+
    '<div class="charts-grid">'+
      '<div class="cbox cbox-wide"><div class="chead"><i class="fa fa-chart-line"></i> التحويلات اليومية</div><div class="ch-wrap"><canvas id="cl"></canvas></div></div>'+
      '<div class="cbox"><div class="chead"><i class="fa fa-mobile-alt"></i> الأجهزة</div><div class="ch-wrap"><canvas id="cd"></canvas></div><div class="leg" id="ld"></div></div>'+
      '<div class="cbox"><div class="chead"><i class="fa fa-globe"></i> المصادر</div><div class="ch-wrap"><canvas id="cs"></canvas></div><div class="leg" id="ls"></div></div>'+
    '</div>'+
    '<div class="wrow">'+
      '<div class="box" style="margin:0"><div class="bhead"><div class="bhl"><i class="fa fa-fire"></i> أعلى الصفحات</div></div><div id="dp"></div></div>'+
      '<div class="box" style="margin:0"><div class="bhead"><div class="bhl"><i class="fa fa-triangle-exclamation"></i> IPs مشبوهة</div></div><div id="di"></div></div>'+
    '</div>';

  api('dashboard',[],function(d){
    if(!d){document.getElementById('dc').innerHTML='<div style="color:var(--tx3);grid-column:1/-1;padding:1rem;text-align:center">تعذّر تحميل البيانات</div>';return;}
    document.getElementById('dc').innerHTML=[
      {v:N(d.total||0),l:'إجمالي التحويلات',i:'fa-bullseye',c:'c-bl'},
      {v:N(d.whatsapp||0),l:'واتساب',i:'fa-whatsapp fab',c:'c-wa'},
      {v:N(d.calls||0),l:'مكالمات',i:'fa-phone',c:'c-gr'},
      {v:N(d.unique||0),l:'فريدة',i:'fa-fingerprint',c:'c-pu'},
      {v:N(d.visitors||0),l:'الزوار',i:'fa-users',c:'c-cy'},
      {v:N(d.sessions||0),l:'الجلسات',i:'fa-layer-group',c:'c-or'},
      {v:N(d.suspicious||0),l:'مشبوهة',i:'fa-triangle-exclamation',c:'c-rd'},
      {v:N(d.nums_count||0),l:'أرقام مسجلة',i:'fa-phone-volume',c:'c-gy'},
    ].map(function(s){return'<div class="sc '+s.c+'"><i class="sc-ico fa '+s.i+'"></i><div class="sc-val">'+s.v+'</div><div class="sc-lbl">'+s.l+'</div></div>';}).join('');

    // Numbers mini
    api('numbers_summary',[],function(nd){
      if(!nd){return;}
      var nums=nd.numbers||[];
      if(!nums.length){document.getElementById('dn').innerHTML='<div class="empty" style="grid-column:1/-1"><i class="fa fa-phone-slash"></i>لا توجد أرقام<br><button class="btn-p" style="margin-top:.5rem;font-size:.72rem" onclick="goTo(\'numbers\')"><i class="fa fa-plus"></i> أضف رقماً</button></div>';return;}
      document.getElementById('dn').innerHTML=nums.slice(0,6).map(function(n){
        return'<div class="num-card" style="--nc:'+x(n.color)+'" onclick="goNum('+n.id+')">'
          +'<div class="nc-top"><span class="nc-badge" dir="ltr">'+fmtPh(n.phone)+'</span><span style="font-size:.62rem;color:var(--tx3)">'+x(n.type)+'</span></div>'
          +'<div class="nc-lbl">'+x(n.label||'رقم '+n.id)+'</div>'
          +'<div class="nc-stats">'
            +'<div class="nc-stat"><span class="nc-sv" style="color:'+x(n.color)+'">'+N(n.total||0)+'</span><span class="nc-sl">إجمالي</span></div>'
            +'<div class="nc-stat"><span class="nc-sv" style="color:var(--green)">'+N(n.calls||0)+'</span><span class="nc-sl">اتصال</span></div>'
            +'<div class="nc-stat"><span class="nc-sv" style="color:var(--wa)">'+N(n.wa||0)+'</span><span class="nc-sl">واتساب</span></div>'
            +'<div class="nc-stat"><span class="nc-sv">'+N(n.uniq||0)+'</span><span class="nc-sl">فريد</span></div>'
          +'</div>'
        +'</div>';
      }).join('');
    });

    // Charts
    if(d.daily&&d.daily.length)mkLine('cl',d.daily.map(function(r){return r.d;}),[
      {label:'إجمالي',data:d.daily.map(function(r){return r.tot;}),borderColor:'#388bfd',backgroundColor:'rgba(56,139,253,.1)',tension:.4,fill:true,pointRadius:0},
      {label:'واتساب',data:d.daily.map(function(r){return r.wa||0;}),borderColor:'#25d366',tension:.4,fill:false,pointRadius:0},
      {label:'اتصال',data:d.daily.map(function(r){return r.call||0;}),borderColor:'#2ea043',tension:.4,fill:false,pointRadius:0},
    ]);
    var dC=['#388bfd','#8957e5','#f0883e'];
    if(d.by_device&&d.by_device.length){var dL=d.by_device.map(function(r){return r.device_type;});mkDonut('cd',dL,d.by_device.map(function(r){return r.cnt;}),dC);document.getElementById('ld').innerHTML=dL.map(function(l,i){return'<div class="leg-i"><span class="leg-dot" style="background:'+dC[i]+'"></span>'+l+'</div>';}).join('');}
    var sC=['#8b949e','#2ea043','#f0883e','#388bfd','#8957e5','#f85149'];
    if(d.by_source&&d.by_source.length){var sL=d.by_source.map(function(r){return r.traffic_src;});mkDonut('cs',sL,d.by_source.map(function(r){return r.cnt;}),sC);document.getElementById('ls').innerHTML=sL.map(function(l,i){return'<div class="leg-i"><span class="leg-dot" style="background:'+sC[i]+'"></span>'+l+'</div>';}).join('');}
    if(d.top_pages&&d.top_pages.length)document.getElementById('dp').innerHTML=d.top_pages.slice(0,5).map(function(p,i){return'<div style="display:flex;align-items:center;gap:.45rem;padding:.42rem .48rem;border-bottom:1px solid var(--bd);font-size:.73rem"><span style="width:19px;height:19px;background:var(--grad);border-radius:50%;color:#fff;font-size:.58rem;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0">'+(i+1)+'</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+x(p.page_title||p.page_url||'—')+'</span><span style="font-family:\'JetBrains Mono\',monospace;font-weight:700;color:var(--blue)">'+N(p.cnt)+'</span></div>';}).join('');
    else if(document.getElementById('dp'))document.getElementById('dp').innerHTML='<div class="empty"><i class="fa fa-folder-open"></i>لا بيانات</div>';
    if(d.sus_ips&&d.sus_ips.length)document.getElementById('di').innerHTML=d.sus_ips.map(function(r){return'<div class="ipr '+(r.cnt>=5?'danger':r.cnt>=3?'warn':'')+'"><span class="iptag">'+x(r.ip)+'</span><span style="flex:1;font-size:.65rem;color:var(--tx3)">'+x(r.city||'—')+'</span><span style="font-family:\'JetBrains Mono\',monospace;font-size:.68rem;font-weight:700;color:var(--red)">'+r.cnt+'</span><button class="blk-btn" onclick="qBlock(\''+x(r.ip)+'\',this)"><i class="fa fa-ban"></i></button></div>';}).join('');
    else if(document.getElementById('di'))document.getElementById('di').innerHTML='<div class="empty"><i class="fa fa-shield-halved"></i>لا IPs مشبوهة</div>';
  });
}

/* ═══════════════════════ NUMBERS ═══════════════════════ */
function rNums(){
  _pg='numbers';
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-phone-volume"></i> إدارة الأرقام</div><div class="psub">تتبع منفصل لكل رقم — مكالمات، واتساب، مصادر</div></div>'+
    pBar()+
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;flex-wrap:wrap;gap:.45rem"><div id="nc-count" style="font-size:.8rem;color:var(--tx3)"></div><button class="btn-p" onclick="openNM()"><i class="fa fa-plus"></i> إضافة رقم</button></div>'+
    '<div class="nums-grid" id="ng"><div class="skel" style="height:155px"></div><div class="skel" style="height:155px"></div><div class="skel" style="height:155px"></div></div>'+
    '<div class="box"><div class="bhead"><div class="bhl"><i class="fa fa-chart-bar"></i> مقارنة الأداء</div></div><div style="position:relative;height:200px"><canvas id="nb-chart"></canvas></div></div>';
  loadNums(function(){
    api('numbers_summary',[],function(d){
      if(!d){document.getElementById('ng').innerHTML='<div style="grid-column:1/-1" class="empty"><i class="fa fa-phone-slash"></i>لا توجد أرقام<br><button class="btn-p" style="margin-top:.5rem" onclick="openNM()"><i class="fa fa-plus"></i> أضف أول رقم</button></div>';return;}
      var nums=d.numbers||[];
      var nc=document.getElementById('nc-count');if(nc)nc.textContent=nums.length+' رقم مسجل';
      document.getElementById('ng').innerHTML=nums.map(function(n){
        return'<div class="num-card" style="--nc:'+x(n.color)+'">'
          +'<div class="nc-top"><span class="nc-badge" dir="ltr">'+fmtPh(n.phone)+'</span><span style="font-size:.62rem;padding:.08rem .38rem;border-radius:4px;background:'+x(n.color)+'20;color:'+x(n.color)+'">'+x(n.type)+'</span></div>'
          +'<div class="nc-lbl">'+x(n.label||'رقم غير مسمى')+'</div>'
          +'<div class="nc-stats"><div class="nc-stat"><span class="nc-sv" style="color:'+x(n.color)+'">'+N(n.total||0)+'</span><span class="nc-sl">إجمالي</span></div><div class="nc-stat"><span class="nc-sv" style="color:var(--green)">'+N(n.calls||0)+'</span><span class="nc-sl">اتصال</span></div><div class="nc-stat"><span class="nc-sv" style="color:var(--wa)">'+N(n.wa||0)+'</span><span class="nc-sl">واتساب</span></div><div class="nc-stat"><span class="nc-sv">'+N(n.uniq||0)+'</span><span class="nc-sl">فريد</span></div></div>'
          +'<div class="nc-acts"><button class="nc-btn" onclick="goNum('+n.id+')"><i class="fa fa-chart-bar"></i> تفاصيل</button><button class="nc-btn" onclick="openNM('+n.id+',\''+x(n.label)+'\',\''+x(n.phone)+'\',\''+x(n.wa_number||'')+'\',\''+x(n.type)+'\',\''+x(n.color)+'\')"><i class="fa fa-edit"></i></button><button class="nc-btn d" onclick="delNum('+n.id+')"><i class="fa fa-trash"></i></button></div>'
        +'</div>';
      }).join('')+(d.unknown&&d.unknown.length?
        '<div style="grid-column:1/-1;border:1px dashed var(--bd);border-radius:var(--r2);padding:.82rem;font-size:.76rem;color:var(--tx3)"><i class="fa fa-question-circle" style="color:var(--yellow)"></i> أرقام غير مسجلة:'+d.unknown.map(function(u){return'<span style="margin:.22rem .32rem;display:inline-flex;align-items:center;gap:.28rem;background:var(--yl);border:1px solid rgba(210,153,34,.3);border-radius:4px;padding:.18rem .45rem;font-family:\'JetBrains Mono\',monospace;font-size:.68rem">'+x(u.phone_raw)+' <strong style="color:var(--tx)">'+u.total+'</strong></span>';}).join('')+'</div>':''
      );
      if(nums.length)setTimeout(function(){mkBar('nb-chart',nums.map(function(n){return n.label||n.phone;}),nums.map(function(n){return n.total||0;}),nums.map(function(n){return n.color;}));},100);
    });
  });
}

/* ═══════════════════════ NUMBER DETAIL ═══════════════════════ */
function rNumDetail(nid){
  var ni=NUMS.find(function(n){return n.id==nid;})||{};
  var M=document.getElementById('main');
  M.innerHTML=
    '<button onclick="goTo(\'numbers\')" style="background:none;border:1px solid var(--bd);border-radius:var(--r4);color:var(--tx3);padding:.22rem .6rem;font-size:.73rem;cursor:pointer;margin-bottom:.5rem"><i class="fa fa-arrow-right"></i> الأرقام</button>'+
    '<div class="phdr"><div class="ptitle"><i class="fa fa-phone" style="color:'+(ni.color||'var(--blue)')+'"></i> '+x(ni.label||'رقم '+nid)+'</div><div class="psub" dir="ltr">'+(ni.phone?fmtPh(ni.phone):'')+'</div></div>'+
    pBar()+
    '<div class="cards" id="nd-cards">'+[1,2,3,4].map(function(){return'<div class="skel" style="height:86px"></div>';}).join('')+'</div>'+
    '<div class="charts-grid"><div class="cbox cbox-wide"><div class="chead"><i class="fa fa-chart-line"></i> التحويلات اليومية</div><div class="ch-wrap"><canvas id="nd-line"></canvas></div></div><div class="cbox"><div class="chead"><i class="fa fa-globe"></i> المصادر</div><div class="ch-wrap"><canvas id="nd-src"></canvas></div><div class="leg" id="nd-src-leg"></div></div><div class="cbox"><div class="chead"><i class="fa fa-file-alt"></i> أعلى الصفحات</div><div id="nd-pages-list" style="overflow:auto;max-height:170px;padding-top:.25rem"></div></div></div>'+
    '<div class="fbar"><div class="sw"><i class="fa fa-search"></i><input class="sinp" id="nd-s" placeholder="ابحث..." onkeydown="if(event.key===\'Enter\'){PAGE=1;ldND('+nid+')}"></div>'+
    '<select class="fsel" id="nd-t"><option value="">كل الأنواع</option><option value="call">اتصال</option><option value="whatsapp">واتساب</option></select>'+
    '<select class="fsel" id="nd-src2"><option value="">كل المصادر</option><option value="direct">مباشر</option><option value="organic">بحث</option><option value="google_ads">جوجل أدس</option><option value="paid">إعلان</option><option value="social">تواصل</option></select>'+
    '<button class="fbtn" onclick="PAGE=1;ldND('+nid+')"><i class="fa fa-filter"></i></button>'+
    '<a class="exp-btn" href="'+C.ajax+'?action=ktp_export_csv&nonce='+C.exp_n+'&days='+DAYS+'" target="_blank"><i class="fa fa-download"></i></a>'+
    '</div>'+
    '<div id="nd-meta" class="tmeta"></div>'+
    '<div class="twrap"><table class="kt"><thead><tr><th>النوع</th><th>IP</th><th>الموقع</th><th>الجهاز</th><th>الصفحة</th><th>المصدر</th><th>الوقت</th></tr></thead><tbody id="nd-tb"><tr><td colspan="7" class="lc"><i class="fa fa-spinner fa-spin"></i></td></tr></tbody></table></div>'+
    '<div id="nd-pg"></div>';

  api('number_detail',[['number_id',nid]],function(d){
    if(!d){document.getElementById('nd-cards').innerHTML='<div style="color:var(--tx3);grid-column:1/-1;padding:1rem">تعذّر التحميل</div>';return;}
    var s=d.stats||{};
    document.getElementById('nd-cards').innerHTML=[
      {v:N(s.total||0),l:'إجمالي',i:'fa-bullseye',c:'c-bl'},
      {v:N(s.calls||0),l:'مكالمات',i:'fa-phone',c:'c-gr'},
      {v:N(s.wa||0),l:'واتساب',i:'fa-whatsapp fab',c:'c-wa'},
      {v:N(s.unique||0),l:'فريدة',i:'fa-fingerprint',c:'c-pu'},
    ].map(function(sc){return'<div class="sc '+sc.c+'"><i class="sc-ico fa '+sc.i+'"></i><div class="sc-val">'+sc.v+'</div><div class="sc-lbl">'+sc.l+'</div></div>';}).join('');
    if(s.daily&&s.daily.length)setTimeout(function(){mkLine('nd-line',s.daily.map(function(r){return r.d;}),[{label:'تحويلات',data:s.daily.map(function(r){return r.cnt;}),borderColor:ni.color||'#388bfd',backgroundColor:(ni.color||'#388bfd')+'20',tension:.4,fill:true,pointRadius:0}]);},80);
    var sC=['#8b949e','#2ea043','#f0883e','#388bfd','#8957e5','#f85149'];
    if(s.by_src&&s.by_src.length){var sL=s.by_src.map(function(r){return r.traffic_src;});setTimeout(function(){mkDonut('nd-src',sL,s.by_src.map(function(r){return r.cnt;}),sC);},80);document.getElementById('nd-src-leg').innerHTML=sL.map(function(l,i){return'<div class="leg-i"><span class="leg-dot" style="background:'+sC[i]+'"></span>'+l+'</div>';}).join('');}
    if(s.by_page&&s.by_page.length)document.getElementById('nd-pages-list').innerHTML=s.by_page.map(function(p,i){return'<div style="display:flex;gap:.38rem;align-items:center;padding:.28rem 0;border-bottom:1px solid var(--bd);font-size:.71rem"><span style="color:var(--tx3)">'+(i+1)+'.</span><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+x(p.page_title||p.page_url)+'</span><span style="font-family:\'JetBrains Mono\',monospace;font-weight:700;color:var(--blue)">'+N(p.cnt)+'</span></div>';}).join('');
    rNDRows(d);
  });
}
function ldND(nid){
  var ex=[['number_id',nid],['page',PAGE],
    ['click_type',document.getElementById('nd-t')?document.getElementById('nd-t').value:''],
    ['traffic_src',document.getElementById('nd-src2')?document.getElementById('nd-src2').value:''],
    ['search',document.getElementById('nd-s')?document.getElementById('nd-s').value:'']];
  document.getElementById('nd-tb').innerHTML='<tr><td colspan="7" class="lc"><i class="fa fa-spinner fa-spin"></i></td></tr>';
  api('number_detail',ex,function(d){if(d)rNDRows(d);});
}
function rNDRows(d){
  if(!d.rows||!d.rows.length){document.getElementById('nd-tb').innerHTML='<tr><td colspan="7" class="nd">لا توجد نتائج</td></tr>';return;}
  var m=document.getElementById('nd-meta');if(m)m.innerHTML='إجمالي: <strong>'+N(d.total||0)+'</strong>';
  document.getElementById('nd-tb').innerHTML=d.rows.map(function(r){return'<tr class="'+(r.is_suspicious=='1'?'sus-row':'')+'">'+'<td>'+badge(r.click_type)+'</td><td><span class="iptag'+(r.is_suspicious=='1'?' sus':'')+'">'+x(r.ip||'—')+'</span></td><td style="font-size:.7rem">'+x(r.city||'—')+'</td><td><div class="dev-c">'+devIco(r.device_type)+'</div></td><td style="max-width:140px;overflow:hidden;text-overflow:ellipsis">'+x((r.page_title||r.page_url||'—').slice(0,38))+'</td><td>'+srcChip(r.traffic_src||'direct')+'</td><td class="td-time">'+ago(r.created_at)+'</td></tr>';}).join('');
  var pp=document.getElementById('nd-pg');if(pp)pp.innerHTML=pgHTML(PAGE,d.total,50);
}

/* ═══════════════════════ ALL CONVERSIONS ═══════════════════════ */
function rConv(){
  _pg='conversions';
  var nOpts='<option value="">كل الأرقام</option>'+NUMS.map(function(n){return'<option value="'+n.id+'">'+x(n.label||n.phone)+'</option>';}).join('');
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-bullseye"></i> كل التحويلات</div><div class="psub">سجل كامل بجميع الأرقام</div></div>'+
    pBar()+
    '<div class="fbar"><div class="sw"><i class="fa fa-search"></i><input class="sinp" id="ck-s" placeholder="ابحث IP، رقم، مدينة..." onkeydown="if(event.key===\'Enter\'){PAGE=1;ldConv()}"></div>'+
    '<select class="fsel" id="ck-n">'+nOpts+'</select>'+
    '<select class="fsel" id="ck-t"><option value="">كل الأنواع</option><option value="call">اتصال</option><option value="whatsapp">واتساب</option></select>'+
    '<select class="fsel" id="ck-src"><option value="">كل المصادر</option><option value="direct">مباشر</option><option value="organic">بحث</option><option value="google_ads">Google Ads</option><option value="paid">إعلان</option><option value="social">تواصل</option></select>'+
    '<select class="fsel" id="ck-sus"><option value="">الكل</option><option value="1">مشبوهة</option></select>'+
    '<button class="fbtn" onclick="PAGE=1;ldConv()"><i class="fa fa-filter"></i> فلتر</button>'+
    '<a class="exp-btn" href="'+C.ajax+'?action=ktp_export_csv&nonce='+C.exp_n+'&days='+DAYS+'" target="_blank"><i class="fa fa-file-csv"></i> CSV</a>'+
    '</div>'+
    '<div id="ck-meta" class="tmeta"></div>'+
    '<div class="twrap"><table class="kt"><thead><tr><th>الرقم</th><th>النوع</th><th>IP</th><th>الموقع</th><th>الجهاز</th><th>الصفحة</th><th>المصدر</th><th>الوقت</th></tr></thead><tbody id="ck-tb"><tr><td colspan="8" class="lc"><i class="fa fa-spinner fa-spin"></i></td></tr></tbody></table></div>'+
    '<div id="ck-pg"></div>';
  ldConv();
}
function ldConv(){
  var ex=[['page',PAGE],
    ['search',document.getElementById('ck-s')?document.getElementById('ck-s').value:''],
    ['number_id',document.getElementById('ck-n')?document.getElementById('ck-n').value:''],
    ['click_type',document.getElementById('ck-t')?document.getElementById('ck-t').value:''],
    ['traffic_src',document.getElementById('ck-src')?document.getElementById('ck-src').value:''],
    ['is_suspicious',document.getElementById('ck-sus')?document.getElementById('ck-sus').value:'']];
  document.getElementById('ck-tb').innerHTML='<tr><td colspan="8" class="lc"><i class="fa fa-spinner fa-spin"></i></td></tr>';
  api('conversions',ex,function(d){
    if(!d){document.getElementById('ck-tb').innerHTML='<tr><td colspan="8" class="nd">تعذّر التحميل</td></tr>';return;}
    var m=document.getElementById('ck-meta');if(m)m.innerHTML='إجمالي: <strong>'+N(d.total||0)+'</strong>';
    if(!d.rows||!d.rows.length){document.getElementById('ck-tb').innerHTML='<tr><td colspan="8" class="nd">لا توجد نتائج</td></tr>';return;}
    document.getElementById('ck-tb').innerHTML=d.rows.map(function(r){
      var ntag=r.num_label?'<span class="numtag" style="background:'+x(r.num_color||'#388bfd')+'20;color:'+x(r.num_color||'#388bfd')+';border-color:'+x(r.num_color||'#388bfd')+'40">'+x(r.num_label)+'</span>':'';
      return'<tr class="'+(r.is_suspicious=='1'?'sus-row':'')+'">'
        +'<td><span class="td-ph">'+fmtPh(r.phone_raw)+'</span>'+(ntag?'<br>'+ntag:'')+'</td>'
        +'<td>'+badge(r.click_type)+'</td>'
        +'<td><span class="iptag'+(r.is_suspicious=='1'?' sus':'')+'">'+x(r.ip)+'</span></td>'
        +'<td style="font-size:.7rem">'+x(r.city||'—')+'</td>'
        +'<td><div class="dev-c">'+devIco(r.device_type)+'</div></td>'
        +'<td style="max-width:120px;overflow:hidden;text-overflow:ellipsis">'+x((r.page_title||r.page_url||'—').slice(0,32))+'</td>'
        +'<td>'+srcChip(r.traffic_src||'direct')+'</td>'
        +'<td class="td-time">'+ago(r.created_at)+'</td>'
      +'</tr>';
    }).join('');
    var pp=document.getElementById('ck-pg');if(pp)pp.innerHTML=pgHTML(PAGE,d.total,50);
  });
}

/* ═══════════════════════ VISITORS ═══════════════════════ */
function rVis(){
  _pg='visitors';
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-users"></i> الزوار</div></div>'+pBar()+
    '<div class="fbar"><div class="sw"><i class="fa fa-search"></i><input class="sinp" id="vi-s" placeholder="ابحث بـ IP أو مدينة..." onkeydown="if(event.key===\'Enter\'){PAGE=1;ldVis()}"></div>'+
    '<select class="fsel" id="vi-d"><option value="">كل الأجهزة</option><option value="mobile">موبايل</option><option value="desktop">سطح مكتب</option><option value="tablet">تابلت</option></select>'+
    '<button class="fbtn" onclick="PAGE=1;ldVis()"><i class="fa fa-filter"></i></button></div>'+
    '<div id="vi-meta" class="tmeta"></div>'+
    '<div class="twrap"><table class="kt"><thead><tr><th>IP</th><th>الموقع</th><th>الجهاز</th><th>المتصفح</th><th>الزيارات</th><th>النوع</th><th>المصدر</th><th>آخر زيارة</th></tr></thead><tbody id="vi-tb"><tr><td colspan="8" class="lc"><i class="fa fa-spinner fa-spin"></i></td></tr></tbody></table></div>'+
    '<div id="vi-pg"></div>';
  ldVis();
}
function ldVis(){
  var ex=[['page',PAGE],['search',document.getElementById('vi-s')?document.getElementById('vi-s').value:''],['device_type',document.getElementById('vi-d')?document.getElementById('vi-d').value:'']];
  api('visitors',ex,function(d){
    if(!d){document.getElementById('vi-tb').innerHTML='<tr><td colspan="8" class="nd">تعذّر التحميل</td></tr>';return;}
    var m=document.getElementById('vi-meta');if(m)m.innerHTML='إجمالي: <strong>'+N(d.total||0)+'</strong>';
    if(!d.rows||!d.rows.length){document.getElementById('vi-tb').innerHTML='<tr><td colspan="8" class="nd">لا نتائج</td></tr>';return;}
    document.getElementById('vi-tb').innerHTML=d.rows.map(function(r){return'<tr><td><span class="iptag">'+x(r.ip||'—')+'</span></td><td style="font-size:.7rem">'+x(r.city||'—')+'</td><td><div class="dev-c">'+devIco(r.device_type)+'</div></td><td style="font-size:.7rem">'+x(r.browser||'—')+'</td><td style="font-family:\'JetBrains Mono\',monospace;font-weight:700;color:var(--blue)">'+N(r.visit_count||1)+'</td><td>'+(r.is_new=='1'?'<span style="background:var(--bl);color:var(--blue);font-size:.6rem;padding:.06rem .38rem;border-radius:100px;font-weight:700">جديد</span>':'<span style="background:var(--gl);color:var(--green);font-size:.6rem;padding:.06rem .38rem;border-radius:100px;font-weight:700">عائد</span>')+'</td><td>'+srcChip(r.traffic_src||'direct')+'</td><td class="td-time">'+ago(r.last_visit)+'</td></tr>';}).join('');
    var pp=document.getElementById('vi-pg');if(pp)pp.innerHTML=pgHTML(PAGE,d.total,50);
  });
}

/* ═══════════════════════ FRAUD ═══════════════════════ */
function rFraud(){
  _pg='fraud';
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-shield-halved"></i> كشف الاحتيال</div></div>'+
    '<div class="box" style="display:flex;flex-wrap:wrap;gap:.75rem;align-items:center;justify-content:space-between"><div><div style="font-weight:800;font-size:.85rem;color:var(--tx)">حماية ذكية متعددة الطبقات</div><div style="font-size:.7rem;color:var(--tx3)">رصد IPs المشبوهة + حظر تلقائي + نظام Cooldown</div></div><div style="display:flex;gap:.35rem;align-items:center"><input class="inp" id="bl-ip" placeholder="أدخل IP للحظر..." style="min-width:155px;width:auto"><button class="btn-d" onclick="manBlk()"><i class="fa fa-ban"></i> حظر</button></div></div>'+
    '<div class="cards" id="fr-c">'+[1,2,3,4].map(function(){return'<div class="skel" style="height:86px"></div>';}).join('')+'</div>'+
    '<div class="wrow"><div class="box" style="margin:0"><div class="bhead"><div class="bhl"><i class="fa fa-triangle-exclamation"></i> IPs مشبوهة</div></div><div id="fr-s"></div></div><div class="box" style="margin:0"><div class="bhead"><div class="bhl"><i class="fa fa-ban"></i> القائمة السوداء</div><button class="btn-o" onclick="ldFraud()"><i class="fa fa-rotate"></i></button></div><div class="bl-grid" id="fr-b"></div></div></div>';
  ldFraud();
}
function ldFraud(){
  api('fraud',[],function(d){
    if(!d)return;
    document.getElementById('fr-c').innerHTML=[
      {v:N(d.sus_count||0),l:'IPs مشبوهة',i:'fa-triangle-exclamation',c:'c-rd'},
      {v:N(d.bl_count||0),l:'محظورة',i:'fa-ban',c:'c-or'},
      {v:N(d.sus_clicks||0),l:'نقرات مشبوهة',i:'fa-cursor',c:'c-yl'},
      {v:N(d.auto_blocked||0),l:'حظر تلقائي',i:'fa-robot',c:'c-pu'},
    ].map(function(s){return'<div class="sc '+s.c+'"><i class="sc-ico fa '+s.i+'"></i><div class="sc-val">'+s.v+'</div><div class="sc-lbl">'+s.l+'</div></div>';}).join('');
    if(d.suspicious&&d.suspicious.length)document.getElementById('fr-s').innerHTML=d.suspicious.map(function(r){return'<div class="ipr '+(r.cnt>=5?'danger':r.cnt>=3?'warn':'')+'"><span class="iptag">'+x(r.ip)+'</span><span style="flex:1;font-size:.65rem;color:var(--tx3)">'+x(r.city||'—')+'</span><span style="font-family:\'JetBrains Mono\',monospace;font-size:.68rem;font-weight:700;color:var(--red)">'+r.cnt+' نقر</span><button class="blk-btn" onclick="qBlock(\''+x(r.ip)+'\',this)"><i class="fa fa-ban"></i></button></div>';}).join('');
    else document.getElementById('fr-s').innerHTML='<div class="empty"><i class="fa fa-shield-halved"></i>لا IPs مشبوهة</div>';
    if(d.blacklist&&d.blacklist.length)document.getElementById('fr-b').innerHTML=d.blacklist.map(function(r){return'<div class="bl-card"><div style="display:flex;align-items:center;gap:.35rem;font-weight:700;color:var(--red);margin-bottom:.32rem"><i class="fa fa-ban"></i><code style="font-family:\'JetBrains Mono\',monospace;font-size:.68rem">'+x(r.ip)+'</code></div><div style="font-size:.66rem;color:var(--tx3);margin-bottom:.48rem">'+x(r.reason||'manual')+' — '+ago(r.created_at)+'</div><button class="ublk" onclick="doUnblk(\''+x(r.ip)+'\',this)"><i class="fa fa-lock-open"></i> رفع الحظر</button></div>';}).join('');
    else document.getElementById('fr-b').innerHTML='<div class="empty"><i class="fa fa-check-circle"></i>القائمة فارغة</div>';
  });
}
function qBlock(ip,btn){btn.disabled=true;btn.innerHTML='<i class="fa fa-spinner fa-spin"></i>';ajax('kt_block_ip',{ip:ip},function(r){if(r&&r.success){btn.innerHTML='<i class="fa fa-check"></i>';toast('تم حظر '+ip,'ok');}else{btn.disabled=false;btn.innerHTML='<i class="fa fa-ban"></i>';toast('فشل','err');}});}
function manBlk(){var ip=document.getElementById('bl-ip').value.trim();if(!ip){toast('أدخل IP','err');return;}ajax('kt_block_ip',{ip:ip},function(r){if(r&&r.success){toast('تم حظر '+ip,'ok');document.getElementById('bl-ip').value='';ldFraud();}else toast('فشل','err');});}
function doUnblk(ip,btn){btn.disabled=true;ajax('kt_unblock_ip',{ip:ip},function(r){if(r&&r.success){toast('رُفع الحظر','ok');ldFraud();}else{btn.disabled=false;toast('فشل','err');}});}

/* ═══════════════════════ HEATMAP ═══════════════════════ */
function rHeat(){
  _pg='heatmap';
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-fire"></i> Heatmap</div></div>'+
    '<div class="box"><div class="fbar"><div class="sw" style="max-width:320px"><i class="fa fa-link"></i><input class="sinp" id="hm-url" placeholder="URL الصفحة (اختياري)"></div><button class="fbtn" onclick="ldHeat()"><i class="fa fa-fire"></i> عرض</button></div><div style="position:relative;border-radius:var(--r2);overflow:hidden;border:1px solid var(--bd);margin-top:.6rem"><div id="hm-bg" style="position:relative;width:100%;height:450px;background:var(--bg3)"><canvas id="hm-c" style="position:absolute;inset:0;width:100%;height:100%"></canvas><div id="hm-lbl" style="position:absolute;top:.45rem;right:.45rem;font-family:\'JetBrains Mono\',monospace;font-size:.56rem;color:var(--tx3);background:rgba(255,255,255,.05);padding:.15rem .48rem;border-radius:100px;border:1px solid var(--bd)">0 نقطة</div></div></div></div>';
  ldHeat();
}
function ldHeat(){
  var url=document.getElementById('hm-url');
  api('heatmap',[['page_url',url?url.value:'']],function(d){
    var lbl=document.getElementById('hm-lbl');
    if(!d||!d.points||!d.points.length){if(lbl)lbl.textContent='0 نقطة';return;}
    if(lbl)lbl.textContent=d.points.length+' نقطة';
    var canvas=document.getElementById('hm-c'),bg=canvas.parentElement;if(!canvas||!bg)return;
    canvas.width=bg.offsetWidth;canvas.height=bg.offsetHeight;
    var ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);
    d.points.forEach(function(p){var px=(p.x_pct/100)*canvas.width,py=(p.y_pct/100)*canvas.height;var g=ctx.createRadialGradient(px,py,0,px,py,18);g.addColorStop(0,'rgba(248,81,73,.8)');g.addColorStop(.5,'rgba(240,136,62,.3)');g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(px,py,18,0,Math.PI*2);ctx.fill();});
  });
}

/* ═══════════════════════ DNI ═══════════════════════ */
function rDNI(){
  _pg='dni';
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-rotate"></i> DNI — Dynamic Number Insertion</div><div class="psub">أظهر رقم مختلف لكل مصدر زيارة</div></div>'+
    '<div class="box info"><div class="bhead"><div class="bhl"><i class="fa fa-lightbulb"></i> كيف يعمل؟</div></div><p style="font-size:.76rem;color:var(--tx2);line-height:1.7">زائر من Google Ads → يرى رقم A. من Facebook → رقم B. مباشر → رقم C. كل تحويل يُحفظ مع الرقم الظاهر.</p></div>'+
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;flex-wrap:wrap;gap:.45rem"><div style="font-weight:700;color:var(--tx)">قواعد DNI</div><button class="btn-p" onclick="openDM()"><i class="fa fa-plus"></i> إضافة قاعدة</button></div>'+
    '<div id="dni-list"><div class="skel" style="height:50px"></div></div>';
  ldDNI();
}
function ldDNI(){
  api('dni_rules',[],function(d){
    if(!d||!d.length){document.getElementById('dni-list').innerHTML='<div class="empty"><i class="fa fa-rotate"></i>لا توجد قواعد بعد<br><small style="margin-top:.3rem;display:block">أضف قاعدة لربط كل مصدر زيارة برقم محدد</small></div>';return;}
    var srcs={google_ads:'Google Ads',paid:'إعلانات',social:'تواصل',organic:'بحث',direct:'مباشر',campaign:'حملة UTM'};
    document.getElementById('dni-list').innerHTML=d.map(function(r){
      return'<div class="ipr" style="border-radius:var(--r2);margin-bottom:.38rem;flex-wrap:wrap;gap:.45rem">'
        +'<span style="font-size:.73rem;font-weight:700;color:var(--tx)">'+x(srcs[r.source_type]||r.source_type)+'</span>'
        +(r.utm_source?'<span class="src s-pad" style="font-size:.6rem">src:'+x(r.utm_source)+'</span>':'')
        +(r.utm_campaign?'<span class="src s-soc" style="font-size:.6rem">camp:'+x(r.utm_campaign)+'</span>':'')
        +'<span style="font-family:\'JetBrains Mono\',monospace;font-size:.7rem;flex:1">→ '+x(r.label||'')+'</span>'
        +'<button style="border:none;background:var(--rl);color:var(--red);border-radius:var(--r4);padding:.18rem .48rem;cursor:pointer;font-size:.66rem" onclick="delDNI('+r.id+')"><i class="fa fa-trash"></i></button>'
      +'</div>';
    }).join('');
  });
}
function openDM(){document.getElementById('dm').style.display='';}
function closeDM(){document.getElementById('dm').style.display='none';}
function saveDNI(){
  ajax('ktp_save_dni_rule',{id:document.getElementById('dm-id').value||0,number_id:document.getElementById('dm-num').value,source_type:document.getElementById('dm-src').value,utm_source:document.getElementById('dm-us').value,utm_campaign:document.getElementById('dm-uc').value,priority:document.getElementById('dm-pri').value},function(r){if(r&&r.success){toast('تم الحفظ','ok');closeDM();ldDNI();}else toast('فشل','err');});
}
function delDNI(id){if(!confirm('حذف هذه القاعدة؟'))return;ajax('ktp_delete_dni_rule',{id:id},function(r){if(r&&r.success){toast('تم الحذف','ok');ldDNI();}});}

/* ═══════════════════════ REPORTS ═══════════════════════ */
function rRep(){
  _pg='reports';
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-share-nodes"></i> التقارير</div><div class="psub">روابط مشتركة مع العملاء</div></div>'+
    '<div class="box"><div class="fbar" style="margin-bottom:.58rem"><label style="font-size:.76rem;font-weight:600;color:var(--tx2)">عنوان</label><input class="inp" id="rp-t" placeholder="تقرير أبريل" style="flex:1;min-width:140px"><select class="inp" id="rp-exp" style="width:auto"><option value="1">24س</option><option value="7" selected>7 أيام</option><option value="30">30 يوم</option></select><select class="inp" id="rp-d" style="width:auto"><option value="7">7 أيام</option><option value="30" selected>30 يوم</option></select><button class="btn-p" onclick="genRep()"><i class="fa fa-share-nodes"></i> إنشاء</button></div><div id="rp-res"></div></div>'+
    '<div class="box"><div class="bhead"><div class="bhl"><i class="fa fa-clock-rotate-left"></i> التقارير السابقة</div></div><div id="rp-list"><div class="skel" style="height:40px"></div></div></div>';
  api('reports',[],function(d){
    if(!d||!d.length){document.getElementById('rp-list').innerHTML='<div class="empty"><i class="fa fa-folder-open"></i>لا توجد تقارير</div>';return;}
    document.getElementById('rp-list').innerHTML=d.map(function(r){var active=r.expires_at&&new Date(r.expires_at)>new Date();var url=C.home+'?kt_report='+r.token;return'<div class="ipr" style="flex-wrap:wrap;gap:.38rem;margin-bottom:.35rem;border-radius:var(--r2)"><span style="font-weight:700;font-size:.78rem;flex:1">'+x(r.title||'تقرير')+'</span><span style="font-size:.65rem;color:'+(active?'var(--green)':'var(--red)')+'">'+( active?'✓ نشط':'✗ منتهي')+'</span><span style="font-size:.65rem;color:var(--tx3)">👁 '+N(r.view_count||0)+'</span><button class="btn-o" style="font-size:.62rem;padding:.2rem .5rem" onclick="navigator.clipboard.writeText(\''+x(url)+'\').then(function(){toast(\'نُسخ!\',\'ok\');})"><i class="fa fa-copy"></i></button></div>';}).join('');
  });
}
function genRep(){
  ajax('kt_generate_report',{title:document.getElementById('rp-t').value||'تقرير',expiry_days:document.getElementById('rp-exp').value,days:document.getElementById('rp-d').value},function(r){
    if(r&&r.success){document.getElementById('rp-res').innerHTML='<div style="background:var(--gl);border:1px solid rgba(46,160,67,.2);border-radius:var(--r4);padding:.6rem;display:flex;gap:.45rem;align-items:center;margin-top:.45rem"><code style="font-family:\'JetBrains Mono\',monospace;font-size:.6rem;flex:1;word-break:break-all">'+x(r.data.url)+'</code><button class="btn-o" onclick="navigator.clipboard.writeText(\''+x(r.data.url)+'\').then(function(){toast(\'نُسخ!\',\'ok\');})"><i class="fa fa-copy"></i></button></div>';toast('تم إنشاء التقرير','ok');}
    else toast('فشل','err');
  });
}

/* ═══════════════════════ SETTINGS ═══════════════════════ */
function rSettings(){
  _pg='settings';
  var s=C.settings||{};
  document.getElementById('main').innerHTML=
    '<div class="phdr"><div class="ptitle"><i class="fa fa-gear"></i> الإعدادات</div></div>'+
    '<form id="sf" onsubmit="saveSt(event)">'
    +'<div class="sg">'
      +'<div class="sbox"><div class="sbox-t"><i class="fa fa-toggle-on"></i> عام</div>'
        +'<div class="swrow"><span>تفعيل التتبع</span><label class="toggle"><input type="checkbox" name="enabled"'+(s.enabled?' checked':'')+' onchange="autoSt()"><span class="tsl"></span></label></div>'
        +'<div class="swrow"><span>موافقة الكوكيز</span><label class="toggle"><input type="checkbox" name="cookie_consent"'+(s.cookie_consent?' checked':'')+' onchange="autoSt()"><span class="tsl"></span></label></div>'
        +'<div class="swrow"><span>تفعيل Heatmap</span><label class="toggle"><input type="checkbox" name="heatmap_enabled"'+(s.heatmap_enabled?' checked':'')+' onchange="autoSt()"><span class="tsl"></span></label></div>'
        +'<div class="swrow"><span>تفعيل DNI</span><label class="toggle"><input type="checkbox" name="dni_enabled"'+(s.dni_enabled?' checked':'')+' onchange="autoSt()"><span class="tsl"></span></label></div>'
      +'</div>'
      +'<div class="sbox"><div class="sbox-t"><i class="fa fa-shield-halved"></i> الاحتيال</div>'
        +'<div class="frow"><span>حد النقرات المشبوهة (24س)</span><input class="inp" name="fraud_threshold" type="number" value="'+(s.fraud_threshold||3)+'" min="2" style="width:58px"></div>'
        +'<div class="frow"><span>حد الحظر التلقائي</span><input class="inp" name="auto_blacklist" type="number" value="'+(s.auto_blacklist||5)+'" min="3" style="width:58px"></div>'
        +'<div class="frow"><span>Cooldown (دقيقة)</span><input class="inp" name="cooldown_mins" type="number" value="'+(s.cooldown_mins||30)+'" min="5" style="width:58px"></div>'
      +'</div>'
      +'<div class="sbox"><div class="sbox-t"><i class="fa fa-database"></i> البيانات</div>'
        +'<div class="frow"><span>الاحتفاظ بالبيانات (يوم)</span><input class="inp" name="data_retention" type="number" value="'+(s.data_retention||90)+'" min="7" max="365" style="width:65px"></div>'
        +'<div class="frow"><span>صلاحية التقارير (يوم)</span><input class="inp" name="report_expiry" type="number" value="'+(s.report_expiry||7)+'" min="1" style="width:65px"></div>'
      +'</div>'
      +'<div class="sbox"><div class="sbox-t"><i class="fab fa-telegram"></i> تنبيهات Telegram</div>'
        +'<div class="swrow"><span>تنبيه عند كل تحويل</span><label class="toggle"><input type="checkbox" name="notify_new_conv"'+(s.notify_new_conv?' checked':'')+' onchange="autoSt()"><span class="tsl"></span></label></div>'
        +'<div class="field" style="margin-top:.55rem"><label>Bot Token</label><input class="inp" name="telegram_token" value="'+x(s.telegram_token||'')+'" placeholder="123456:ABC-DEF..."></div>'
        +'<div class="field"><label>Chat ID</label><input class="inp" name="telegram_chat" value="'+x(s.telegram_chat||'')+'" placeholder="-100123456789"></div>'
      +'</div>'
      +'<div class="sbox info" style="grid-column:1/-1"><div class="sbox-t"><i class="fa fa-code"></i> كود التتبع</div><p style="font-size:.75rem;color:var(--tx2);line-height:1.7">الإضافة تتتبع تلقائياً: <code>tel:</code> و <code>wa.me</code><br>لعنصر مخصص: <code>data-track="cta" data-phone="971501234567"</code><br>مصادر DNI: <code>google_ads | paid | organic | social | direct | campaign</code></p></div>'
    +'</div>'
    +'<div style="margin-top:1rem"><button type="submit" class="btn-p"><i class="fa fa-save"></i> حفظ الإعدادات</button></div>'
    +'</form>';
}
function saveSt(e){
  e.preventDefault();
  var fd=new FormData(document.getElementById('sf'));
  fd.append('action','kt_save_settings_spa');fd.append('nonce',C.nonce||'');
  fetch(C.ajax||'',{method:'POST',body:fd}).then(function(r){return r.json();}).then(function(r){if(r&&r.success)toast('تم الحفظ ✓','ok');else toast('فشل الحفظ','err');});
}
function autoSt(){}

/* ═══════════════════════ NUMBER MODAL ═══════════════════════ */
function openNM(id,label,phone,wa,type,color){
  document.getElementById('nm-id').value=id||'';
  document.getElementById('nm-title').textContent=id?'تعديل الرقم':'إضافة رقم جديد';
  document.getElementById('nm-label').value=label||'';
  document.getElementById('nm-phone').value=phone||'';
  document.getElementById('nm-wa').value=wa||'';
  document.getElementById('nm-type').value=type||'both';
  document.getElementById('nm-color').value=color||'#388bfd';
  document.getElementById('nm-note').value='';
  document.getElementById('nm').style.display='';
}
function closeNM(){document.getElementById('nm').style.display='none';}
function saveNum(){
  ajax('ktp_save_number',{id:document.getElementById('nm-id').value||0,label:document.getElementById('nm-label').value,phone:document.getElementById('nm-phone').value,wa_number:document.getElementById('nm-wa').value,type:document.getElementById('nm-type').value,color:document.getElementById('nm-color').value,note:document.getElementById('nm-note').value},function(r){
    if(r&&r.success){toast(r.data.msg||'تم الحفظ','ok');closeNM();loadNums(function(){if(_pg==='numbers')rNums();});}
    else toast(r&&r.data||'فشل الحفظ','err');
  });
}
function delNum(id){if(!confirm('حذف هذا الرقم؟ التحويلات السابقة تُحفظ.'))return;ajax('ktp_delete_number',{id:id},function(r){if(r&&r.success){toast('تم الحذف','ok');loadNums(function(){rNums();});}});}
</script>
<?php
    }
}

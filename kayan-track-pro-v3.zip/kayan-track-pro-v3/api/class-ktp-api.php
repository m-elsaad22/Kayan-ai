<?php
defined('ABSPATH') || exit;

class KTP_API {

    public function __construct() {
        $pub = ['kt_register_visit','kt_track_click','kt_heatmap_batch','kt_session_end','ktp_track_conversion'];
        foreach ($pub as $a) {
            add_action('wp_ajax_' . $a,        [$this, 'h_' . $a]);
            add_action('wp_ajax_nopriv_' . $a, [$this, 'h_' . $a]);
        }
        $adm = ['ktp_admin_data','ktp_export_csv','kt_block_ip','kt_unblock_ip',
                'kt_generate_report','kt_save_settings_spa'];
        foreach ($adm as $a) add_action('wp_ajax_' . $a, [$this, 'h_' . $a]);
    }

    /* ── Helpers ─────────────────────────────────────────────── */
    private function nonce(string $n = 'kt_track'): void {
        if (!check_ajax_referer($n, 'nonce', false)) wp_send_json_error(['msg'=>'Invalid nonce'],403);
    }
    private function admin(): void {
        if (!current_user_can('manage_options')) wp_send_json_error(['msg'=>'Forbidden'],403);
    }
    private function s(string $k, string $t='text'): string {
        $v = wp_unslash($_POST[$k] ?? '');
        return match($t) { 'url' => esc_url_raw((string)$v), default => sanitize_text_field((string)$v) };
    }
    private function ip(): string {
        foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR'] as $k)
            if (!empty($_SERVER[$k])) { $ip=trim(explode(',',$_SERVER[$k])[0]); if(filter_var($ip,FILTER_VALIDATE_IP))return $ip; }
        return '0.0.0.0';
    }
    private function geo(string $ip): array {
        if (in_array($ip,['127.0.0.1','::1'])) return ['country'=>'Local','city'=>'Local'];
        $c = get_transient('ktp_geo_'.md5($ip));
        if ($c) return $c;
        $r = wp_remote_get("http://ip-api.com/json/{$ip}?fields=country,city,status",['timeout'=>4,'sslverify'=>false]);
        if (is_wp_error($r)) return ['country'=>'','city'=>''];
        $d   = json_decode(wp_remote_retrieve_body($r), true);
        $geo = ['country'=>sanitize_text_field($d['country']??''),'city'=>sanitize_text_field($d['city']??'')];
        set_transient('ktp_geo_'.md5($ip), $geo, DAY_IN_SECONDS);
        return $geo;
    }
    private function tsrc(string $ref, string $med, string $src, string $gclid=''): string {
        if ($gclid) return 'google_ads';
        if ($med==='cpc'||$med==='paid'||str_contains($src,'ads')) return 'paid';
        if ($med||$src) return 'campaign';
        if (!$ref) return 'direct';
        $d = parse_url($ref,PHP_URL_HOST)??'';
        foreach (['facebook','instagram','twitter','x.com','tiktok','snapchat','linkedin','youtube'] as $s) if(str_contains($d,$s))return 'social';
        foreach (['google','bing','yahoo','yandex','duckduckgo'] as $s) if(str_contains($d,$s))return 'organic';
        return 'referral';
    }
    private function cfg(): array { return array_merge(kt_default_settings(),(array)(get_option('kt_settings')??[])); }
    private function dates(int $days=30, string $from='', string $to=''): array {
        $since = $from ? $from.' 00:00:00' : date('Y-m-d H:i:s',strtotime("-{$days} days"));
        $until = $to   ? $to.' 23:59:59'   : date('Y-m-d H:i:s');
        return [$since,$until];
    }

    /* ════════════════════════════════════════════════════════════
       PUBLIC — VISITOR TRACKING
    ════════════════════════════════════════════════════════════ */
    public function h_kt_register_visit(): void {
        $this->nonce();
        $ip=$this->ip(); $fp=$this->s('fp'); $sid=$this->s('sid');
        $geo=$this->geo($ip); $ref=$this->s('referrer','url');
        $med=$this->s('utm_medium'); $src=$this->s('utm_source');
        $ex = KT_DB::get_row("SELECT id,visit_count FROM ".KT_DB::visitors_table()." WHERE fingerprint=%s LIMIT 1",[$fp]);
        if ($ex) {
            KT_DB::update(KT_DB::visitors_table(),['session_id'=>$sid,'last_visit'=>current_time('mysql'),'visit_count'=>$ex->visit_count+1,'is_new'=>0],['id'=>$ex->id]);
        } else {
            KT_DB::insert(KT_DB::visitors_table(),[
                'fingerprint'=>$fp,'session_id'=>$sid,'ip'=>$ip,
                'country'=>$geo['country'],'city'=>$geo['city'],
                'language'=>$this->s('lang'),'device_type'=>$this->s('device_type'),
                'os'=>$this->s('os'),'browser'=>$this->s('browser'),
                'screen_res'=>$this->s('screen'),'referrer'=>$ref,
                'utm_source'=>$src,'utm_medium'=>$med,'utm_campaign'=>$this->s('utm_campaign'),
                'traffic_src'=>$this->tsrc($ref,$med,$src),
                'first_visit'=>current_time('mysql'),'last_visit'=>current_time('mysql'),
            ]);
        }
        KT_DB::insert(KT_DB::sessions_table(),['session_id'=>$sid,'fingerprint'=>$fp,'ip'=>$ip,'start_time'=>current_time('mysql'),'is_new'=>$ex?0:1]);
        wp_send_json_success();
    }

    /* ── Legacy click (keeps kt_clicks data) ─────────────────── */
    public function h_kt_track_click(): void {
        $this->nonce();
        $ip=$this->ip(); $cfg=$this->cfg();
        if (KT_DB::is_blacklisted($ip)){wp_send_json_success(['blocked'=>true]);return;}
        $geo=$this->geo($ip); $fp=$this->s('fp');
        $vis=KT_DB::get_row("SELECT device_type,browser,os FROM ".KT_DB::visitors_table()." WHERE fingerprint=%s LIMIT 1",[$fp]);
        $cnt24=KT_DB::get_ip_click_count($ip,24);
        $sus=($cnt24>=(int)($cfg['fraud_threshold']??3))?1:0;
        $phone=ktp_clean_phone($this->s('phone_number'));
        $gclid=$this->s('gclid');
        KT_DB::insert(KT_DB::clicks_table(),[
            'session_id'=>$this->s('sid'),'fingerprint'=>$fp,'ip'=>$ip,
            'country'=>$geo['country'],'city'=>$geo['city'],
            'device_type'=>$vis->device_type??'','browser'=>$vis->browser??'','os'=>$vis->os??'',
            'click_type'=>$this->s('click_type'),'phone_number'=>$phone,
            'element'=>$this->s('element'),'page_url'=>$this->s('page_url','url'),
            'page_title'=>$this->s('page_title'),'utm_campaign'=>$this->s('utm_campaign'),
            'utm_source'=>$this->s('utm_source'),'traffic_src'=>$this->s('traffic_src')?:'direct',
            'gclid'=>$gclid,'is_suspicious'=>$sus,'created_at'=>current_time('mysql'),
        ]);
        $auto=(int)($cfg['auto_blacklist']??5);
        if ($cnt24+1>=$auto) {
            global $wpdb;
            $wpdb->query($wpdb->prepare("INSERT IGNORE INTO ".KT_DB::blacklist_table()."(ip,reason,click_count,blocked_by,created_at) VALUES(%s,'auto',%d,'system',%s)",[$ip,$cnt24+1,current_time('mysql')]));
            KT_DB::flag_suspicious_clicks($ip);
        }
        wp_send_json_success(['suspicious'=>$sus]);
    }

    /* ── PRO: save to ktp_conversions with number_id ─────────── */
    public function h_ktp_track_conversion(): void {
        $this->nonce();
        $ip    = $this->ip();
        $fp    = $this->s('fp');
        $phone = ktp_clean_phone($this->s('phone_number'));
        $type  = $this->s('click_type');
        $cfg   = $this->cfg();
        $cool  = (int)($cfg['cooldown_mins']??30);

        if (!$phone || !$type) { wp_send_json_success(['skip'=>true]); return; }

        // Server-side cooldown check
        if (KTP_DB::is_duplicate($fp, $phone, $cool)) { wp_send_json_success(['duplicate'=>true]); return; }

        // Fraud check
        $cnt24 = KT_DB::get_ip_click_count($ip, 24);
        $sus   = ($cnt24 >= (int)($cfg['fraud_threshold']??3)) ? 1 : 0;

        // Find registered number
        $num     = KTP_DB::find_number($phone);
        $num_id  = $num ? (int)$num->id : null;

        $geo = $this->geo($ip);
        $vis = KT_DB::get_row("SELECT device_type,browser,os FROM ".KT_DB::visitors_table()." WHERE fingerprint=%s LIMIT 1",[$fp]);
        $ref = $this->s('referrer','url'); $med=$this->s('utm_medium'); $src=$this->s('utm_source');
        $gclid=$this->s('gclid');

        $id = KTP_DB::insert(KTP_DB::conversions_table(),[
            'number_id'   => $num_id,
            'phone_raw'   => $phone,
            'session_id'  => $this->s('sid'),
            'fingerprint' => $fp,
            'ip'          => $ip,
            'country'     => $geo['country'],
            'city'        => $geo['city'],
            'device_type' => $vis->device_type??'',
            'browser'     => $vis->browser??'',
            'os'          => $vis->os??'',
            'click_type'  => $type,
            'page_url'    => $this->s('page_url','url'),
            'page_title'  => $this->s('page_title'),
            'referrer'    => $ref,
            'utm_source'  => $src,
            'utm_medium'  => $med,
            'utm_campaign'=> $this->s('utm_campaign'),
            'traffic_src' => $this->tsrc($ref,$med,$src,$gclid),
            'gclid'       => $gclid,
            'is_suspicious'=> $sus,
            'is_duplicate' => 0,
            'created_at'  => current_time('mysql'),
        ]);

        // Telegram notification
        $this->maybe_notify($phone, $type, $cfg);

        wp_send_json_success(['id'=>$id,'number_id'=>$num_id]);
    }

    private function maybe_notify(string $phone, string $type, array $cfg): void {
        if (empty($cfg['notify_new_conv'])||empty($cfg['telegram_token'])||empty($cfg['telegram_chat'])) return;
        $msg = "🔔 تحويل جديد\n📞 " . ktp_format_phone($phone) . "\n📋 النوع: " . ($type==='call'?'اتصال':'واتساب');
        wp_remote_post("https://api.telegram.org/bot{$cfg['telegram_token']}/sendMessage",[
            'body'=>['chat_id'=>$cfg['telegram_chat'],'text'=>$msg],'timeout'=>5,'blocking'=>false,
        ]);
    }

    /* ── Heatmap ──────────────────────────────────────────────── */
    public function h_kt_heatmap_batch(): void {
        $this->nonce();
        $pts = json_decode(sanitize_textarea_field(wp_unslash($_POST['points']??'[]')),true);
        if(!is_array($pts))return;
        $url=$this->s('page_url','url'); $fp=$this->s('fp'); $sid=$this->s('sid');
        foreach(array_slice($pts,0,100) as $p) {
            if(!isset($p['x'],$p['y']))continue;
            KT_DB::insert(KT_DB::heatmap_table(),['session_id'=>$sid,'page_url'=>$url,'x_pct'=>(int)$p['x'],'y_pct'=>(int)$p['y'],'element'=>sanitize_text_field(substr($p['el']??'',0,255)),'created_at'=>current_time('mysql')]);
        }
        wp_send_json_success();
    }

    /* ── Session end ──────────────────────────────────────────── */
    public function h_kt_session_end(): void {
        $sid=(string)($_POST['sid']??''); $dur=(int)($_POST['duration']??0);
        if($sid) KT_DB::update(KT_DB::sessions_table(),['end_time'=>current_time('mysql'),'duration'=>$dur],['session_id'=>$sid]);
        exit;
    }

    /* ════════════════════════════════════════════════════════════
       ADMIN DATA — main dashboard provider
    ════════════════════════════════════════════════════════════ */
    public function h_ktp_admin_data(): void {
        $this->nonce(); $this->admin();
        $action = sanitize_text_field($_POST['ktp_action']??'');
        $days   = max(1,min(365,(int)($_POST['days']??30)));
        [$since,$until] = $this->dates($days,$_POST['date_from']??'',$_POST['date_to']??'');

        global $wpdb;
        $ct = KTP_DB::conversions_table();  // ktp_conversions (pro)
        $nt = KTP_DB::numbers_table();      // ktp_numbers
        $vt = KT_DB::visitors_table();      // kt_visitors (legacy)
        $st = KT_DB::sessions_table();      // kt_sessions (legacy)
        $bl = KT_DB::blacklist_table();

        switch ($action) {

            /* ── Overview dashboard ── */
            case 'dashboard':
                $daily = KTP_DB::get_results($wpdb->prepare(
                    "SELECT DATE(created_at) d, COUNT(*) tot, SUM(click_type='whatsapp') wa, SUM(click_type='call') `call`
                     FROM $ct WHERE created_at>=%s AND created_at<=%s GROUP BY DATE(created_at) ORDER BY d ASC", [$since,$until]));
                $by_dev = KTP_DB::get_results($wpdb->prepare("SELECT device_type,COUNT(*) cnt FROM $ct WHERE created_at>=%s GROUP BY device_type ORDER BY cnt DESC",[$since]));
                $by_src = KTP_DB::get_results($wpdb->prepare("SELECT traffic_src,COUNT(*) cnt FROM $ct WHERE created_at>=%s GROUP BY traffic_src ORDER BY cnt DESC",[$since]));
                $top_pg = KTP_DB::get_results($wpdb->prepare("SELECT page_title,page_url,COUNT(*) cnt FROM $ct WHERE created_at>=%s GROUP BY page_url ORDER BY cnt DESC LIMIT 6",[$since]));
                $sus_ip = KTP_DB::get_results($wpdb->prepare("SELECT ip,COUNT(*) cnt,MAX(city) city FROM $ct WHERE created_at>=%s AND is_suspicious=1 GROUP BY ip HAVING cnt>=2 ORDER BY cnt DESC LIMIT 6",[$since]));
                wp_send_json_success([
                    'total'        => (int)KTP_DB::get_var($wpdb->prepare("SELECT COUNT(*) FROM $ct WHERE created_at>=%s AND created_at<=%s",[$since,$until])),
                    'calls'        => (int)KTP_DB::get_var($wpdb->prepare("SELECT COUNT(*) FROM $ct WHERE click_type='call' AND created_at>=%s",[$since])),
                    'whatsapp'     => (int)KTP_DB::get_var($wpdb->prepare("SELECT COUNT(*) FROM $ct WHERE click_type='whatsapp' AND created_at>=%s",[$since])),
                    'unique'       => (int)KTP_DB::get_var($wpdb->prepare("SELECT COUNT(DISTINCT fingerprint) FROM $ct WHERE created_at>=%s",[$since])),
                    'suspicious'   => (int)KTP_DB::get_var($wpdb->prepare("SELECT COUNT(*) FROM $ct WHERE is_suspicious=1 AND created_at>=%s",[$since])),
                    'visitors'     => (int)KT_DB::get_var("SELECT COUNT(DISTINCT fingerprint) FROM $vt WHERE last_visit>='$since'"),
                    'sessions'     => (int)KT_DB::get_var("SELECT COUNT(*) FROM $st WHERE start_time>='$since'"),
                    'nums_count'   => (int)KTP_DB::get_var("SELECT COUNT(*) FROM $nt WHERE active=1"),
                    'daily'        => $daily,
                    'by_device'    => $by_dev,
                    'by_source'    => $by_src,
                    'top_pages'    => $top_pg,
                    'sus_ips'      => $sus_ip,
                ]);
                break;

            /* ── Numbers with stats ── */
            case 'numbers_summary':
                $nums = KTP_DB::all_numbers(true, $since);
                // Unknown numbers (not registered)
                $unk = KTP_DB::get_results($wpdb->prepare(
                    "SELECT phone_raw,COUNT(*) total,SUM(click_type='call') calls,SUM(click_type='whatsapp') wa
                     FROM $ct WHERE number_id IS NULL AND phone_raw!='' AND created_at>=%s
                     GROUP BY phone_raw ORDER BY total DESC LIMIT 20",[$since]));
                wp_send_json_success(['numbers'=>$nums,'unknown'=>$unk]);
                break;

            /* ── Single number detail ── */
            case 'number_detail':
                $nid   = (int)($_POST['number_id']??0);
                $praw  = sanitize_text_field($_POST['phone_raw']??'');
                $pg    = max(1,(int)($_POST['page']??1));
                $per   = 50; $off=($pg-1)*$per;
                $tf    = sanitize_key($_POST['click_type']??'');
                $sf    = sanitize_key($_POST['traffic_src']??'');
                $sr    = sanitize_text_field($_POST['search']??'');

                if ($nid) $base = $wpdb->prepare("WHERE c.number_id=%d AND c.created_at>=%s AND c.created_at<=%s",[$nid,$since,$until]);
                elseif ($praw) $base=$wpdb->prepare("WHERE c.phone_raw=%s AND c.created_at>=%s",[$praw,$since]);
                else { wp_send_json_error('missing'); return; }
                if ($tf) $base.=$wpdb->prepare(" AND c.click_type=%s",[$tf]);
                if ($sf) $base.=$wpdb->prepare(" AND c.traffic_src=%s",[$sf]);
                if ($sr) $base.=$wpdb->prepare(" AND (c.ip LIKE %s OR c.city LIKE %s OR c.page_title LIKE %s)",array_fill(0,3,'%'.$wpdb->esc_like($sr).'%'));

                $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM $ct c $base");
                $rows  = $wpdb->get_results("SELECT c.* FROM $ct c $base ORDER BY c.created_at DESC LIMIT $per OFFSET $off");
                $stats = [
                    'total'   => $total,
                    'calls'   => (int)$wpdb->get_var("SELECT COUNT(*) FROM $ct c $base AND c.click_type='call'"),
                    'wa'      => (int)$wpdb->get_var("SELECT COUNT(*) FROM $ct c $base AND c.click_type='whatsapp'"),
                    'unique'  => (int)$wpdb->get_var("SELECT COUNT(DISTINCT c.fingerprint) FROM $ct c $base"),
                    'sus'     => (int)$wpdb->get_var("SELECT COUNT(*) FROM $ct c $base AND c.is_suspicious=1"),
                    'by_src'  => $wpdb->get_results("SELECT c.traffic_src,COUNT(*) cnt FROM $ct c $base GROUP BY c.traffic_src ORDER BY cnt DESC"),
                    'by_page' => $wpdb->get_results("SELECT c.page_title,c.page_url,COUNT(*) cnt FROM $ct c $base GROUP BY c.page_url ORDER BY cnt DESC LIMIT 5"),
                    'daily'   => $wpdb->get_results("SELECT DATE(c.created_at) d,COUNT(*) cnt FROM $ct c $base GROUP BY DATE(c.created_at) ORDER BY d ASC"),
                ];
                wp_send_json_success(['rows'=>$rows,'total'=>$total,'stats'=>$stats]);
                break;

            /* ── All conversions ── */
            case 'conversions':
                $pg   = max(1,(int)($_POST['page']??1));
                $per  = 50; $off=($pg-1)*$per;
                $tf   = sanitize_key($_POST['click_type']??'');
                $sf   = sanitize_key($_POST['traffic_src']??'');
                $nf   = (int)($_POST['number_id']??0);
                $susf = sanitize_text_field($_POST['is_suspicious']??'');
                $sr   = sanitize_text_field($_POST['search']??'');
                $where= "WHERE c.created_at>='$since' AND c.created_at<='$until'";
                if ($tf)   $where.=$wpdb->prepare(" AND c.click_type=%s",[$tf]);
                if ($sf)   $where.=$wpdb->prepare(" AND c.traffic_src=%s",[$sf]);
                if ($nf)   $where.=$wpdb->prepare(" AND c.number_id=%d",[$nf]);
                if ($susf!=='') $where.=" AND c.is_suspicious='".(int)$susf."'";
                if ($sr)   $where.=$wpdb->prepare(" AND (c.ip LIKE %s OR c.phone_raw LIKE %s OR c.city LIKE %s OR c.page_title LIKE %s)",array_fill(0,4,'%'.$wpdb->esc_like($sr).'%'));
                $total=$wpdb->get_var("SELECT COUNT(*) FROM $ct c $where");
                $rows =$wpdb->get_results("SELECT c.*,n.label num_label,n.color num_color FROM $ct c LEFT JOIN $nt n ON n.id=c.number_id $where ORDER BY c.created_at DESC LIMIT $per OFFSET $off");
                wp_send_json_success(['rows'=>$rows,'total'=>$total]);
                break;

            /* ── Visitors ── */
            case 'visitors':
                $pg   = max(1,(int)($_POST['page']??1)); $per=50; $off=($pg-1)*$per;
                $dev  = sanitize_text_field($_POST['device_type']??'');
                $sr   = sanitize_text_field($_POST['search']??'');
                $where= "WHERE last_visit>='$since'";
                if ($dev) $where.=$wpdb->prepare(" AND device_type=%s",[$dev]);
                if ($sr)  $where.=$wpdb->prepare(" AND (ip LIKE %s OR city LIKE %s)",array_fill(0,2,'%'.$wpdb->esc_like($sr).'%'));
                $total=$wpdb->get_var("SELECT COUNT(*) FROM $vt $where");
                $rows =$wpdb->get_results("SELECT * FROM $vt $where ORDER BY last_visit DESC LIMIT $per OFFSET $off");
                wp_send_json_success(['rows'=>$rows,'total'=>$total]);
                break;

            /* ── Fraud ── */
            case 'fraud':
                $cfg2=$this->cfg(); $thr=(int)($cfg2['fraud_threshold']??3);
                $sus=$wpdb->get_results($wpdb->prepare("SELECT ip,COUNT(*) cnt,MAX(city) city FROM $ct WHERE created_at>=%s AND is_suspicious=1 GROUP BY ip HAVING cnt>=%d ORDER BY cnt DESC LIMIT 25",[$since,$thr]));
                $blk=$wpdb->get_results("SELECT * FROM $bl ORDER BY created_at DESC LIMIT 100");
                wp_send_json_success([
                    'sus_count'    => count($sus),
                    'bl_count'     => count($blk),
                    'sus_clicks'   => (int)KTP_DB::get_var($wpdb->prepare("SELECT COUNT(*) FROM $ct WHERE is_suspicious=1 AND created_at>=%s",[$since])),
                    'auto_blocked' => (int)KT_DB::get_var("SELECT COUNT(*) FROM $bl WHERE blocked_by='auto'"),
                    'suspicious'   => $sus,
                    'blacklist'    => $blk,
                ]);
                break;

            /* ── Heatmap ── */
            case 'heatmap':
                $hurl=sanitize_text_field($_POST['page_url']??'');
                $ht=KT_DB::heatmap_table();
                $w=$hurl?$wpdb->prepare(" WHERE page_url=%s",[$hurl]):'';
                wp_send_json_success(['points'=>KT_DB::get_results("SELECT x_pct,y_pct,element FROM $ht{$w} ORDER BY id DESC LIMIT 3000")]);
                break;

            /* ── Reports list ── */
            case 'reports':
                wp_send_json_success(KT_DB::get_results("SELECT id,token,title,expires_at,view_count,created_at FROM ".KT_DB::reports_table()." ORDER BY created_at DESC LIMIT 20"));
                break;

            /* ── DNI rules ── */
            case 'dni_rules':
                $rules=KTP_DB::get_results("SELECT r.*,n.label,n.phone,n.color FROM ".KTP_DB::dni_rules_table()." r JOIN ".KTP_DB::numbers_table()." n ON n.id=r.number_id ORDER BY r.priority DESC,r.id ASC");
                wp_send_json_success($rules);
                break;

            /* ── Settings read ── */
            case 'get_settings':
                wp_send_json_success($this->cfg());
                break;
        }
    }

    /* ── Block / Unblock ──────────────────────────────────────── */
    public function h_kt_block_ip(): void {
        $this->nonce(); $this->admin();
        $ip=filter_var(sanitize_text_field($_POST['ip']??''),FILTER_VALIDATE_IP);
        if(!$ip){wp_send_json_error('Invalid IP');}
        global $wpdb;
        $wpdb->query($wpdb->prepare("INSERT IGNORE INTO ".KT_DB::blacklist_table()."(ip,reason,blocked_by,created_at) VALUES(%s,'manual','admin',%s)",[$ip,current_time('mysql')]));
        KT_DB::flag_suspicious_clicks($ip);
        wp_send_json_success('Blocked');
    }
    public function h_kt_unblock_ip(): void {
        $this->nonce(); $this->admin();
        $ip=filter_var(sanitize_text_field($_POST['ip']??''),FILTER_VALIDATE_IP);
        if(!$ip){wp_send_json_error('Invalid IP');}
        global $wpdb; $wpdb->delete(KT_DB::blacklist_table(),['ip'=>$ip]);
        wp_send_json_success('Unblocked');
    }

    /* ── Generate report ──────────────────────────────────────── */
    public function h_kt_generate_report(): void {
        $this->nonce(); $this->admin();
        $title =$this->s('title') ?: 'تقرير';
        $expiry=max(1,min(90,(int)($_POST['expiry_days']??7)));
        $days  =max(1,(int)($_POST['days']??30));
        $since =date('Y-m-d H:i:s',strtotime("-{$days} days"));
        $token =bin2hex(random_bytes(32));
        $ct    =KTP_DB::conversions_table();
        $data  =['total'=>(int)KTP_DB::get_var("SELECT COUNT(*) FROM $ct WHERE created_at>='$since'"),
                 'calls'=>(int)KTP_DB::get_var("SELECT COUNT(*) FROM $ct WHERE click_type='call' AND created_at>='$since'"),
                 'wa'   =>(int)KTP_DB::get_var("SELECT COUNT(*) FROM $ct WHERE click_type='whatsapp' AND created_at>='$since'")];
        KT_DB::insert(KT_DB::reports_table(),[
            'token'=>$token,'title'=>$title,'filters_json'=>json_encode(['days'=>$days]),
            'data_json'=>json_encode($data),'created_by'=>get_current_user_id(),
            'expires_at'=>date('Y-m-d H:i:s',strtotime("+{$expiry} days")),'created_at'=>current_time('mysql'),
        ]);
        wp_send_json_success(['url'=>home_url('/?kt_report='.$token)]);
    }

    /* ── Export CSV ───────────────────────────────────────────── */
    public function h_ktp_export_csv(): void {
        check_admin_referer('kt_export','nonce'); $this->admin();
        $days =(int)($_GET['days']??30);
        $since=date('Y-m-d H:i:s',strtotime("-{$days} days"));
        $ct=KTP_DB::conversions_table(); $nt=KTP_DB::numbers_table();
        $rows=KTP_DB::get_results("SELECT c.*,n.label FROM $ct c LEFT JOIN $nt n ON n.id=c.number_id WHERE c.created_at>='$since' ORDER BY c.created_at DESC LIMIT 10000");
        header('Content-Type:text/csv;charset=utf-8');
        header('Content-Disposition:attachment;filename="ktp-'.date('Y-m-d').'.csv"');
        $out=fopen('php://output','w');
        fprintf($out,chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($out,['ID','الرقم','التصنيف','النوع','IP','المدينة','الدولة','الجهاز','الصفحة','المصدر','gclid','مشبوه','التاريخ']);
        foreach($rows as $r) fputcsv($out,[$r->id,$r->phone_raw,$r->label??'',$r->click_type,$r->ip,$r->city,$r->country,$r->device_type,$r->page_title,$r->traffic_src,$r->gclid,$r->is_suspicious,$r->created_at]);
        fclose($out); exit;
    }

    /* ── Save settings ────────────────────────────────────────── */
    public function h_kt_save_settings_spa(): void {
        $this->nonce(); $this->admin();
        update_option('kt_settings',[
            'enabled'         => !empty($_POST['enabled']),
            'cookie_consent'  => !empty($_POST['cookie_consent']),
            'heatmap_enabled' => !empty($_POST['heatmap_enabled']),
            'data_retention'  => max(7,min(365,(int)($_POST['data_retention']??90))),
            'fraud_threshold' => max(2,(int)($_POST['fraud_threshold']??3)),
            'auto_blacklist'  => max(3,(int)($_POST['auto_blacklist']??5)),
            'report_expiry'   => max(1,(int)($_POST['report_expiry']??7)),
            'cooldown_mins'   => max(5,(int)($_POST['cooldown_mins']??30)),
            'dni_enabled'     => !empty($_POST['dni_enabled']),
            'geoip_service'   => sanitize_text_field($_POST['geoip_service']??'ip-api'),
            'telegram_token'  => sanitize_text_field($_POST['telegram_token']??''),
            'telegram_chat'   => sanitize_text_field($_POST['telegram_chat']??''),
            'notify_new_conv' => !empty($_POST['notify_new_conv']),
            'whatsapp_number' => sanitize_text_field($_POST['whatsapp_number']??''),
        ]);
        wp_send_json_success('Saved');
    }
}

<?php
defined('WP_UNINSTALL_PLUGIN') || exit;

if (!get_option('kt_delete_on_uninstall')) return;

global $wpdb;
$tables = [
    $wpdb->prefix . 'ktp_numbers',
    $wpdb->prefix . 'ktp_conversions',
    $wpdb->prefix . 'ktp_dni_rules',
    $wpdb->prefix . 'kt_visitors',
    $wpdb->prefix . 'kt_sessions',
    $wpdb->prefix . 'kt_events',
    $wpdb->prefix . 'kt_clicks',
    $wpdb->prefix . 'kt_heatmap',
    $wpdb->prefix . 'kt_pageviews',
    $wpdb->prefix . 'kt_blacklist',
    $wpdb->prefix . 'kt_reports',
];
foreach ($tables as $t) $wpdb->query("DROP TABLE IF EXISTS `$t`");
delete_option('kt_db_version');
delete_option('ktp_db_version');
delete_option('kt_settings');

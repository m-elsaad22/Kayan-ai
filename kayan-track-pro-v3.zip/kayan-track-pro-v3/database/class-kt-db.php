<?php
defined('ABSPATH') || exit;

class KT_DB {

    public static function visitors_table()  : string { global $wpdb; return $wpdb->prefix . 'kt_visitors'; }
    public static function sessions_table()  : string { global $wpdb; return $wpdb->prefix . 'kt_sessions'; }
    public static function events_table()    : string { global $wpdb; return $wpdb->prefix . 'kt_events'; }
    public static function clicks_table()    : string { global $wpdb; return $wpdb->prefix . 'kt_clicks'; }
    public static function heatmap_table()   : string { global $wpdb; return $wpdb->prefix . 'kt_heatmap'; }
    public static function pageviews_table() : string { global $wpdb; return $wpdb->prefix . 'kt_pageviews'; }
    public static function blacklist_table() : string { global $wpdb; return $wpdb->prefix . 'kt_blacklist'; }
    public static function reports_table()   : string { global $wpdb; return $wpdb->prefix . 'kt_reports'; }

    public static function install(): void {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::visitors_table() . " (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            fingerprint  VARCHAR(64)  NOT NULL DEFAULT '',
            session_id   VARCHAR(64)  NOT NULL DEFAULT '',
            ip           VARCHAR(45)  NOT NULL DEFAULT '',
            country      VARCHAR(100) NOT NULL DEFAULT '',
            city         VARCHAR(100) NOT NULL DEFAULT '',
            language     VARCHAR(20)  NOT NULL DEFAULT '',
            device_type  VARCHAR(20)  NOT NULL DEFAULT '',
            os           VARCHAR(60)  NOT NULL DEFAULT '',
            browser      VARCHAR(60)  NOT NULL DEFAULT '',
            screen_res   VARCHAR(20)  NOT NULL DEFAULT '',
            referrer     TEXT         NOT NULL,
            utm_source   VARCHAR(100) NOT NULL DEFAULT '',
            utm_medium   VARCHAR(100) NOT NULL DEFAULT '',
            utm_campaign VARCHAR(200) NOT NULL DEFAULT '',
            traffic_src  VARCHAR(40)  NOT NULL DEFAULT 'direct',
            is_new       TINYINT(1)   NOT NULL DEFAULT 1,
            visit_count  INT(11)      NOT NULL DEFAULT 1,
            first_visit  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_visit   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY fingerprint (fingerprint),
            KEY ip (ip),
            KEY last_visit (last_visit)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::sessions_table() . " (
            id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id  VARCHAR(64)  NOT NULL DEFAULT '',
            fingerprint VARCHAR(64)  NOT NULL DEFAULT '',
            ip          VARCHAR(45)  NOT NULL DEFAULT '',
            start_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            end_time    DATETIME     DEFAULT NULL,
            duration    INT(11)      NOT NULL DEFAULT 0,
            pages_count INT(11)      NOT NULL DEFAULT 1,
            is_new      TINYINT(1)   NOT NULL DEFAULT 1,
            PRIMARY KEY (id),
            UNIQUE KEY session_id (session_id),
            KEY fingerprint (fingerprint),
            KEY start_time (start_time)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::events_table() . " (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id   VARCHAR(64)  NOT NULL DEFAULT '',
            fingerprint  VARCHAR(64)  NOT NULL DEFAULT '',
            ip           VARCHAR(45)  NOT NULL DEFAULT '',
            event_type   VARCHAR(40)  NOT NULL DEFAULT '',
            element      VARCHAR(255) NOT NULL DEFAULT '',
            element_text VARCHAR(500) NOT NULL DEFAULT '',
            page_url     TEXT         NOT NULL,
            page_title   VARCHAR(255) NOT NULL DEFAULT '',
            scroll_depth TINYINT(3)   NOT NULL DEFAULT 0,
            time_on_page INT(11)      NOT NULL DEFAULT 0,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY event_type (event_type),
            KEY created_at (created_at)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::clicks_table() . " (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id    VARCHAR(64)  NOT NULL DEFAULT '',
            fingerprint   VARCHAR(64)  NOT NULL DEFAULT '',
            ip            VARCHAR(45)  NOT NULL DEFAULT '',
            country       VARCHAR(100) NOT NULL DEFAULT '',
            city          VARCHAR(100) NOT NULL DEFAULT '',
            device_type   VARCHAR(20)  NOT NULL DEFAULT '',
            browser       VARCHAR(60)  NOT NULL DEFAULT '',
            os            VARCHAR(60)  NOT NULL DEFAULT '',
            click_type    VARCHAR(40)  NOT NULL DEFAULT '',
            element       VARCHAR(255) NOT NULL DEFAULT '',
            page_url      TEXT         NOT NULL,
            page_title    VARCHAR(255) NOT NULL DEFAULT '',
            utm_campaign  VARCHAR(200) NOT NULL DEFAULT '',
            utm_source    VARCHAR(100) NOT NULL DEFAULT '',
            traffic_src   VARCHAR(40)  NOT NULL DEFAULT 'direct',
            is_suspicious TINYINT(1)   NOT NULL DEFAULT 0,
            created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY click_type (click_type),
            KEY ip (ip),
            KEY created_at (created_at),
            KEY is_suspicious (is_suspicious)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::heatmap_table() . " (
            id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id VARCHAR(64)  NOT NULL DEFAULT '',
            page_url   TEXT         NOT NULL,
            x_pct      SMALLINT     NOT NULL DEFAULT 0,
            y_pct      SMALLINT     NOT NULL DEFAULT 0,
            element    VARCHAR(255) NOT NULL DEFAULT '',
            created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY created_at (created_at)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::pageviews_table() . " (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            session_id   VARCHAR(64)  NOT NULL DEFAULT '',
            fingerprint  VARCHAR(64)  NOT NULL DEFAULT '',
            ip           VARCHAR(45)  NOT NULL DEFAULT '',
            page_url     TEXT         NOT NULL,
            page_title   VARCHAR(255) NOT NULL DEFAULT '',
            referrer     TEXT         NOT NULL,
            scroll_depth TINYINT(3)   NOT NULL DEFAULT 0,
            time_spent   INT(11)      NOT NULL DEFAULT 0,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY created_at (created_at)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::blacklist_table() . " (
            id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            ip          VARCHAR(45)  NOT NULL DEFAULT '',
            reason      VARCHAR(255) NOT NULL DEFAULT 'manual',
            click_count INT(11)      NOT NULL DEFAULT 0,
            blocked_by  VARCHAR(60)  NOT NULL DEFAULT 'admin',
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY ip (ip)
        ) $c;");

        dbDelta("CREATE TABLE IF NOT EXISTS " . self::reports_table() . " (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            token        VARCHAR(64)  NOT NULL DEFAULT '',
            title        VARCHAR(255) NOT NULL DEFAULT '',
            filters_json TEXT         NOT NULL,
            data_json    LONGTEXT     NOT NULL,
            created_by   BIGINT(20)   NOT NULL DEFAULT 0,
            expires_at   DATETIME     DEFAULT NULL,
            view_count   INT(11)      NOT NULL DEFAULT 0,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY token (token)
        ) $c;");

        update_option('kt_db_version', KTP_VERSION);
    }

    // ── Migration: upgrade existing database ──────────────────
    public static function maybe_migrate(): void {
        $installed = get_option('kt_db_version', '0');
        if ( version_compare($installed, KTP_VERSION, '>=') ) {
            return;
        }

        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Safely get existing columns
        $cols = $wpdb->get_col("SHOW COLUMNS FROM `" . self::clicks_table() . "`");
        if ( ! is_array($cols) ) {
            $cols = [];
        }

        // Add is_suspicious if missing
        if ( ! in_array('is_suspicious', $cols, true) ) {
            $wpdb->query("ALTER TABLE `" . self::clicks_table() . "` ADD COLUMN `is_suspicious` TINYINT(1) NOT NULL DEFAULT 0");
            $wpdb->query("ALTER TABLE `" . self::clicks_table() . "` ADD INDEX `kt_idx_sus` (`is_suspicious`)");
        }

        // Add traffic_src if missing
        if ( ! in_array('traffic_src', $cols, true) ) {
            $wpdb->query("ALTER TABLE `" . self::clicks_table() . "` ADD COLUMN `traffic_src` VARCHAR(40) NOT NULL DEFAULT 'direct'");
        }

        // Create blacklist table if not exists
        dbDelta("CREATE TABLE IF NOT EXISTS " . self::blacklist_table() . " (
            id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            ip          VARCHAR(45)  NOT NULL DEFAULT '',
            reason      VARCHAR(255) NOT NULL DEFAULT 'manual',
            click_count INT(11)      NOT NULL DEFAULT 0,
            blocked_by  VARCHAR(60)  NOT NULL DEFAULT 'admin',
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY ip (ip)
        ) $c;");

        // Create reports table if not exists
        dbDelta("CREATE TABLE IF NOT EXISTS " . self::reports_table() . " (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            token        VARCHAR(64)  NOT NULL DEFAULT '',
            title        VARCHAR(255) NOT NULL DEFAULT '',
            filters_json TEXT         NOT NULL,
            data_json    LONGTEXT     NOT NULL,
            created_by   BIGINT(20)   NOT NULL DEFAULT 0,
            expires_at   DATETIME     DEFAULT NULL,
            view_count   INT(11)      NOT NULL DEFAULT 0,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY token (token)
        ) $c;");

        update_option('kt_db_version', KTP_VERSION);
    }

    // ── Deactivate / Uninstall ────────────────────────────────
    public static function deactivate(): void {}

    public static function uninstall(): void {
        global $wpdb;
        if ( ! get_option('kt_delete_on_uninstall') ) {
            return;
        }
        foreach ([
            self::visitors_table(),
            self::sessions_table(),
            self::events_table(),
            self::clicks_table(),
            self::heatmap_table(),
            self::pageviews_table(),
            self::blacklist_table(),
            self::reports_table(),
        ] as $t) {
            $wpdb->query("DROP TABLE IF EXISTS `$t`");
        }
        delete_option('kt_db_version');
        delete_option('kt_settings');
    }

    // ── CRUD helpers ──────────────────────────────────────────
    public static function insert(string $t, array $d): int|false {
        global $wpdb;
        $wpdb->insert($t, $d);
        return $wpdb->insert_id ?: false;
    }

    public static function update(string $t, array $d, array $w): bool {
        global $wpdb;
        return (bool) $wpdb->update($t, $d, $w);
    }

    public static function get_row(string $sql, array $args = []): ?object {
        global $wpdb;
        if ($args) $sql = $wpdb->prepare($sql, $args);
        return $wpdb->get_row($sql) ?: null;
    }

    public static function get_results(string $sql, array $args = []): array {
        global $wpdb;
        if ($args) $sql = $wpdb->prepare($sql, $args);
        return $wpdb->get_results($sql) ?: [];
    }

    public static function get_var(string $sql, array $args = []): mixed {
        global $wpdb;
        if ($args) $sql = $wpdb->prepare($sql, $args);
        return $wpdb->get_var($sql);
    }

    // ── Fraud helpers ─────────────────────────────────────────
    public static function is_blacklisted(string $ip): bool {
        return ! empty(self::get_var(
            "SELECT id FROM " . self::blacklist_table() . " WHERE ip=%s LIMIT 1",
            [$ip]
        ));
    }

    public static function get_ip_click_count(string $ip, int $hours = 24): int {
        $since = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));
        return (int) self::get_var(
            "SELECT COUNT(*) FROM " . self::clicks_table() . " WHERE ip=%s AND created_at>=%s",
            [$ip, $since]
        );
    }

    public static function flag_suspicious_clicks(string $ip): void {
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "UPDATE " . self::clicks_table() . " SET is_suspicious=1 WHERE ip=%s",
            [$ip]
        ));
    }

} // end class KT_DB

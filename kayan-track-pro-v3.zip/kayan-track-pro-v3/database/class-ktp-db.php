<?php
defined('ABSPATH') || exit;

/**
 * KTP_DB — Pro tables added on top of existing kt_ tables
 * NEVER drops or modifies kt_ tables — 100% non-destructive
 */
class KTP_DB {

    public static function numbers_table()      : string { global $wpdb; return $wpdb->prefix . 'ktp_numbers'; }
    public static function conversions_table()  : string { global $wpdb; return $wpdb->prefix . 'ktp_conversions'; }
    public static function dni_rules_table()    : string { global $wpdb; return $wpdb->prefix . 'ktp_dni_rules'; }

    /* ── Install ──────────────────────────────────────────────── */
    public static function install(): void {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        /* Phone numbers registry */
        dbDelta("CREATE TABLE IF NOT EXISTS " . self::numbers_table() . " (
            id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            label       VARCHAR(100)  NOT NULL DEFAULT '',
            phone       VARCHAR(30)   NOT NULL DEFAULT '',
            wa_number   VARCHAR(30)   NOT NULL DEFAULT '',
            type        VARCHAR(10)   NOT NULL DEFAULT 'both',
            color       VARCHAR(10)   NOT NULL DEFAULT '#388bfd',
            active      TINYINT(1)   NOT NULL DEFAULT 1,
            note        TEXT,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY phone (phone),
            KEY active (active)
        ) $c;");

        /* Pro conversions — each conversion linked to a phone number */
        dbDelta("CREATE TABLE IF NOT EXISTS " . self::conversions_table() . " (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            number_id     BIGINT(20) UNSIGNED DEFAULT NULL,
            phone_raw     VARCHAR(50)  NOT NULL DEFAULT '',
            session_id    VARCHAR(64)  NOT NULL DEFAULT '',
            fingerprint   VARCHAR(64)  NOT NULL DEFAULT '',
            ip            VARCHAR(45)  NOT NULL DEFAULT '',
            country       VARCHAR(100) NOT NULL DEFAULT '',
            city          VARCHAR(100) NOT NULL DEFAULT '',
            device_type   VARCHAR(20)  NOT NULL DEFAULT '',
            browser       VARCHAR(60)  NOT NULL DEFAULT '',
            os            VARCHAR(60)  NOT NULL DEFAULT '',
            click_type    VARCHAR(20)  NOT NULL DEFAULT '',
            page_url      TEXT         NOT NULL,
            page_title    VARCHAR(255) NOT NULL DEFAULT '',
            referrer      TEXT         NOT NULL,
            utm_source    VARCHAR(100) NOT NULL DEFAULT '',
            utm_medium    VARCHAR(100) NOT NULL DEFAULT '',
            utm_campaign  VARCHAR(200) NOT NULL DEFAULT '',
            traffic_src   VARCHAR(40)  NOT NULL DEFAULT 'direct',
            gclid         VARCHAR(255) NOT NULL DEFAULT '',
            is_suspicious TINYINT(1)   NOT NULL DEFAULT 0,
            is_duplicate  TINYINT(1)   NOT NULL DEFAULT 0,
            created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY number_id (number_id),
            KEY phone_raw (phone_raw),
            KEY click_type (click_type),
            KEY ip (ip),
            KEY traffic_src (traffic_src),
            KEY is_suspicious (is_suspicious),
            KEY created_at (created_at)
        ) $c;");

        /* DNI rules — which number shows for which traffic source */
        dbDelta("CREATE TABLE IF NOT EXISTS " . self::dni_rules_table() . " (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            number_id    BIGINT(20) UNSIGNED NOT NULL,
            source_type  VARCHAR(30)  NOT NULL DEFAULT 'direct',
            utm_source   VARCHAR(100) NOT NULL DEFAULT '',
            utm_medium   VARCHAR(100) NOT NULL DEFAULT '',
            utm_campaign VARCHAR(200) NOT NULL DEFAULT '',
            priority     TINYINT      NOT NULL DEFAULT 0,
            active       TINYINT(1)   NOT NULL DEFAULT 1,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY number_id (number_id),
            KEY source_type (source_type),
            KEY priority (priority)
        ) $c;");

        /* Add phone_number + gclid columns to original kt_clicks (non-destructive) */
        $cols = $wpdb->get_col("SHOW COLUMNS FROM `{$wpdb->prefix}kt_clicks`");
        if (is_array($cols)) {
            if (!in_array('phone_number', $cols)) {
                $wpdb->query("ALTER TABLE `{$wpdb->prefix}kt_clicks` ADD COLUMN `phone_number` VARCHAR(30) NOT NULL DEFAULT '' AFTER `click_type`");
                $wpdb->query("ALTER TABLE `{$wpdb->prefix}kt_clicks` ADD INDEX `ktp_idx_phone` (`phone_number`)");
            }
            if (!in_array('gclid', $cols)) {
                $wpdb->query("ALTER TABLE `{$wpdb->prefix}kt_clicks` ADD COLUMN `gclid` VARCHAR(255) NOT NULL DEFAULT '' AFTER `utm_source`");
            }
        }

        update_option('ktp_db_version', KTP_VERSION);
    }

    public static function maybe_migrate(): void {
        $v = get_option('ktp_db_version', '0');
        if (version_compare($v, KTP_VERSION, '>=')) return;
        self::install();
    }

    /* ── CRUD ─────────────────────────────────────────────────── */
    public static function insert(string $t, array $d): int|false {
        global $wpdb; $wpdb->insert($t, $d); return $wpdb->insert_id ?: false;
    }
    public static function update(string $t, array $d, array $w): bool {
        global $wpdb; return (bool) $wpdb->update($t, $d, $w);
    }
    public static function get_row(string $sql, array $a = []): ?object {
        global $wpdb; if ($a) $sql = $wpdb->prepare($sql, $a); return $wpdb->get_row($sql) ?: null;
    }
    public static function get_results(string $sql, array $a = []): array {
        global $wpdb; if ($a) $sql = $wpdb->prepare($sql, $a); return $wpdb->get_results($sql) ?: [];
    }
    public static function get_var(string $sql, array $a = []): mixed {
        global $wpdb; if ($a) $sql = $wpdb->prepare($sql, $a); return $wpdb->get_var($sql);
    }

    /* ── Number helpers ──────────────────────────────────────── */
    public static function find_number(string $phone): ?object {
        $clean = ktp_clean_phone($phone);
        return self::get_row(
            "SELECT * FROM " . self::numbers_table() . " WHERE (phone=%s OR wa_number=%s) AND active=1 LIMIT 1",
            [$clean, $clean]
        );
    }

    public static function all_numbers(bool $with_stats = false, string $since = ''): array {
        $nt = self::numbers_table();
        $ct = self::conversions_table();
        if ($with_stats && $since) {
            return self::get_results(
                "SELECT n.*,
                 (SELECT COUNT(*) FROM $ct c WHERE c.number_id=n.id AND c.created_at>='$since') total,
                 (SELECT COUNT(*) FROM $ct c WHERE c.number_id=n.id AND c.click_type='call' AND c.created_at>='$since') calls,
                 (SELECT COUNT(*) FROM $ct c WHERE c.number_id=n.id AND c.click_type='whatsapp' AND c.created_at>='$since') wa,
                 (SELECT COUNT(DISTINCT c.fingerprint) FROM $ct c WHERE c.number_id=n.id AND c.created_at>='$since') uniq
                 FROM $nt n WHERE n.active=1 ORDER BY total DESC"
            );
        }
        return self::get_results("SELECT * FROM $nt WHERE active=1 ORDER BY id ASC");
    }

    /* ── Duplicate / cooldown check ──────────────────────────── */
    public static function is_duplicate(string $fp, string $phone, int $mins): bool {
        $since = date('Y-m-d H:i:s', time() - $mins * 60);
        return (bool) self::get_var(
            "SELECT id FROM " . self::conversions_table() . " WHERE fingerprint=%s AND phone_raw=%s AND created_at>=%s LIMIT 1",
            [$fp, $phone, $since]
        );
    }
}

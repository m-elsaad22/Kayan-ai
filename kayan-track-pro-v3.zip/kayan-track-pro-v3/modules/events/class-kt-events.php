<?php
defined('ABSPATH') || exit;
class KT_Events {
    public function get_top(int $limit = 10, int $days = 30): array {
        global $wpdb;
        return KT_DB::get_results($wpdb->prepare(
            "SELECT event_type,element,COUNT(*) cnt FROM ".KT_DB::events_table()." WHERE created_at>=%s GROUP BY event_type,element ORDER BY cnt DESC LIMIT %d",
            [date('Y-m-d H:i:s', strtotime("-{$days} days")), $limit]
        ));
    }
}

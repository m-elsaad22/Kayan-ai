<?php
defined('ABSPATH') || exit;
class KT_Sessions {
    public function __construct() {
        add_action('kt_cleanup', [$this, 'cleanup']);
        if (!wp_next_scheduled('kt_cleanup'))
            wp_schedule_event(time(), 'daily', 'kt_cleanup');
    }
    public function cleanup(): void {
        global $wpdb;
        $days   = max(7, (int)(get_option('kt_settings', kt_default_settings())['data_retention'] ?? 90));
        $cutoff = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        foreach ([KT_DB::sessions_table(), KT_DB::pageviews_table(), KT_DB::heatmap_table()] as $t)
            $wpdb->query("DELETE FROM `$t` WHERE created_at < '$cutoff' OR start_time < '$cutoff'");
    }
}

<?php
defined('ABSPATH') || exit;
class KT_Clicks {
    public function conv_rate(int $days = 30): float {
        $since    = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        $visitors = (int) KT_DB::get_var("SELECT COUNT(DISTINCT fingerprint) FROM ".KT_DB::visitors_table()." WHERE last_visit>='$since'");
        $clicks   = (int) KT_DB::get_var("SELECT COUNT(*) FROM ".KT_DB::clicks_table()." WHERE created_at>='$since'");
        return $visitors > 0 ? round($clicks / $visitors * 100, 1) : 0.0;
    }
}

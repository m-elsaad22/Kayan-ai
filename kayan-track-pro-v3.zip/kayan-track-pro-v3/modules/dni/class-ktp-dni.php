<?php
defined('ABSPATH') || exit;

class KTP_DNI {
    public function __construct() {
        add_action('wp_ajax_nopriv_ktp_get_dni_number', [$this, 'ajax_get']);
        add_action('wp_ajax_ktp_get_dni_number',        [$this, 'ajax_get']);
        add_action('wp_ajax_ktp_save_dni_rule',         [$this, 'ajax_save']);
        add_action('wp_ajax_ktp_delete_dni_rule',       [$this, 'ajax_delete']);
        add_action('wp_ajax_ktp_list_dni_rules',        [$this, 'ajax_list']);
    }

    public function ajax_get(): void {
        // No nonce needed — public endpoint called from JS
        $src   = sanitize_key($_POST['traffic_src'] ?? 'direct');
        $utm_s = sanitize_text_field($_POST['utm_source'] ?? '');
        $utm_m = sanitize_text_field($_POST['utm_medium'] ?? '');
        $utm_c = sanitize_text_field($_POST['utm_campaign'] ?? '');

        $rules = KTP_DB::get_results(
            "SELECT r.*,n.phone,n.wa_number,n.label FROM " . KTP_DB::dni_rules_table() . " r
             JOIN " . KTP_DB::numbers_table() . " n ON n.id=r.number_id
             WHERE r.active=1 AND n.active=1 ORDER BY r.priority DESC, r.id ASC"
        );
        foreach ($rules as $rule) {
            $match = false;
            if ($rule->source_type && $rule->source_type === $src) $match = true;
            if ($rule->utm_source  && stripos($utm_s, $rule->utm_source) !== false) $match = true;
            if ($rule->utm_medium  && stripos($utm_m, $rule->utm_medium) !== false) $match = true;
            if ($rule->utm_campaign && stripos($utm_c, $rule->utm_campaign) !== false) $match = true;
            if ($match) {
                wp_send_json_success([
                    'phone'     => $rule->phone,
                    'wa_number' => $rule->wa_number,
                    'display'   => ktp_format_phone($rule->phone),
                    'label'     => $rule->label,
                ]);
                return;
            }
        }
        wp_send_json_success(null);
    }

    public function ajax_save(): void {
        check_ajax_referer('ktp_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('forbidden');
        $id   = (int)($_POST['id'] ?? 0);
        $data = [
            'number_id'   => (int)($_POST['number_id'] ?? 0),
            'source_type' => sanitize_key($_POST['source_type'] ?? ''),
            'utm_source'  => sanitize_text_field($_POST['utm_source'] ?? ''),
            'utm_medium'  => sanitize_text_field($_POST['utm_medium'] ?? ''),
            'utm_campaign'=> sanitize_text_field($_POST['utm_campaign'] ?? ''),
            'priority'    => (int)($_POST['priority'] ?? 0),
            'active'      => 1,
        ];
        if ($id) { KTP_DB::update(KTP_DB::dni_rules_table(), $data, ['id' => $id]); wp_send_json_success('تم التحديث'); }
        else     { $n = KTP_DB::insert(KTP_DB::dni_rules_table(), $data + ['created_at' => current_time('mysql')]); wp_send_json_success(['id' => $n]); }
    }

    public function ajax_delete(): void {
        check_ajax_referer('ktp_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('forbidden');
        global $wpdb;
        $wpdb->delete(KTP_DB::dni_rules_table(), ['id' => (int)($_POST['id'] ?? 0)]);
        wp_send_json_success('تم الحذف');
    }

    public function ajax_list(): void {
        check_ajax_referer('ktp_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('forbidden');
        $rules = KTP_DB::get_results(
            "SELECT r.*,n.label,n.phone,n.color FROM " . KTP_DB::dni_rules_table() . " r
             JOIN " . KTP_DB::numbers_table() . " n ON n.id=r.number_id ORDER BY r.priority DESC, r.id ASC"
        );
        wp_send_json_success($rules);
    }
}

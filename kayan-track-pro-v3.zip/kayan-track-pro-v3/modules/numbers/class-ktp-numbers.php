<?php
defined('ABSPATH') || exit;

class KTP_Numbers {
    public function __construct() {
        add_action('wp_ajax_ktp_save_number',   [$this, 'ajax_save']);
        add_action('wp_ajax_ktp_delete_number', [$this, 'ajax_delete']);
        add_action('wp_ajax_ktp_list_numbers',  [$this, 'ajax_list']);
    }
    public function ajax_save(): void {
        check_ajax_referer('ktp_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('forbidden');
        $id    = (int)($_POST['id'] ?? 0);
        $phone = ktp_clean_phone(sanitize_text_field($_POST['phone'] ?? ''));
        if (!$phone) { wp_send_json_error('رقم الهاتف مطلوب'); }
        $data  = [
            'label'     => sanitize_text_field($_POST['label'] ?? ''),
            'phone'     => $phone,
            'wa_number' => ktp_clean_phone(sanitize_text_field($_POST['wa_number'] ?? '')) ?: $phone,
            'type'      => sanitize_key($_POST['type'] ?? 'both'),
            'color'     => sanitize_hex_color($_POST['color'] ?? '#388bfd') ?: '#388bfd',
            'note'      => sanitize_textarea_field($_POST['note'] ?? ''),
        ];
        if ($id) {
            KTP_DB::update(KTP_DB::numbers_table(), $data, ['id' => $id]);
            wp_send_json_success(['id' => $id, 'msg' => 'تم تحديث الرقم']);
        } else {
            $new = KTP_DB::insert(KTP_DB::numbers_table(), $data + ['created_at' => current_time('mysql')]);
            wp_send_json_success(['id' => $new, 'msg' => 'تم إضافة الرقم']);
        }
    }
    public function ajax_delete(): void {
        check_ajax_referer('ktp_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('forbidden');
        global $wpdb;
        $wpdb->update(KTP_DB::numbers_table(), ['active' => 0], ['id' => (int)($_POST['id'] ?? 0)]);
        wp_send_json_success('تم الحذف');
    }
    public function ajax_list(): void {
        check_ajax_referer('ktp_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('forbidden');
        $days  = max(1, (int)($_POST['days'] ?? 30));
        $since = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        wp_send_json_success(KTP_DB::all_numbers(true, $since));
    }
}

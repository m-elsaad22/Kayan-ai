<?php
defined('ABSPATH') || exit;

class KTP_Tracker {
    private array $cfg;
    public function __construct() {
        $this->cfg = array_merge(kt_default_settings(), (array)(get_option('kt_settings') ?: []));
        if (!$this->cfg['enabled']) return;
        if (is_admin() && !wp_doing_ajax()) return;
        add_action('wp_head',   [$this, 'maybe_consent'], 1);
        add_action('wp_footer', [$this, 'inject'],       99);
    }

    public function inject(): void {
        if ($this->is_bot()) return;
        $ip       = $this->real_ip();
        $blocked  = KT_DB::is_blacklisted($ip);
        $nonce    = wp_create_nonce('kt_track');
        $ajax     = admin_url('admin-ajax.php');
        $consent  = $this->cfg['cookie_consent'] ? 'true' : 'false';
        $hm       = $this->cfg['heatmap_enabled'] ? 'true' : 'false';
        $threshold= (int)($this->cfg['fraud_threshold'] ?? 3);
        $cooldown = (int)($this->cfg['cooldown_mins'] ?? 30);
        $dni_on   = !empty($this->cfg['dni_enabled']) ? 'true' : 'false';
        ?>
<script id="ktp-tracker" data-cfasync="false">
(function(){
'use strict';
var KTC={ajax:'<?php echo esc_js($ajax);?>',nonce:'<?php echo esc_js($nonce);?>',
  consent:<?php echo $consent;?>,hm:<?php echo $hm;?>,
  blocked:<?php echo $blocked?'true':'false';?>,
  threshold:<?php echo $threshold;?>,cooldown:<?php echo $cooldown;?>,
  dni:<?php echo $dni_on;?>};

if(KTC.consent&&localStorage.getItem('ktp_consent')==='0')return;

/* ── Fingerprint ── */
function mkFP(){var s=navigator.userAgent+(screen.width|0)+(screen.height|0)+(navigator.language||'')+(Intl.DateTimeFormat().resolvedOptions().timeZone||'');var h=0;for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);h=((h<<5)-h)+c;h|=0;}return'ktp'+(h>>>0).toString(16)+Date.now().toString(36).slice(-4);}
var FP=localStorage.getItem('ktp_fp')||(function(){var f=mkFP();localStorage.setItem('ktp_fp',f);return f;}());
var SID=(function(){var k='ktp_sid',v=sessionStorage.getItem(k);if(!v){v='ks'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);sessionStorage.setItem(k,v);}return v;}());
var isNew=!localStorage.getItem('ktp_fp_set');if(isNew)localStorage.setItem('ktp_fp_set','1');

/* ── Device ── */
var UA=navigator.userAgent;
var DEV={
  type:/Mobi|Android|iPhone/i.test(UA)?'mobile':/iPad|Tablet/i.test(UA)?'tablet':'desktop',
  os:/Windows/i.test(UA)?'Windows':/Mac OS X/.test(UA)&&!/iPhone|iPad/.test(UA)?'macOS':/iPhone/.test(UA)?'iOS':/Android/.test(UA)?'Android':'Other',
  browser:/Edg\//.test(UA)?'Edge':/Chrome\//.test(UA)?'Chrome':/Firefox\//.test(UA)?'Firefox':/Safari\//.test(UA)?'Safari':'Other',
  screen:screen.width+'x'+screen.height,lang:navigator.language||'en'};

/* ── UTM + GCLID ── */
var P=new URLSearchParams(location.search);
var UTM={src:P.get('utm_source')||'',med:P.get('utm_medium')||'',camp:P.get('utm_campaign')||''};
var GCLID=P.get('gclid')||sessionStorage.getItem('ktp_gclid')||'';
if(P.get('gclid'))sessionStorage.setItem('ktp_gclid',GCLID);

/* ── Traffic source ── */
function tsrc(ref,med,src){
  if(GCLID)return 'google_ads';
  if(med==='cpc'||med==='paid'||/ads/i.test(src))return 'paid';
  if(med||src)return 'campaign';
  if(!ref)return 'direct';
  var d=(function(){try{return new URL(ref).hostname;}catch(e){return '';}}());
  if(/facebook|instagram|twitter|x\.com|tiktok|snapchat|linkedin|youtube/i.test(d))return 'social';
  if(/google|bing|yahoo|yandex|duckduckgo/i.test(d))return 'organic';
  return 'referral';
}
var TSRC=tsrc(document.referrer,UTM.med,UTM.src);

/* ── Send ── */
function send(action,data,cb){
  var fd=new FormData();fd.append('action',action);fd.append('nonce',KTC.nonce);
  Object.keys(data).forEach(function(k){fd.append(k,typeof data[k]==='object'?JSON.stringify(data[k]):data[k]);});
  var x=new XMLHttpRequest();x.open('POST',KTC.ajax,true);
  x.onload=function(){try{if(cb)cb(JSON.parse(x.responseText));}catch(e){}};
  x.send(fd);
}

/* ── Extract phone from href ── */
function extractPhone(href){
  if(!href)return'';
  var m=href.match(/^tel:\+?([0-9\s\-\(\)\.]+)/i);
  if(m)return m[1].replace(/[\s\-\(\)\.]/g,'');
  var w=href.match(/wa\.me\/\+?([0-9]+)/i);
  if(w)return w[1];
  try{var wp=new URLSearchParams(href.split('?')[1]||'').get('phone');if(wp)return wp.replace(/[^0-9]/g,'');}catch(e){}
  return'';
}

/* ── Cooldown (client-side) ── */
function onCooldown(phone){
  var k='ktp_cd_'+phone,t=localStorage.getItem(k);
  if(!t)return false;
  return(Date.now()-parseInt(t))<KTC.cooldown*60*1000;
}
function setCooldown(phone){localStorage.setItem('ktp_cd_'+phone,Date.now());}

var maxScroll=0,startTime=Date.now();
document.addEventListener('scroll',function(){var p=Math.round((scrollY/(document.documentElement.scrollHeight-innerHeight||1))*100);if(p>maxScroll)maxScroll=Math.min(p,100);},{passive:true});

/* ── Register visit (original action — keeps legacy data) ── */
setTimeout(function(){
  send('kt_register_visit',{
    fp:FP,sid:SID,is_new:isNew?1:0,
    device_type:DEV.type,os:DEV.os,browser:DEV.browser,
    screen:DEV.screen,lang:DEV.lang,
    referrer:document.referrer,traffic_src:TSRC,
    utm_source:UTM.src,utm_medium:UTM.med,utm_campaign:UTM.camp,
    page_url:location.href,page_title:document.title});
},400);

/* ── Track conversion WITH phone number ── */
function trackConv(type,element,phone){
  phone=phone||'';
  if(KTC.blocked){
    document.querySelectorAll('a[href^="tel:"],a[href*="wa.me"],[data-track="call"],[data-track="whatsapp"]')
      .forEach(function(el){el.style.opacity='0.3';el.style.pointerEvents='none';});
    return;
  }
  // Client cooldown
  if(phone&&onCooldown(phone)){
    console.log('[KTP] cooldown active for '+phone);return;
  }
  if(phone)setCooldown(phone);

  var data={fp:FP,sid:SID,click_type:type,element:element,phone_number:phone,
    page_url:location.href,page_title:document.title,referrer:document.referrer,
    utm_source:UTM.src,utm_medium:UTM.med,utm_campaign:UTM.camp,
    traffic_src:TSRC,gclid:GCLID,
    scroll_depth:maxScroll,time_on_page:Math.round((Date.now()-startTime)/1000)};

  // Legacy endpoint (keeps existing kt_clicks data)
  send('kt_track_click',data);
  // Pro endpoint (saves to ktp_conversions with number_id)
  send('ktp_track_conversion',data);
}

/* ── Auto-detect tel: + wa.me → extract phone ── */
document.addEventListener('click',function(e){
  var a=e.target.closest('a');if(!a)return;
  var href=a.href||'';
  if(/^tel:/i.test(href))trackConv('call','a[tel]',extractPhone(href));
  else if(/wa\.me|whatsapp\.com/i.test(href))trackConv('whatsapp','a[wa]',extractPhone(href));
},{passive:true});

/* ── data-track + data-phone ── */
document.addEventListener('click',function(e){
  var el=e.target.closest('[data-track],[class*="kayan-track"],[class*="ktp-track"]');
  if(!el)return;
  var t=el.getAttribute('data-track')||'cta';
  var phone=el.getAttribute('data-phone')||'';
  if(!phone){var near=el.querySelector('a[href^="tel:"]');if(near)phone=extractPhone(near.href);}
  trackConv(t,el.tagName.toLowerCase()+(el.id?'#'+el.id:''),phone);
},{passive:true});

/* ── Form tracking ── */
document.addEventListener('submit',function(e){
  trackConv('form','form'+(e.target.id?'#'+e.target.id:''),'');
},{passive:true});

/* ── Heatmap ── */
if(KTC.hm){
  var hq=[],hT=null;
  document.addEventListener('click',function(e){
    var xp=Math.round(e.clientX/innerWidth*100);
    var yp=Math.round((e.clientY+scrollY)/Math.max(document.body.scrollHeight,1)*100);
    var el=e.target,sel=el.tagName+(el.id?'#'+el.id:el.className?'.'+el.className.split(' ')[0]:'');
    hq.push({x:xp,y:yp,el:sel.slice(0,60)});
    clearTimeout(hT);hT=setTimeout(function(){
      if(!hq.length)return;
      send('kt_heatmap_batch',{fp:FP,sid:SID,page_url:location.href,points:JSON.stringify(hq)});hq=[];
    },3000);
  },{passive:true});
}

/* ── Session end ── */
function endSess(){var dur=Math.round((Date.now()-startTime)/1000);navigator.sendBeacon(KTC.ajax,'action=kt_session_end&nonce='+KTC.nonce+'&sid='+encodeURIComponent(SID)+'&duration='+dur+'&scroll='+maxScroll);}
window.addEventListener('pagehide',endSess);
window.addEventListener('beforeunload',endSess);

/* ── DNI: replace phone numbers per traffic source ── */
if(KTC.dni){
  send('ktp_get_dni_number',{traffic_src:TSRC,utm_source:UTM.src,utm_medium:UTM.med,utm_campaign:UTM.camp},function(r){
    if(!r||!r.success||!r.data)return;
    var num=r.data;
    document.querySelectorAll('a[href^="tel:"]').forEach(function(a){
      a.href='tel:+'+num.phone;
      if(a.textContent&&/[0-9]/.test(a.textContent))a.textContent=num.display;
    });
    if(num.wa_number){
      document.querySelectorAll('a[href*="wa.me"]').forEach(function(a){
        a.href=a.href.replace(/wa\.me\/\+?[0-9]+/,'wa.me/'+num.wa_number);
      });
    }
  });
}

}());
</script>
<?php
    }

    public function maybe_consent(): void {
        if (!$this->cfg['cookie_consent'] || isset($_COOKIE['ktp_consent'])) return;
        ?>
<style>#ktp-cb{position:fixed;bottom:1rem;right:1rem;left:1rem;max-width:460px;margin:0 auto;background:#161b22;border:1px solid #30363d;border-radius:14px;padding:1rem 1.2rem;z-index:9999;display:flex;align-items:center;gap:.75rem;font-family:system-ui,sans-serif;font-size:13px;box-shadow:0 8px 32px rgba(0,0,0,.5);color:#c9d1d9}
#ktp-cb p{margin:0;flex:1;line-height:1.5}#ktp-ca,#ktp-cr{padding:6px 14px;border:none;border-radius:7px;font-weight:700;font-size:12px;cursor:pointer}
#ktp-ca{background:linear-gradient(135deg,#1a6bff,#7c3aed);color:#fff}#ktp-cr{background:#21262d;color:#8b949e;border:1px solid #30363d}</style>
<div id="ktp-cb"><p>🍪 نستخدم التتبع لقياس أداء الأرقام والحملات.</p><button id="ktp-cr">رفض</button><button id="ktp-ca">موافق</button></div>
<script>document.getElementById('ktp-ca').onclick=function(){localStorage.setItem('ktp_consent','1');document.cookie='ktp_consent=1;path=/;max-age=31536000';document.getElementById('ktp-cb').remove();};document.getElementById('ktp-cr').onclick=function(){localStorage.setItem('ktp_consent','0');document.getElementById('ktp-cb').remove();};</script>
<?php
    }

    private function is_bot(): bool {
        $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
        foreach (['bot','spider','crawl','semrush','ahrefs','mj12','bytespider','curl','wget'] as $b)
            if (str_contains($ua, $b)) return true;
        return false;
    }
    private function real_ip(): string {
        foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR'] as $k)
            if (!empty($_SERVER[$k])) { $ip = trim(explode(',', $_SERVER[$k])[0]); if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip; }
        return '0.0.0.0';
    }
}

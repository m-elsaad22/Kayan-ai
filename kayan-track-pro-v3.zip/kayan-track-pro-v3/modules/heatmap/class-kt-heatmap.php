<?php
defined('ABSPATH') || exit;
class KT_Heatmap {
    public function get_points(string $url, int $limit = 2000): array {
        global $wpdb;
        return KT_DB::get_results($wpdb->prepare(
            "SELECT x_pct,y_pct,COUNT(*) cnt FROM ".KT_DB::heatmap_table()." WHERE page_url=%s GROUP BY x_pct,y_pct ORDER BY cnt DESC LIMIT %d",
            [$url, $limit]
        ));
    }
}

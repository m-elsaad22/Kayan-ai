<?php
defined('ABSPATH') || exit;

function kt_render_public_report(string $token): void {
    $row = KT_DB::get_row(
        "SELECT * FROM " . KT_DB::reports_table() . " WHERE token=%s LIMIT 1",
        [$token]
    );

    if (!$row) { kt_report_404('التقرير غير موجود'); return; }

    $exp = strtotime($row->expires_at ?? '');
    if ($exp && $exp < time()) { kt_report_404('انتهت صلاحية هذا التقرير'); return; }

    // Increment view count
    KT_DB::update(KT_DB::reports_table(), ['view_count' => $row->view_count + 1], ['id' => $row->id]);

    $data = json_decode($row->data_json, true);
    if (!$data) { kt_report_404('خطأ في البيانات'); return; }

    $s     = $data['summary'] ?? [];
    $pages = $data['top_pages']  ?? [];
    $cities= $data['top_cities'] ?? [];
    $byDay = $data['by_day']     ?? [];
    $byType= $data['by_type']    ?? [];
    $byDev = $data['by_device']  ?? [];
    $days  = (int)($data['days'] ?? 30);
    $title = esc_html($data['title'] ?? 'تقرير KAYAN Tracking');
    $gen   = esc_html($data['generated'] ?? '');
    $total = (int)($s['conversions'] ?? 0);
    $calls = (int)($s['calls'] ?? 0);
    $waps  = (int)($s['whatsapps'] ?? 0);
    $vis   = (int)($s['visitors'] ?? 0);

    $conv_rate = $vis > 0 ? round($total / $vis * 100, 1) : 0;

    ?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $title; ?> — KAYAN Tracking</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;600;700;800;900&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
  --ink:#0A0F1E;--ink2:#111827;--ink3:#1F2937;
  --blue:#3B82F6;--blue2:#2563EB;--cyan:#06B6D4;
  --gold:#F59E0B;--gold2:#FBBF24;
  --green:#10B981;--wa:#25D366;
  --red:#EF4444;--pur:#8B5CF6;
  --white:#F9FAFB;--gray:#9CA3AF;
  --bd:rgba(255,255,255,.07);
  --gl:rgba(255,255,255,.04);
  --f:'Tajawal',sans-serif;--mono:'Space Mono',monospace;
  --r:14px;--r2:10px;
}
html{scroll-behavior:smooth}
body{font-family:var(--f);background:var(--ink);color:var(--white);
     -webkit-font-smoothing:antialiased;min-height:100vh;overflow-x:hidden}
/* BG dots */
body::before{content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background-image:radial-gradient(rgba(255,255,255,.035) 1px,transparent 1px);
  background-size:32px 32px}

/* ── Layout ─── */
.wrap{max-width:1100px;margin:0 auto;padding:2rem 1.25rem 5rem;position:relative;z-index:1}

/* ── Header ─── */
.rpt-header{
  display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1.25rem;
  padding:1.5rem 2rem;
  background:linear-gradient(135deg,var(--ink2),var(--ink3));
  border:1px solid var(--bd);border-radius:var(--r);
  margin-bottom:2rem;
  box-shadow:0 8px 40px rgba(0,0,0,.4);
}
.rpt-brand{display:flex;align-items:center;gap:.85rem}
.rpt-hex{width:46px;height:46px;background:linear-gradient(135deg,var(--blue),var(--cyan));
  border-radius:12px;display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:1.1rem}
.rpt-brand-name{font-weight:900;font-size:1.1rem;color:var(--white);letter-spacing:-.01em}
.rpt-brand-by{font-family:var(--mono);font-size:.6rem;color:var(--gray);letter-spacing:.15em;margin-top:.1rem}
.rpt-title-block{text-align:left}
.rpt-title{font-size:clamp(1rem,3vw,1.4rem);font-weight:800;color:var(--white);margin-bottom:.2rem}
.rpt-meta{font-family:var(--mono);font-size:.65rem;color:var(--gray);display:flex;align-items:center;gap:.75rem;flex-wrap:wrap}
.rpt-period{background:rgba(59,130,246,.15);color:var(--blue);border:1px solid rgba(59,130,246,.3);
  padding:.15rem .6rem;border-radius:100px;font-size:.62rem}

/* ── Stat cards ─── */
.stat-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:1rem;margin-bottom:2rem}
.sc{
  background:var(--gl);border:1px solid var(--bd);border-radius:var(--r2);padding:1.25rem 1rem;
  position:relative;overflow:hidden;transition:transform .25s,box-shadow .25s;
}
.sc:hover{transform:translateY(-4px);box-shadow:0 12px 40px rgba(0,0,0,.35)}
.sc::before{content:'';position:absolute;top:0;right:0;width:3px;height:100%;border-radius:0 var(--r2) var(--r2) 0}
.sc-blue::before {background:var(--blue)}
.sc-green::before{background:var(--green)}
.sc-wa::before   {background:var(--wa)}
.sc-gold::before {background:var(--gold)}
.sc-pur::before  {background:var(--pur)}
.sc-icon{font-size:1.4rem;margin-bottom:.5rem}
.sc-blue .sc-icon {color:var(--blue)}.sc-green .sc-icon{color:var(--green)}
.sc-wa .sc-icon  {color:var(--wa)}.sc-gold .sc-icon {color:var(--gold)}.sc-pur .sc-icon{color:var(--pur)}
.sc-val{font-family:var(--mono);font-size:2rem;font-weight:700;color:var(--white);line-height:1;margin-bottom:.2rem}
.sc-lbl{font-size:.73rem;color:var(--gray)}

/* ── Charts row ─── */
.charts-row{display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:2rem}
@media(max-width:680px){.charts-row{grid-template-columns:1fr}}
.chart-box{background:var(--gl);border:1px solid var(--bd);border-radius:var(--r2);padding:1.25rem}
.chart-head{font-weight:700;font-size:.85rem;color:var(--gray);margin-bottom:1rem;
  display:flex;align-items:center;gap:.4rem;padding-bottom:.75rem;border-bottom:1px solid var(--bd)}
.chart-head i{color:var(--blue)}

/* ── Lists ─── */
.list-row{display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:2rem}
@media(max-width:680px){.list-row{grid-template-columns:1fr}}
.list-box{background:var(--gl);border:1px solid var(--bd);border-radius:var(--r2);padding:1.25rem}
.list-head{font-weight:700;font-size:.85rem;color:var(--gray);margin-bottom:1rem;
  display:flex;align-items:center;gap:.4rem;padding-bottom:.75rem;border-bottom:1px solid var(--bd)}
.list-item{display:flex;align-items:center;gap:.65rem;padding:.55rem 0;border-top:1px solid var(--bd)}
.list-item:first-of-type{border-top:none}
.li-rank{width:22px;height:22px;background:linear-gradient(135deg,var(--blue),var(--cyan));
  border-radius:50%;font-size:.68rem;font-weight:800;color:#fff;
  display:flex;align-items:center;justify-content:center;flex-shrink:0}
.li-info{flex:1;min-width:0}
.li-title{font-size:.82rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.li-url{font-family:var(--mono);font-size:.64rem;color:var(--gray);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.li-cnt{font-family:var(--mono);font-size:.8rem;font-weight:700;color:var(--blue);white-space:nowrap}
.city-bar{display:flex;align-items:center;gap:.6rem;padding:.4rem 0;border-top:1px solid var(--bd)}
.city-bar:first-of-type{border-top:none}
.city-name{font-size:.8rem;font-weight:600;width:90px;flex-shrink:0}
.city-track{flex:1;height:6px;background:rgba(255,255,255,.07);border-radius:3px;overflow:hidden}
.city-fill{height:100%;border-radius:3px;background:linear-gradient(90deg,var(--blue),var(--cyan))}
.city-cnt{font-family:var(--mono);font-size:.7rem;color:var(--gray);width:30px;text-align:left;flex-shrink:0}

/* ── Watermark / footer ─── */
.rpt-footer{text-align:center;padding:2.5rem 1rem;margin-top:2rem;border-top:1px solid var(--bd)}
.rpt-footer-logo{font-family:var(--mono);font-weight:700;font-size:.85rem;color:var(--gold);letter-spacing:.2em;margin-bottom:.3rem}
.rpt-footer-sub{font-size:.75rem;color:var(--gray)}
.rpt-views{display:inline-flex;align-items:center;gap:.4rem;font-family:var(--mono);font-size:.68rem;
  color:var(--gray);background:var(--gl);border:1px solid var(--bd);
  padding:.25rem .75rem;border-radius:100px;margin-top:.75rem}

@media(max-width:520px){
  .stat-row{grid-template-columns:repeat(2,1fr)}
  .rpt-header{flex-direction:column}
}
</style>
</head>
<body>
<div class="wrap">

  <!-- Header -->
  <div class="rpt-header">
    <div class="rpt-brand">
      <div class="rpt-hex"><i class="fa fa-chart-line"></i></div>
      <div>
        <div class="rpt-brand-name">KAYAN Tracking</div>
        <div class="rpt-brand-by">by MAHMOUD ELSAAD</div>
      </div>
    </div>
    <div class="rpt-title-block">
      <div class="rpt-title"><?php echo $title; ?></div>
      <div class="rpt-meta">
        <span class="rpt-period"><i class="fa fa-calendar-days"></i> آخر <?php echo $days; ?> يوم</span>
        <span><i class="fa fa-clock"></i> <?php echo $gen; ?></span>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stat-row">
    <div class="sc sc-blue">
      <div class="sc-icon"><i class="fa fa-bullseye"></i></div>
      <div class="sc-val"><?php echo number_format($total); ?></div>
      <div class="sc-lbl">إجمالي التحويلات</div>
    </div>
    <div class="sc sc-green">
      <div class="sc-icon"><i class="fa fa-phone"></i></div>
      <div class="sc-val"><?php echo number_format($calls); ?></div>
      <div class="sc-lbl">اتصالات</div>
    </div>
    <div class="sc sc-wa">
      <div class="sc-icon"><i class="fab fa-whatsapp"></i></div>
      <div class="sc-val"><?php echo number_format($waps); ?></div>
      <div class="sc-lbl">واتساب</div>
    </div>
    <div class="sc sc-gold">
      <div class="sc-icon"><i class="fa fa-users"></i></div>
      <div class="sc-val"><?php echo number_format($vis); ?></div>
      <div class="sc-lbl">الزوار</div>
    </div>
    <div class="sc sc-pur">
      <div class="sc-icon"><i class="fa fa-percent"></i></div>
      <div class="sc-val"><?php echo $conv_rate; ?>%</div>
      <div class="sc-lbl">معدل التحويل</div>
    </div>
  </div>

  <!-- Charts row -->
  <div class="charts-row">
    <div class="chart-box">
      <div class="chart-head"><i class="fa fa-chart-line"></i> التحويلات اليومية</div>
      <canvas id="ch-day" height="180"></canvas>
    </div>
    <div class="chart-box">
      <div class="chart-head"><i class="fa fa-chart-pie"></i> واتساب vs اتصال</div>
      <canvas id="ch-type" height="180"></canvas>
    </div>
  </div>

  <!-- Devices + Pages -->
  <div class="charts-row">
    <div class="chart-box">
      <div class="chart-head"><i class="fa fa-mobile-screen"></i> الأجهزة</div>
      <canvas id="ch-dev" height="160"></canvas>
    </div>
    <div class="chart-box">
      <div class="chart-head"><i class="fa fa-globe"></i> المدن الأعلى أداءً</div>
      <?php
      $max_city = max(array_column($cities,'cnt') ?: [1]);
      foreach ($cities as $city):
        $w = round($city->cnt / $max_city * 100);
      ?>
        <div class="city-bar">
          <div class="city-name"><?php echo esc_html($city->city ?: '—'); ?></div>
          <div class="city-track"><div class="city-fill" style="width:<?php echo $w; ?>%"></div></div>
          <div class="city-cnt"><?php echo (int)$city->cnt; ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Top pages -->
  <?php if (!empty($pages)): ?>
  <div class="list-row">
    <div class="list-box">
      <div class="list-head"><i class="fa fa-trophy"></i> أكثر الصفحات تحويلاً</div>
      <?php foreach ($pages as $i => $pg): ?>
        <div class="list-item">
          <div class="li-rank"><?php echo $i+1; ?></div>
          <div class="li-info">
            <div class="li-title"><?php echo esc_html($pg->page_title ?: 'بدون عنوان'); ?></div>
            <div class="li-url"><?php echo esc_html(str_replace(['https://','http://'],'',$pg->page_url)); ?></div>
          </div>
          <div class="li-cnt"><?php echo (int)$pg->cnt; ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="list-box">
      <div class="list-head"><i class="fa fa-chart-bar"></i> التحويلات حسب النوع</div>
      <?php foreach ($byType as $bt):
        $icons = ['call'=>'fa-phone','whatsapp'=>'fab fa-whatsapp','form'=>'fa-envelope','cta'=>'fa-bullseye'];
        $colors= ['call'=>'#10B981','whatsapp'=>'#25D366','form'=>'#3B82F6','cta'=>'#F59E0B'];
        $ic    = $icons[$bt->click_type] ?? 'fa-bullseye';
        $cl    = $colors[$bt->click_type] ?? '#3B82F6';
        $pct   = $total > 0 ? round($bt->cnt / $total * 100) : 0;
      ?>
        <div class="list-item" style="align-items:center">
          <div style="width:30px;height:30px;border-radius:50%;background:<?php echo $cl; ?>22;
               display:flex;align-items:center;justify-content:center;flex-shrink:0">
            <i class="<?php echo $ic; ?>" style="color:<?php echo $cl; ?>;font-size:.85rem"></i>
          </div>
          <div class="li-info"><div class="li-title"><?php echo esc_html($bt->click_type); ?></div></div>
          <div style="font-family:var(--mono);font-size:.78rem;color:<?php echo $cl; ?>;font-weight:700"><?php echo $pct; ?>%</div>
          <div class="li-cnt"><?php echo (int)$bt->cnt; ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Footer -->
  <div class="rpt-footer">
    <div class="rpt-footer-logo">KAYAN TRACKING — POWERED BY KAYAN</div>
    <div class="rpt-footer-sub">by MAHMOUD ELSAAD · تم التوليد: <?php echo $gen; ?></div>
    <div class="rpt-views"><i class="fa fa-eye"></i> <?php echo (int)($row->view_count + 1); ?> مشاهدة</div>
  </div>

</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
(function(){
  var DAY_DATA  = <?php echo wp_json_encode(array_map(fn($r)=>['dt'=>$r->dt,'cnt'=>(int)$r->cnt], $byDay)); ?>;
  var TYPE_DATA = <?php echo wp_json_encode(array_map(fn($r)=>['t'=>$r->click_type,'c'=>(int)$r->cnt], $byType)); ?>;
  var DEV_DATA  = <?php echo wp_json_encode(array_map(fn($r)=>['t'=>$r->device_type,'c'=>(int)$r->cnt], $byDev)); ?>;
  var COLORS = {call:'#10B981',whatsapp:'#25D366',form:'#3B82F6',cta:'#F59E0B',
                mobile:'#3B82F6',desktop:'#8B5CF6',tablet:'#F59E0B'};
  var CHART_OPTS = {
    responsive:true,maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{grid:{color:'rgba(255,255,255,.04)'},ticks:{color:'#9CA3AF',font:{size:10}}},
      y:{grid:{color:'rgba(255,255,255,.04)'},ticks:{color:'#9CA3AF',font:{size:10}}}
    }
  };

  // Daily conversions
  if(document.getElementById('ch-day')&&DAY_DATA.length){
    new Chart(document.getElementById('ch-day'),{
      type:'bar',
      data:{labels:DAY_DATA.map(r=>r.dt),datasets:[{
        label:'تحويلات',data:DAY_DATA.map(r=>r.c||r.cnt||0),
        backgroundColor:'rgba(59,130,246,.4)',borderColor:'#3B82F6',borderWidth:1.5,borderRadius:4
      }]},
      options:CHART_OPTS
    });
  }

  // Type donut
  if(document.getElementById('ch-type')&&TYPE_DATA.length){
    new Chart(document.getElementById('ch-type'),{
      type:'doughnut',
      data:{labels:TYPE_DATA.map(r=>r.t),datasets:[{
        data:TYPE_DATA.map(r=>r.c),
        backgroundColor:TYPE_DATA.map(r=>COLORS[r.t]||'#6B7280'),
        borderWidth:0,hoverOffset:6
      }]},
      options:{responsive:true,maintainAspectRatio:false,cutout:'65%',
        plugins:{legend:{position:'bottom',labels:{color:'#9CA3AF',padding:12,font:{size:11}}}}}
    });
  }

  // Devices donut
  if(document.getElementById('ch-dev')&&DEV_DATA.length){
    new Chart(document.getElementById('ch-dev'),{
      type:'doughnut',
      data:{labels:DEV_DATA.map(r=>r.t),datasets:[{
        data:DEV_DATA.map(r=>r.c),
        backgroundColor:DEV_DATA.map(r=>COLORS[r.t]||'#6B7280'),
        borderWidth:0,hoverOffset:6
      }]},
      options:{responsive:true,maintainAspectRatio:false,cutout:'65%',
        plugins:{legend:{position:'bottom',labels:{color:'#9CA3AF',padding:10,font:{size:11}}}}}
    });
  }
}());
</script>
</body>
</html>
<?php
}

function kt_report_404(string $msg): void {
    status_header(404);
    ?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>KAYAN Tracking — <?php echo esc_html($msg); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@700;900&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Tajawal',sans-serif;background:#0A0F1E;color:#F9FAFB;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem}h1{font-size:4rem;color:#EF4444;margin-bottom:1rem}p{color:#9CA3AF;font-size:1.1rem}</style>
</head>
<body>
<h1>⚠</h1>
<p><?php echo esc_html($msg); ?></p>
</body>
</html>
<?php
}

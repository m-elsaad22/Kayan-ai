<?php
defined('ABSPATH') || exit;

/**
 * RSA_Admin — لوحة تحكم Rukn Smart AI
 * Author: Mahmoud Elsaad
 */
class RSA_Admin {

    private array $modules;

    public function __construct(array $modules) {
        $this->modules = $modules;
        add_action('admin_menu',            [$this, 'add_menu']);
        add_action('admin_init',            [$this, 'save_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('save_post',             [$this, 'save_seo_metabox'], 25, 2);

        // AJAX
        $ajax = [
            'rsa_test_gemini', 'rsa_test_claude',
            'rsa_gen_local_page', 'rsa_gen_bulk_cities',
            'rsa_run_analysis', 'rsa_fix_issue',
            'rsa_scan_all_links', 'rsa_quick_generate',
            'rsa_bulk_generate_single', 'rsa_bulk_publish_article',
            'rsa_bulk_export_csv',
        ];
        foreach ($ajax as $a) {
            add_action('wp_ajax_' . $a, [$this, 'handle_ajax']);
        }
    }

    /* ── Menu ─────────────────────────────────── */
    public function add_menu(): void {
        add_menu_page(
            'Rukn Smart AI', 'Rukn Smart AI', 'manage_options',
            'rukn-smart-ai', [$this, 'page_dashboard'],
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>'),
            3
        );

        $pages = [
            'rukn-dashboard'   => ['🏠 الرئيسية',         [$this, 'page_dashboard']],
            'rukn-bulk-writer'  => ['✍️ مولّد جماعي',        [$this, 'page_bulk_writer']],
            'rukn-ai'          => ['🤖 توليد AI',          [$this, 'page_ai']],
            'rukn-local-seo'   => ['📍 Local SEO',         [$this, 'page_local_seo']],
            'rukn-tracker'     => ['📊 تتبع الزيارات',     [$this, 'page_tracker']],
            'rukn-analyzer'    => ['🔍 محلل الموقع',       [$this, 'page_analyzer']],
            'rukn-linking'     => ['🔗 ربط داخلي',         [$this, 'page_linking']],
            'rukn-competitor'  => ['🕵️ منافسين',           [$this, 'page_competitor']],
            'rukn-offers'      => ['🎁 العروض',             [$this, 'page_offers']],
            'rukn-icons'       => ['🎨 أيقونات',           [$this, 'page_icons']],
            'rukn-settings'    => ['⚙️ الإعدادات',         [$this, 'page_settings']],
        ];

        foreach ($pages as $slug => [$title, $cb]) {
            add_submenu_page('rukn-smart-ai', $title, $title, 'manage_options', $slug, $cb);
        }
    }

    public function enqueue_assets(string $hook): void {
        if (!str_contains($hook, 'rukn')) return;
        wp_enqueue_style('dashicons');
        wp_enqueue_style('rsa-admin', RSA_URL . 'assets/css/admin.css', [], RSA_VERSION);
        wp_enqueue_style('rsa-fa', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css', [], '6.5.0');
        wp_enqueue_script('jquery');
        wp_enqueue_script('rsa-admin', RSA_URL . 'assets/js/admin.js', ['jquery'], RSA_VERSION, true);
        wp_localize_script('rsa-admin', 'RSA_Admin', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('rsa_admin'),
        ]);
    }

    /* ── Shared: Header ───────────────────────── */
    private function header(string $title, string $subtitle = '', string $icon = '🤖'): void {
        $ai        = RSA_AI::instance();
        $ready     = $ai->is_ready();
        $provider  = $ai->active_provider_name();
        ?>
        <div class="rsa-header">
            <div class="rsa-header-inner">
                <div class="rsa-header-brand">
                    <div class="rsa-header-logo"><?= $icon ?></div>
                    <div>
                        <h1><?= esc_html($title) ?> <span class="rsa-version-badge">v<?= RSA_VERSION ?></span></h1>
                        <?php if ($subtitle): ?><p><?= esc_html($subtitle) ?></p><?php endif; ?>
                        <p style="opacity:.7;font-size:11px;margin-top:2px">by Mahmoud Elsaad</p>
                    </div>
                </div>
                <div class="rsa-ai-status">
                    <span class="rsa-ai-dot <?= $ready ? '' : 'off' ?>"></span>
                    <?= $ready ? esc_html($provider) : 'AI غير متصل' ?>
                </div>
            </div>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════
       DASHBOARD
    ══════════════════════════════════════════ */
    public function page_dashboard(): void {
        $tracker = $this->modules['tracker'] ?? null;
        $stats   = $tracker ? $tracker->get_stats(30) : [];
        $score   = (int)(json_decode(get_option('rsa_last_analysis', '{}'), true)['score'] ?? 0);
        $ai      = RSA_AI::instance();
        ?>
        <div class="rsa-wrap">
        <?php $this->header('Rukn Smart AI', 'نظام الذكاء الاصطناعي المتكامل لتصدر Google وتحويل الزوار لعملاء'); ?>

        <?php if (!$ai->is_ready()): ?>
        <div class="rsa-notice">
            <span class="rsa-notice-icon">⚠️</span>
            <div>
                <strong>يلزم مفتاح Gemini للعمل</strong> — احصل على مفتاحك المجاني في دقيقة واحدة:<br>
                <small style="color:#1a6b3a;font-weight:600">
                    1. افتح <a href="https://aistudio.google.com/app/apikey" target="_blank">aistudio.google.com/app/apikey</a>
                    &nbsp;→&nbsp; 2. اضغط "Create API Key" &nbsp;→&nbsp; 3. انسخه واحفظه في
                    <a href="<?= admin_url('admin.php?page=rukn-settings') ?>">الإعدادات</a>
                </small><br>
                <small style="color:#64748b">✅ مجاني 100% — 1500 طلب/يوم — لا يحتاج بطاقة بنكية</small>
            </div>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="rsa-stats-grid">
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#eff6ff"><i class="fas fa-users" style="color:#3b82f6"></i></div>
                <div class="rsa-stat-value"><?= number_format($stats['total_visits'] ?? 0) ?></div>
                <div class="rsa-stat-label">زيارة (30 يوم)</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#fef2f2"><i class="fas fa-fire" style="color:#ef4444"></i></div>
                <div class="rsa-stat-value"><?= number_format($stats['buying_intent'] ?? 0) ?></div>
                <div class="rsa-stat-label">نية شراء</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#f0fdf4"><i class="fas fa-chart-line" style="color:#22c55e"></i></div>
                <div class="rsa-stat-value"><?= round($stats['avg_scroll'] ?? 0) ?>%</div>
                <div class="rsa-stat-label">متوسط التمرير</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#fffbeb"><i class="fas fa-gauge" style="color:#f59e0b"></i></div>
                <div class="rsa-stat-value"><?= $score ?: '—' ?></div>
                <div class="rsa-stat-label">نقاط SEO</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="rsa-section">
            <h2>⚡ إجراءات سريعة</h2>
            <div class="rsa-actions-grid">
                <a href="<?= admin_url('admin.php?page=rukn-bulk-writer') ?>" class="rsa-btn rsa-btn-primary">
                    <i class="fas fa-magic"></i> مولّد جماعي
                </a>
                <a href="<?= admin_url('admin.php?page=rukn-ai') ?>" class="rsa-btn rsa-btn-primary">
                    <i class="fas fa-brain"></i> توليد AI سريع
                </a>
                <a href="<?= admin_url('admin.php?page=rukn-local-seo') ?>" class="rsa-btn rsa-btn-green">
                    <i class="fas fa-map-marker-alt"></i> Local SEO
                </a>
                <a href="<?= admin_url('admin.php?page=rukn-tracker') ?>" class="rsa-btn rsa-btn-blue">
                    <i class="fas fa-chart-bar"></i> تقرير الزيارات
                </a>
                <button class="rsa-btn rsa-btn-orange" onclick="rsaAjax('rsa_run_analysis',{},'rsa-dash-result','تحليل الموقع...')">
                    <i class="fas fa-search"></i> تحليل الموقع
                </button>
                <a href="<?= admin_url('admin.php?page=rukn-settings') ?>" class="rsa-btn rsa-btn-gray">
                    <i class="fas fa-cog"></i> الإعدادات
                </a>
            </div>
            <div id="rsa-dash-result" style="margin-top:14px"></div>
        </div>

        <!-- Modules -->
        <div class="rsa-section">
            <h2>🧩 حالة الوحدات</h2>
            <div class="rsa-modules-grid">
            <?php
            $all_modules = [
                'local_seo'  => ['📍 Local SEO Generator',  'توليد صفحات مدن وأحياء تلقائياً'],
                'seo_engine' => ['🧠 AI SEO Engine',        'Meta + FAQ + LSI تلقائي بـ AI'],
                'schema'     => ['📋 Schema Factory',        'LocalBusiness + FAQ + Review'],
                'conversion' => ['🎯 Conversion Engine',     'Popup + CTA ذكي + Sticky Bar'],
                'tracker'    => ['📊 Visitor Tracker',       'تتبع كامل للزيارات والسلوك'],
                'linking'    => ['🔗 Internal Linking',      'ربط داخلي AI تلقائي'],
                'auto_slug'  => ['🔤 Auto Slug',             'تحويل العناوين العربية لـ URL'],
                'image_gen'  => ['🖼️ Image Gen',             'صورة بارزة تلقائية من المكتبة'],
                'icons'      => ['🎨 Icons Library',         'أيقونات Font Awesome للخدمات'],
                'analyzer'   => ['🔍 Site Analyzer',         'تحليل شامل وتقارير تحسين'],
                'bulk_writer'=> ['✍️ Bulk Article Writer',   'توليد مقالات SEO جماعي بالذكاء الاصطناعي'],
            ];
            $enabled = get_option('rsa_enabled_modules', []);
            foreach ($all_modules as $key => [$name, $desc]):
                $on = !empty($enabled[$key]);
            ?>
            <div class="rsa-module-card <?= $on ? 'active' : 'inactive' ?>">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px">
                    <strong style="font-size:13px"><?= $name ?></strong>
                    <span class="rsa-badge <?= $on ? 'rsa-badge-green' : 'rsa-badge-gray' ?>"><?= $on ? 'مفعّل' : 'معطّل' ?></span>
                </div>
                <p style="font-size:11px;color:var(--rsa-text-soft);margin:0"><?= esc_html($desc) ?></p>
            </div>
            <?php endforeach; ?>
            </div>
        </div>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════
       AI GENERATOR PAGE
    ══════════════════════════════════════════ */
    public function page_ai(): void {
        $ai = RSA_AI::instance();
        ?>
        <div class="rsa-wrap">
        <?php $this->header('توليد محتوى AI', 'توليد تلقائي بـ ' . $ai->active_provider_name(), '🤖'); ?>

        <?php if (!$ai->is_ready()): ?>
        <div class="rsa-error" style="margin-bottom:20px">
            ❌ يلزم مفتاح Gemini — احصل عليه مجاناً من
            <a href="https://aistudio.google.com/app/apikey" target="_blank">aistudio.google.com</a>
            ثم أضفه في <a href="<?= admin_url('admin.php?page=rukn-settings') ?>">الإعدادات</a>
        </div>
        <?php endif; ?>

        <div class="rsa-section">
            <h2>⚡ توليد سريع بـ AI</h2>
            <div class="rsa-form-grid">
                <div>
                    <label>الكلمة المفتاحية</label>
                    <input type="text" id="rsa-quick-keyword" class="rsa-input" placeholder="مثال: تنظيف منازل دبي">
                </div>
            </div>
            <div class="rsa-actions-grid" style="margin-bottom:16px">
                <button class="rsa-btn rsa-btn-primary" onclick="rsaQuickGenerate('seo')">
                    <i class="fas fa-brain"></i> توليد Meta SEO كامل
                </button>
                <button class="rsa-btn rsa-btn-green" onclick="rsaQuickGenerate('article')">
                    <i class="fas fa-file-alt"></i> توليد مقال
                </button>
                <button class="rsa-btn rsa-btn-purple" onclick="rsaQuickGenerate('faq')">
                    <i class="fas fa-question-circle"></i> توليد FAQ
                </button>
                <button class="rsa-btn rsa-btn-orange" onclick="rsaQuickGenerate('schema')">
                    <i class="fas fa-code"></i> توليد Schema
                </button>
            </div>
            <div class="rsa-ai-box">
                <div class="rsa-ai-box-header">
                    <span>🤖</span> نتيجة الذكاء الاصطناعي — <?= esc_html($ai->active_provider_name()) ?>
                </div>
                <div id="rsa-quick-result" class="rsa-ai-response" style="min-height:100px;color:var(--rsa-text-soft);font-style:italic">
                    أدخل كلمة مفتاحية واضغط على نوع المحتوى لتوليده...
                </div>
            </div>
        </div>

        <div class="rsa-section">
            <h2>📊 إحصائيات AI</h2>
            <?php
            $db   = RSA_DB::instance();
            $logs = $db->get('logs', [], 'id DESC', 10);
            if ($logs):
            ?>
            <div class="rsa-table-wrap">
            <table class="rsa-table">
                <thead><tr><th>الوحدة</th><th>الإجراء</th><th>المزوّد</th><th>الحالة</th><th>التاريخ</th></tr></thead>
                <tbody>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= esc_html($log['module']) ?></td>
                    <td><?= esc_html($log['action']) ?></td>
                    <td><span class="rsa-badge rsa-badge-blue"><?= esc_html($log['provider'] ?? 'gemini') ?></span></td>
                    <td><span class="rsa-badge <?= $log['status'] === 'ok' ? 'rsa-badge-green' : 'rsa-badge-red' ?>"><?= esc_html($log['status']) ?></span></td>
                    <td><?= esc_html(substr($log['created_at'], 0, 16)) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php else: ?><p style="color:var(--rsa-text-soft)">لا توجد سجلات AI بعد</p><?php endif; ?>
        </div>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════
       LOCAL SEO
    ══════════════════════════════════════════ */
    public function page_local_seo(): void {
        $country = get_option('rsa_default_country', 'ae');
        $cities  = RSA_Local_SEO::$CITIES[$country] ?? [];
        ?>
        <div class="rsa-wrap">
        <?php $this->header('Local SEO Generator', 'توليد صفحات مدن وأحياء تلقائياً بمحتوى AI', '📍'); ?>

        <div class="rsa-section">
            <h2>توليد صفحة مدينة</h2>
            <div class="rsa-form-grid">
                <div>
                    <label>الخدمة</label>
                    <input type="text" id="rsa-service" placeholder="مثال: تنظيف منازل" class="rsa-input">
                </div>
                <div>
                    <label>المدينة</label>
                    <select id="rsa-city" class="rsa-input">
                        <?php foreach ($cities as $key => $c): ?>
                        <option value="<?= esc_attr($key) ?>"><?= esc_html($c['name_ar']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <button class="rsa-btn rsa-btn-primary" onclick="rsaGenLocalPage()">
                <i class="fas fa-magic"></i> توليد بـ AI
            </button>
            <div id="rsa-local-result" style="margin-top:14px"></div>
        </div>

        <div class="rsa-section">
            <h2>🚀 توليد جميع المدن دفعة واحدة</h2>
            <div class="rsa-warning-box" style="margin-bottom:14px">
                ⚠️ سيتم إنشاء <?= count($cities) ?> صفحة — قد يستغرق بضع دقائق
            </div>
            <div class="rsa-form-grid">
                <div>
                    <label>الخدمة</label>
                    <input type="text" id="rsa-bulk-service" placeholder="الخدمة" class="rsa-input">
                </div>
            </div>
            <button class="rsa-btn rsa-btn-green" onclick="rsaGenBulkCities()">
                <i class="fas fa-layer-group"></i> توليد كل المدن
            </button>
            <div id="rsa-bulk-result" style="margin-top:14px"></div>
        </div>

        <div class="rsa-section">
            <h2>📋 صفحات المدن المنشأة</h2>
            <?php
            $db    = RSA_DB::instance();
            $pages = $db->get('local_pages', [], 'id DESC', 50);
            if ($pages):
            ?>
            <div class="rsa-table-wrap">
            <table class="rsa-table">
                <thead><tr><th>المدينة</th><th>الخدمة</th><th>الرابط</th><th>التاريخ</th></tr></thead>
                <tbody>
                <?php foreach ($pages as $p): ?>
                <tr>
                    <td><?= esc_html($p['city']) ?></td>
                    <td><?= esc_html($p['service']) ?></td>
                    <td><?php if ($p['post_id']): ?><a href="<?= esc_url(get_permalink($p['post_id'])) ?>" target="_blank" class="rsa-btn rsa-btn-outline rsa-btn-sm">عرض</a><?php endif; ?></td>
                    <td><?= esc_html(substr($p['created_at'], 0, 10)) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php else: ?><p style="color:var(--rsa-text-soft)">لا توجد صفحات مدن بعد</p><?php endif; ?>
        </div>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════
       TRACKER
    ══════════════════════════════════════════ */
    public function page_tracker(): void {
        $tracker = $this->modules['tracker'] ?? null;
        $stats   = $tracker ? $tracker->get_stats(30) : [];
        $recent  = $tracker ? $tracker->get_recent(20) : [];
        ?>
        <div class="rsa-wrap">
        <?php $this->header('تتبع وتحليل الزيارات', 'آخر 30 يوم — بيانات مفصلة', '📊'); ?>

        <div class="rsa-stats-grid">
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#eff6ff"><i class="fas fa-users" style="color:#3b82f6"></i></div>
                <div class="rsa-stat-value"><?= number_format($stats['total_visits'] ?? 0) ?></div>
                <div class="rsa-stat-label">إجمالي الزيارات</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#f0fdf4"><i class="fas fa-user-check" style="color:#22c55e"></i></div>
                <div class="rsa-stat-value"><?= number_format($stats['unique_sessions'] ?? 0) ?></div>
                <div class="rsa-stat-label">جلسات فريدة</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#fffbeb"><i class="fas fa-scroll" style="color:#f59e0b"></i></div>
                <div class="rsa-stat-value"><?= round($stats['avg_scroll'] ?? 0) ?>%</div>
                <div class="rsa-stat-label">متوسط التمرير</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#faf5ff"><i class="fas fa-clock" style="color:#8b5cf6"></i></div>
                <div class="rsa-stat-value"><?= round($stats['avg_time'] ?? 0) ?>ث</div>
                <div class="rsa-stat-label">وقت الجلسة</div>
            </div>
            <div class="rsa-stat-card">
                <div class="rsa-stat-icon" style="background:#fef2f2"><i class="fas fa-fire" style="color:#ef4444"></i></div>
                <div class="rsa-stat-value"><?= number_format($stats['buying_intent'] ?? 0) ?></div>
                <div class="rsa-stat-label">نية شراء</div>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:20px;margin-bottom:20px">
            <div class="rsa-section" style="margin:0">
                <h2>🏙️ أكثر المدن زيارة</h2>
                <?php foreach (($stats['top_cities'] ?? []) as $i => $c): ?>
                <div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--rsa-border)">
                    <span><?= ($i + 1) ?>. <?= esc_html($c['city'] ?: 'غير معروف') ?></span>
                    <span class="rsa-badge rsa-badge-blue"><?= number_format($c['cnt']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="rsa-section" style="margin:0">
                <h2>📱 الأجهزة</h2>
                <?php foreach (($stats['by_device'] ?? []) as $d): ?>
                <div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--rsa-border)">
                    <span><?= esc_html($d['device']) ?></span>
                    <span class="rsa-badge rsa-badge-green"><?= number_format($d['cnt']) ?></span>
                </div>
                <?php endforeach; ?>

                <h3>🎯 نية الزيارة</h3>
                <?php foreach (($stats['by_intent'] ?? []) as $intent): ?>
                <div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--rsa-border)">
                    <span><?= esc_html($intent['intent'] ?: 'unknown') ?></span>
                    <span class="rsa-badge <?= $intent['intent'] === 'buying' ? 'rsa-badge-red' : 'rsa-badge-gray' ?>"><?= number_format($intent['cnt']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="rsa-section">
            <h2>🕐 آخر الزيارات</h2>
            <div class="rsa-table-wrap">
            <table class="rsa-table">
                <thead><tr><th>المدينة</th><th>الجهاز</th><th>التمرير</th><th>الوقت</th><th>النية</th><th>المصدر</th><th>التاريخ</th></tr></thead>
                <tbody>
                <?php foreach ($recent as $v): ?>
                <tr>
                    <td><?= esc_html($v['city'] ?: '—') ?></td>
                    <td><?= esc_html($v['device'] ?: '—') ?></td>
                    <td>
                        <div class="rsa-progress" style="width:60px">
                            <div class="rsa-progress-bar" style="width:<?= $v['scroll_pct'] ?>%"></div>
                        </div>
                        <small><?= $v['scroll_pct'] ?>%</small>
                    </td>
                    <td><?= $v['time_sec'] ?>ث</td>
                    <td><span class="rsa-badge <?= $v['intent'] === 'buying' ? 'rsa-badge-red' : 'rsa-badge-gray' ?>"><?= esc_html($v['intent'] ?: '—') ?></span></td>
                    <td><?= esc_html($v['utm_source'] ?: 'organic') ?></td>
                    <td style="white-space:nowrap"><?= esc_html(substr($v['created_at'], 5, 11)) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        </div>
        <?php
    }

    /* ══════════════════════════════════════════
       ANALYZER
    ══════════════════════════════════════════ */
    public function page_analyzer(): void {
        $last_report = json_decode(get_option('rsa_last_analysis', '{}'), true);
        ?>
        <div class="rsa-wrap">
        <?php $this->header('محلل الموقع الكامل', 'أخطاء + مشاكل + اقتراحات AI + حلول بضغطة واحدة', '🔍'); ?>

        <div class="rsa-section">
            <div class="rsa-actions-grid">
                <button class="rsa-btn rsa-btn-primary" onclick="rsaRunAnalysis()">
                    <i class="fas fa-search"></i> تشغيل التحليل الكامل
                </button>
                <?php if (!empty($last_report['timestamp'])): ?>
                <span style="color:var(--rsa-text-soft);font-size:13px;align-self:center">
                    آخر تحليل: <?= esc_html($last_report['timestamp']) ?> — النتيجة:
                    <strong><?= $last_report['score'] ?? '—' ?>/100</strong>
                </span>
                <?php endif; ?>
            </div>
            <div id="rsa-analysis-output" style="margin-top:20px">
                <?php if (!empty($last_report['posts'])): ?>
                    <?php $this->render_analysis_report($last_report); ?>
                <?php endif; ?>
            </div>
        </div>
        </div>
        <?php
    }

    private function render_analysis_report(array $report): void {
        $score = $report['score'] ?? 0;
        $cls   = $score >= 80 ? 'rsa-score-high' : ($score >= 60 ? 'rsa-score-mid' : 'rsa-score-low');
        echo '<div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;background:var(--rsa-bg);border-radius:12px;padding:20px;margin-bottom:20px">';
        echo '<div class="rsa-score-ring ' . $cls . '">' . $score . '</div>';
        echo '<div><h3 style="margin:0">نتيجة SEO الموقع</h3><p style="color:var(--rsa-text-soft);margin:5px 0 0">بناءً على ' . count($report['posts']) . ' مقال/صفحة</p></div>';
        echo '</div>';

        if (!empty($report['site_issues'])) {
            echo '<h3>⚠️ مشاكل الموقع</h3>';
            foreach ($report['site_issues'] as $issue) {
                $color = $issue['severity'] === 'high' ? 'var(--rsa-danger)' : ($issue['severity'] === 'warning' ? 'var(--rsa-warning)' : 'var(--rsa-primary)');
                echo '<div style="border-right:4px solid ' . $color . ';padding:10px 15px;margin-bottom:8px;background:#fff;border-radius:8px;border:1px solid var(--rsa-border)">' . esc_html($issue['msg']) . '</div>';
            }
        }

        if (!empty($report['opportunities'])) {
            echo '<h3>🚀 فرص التحسين (AI)</h3>';
            foreach ($report['opportunities'] as $opp) {
                $color = $opp['priority'] === 'high' ? 'var(--rsa-danger)' : ($opp['priority'] === 'medium' ? 'var(--rsa-warning)' : 'var(--rsa-success)');
                echo '<div style="border:1px solid var(--rsa-border);padding:12px;border-radius:8px;margin-bottom:8px;border-right:4px solid ' . $color . '">';
                echo '<strong>' . esc_html($opp['action'] ?? '') . '</strong>';
                echo '<span style="float:left;font-size:12px;color:var(--rsa-text-soft)">' . esc_html($opp['impact'] ?? '') . '</span>';
                echo '</div>';
            }
        }

        echo '<h3>📄 تقييم المقالات</h3>';
        echo '<div class="rsa-table-wrap"><table class="rsa-table"><thead><tr><th>الصفحة</th><th>الكلمات</th><th>النتيجة</th><th>المشاكل</th><th>إصلاح</th></tr></thead><tbody>';
        usort($report['posts'], fn($a, $b) => $a['score'] - $b['score']);
        foreach ($report['posts'] as $p) {
            $sc  = $p['score'];
            $cls = $sc >= 80 ? 'rsa-badge-green' : ($sc >= 60 ? 'rsa-badge-orange' : 'rsa-badge-red');
            echo '<tr>';
            echo '<td><a href="' . esc_url($p['edit_url']) . '" target="_blank">' . esc_html(mb_substr($p['title'], 0, 40)) . '</a></td>';
            echo '<td>' . number_format($p['word_count']) . '</td>';
            echo '<td><span class="rsa-badge ' . $cls . '">' . $sc . '</span></td>';
            echo '<td>' . count($p['issues']) . ' مشكلة</td>';
            echo '<td style="display:flex;gap:4px;flex-wrap:wrap">';
            foreach ($p['issues'] as $issue) {
                if (!empty($issue['fix'])) {
                    echo '<button onclick="rsaFixIssue(\'' . esc_js($issue['fix']) . '\',' . $p['post_id'] . ',this)" class="rsa-btn rsa-btn-primary rsa-btn-sm">' . esc_html($issue['fix']) . '</button>';
                }
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    /* ══════════════════════════════════════════
       LINKING
    ══════════════════════════════════════════ */
    public function page_linking(): void { ?>
        <div class="rsa-wrap">
        <?php $this->header('الربط الداخلي الذكي', 'ربط تلقائي بـ AI', '🔗'); ?>
        <div class="rsa-section">
            <h2>مسح جميع المقالات وإضافة روابط داخلية</h2>
            <button class="rsa-btn rsa-btn-primary" onclick="rsaScanAllLinks()">
                <i class="fas fa-link"></i> مسح وربط كل المقالات
            </button>
            <div id="rsa-linking-result" style="margin-top:14px"></div>
        </div>
        <div class="rsa-section">
            <h2>روابط خارجية معتمدة</h2>
            <p style="color:var(--rsa-text-soft);font-size:13px">أضف روابط خارجية يتم حقنها تلقائياً في المحتوى</p>
            <?php $external = get_option('rsa_external_links', []); ?>
            <form method="post">
                <?php wp_nonce_field('rsa_save_external_links'); ?>
                <textarea name="rsa_external_links_json" rows="8" style="width:100%;font-family:monospace;font-size:13px;padding:12px;border:1.5px solid var(--rsa-border);border-radius:8px"><?= esc_textarea(wp_json_encode($external, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) ?></textarea>
                <p style="font-size:12px;color:var(--rsa-text-soft)">مثال: [{"anchor":"تنظيف منازل دبي","url":"https://example.com/page"}]</p>
                <button type="submit" name="save_external_links" class="rsa-btn rsa-btn-primary">💾 حفظ</button>
            </form>
        </div>
        </div>
    <?php }

    /* ══════════════════════════════════════════
       SETTINGS
    ══════════════════════════════════════════ */
    public function page_settings(): void {
        $provider = get_option('rsa_ai_provider', 'auto');
        ?>
        <div class="rsa-wrap">
        <?php $this->header('الإعدادات', 'إعداد Rukn Smart AI', '⚙️'); ?>

        <form method="post">
        <?php wp_nonce_field('rsa_save_settings', 'rsa_settings_nonce'); ?>
        <input type="hidden" name="rsa_save" value="1">
        <input type="hidden" name="rsa_ai_provider" value="<?= esc_attr($provider) ?>" id="rsa-provider-val">

        <!-- AI Provider -->
        <div class="rsa-section">
            <h2>🤖 مزوّد الذكاء الاصطناعي</h2>
            <div class="rsa-provider-grid">
                <div class="rsa-provider-card <?= $provider === 'auto' ? 'selected' : '' ?>" data-value="auto" onclick="selectProvider(this)">
                    <div class="icon">🔄</div>
                    <strong>تلقائي (Auto)</strong>
                    <small>يستخدم Gemini أولاً، ثم Claude إذا لم يتوفر</small>
                </div>
                <div class="rsa-provider-card <?= $provider === 'gemini' ? 'selected' : '' ?>" data-value="gemini" onclick="selectProvider(this)">
                    <div class="icon">🌟</div>
                    <strong>Google Gemini</strong>
                    <small>مجاني 100% — الأسرع والأفضل للعربية</small>
                </div>
                <div class="rsa-provider-card <?= $provider === 'claude' ? 'selected' : '' ?>" data-value="claude" onclick="selectProvider(this)">
                    <div class="icon">🧠</div>
                    <strong>Anthropic Claude</strong>
                    <small>الأكثر دقة — يتطلب اشتراكاً</small>
                </div>
            </div>
        </div>

        <!-- API Keys -->
        <div class="rsa-section">
            <h2>🔑 مفاتيح API</h2>
            <div class="rsa-form-grid">
                <div>
                    <label>
                        🌟 Gemini API Key
                        <span class="rsa-badge rsa-badge-green" style="margin-right:8px">مجاني</span>
                    </label>
                    <div style="display:flex;gap:8px">
                        <input type="password" name="rsa_gemini_api_key" value="<?= esc_attr(get_option('rsa_gemini_api_key')) ?>" class="rsa-input" placeholder="AIza...">
                        <button type="button" class="rsa-show-pass rsa-btn rsa-btn-gray rsa-btn-sm" style="flex-shrink:0">👁</button>
                    </div>
                    <small>من <a href="https://makersuite.google.com/app/apikey" target="_blank">Google AI Studio</a> — مجاني تماماً</small>
                    <div style="margin-top:8px;display:flex;gap:8px;align-items:center">
                        <button type="button" id="rsa-test-gemini" class="rsa-btn rsa-btn-green rsa-btn-sm">اختبار الاتصال</button>
                        <div id="rsa-gemini-test-result" style="font-size:13px"></div>
                    </div>
                </div>
                <div>
                    <label>🧠 Claude API Key <small style="color:var(--rsa-text-soft)">(اختياري)</small></label>
                    <div style="display:flex;gap:8px">
                        <input type="password" name="rsa_claude_api_key" value="<?= esc_attr(get_option('rsa_claude_api_key')) ?>" class="rsa-input" placeholder="sk-ant-...">
                        <button type="button" class="rsa-show-pass rsa-btn rsa-btn-gray rsa-btn-sm" style="flex-shrink:0">👁</button>
                    </div>
                    <small>من <a href="https://console.anthropic.com" target="_blank">console.anthropic.com</a></small>
                    <div style="margin-top:8px;display:flex;gap:8px;align-items:center">
                        <button type="button" id="rsa-test-claude" class="rsa-btn rsa-btn-blue rsa-btn-sm">اختبار الاتصال</button>
                        <div id="rsa-claude-test-result" style="font-size:13px"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Company Info -->
        <div class="rsa-section">
            <h2>🏢 معلومات الشركة</h2>
            <div class="rsa-form-grid">
                <div><label>اسم الشركة</label><input type="text" name="rsa_company_name" value="<?= esc_attr(get_option('rsa_company_name')) ?>" class="rsa-input"></div>
                <div><label>رقم الهاتف</label><input type="text" name="rsa_phone_number" value="<?= esc_attr(get_option('rsa_phone_number')) ?>" class="rsa-input" placeholder="+97150..."></div>
                <div><label>رقم واتساب</label><input type="text" name="rsa_whatsapp_number" value="<?= esc_attr(get_option('rsa_whatsapp_number')) ?>" class="rsa-input" placeholder="97150..."></div>
                <div>
                    <label>الدولة الافتراضية</label>
                    <select name="rsa_default_country" class="rsa-input">
                        <option value="ae" <?= selected(get_option('rsa_default_country'), 'ae', false) ?>>الإمارات 🇦🇪</option>
                        <option value="sa" <?= selected(get_option('rsa_default_country'), 'sa', false) ?>>السعودية 🇸🇦</option>
                        <option value="qa" <?= selected(get_option('rsa_default_country'), 'qa', false) ?>>قطر 🇶🇦</option>
                        <option value="eg" <?= selected(get_option('rsa_default_country'), 'eg', false) ?>>مصر 🇪🇬</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Modules -->
        <div class="rsa-section">
            <h2>🧩 تفعيل/إيقاف الوحدات</h2>
            <?php
            $enabled = get_option('rsa_enabled_modules', []);
            $modules_labels = [
                'local_seo'  => '📍 Local SEO Generator',
                'seo_engine' => '🧠 AI SEO Engine',
                'schema'     => '📋 Schema Factory',
                'conversion' => '🎯 Conversion Engine',
                'intent'     => '💡 Intent Detection',
                'tracker'    => '📊 Visitor Tracker',
                'linking'    => '🔗 Internal Linking',
                'offers'     => '🎁 Offers Engine',
                'content'    => '✍️ Content System',
                'competitor' => '🕵️ Competitor Analysis',
                'icons'      => '🎨 Icons Library',
                'image_gen'  => '🖼️ Auto Image',
                'auto_slug'  => '🔤 Auto Slug',
                'analyzer'   => '🔍 Site Analyzer',
                'bulk_writer'=> '✍️ Bulk Article Writer',
            ];
            foreach ($modules_labels as $key => $label):
                $on = !empty($enabled[$key]);
            ?>
            <label class="rsa-module-card <?= $on ? 'active' : 'inactive' ?>" style="display:flex;align-items:center;gap:14px;cursor:pointer;margin-bottom:10px">
                <label class="rsa-toggle">
                    <input type="checkbox" name="rsa_modules[<?= esc_attr($key) ?>]" value="1" <?= checked($on, true, false) ?> class="rsa-module-toggle">
                    <span class="rsa-toggle-slider"></span>
                </label>
                <span style="font-weight:600;font-size:14px"><?= $label ?></span>
            </label>
            <?php endforeach; ?>
        </div>

        <!-- Conversion -->
        <div class="rsa-section">
            <h2>🔔 إعدادات التحويل</h2>
            <div style="display:flex;flex-direction:column;gap:12px">
                <?php
                $conv_options = [
                    'rsa_conv_sticky_bar'    => 'تفعيل Sticky Bar السفلي',
                    'rsa_conv_popups'        => 'تفعيل Popup الذكي',
                    'rsa_conv_notifications' => 'تفعيل الإشعارات',
                ];
                foreach ($conv_options as $opt => $label):
                ?>
                <label style="display:flex;align-items:center;gap:12px;cursor:pointer">
                    <label class="rsa-toggle">
                        <input type="checkbox" name="<?= esc_attr($opt) ?>" value="1" <?= checked(get_option($opt, 1), 1, false) ?>>
                        <span class="rsa-toggle-slider"></span>
                    </label>
                    <span><?= $label ?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>

        <button type="submit" class="rsa-btn rsa-btn-primary rsa-btn-lg">
            <i class="fas fa-save"></i> حفظ الإعدادات
        </button>
        </form>
        </div>

        <script>
        function selectProvider(card) {
            document.querySelectorAll('.rsa-provider-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            document.getElementById('rsa-provider-val').value = card.dataset.value;
        }
        </script>
        <?php
    }

    /* ── Save Settings ─────────────────────── */
    public function save_settings(): void {
        if (empty($_POST['rsa_save'])) return;
        if (!wp_verify_nonce($_POST['rsa_settings_nonce'] ?? '', 'rsa_save_settings')) return;
        if (!current_user_can('manage_options')) return;

        $fields = ['rsa_gemini_api_key', 'rsa_claude_api_key', 'rsa_ai_provider',
                   'rsa_company_name', 'rsa_phone_number', 'rsa_whatsapp_number', 'rsa_default_country'];
        foreach ($fields as $f) {
            if (isset($_POST[$f])) update_option($f, sanitize_text_field($_POST[$f]));
        }

        $modules = [];
        foreach (array_keys(['local_seo'=>1,'seo_engine'=>1,'schema'=>1,'conversion'=>1,'intent'=>1,'tracker'=>1,'linking'=>1,'offers'=>1,'content'=>1,'competitor'=>1,'icons'=>1,'image_gen'=>1,'auto_slug'=>1,'analyzer'=>1,'bulk_writer'=>1]) as $k) {
            $modules[$k] = !empty($_POST['rsa_modules'][$k]) ? 1 : 0;
        }
        update_option('rsa_enabled_modules', $modules);

        foreach (['rsa_conv_sticky_bar', 'rsa_conv_popups', 'rsa_conv_notifications'] as $opt) {
            update_option($opt, !empty($_POST[$opt]) ? 1 : 0);
        }

        add_action('admin_notices', function () {
            echo '<div class="notice notice-success is-dismissible"><p>✅ تم حفظ إعدادات Rukn Smart AI بنجاح.</p></div>';
        });
    }

    /* ── AJAX Handler ──────────────────────── */
    public function handle_ajax(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('unauthorized');

        $action = sanitize_key($_POST['action'] ?? '');

        switch ($action) {
            case 'rsa_test_gemini':
                $key = sanitize_text_field($_POST['key'] ?? '');
                $api = RSA_Gemini_API::instance();
                $api->set_key($key);
                $result = $api->test();
                if ($result['success']) wp_send_json_success($result);
                else wp_send_json_error($result);
                break;

            case 'rsa_test_claude':
                $key = sanitize_text_field($_POST['key'] ?? '');
                $api = RSA_Claude_API::instance();
                $api->set_key($key);
                $result = $api->test();
                if ($result['success']) wp_send_json_success($result);
                else wp_send_json_error($result);
                break;

            case 'rsa_quick_generate':
                $type    = sanitize_key($_POST['type'] ?? 'seo');
                $keyword = sanitize_text_field($_POST['keyword'] ?? '');
                $ai      = RSA_AI::instance();

                if (!$ai->is_ready()) { wp_send_json_error('AI غير متصل — أضف مفتاح API في الإعدادات'); }

                $prompts = [
                    'seo'     => "اكتب Meta Title وMeta Description وH1 ووصف موجز لـ '{$keyword}' لموقع خدمات منازل في الخليج. استخدم العربية الفصحى.",
                    'article' => "اكتب مقال SEO عربي متكامل عن '{$keyword}' — 500 كلمة — مع مقدمة وفقرات وخاتمة.",
                    'faq'     => "اكتب 5 أسئلة شائعة وأجوبة مفصلة عن '{$keyword}' لموقع خدمات منازل.",
                    'schema'  => "اكتب Schema JSON-LD من نوع LocalBusiness لخدمة '{$keyword}' في دبي.",
                ];

                $result = $ai->ask($prompts[$type] ?? $prompts['seo'], 2000);
                RSA_DB::instance()->log('admin', 'quick_generate_' . $type, 0, 0);

                if ($result) wp_send_json_success(['content' => esc_html($result)]);
                else wp_send_json_error('فشل التوليد — تحقق من مفتاح AI');
                break;

            case 'rsa_gen_local_page':
                $city    = sanitize_text_field($_POST['city'] ?? '');
                $service = sanitize_text_field($_POST['service'] ?? '');
                $module  = $this->modules['local_seo'] ?? null;
                if (!$module) { wp_send_json_error('وحدة Local SEO غير مفعّلة'); }
                $result = $module->generate_page($city, $service);
                if ($result) wp_send_json_success($result);
                else wp_send_json_error('فشل إنشاء الصفحة — تحقق من مفتاح AI');
                break;

            case 'rsa_gen_bulk_cities':
                $service = sanitize_text_field($_POST['service'] ?? '');
                $module  = $this->modules['local_seo'] ?? null;
                if (!$module) { wp_send_json_error('وحدة Local SEO غير مفعّلة'); }
                $result = $module->generate_bulk($service);
                wp_send_json_success(['total' => $result]);
                break;

            case 'rsa_run_analysis':
                $module = $this->modules['analyzer'] ?? null;
                if (!$module) { wp_send_json_error('وحدة التحليل غير مفعّلة'); }
                $result = $module->run_full_analysis();
                update_option('rsa_last_analysis', wp_json_encode($result));
                wp_send_json_success(['score' => $result['score'] ?? 0]);
                break;

            case 'rsa_fix_issue':
                $fix     = sanitize_key($_POST['fix'] ?? '');
                $post_id = (int)($_POST['post_id'] ?? 0);
                $module  = $this->modules['analyzer'] ?? null;
                if (!$module) { wp_send_json_error('وحدة التحليل غير مفعّلة'); }
                $result = $module->fix_issue($fix, $post_id);
                if ($result) wp_send_json_success('تم الإصلاح');
                else wp_send_json_error('فشل الإصلاح');
                break;

            case 'rsa_scan_all_links':
                $module = $this->modules['linking'] ?? null;
                if (!$module) { wp_send_json_error('وحدة الربط الداخلي غير مفعّلة'); }
                $count = $module->scan_all();
                wp_send_json_success(['processed' => $count]);
                break;
        }
    }

    /* ── Other Pages ─────────────────────── */
    public function page_bulk_writer(): void {
        if (class_exists('RSA_Bulk_Writer')) RSA_Bulk_Writer::render_page();
        else echo '<div class="rsa-wrap"><p class="rsa-error">❌ وحدة المولّد الجماعي غير مفعّلة — فعّلها من الإعدادات</p></div>';
    }

    public function page_icons():      void { if (class_exists('RSA_Icons'))      RSA_Icons::render_admin_page();      else echo '<div class="rsa-wrap"><p>وحدة الأيقونات غير مفعّلة</p></div>'; }
    public function page_competitor(): void { if (class_exists('RSA_Competitor')) RSA_Competitor::render_page();       else echo '<div class="rsa-wrap"><p>وحدة التحليل غير مفعّلة</p></div>'; }
    public function page_offers():     void { if (class_exists('RSA_Offers'))     RSA_Offers::render_page();           else echo '<div class="rsa-wrap"><p>وحدة العروض غير مفعّلة</p></div>'; }

    public function save_seo_metabox(int $post_id, WP_Post $post): void {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!isset($_POST['rsa_meta_title'])) return;
        $module = $this->modules['seo_engine'] ?? null;
        if ($module) $module->save_metabox($post_id);
    }
}

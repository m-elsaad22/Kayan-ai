=== Rukn Smart AI ===
Contributors: mahmoudelsaad
Plugin Name: Rukn Smart AI
Plugin URI: https://rukn-eltatawer.com
Author: Mahmoud Elsaad
Version: 3.0.0
Requires at least: 6.0
Requires PHP: 7.4

== Description ==
نظام ذكاء اصطناعي متكامل مدعوم بـ Google Gemini (مجاني) و Anthropic Claude.
يشمل: SEO محلي، توليد محتوى، تتبع زيارات، تحليل منافسين، ربط داخلي، تحويل زوار.

== Changelog ==
= 3.0.0 =
* ربط تلقائي بـ Google Gemini (مجاني 100%)
* دعم Anthropic Claude كبديل
* واجهة admin جديدة احترافية
* إعادة تسمية الإضافة: Rukn Smart AI
* by Mahmoud Elsaad

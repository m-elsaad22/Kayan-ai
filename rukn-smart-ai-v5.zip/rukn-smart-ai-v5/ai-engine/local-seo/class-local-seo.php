<?php
defined('ABSPATH') || exit;

/**
 * RSA_Local_SEO
 * - إنشاء صفحات مدن وأحياء تلقائياً
 * - Schema LocalBusiness لكل صفحة
 * - تغيير H1/CTA حسب المدينة ديناميكياً
 */
class RSA_Local_SEO {

    private RSA_Claude_API $ai;
    private RSA_DB         $db;

    // قائمة المدن المدعومة
    public static array $CITIES = [
        'ae' => [
            'dubai'         => ['name_ar'=>'دبي',        'districts'=>['البرشاء','الجميرا','ديرة','بر دبي','المرقابات','النهدة','أبو هيل','القصيص','الخبيصي','الريم','المنخول','السطوة','الوحيدة','الوصل','زعبيل','عود ميثاء','الروضة']],
            'abu-dhabi'     => ['name_ar'=>'أبوظبي',     'districts'=>['الخالدية','المطار','الريم','الشامخة','محمد بن زايد','مصفح','الوحدة','زايد','بني ياس']],
            'sharjah'       => ['name_ar'=>'الشارقة',    'districts'=>['النهدة','الخان','القليعة','الغوير','التعاون','الجفالي','رأس الخيمة','المجاز']],
            'ajman'         => ['name_ar'=>'عجمان',      'districts'=>['الراشدية','الجرف','مويهات','النعيمية','الحميدية']],
            'fujairah'      => ['name_ar'=>'الفجيرة',    'districts'=>['مركز المدينة','دبا','قدفع']],
            'ras-al-khaimah'=> ['name_ar'=>'رأس الخيمة','districts'=>['الرميثة','الخوزامي','الجزيرة']],
            'umm-al-quwain' => ['name_ar'=>'أم القيوين', 'districts'=>['مركز المدينة','فلج المعلا']],
            'al-ain'        => ['name_ar'=>'العين',      'districts'=>['الجيمي','الفوعة','الرحبة','الهيلي','الجاهلي']],
        ],
        'sa' => [
            'riyadh'  => ['name_ar'=>'الرياض', 'districts'=>['النرجس','الملز','اليرموك','الورود','الروضة','العليا','حي الملك فهد','العزيزية','الشميسي','المربع','القيروان','الوادي','الرائد','الصحافة','النخيل']],
            'jeddah'  => ['name_ar'=>'جدة',    'districts'=>['البلد','الروضة','الشاطئ','العزيزية','النسيم','الفيصلية','السلامة','الهنداوية']],
            'dammam'  => ['name_ar'=>'الدمام', 'districts'=>['العنود','الفيصلية','المزروعية','الواجهة البحرية']],
            'khobar'  => ['name_ar'=>'الخبر',  'districts'=>['العقربية','الراكة','الثقبة','العزيزية']],
            'mecca'   => ['name_ar'=>'مكة',    'districts'=>['العزيزية','المنصور','الشوقية','النسيم']],
            'medina'  => ['name_ar'=>'المدينة المنورة','districts'=>['العزيزية','الحرة الشرقية','الجماوات']],
        ],
        'qa' => [
            'doha'   => ['name_ar'=>'الدوحة', 'districts'=>['العزيزية','الدحيل','الوكرة','النصر','الريان','لوسيل','المعمورة','مشيرب']],
            'wakra'  => ['name_ar'=>'الوكرة', 'districts'=>['مركز الوكرة']],
            'lusail' => ['name_ar'=>'لوسيل',  'districts'=>['فاخر','الوعب']],
        ],
    ];

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        $this->db = RSA_DB::instance();

        add_action('wp_ajax_rsa_gen_local_page',    [$this, 'ajax_gen_local_page']);
        add_action('wp_ajax_rsa_gen_bulk_cities',   [$this, 'ajax_bulk_cities']);
        add_filter('the_content',                   [$this, 'inject_city_content'], 20);
        add_action('wp_head',                       [$this, 'inject_local_schema'], 5);
    }

    /* ─── Generate single city page ─── */
    public function generate_city_page(string $city_key, string $service, string $district = ''): int|false {
        $country = get_option('rsa_default_country', 'ae');
        $city_data = self::$CITIES[$country][$city_key] ?? null;
        if (!$city_data) return false;

        $city_ar    = $city_data['name_ar'];
        $districts  = $district ?: implode('، ', array_slice($city_data['districts'], 0, 6));
        $company    = get_option('rsa_company_name', get_bloginfo('name'));
        $phone      = get_option('rsa_phone_number', '');
        $whatsapp   = get_option('rsa_whatsapp_number', '');

        $prompt = <<<PROMPT
أنت خبير Local SEO عربي. اكتب محتوى صفحة خدمة بالعربية.

المعلومات:
- الشركة: {$company}
- الخدمة: {$service}
- المدينة: {$city_ar}
- الأحياء: {$districts}
- الهاتف: {$phone}

المطلوب JSON:
{
  "post_title": "عنوان الصفحة (60-70 حرف بدون اسم الشركة)",
  "meta_desc": "وصف 155 حرف مع CTA",
  "hero_text": "فقرة مقدمة 100 كلمة - Direct Answer + Hook",
  "sections": [
    {"h2": "عنوان", "content": "250 كلمة"},
    {"h2": "عنوان", "content": "200 كلمة"},
    {"h2": "أسباب اختيارنا في {$city_ar}", "content": "200 كلمة"},
    {"h2": "أسئلة شائعة", "faqs": [{"q":"سؤال","a":"جواب"},{"q":"سؤال","a":"جواب"},{"q":"سؤال","a":"جواب"}]}
  ],
  "districts_section": "فقرة تذكر أحياء {$city_ar} بشكل طبيعي",
  "slug": "slug-in-english-for-url"
}

أعطني JSON فقط.
PROMPT;

        $data = $this->ai->ask_json($prompt, 3000);
        if (empty($data)) return false;

        // Build HTML content
        $content = $this->build_page_html($data, $city_ar, $service, $whatsapp, $phone, $districts);

        // Create WP post
        $slug = RSA_Helper::instance()->arabic_to_slug($service . '-' . $city_ar);
        if (!empty($data['slug'])) $slug = sanitize_title($data['slug']);

        $post_id = wp_insert_post([
            'post_title'   => sanitize_text_field($data['post_title'] ?? "{$service} في {$city_ar}"),
            'post_content' => $content,
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_name'    => $slug,
            'meta_input'   => [
                '_rsa_city'    => $city_ar,
                '_rsa_service' => $service,
                '_rsa_country' => $country,
            ],
        ]);

        if (is_wp_error($post_id)) return false;

        // Save SEO meta
        global $wpdb;
        $wpdb->insert("{$wpdb->prefix}rsa_seo", [
            'post_id'   => $post_id,
            'meta_title'=> sanitize_text_field($data['post_title'] ?? ''),
            'meta_desc' => sanitize_textarea_field($data['meta_desc'] ?? ''),
            'focus_kw'  => "{$service} في {$city_ar}",
            'last_ai'   => current_time('mysql'),
        ]);

        // Save in local pages table
        $this->db->insert('local_pages', [
            'city'      => $city_ar,
            'district'  => $district,
            'service'   => $service,
            'post_id'   => $post_id,
            'generated' => 1,
            'created_at'=> current_time('mysql'),
        ]);

        $this->db->log('local_seo', 'generate_page', $post_id, 1500);
        return $post_id;
    }

    /* ─── Build HTML ─── */
    private function build_page_html(array $d, string $city, string $service, string $wa, string $phone, string $districts): string {
        $company = get_option('rsa_company_name', get_bloginfo('name'));
        $wa_link = $wa ? "https://wa.me/{$wa}" : '#';

        $html = '';
        // Hero
        $html .= '<div style="background:#f0f7ff;border-right:6px solid #0056b3;padding:30px;border-radius:15px;margin-bottom:30px">';
        $html .= '<h2 style="color:#003366;margin-top:0">' . esc_html($d['post_title'] ?? '') . '</h2>';
        $html .= '<p style="font-size:17px;line-height:1.8">' . esc_html($d['hero_text'] ?? '') . '</p>';
        if ($phone) $html .= '<a href="tel:' . esc_attr($phone) . '" style="background:#0056b3;color:#fff;padding:12px 25px;border-radius:50px;text-decoration:none;display:inline-block;margin-top:15px;margin-left:10px"><i class="fas fa-phone"></i> اتصل الآن</a>';
        $html .= '<a href="' . esc_url($wa_link) . '" style="background:#25d366;color:#fff;padding:12px 25px;border-radius:50px;text-decoration:none;display:inline-block;margin-top:15px"><i class="fab fa-whatsapp"></i> واتساب</a>';
        $html .= '</div>';

        // Sections
        foreach ($d['sections'] ?? [] as $section) {
            $html .= '<h2>' . esc_html($section['h2'] ?? '') . '</h2>';
            if (!empty($section['faqs'])) {
                foreach ($section['faqs'] as $faq) {
                    $html .= '<details style="border:1px solid #e2e8f0;border-radius:10px;padding:15px;margin-bottom:10px">';
                    $html .= '<summary style="font-weight:bold;cursor:pointer">' . esc_html($faq['q'] ?? '') . '</summary>';
                    $html .= '<p style="margin-top:10px;color:#555">' . esc_html($faq['a'] ?? '') . '</p>';
                    $html .= '</details>';
                }
            } else {
                $html .= '<p>' . esc_html($section['content'] ?? '') . '</p>';
            }
        }

        // Districts section
        if (!empty($d['districts_section'])) {
            $html .= '<div style="background:#f8fafc;padding:20px;border-radius:12px;margin:25px 0;border-right:4px solid #0056b3">';
            $html .= '<h3><i class="fas fa-map-marker-alt" style="color:#0056b3"></i> مناطق الخدمة في ' . esc_html($city) . '</h3>';
            $html .= '<p>' . esc_html($d['districts_section']) . '</p>';
            $html .= '</div>';
        }

        // Final CTA
        $html .= '<div style="background:linear-gradient(45deg,#0f172a,#1e3a8a);color:#fff;padding:30px;border-radius:15px;text-align:center;margin-top:30px">';
        $html .= '<h3 style="color:#fbbf24;margin-bottom:15px">احصل على خدمة ' . esc_html($service) . ' في ' . esc_html($city) . ' الآن</h3>';
        $html .= '<p style="margin-bottom:20px">خدمة سريعة واحترافية — نصل إليك خلال 30 دقيقة</p>';
        $html .= '<div style="display:flex;gap:15px;justify-content:center;flex-wrap:wrap">';
        if ($phone) $html .= '<a href="tel:' . esc_attr($phone) . '" style="background:#0056b3;color:#fff;padding:15px 35px;border-radius:50px;text-decoration:none;font-weight:bold"><i class="fas fa-phone"></i> اتصل بنا</a>';
        $html .= '<a href="' . esc_url($wa_link) . '" style="background:#25d366;color:#fff;padding:15px 35px;border-radius:50px;text-decoration:none;font-weight:bold"><i class="fab fa-whatsapp"></i> واتساب الآن</a>';
        $html .= '</div></div>';

        return $html;
    }

    /* ─── Dynamic city content injection ─── */
    public function inject_city_content(string $content): string {
        if (!is_singular()) return $content;
        $city  = get_post_meta(get_the_ID(), '_rsa_city', true);
        $phone = get_option('rsa_phone_number', '');
        $wa    = get_option('rsa_whatsapp_number', '');
        if (empty($city)) return $content;

        // Replace placeholders in content
        $content = str_replace('[rsa_city]', esc_html($city), $content);
        $content = str_replace('[rsa_phone]', esc_html($phone), $content);
        $content = str_replace('[rsa_whatsapp]', esc_html($wa), $content);
        return $content;
    }

    /* ─── LocalBusiness Schema ─── */
    public function inject_local_schema(): void {
        if (!is_singular()) return;
        $post_id = get_the_ID();
        $city    = get_post_meta($post_id, '_rsa_city', true);
        if (!$city) return;

        $company = get_option('rsa_company_name', get_bloginfo('name'));
        $phone   = get_option('rsa_phone_number', '');
        $service = get_post_meta($post_id, '_rsa_service', true);

        $schema = [
            '@context'    => 'https://schema.org',
            '@type'       => ['LocalBusiness','Service'],
            'name'        => $company,
            'description' => $service ? "{$service} في {$city}" : $company,
            'areaServed'  => $city,
            'telephone'   => $phone,
            'url'         => get_permalink($post_id),
            'aggregateRating' => [
                '@type'       => 'AggregateRating',
                'ratingValue' => '4.9',
                'reviewCount' => '127',
            ],
        ];

        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    /* ─── AJAX: generate single page ─── */
    public function ajax_gen_local_page(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $city    = sanitize_text_field($_POST['city'] ?? '');
        $service = sanitize_text_field($_POST['service'] ?? '');
        if (!$city || !$service) wp_send_json_error('Missing city or service');

        $post_id = $this->generate_city_page($city, $service);
        if (!$post_id) wp_send_json_error('Generation failed');

        wp_send_json_success(['post_id'=>$post_id, 'edit_url'=>get_edit_post_link($post_id, 'raw'), 'view_url'=>get_permalink($post_id)]);
    }

    /* ─── AJAX: bulk generate for all cities ─── */
    public function ajax_bulk_cities(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $service = sanitize_text_field($_POST['service'] ?? '');
        $country = sanitize_text_field($_POST['country'] ?? get_option('rsa_default_country', 'ae'));
        if (!$service) wp_send_json_error('Missing service');

        $cities  = array_keys(self::$CITIES[$country] ?? []);
        $results = [];

        foreach ($cities as $city_key) {
            $post_id = $this->generate_city_page($city_key, $service);
            $results[] = ['city'=>$city_key, 'post_id'=>$post_id, 'ok'=>(bool)$post_id];
            sleep(2); // Rate limit
        }

        wp_send_json_success(['results'=>$results, 'total'=>count($cities)]);
    }
}

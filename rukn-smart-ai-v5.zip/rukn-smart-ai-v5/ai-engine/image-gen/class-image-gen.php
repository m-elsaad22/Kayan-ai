<?php
defined('ABSPATH') || exit;

/**
 * RSA_Image_Gen
 * - عندما يُضاف مقال بدون صورة بارزة
 * - يبحث في المكتبة عن صورة اسمها أقرب لعنوان المقال
 * - يضبطها كـ Featured Image
 * - يضيف نسخة داخل المقال مع alt text = الكلمة المفتاحية
 */
class RSA_Image_Gen {

    public function __construct() {
        add_action('save_post',    [$this, 'auto_assign_image'], 30, 2);
        add_filter('the_content', [$this, 'inject_image_in_content'], 25);
    }

    /* ─── Auto-assign featured image ─── */
    public function auto_assign_image(int $post_id, WP_Post $post): void {
        if (wp_is_post_revision($post_id)) return;
        if ($post->post_status !== 'publish') return;
        if (!in_array($post->post_type, ['post','page'], true)) return;

        // Skip if already has thumbnail
        if (has_post_thumbnail($post_id)) return;

        $best_image = $this->find_best_image($post->post_title, $post->post_content);
        if ($best_image) {
            set_post_thumbnail($post_id, $best_image['id']);
            // Add alt text
            update_post_meta($best_image['id'], '_wp_attachment_image_alt',
                sanitize_text_field($post->post_title));
        }
    }

    /* ─── Find closest image in media library ─── */
    public function find_best_image(string $title, string $content = ''): array|null {
        // Extract keywords from title
        $keywords = $this->extract_keywords($title);
        if (empty($keywords)) return null;

        $helper = RSA_Helper::instance();

        // Get all images from media library
        $images = get_posts([
            'post_type'      => 'attachment',
            'post_mime_type' => 'image',
            'posts_per_page' => 200,
            'post_status'    => 'inherit',
        ]);

        if (empty($images)) return null;

        $best       = null;
        $best_score = 0;

        foreach ($images as $img) {
            $img_title = strtolower($img->post_title . ' ' . $img->post_excerpt . ' ' . $img->post_content);
            $alt       = strtolower(get_post_meta($img->ID, '_wp_attachment_image_alt', true));
            $filename  = strtolower(basename(get_attached_file($img->ID) ?? ''));
            $haystack  = $img_title . ' ' . $alt . ' ' . $filename;

            $score = 0;
            foreach ($keywords as $kw) {
                $kw_en = $helper->arabic_to_slug($kw);
                if (str_contains($haystack, $kw))    $score += 2;
                if (str_contains($haystack, $kw_en)) $score += 1;
            }

            if ($score > $best_score) {
                $best_score = $score;
                $best       = $img;
            }
        }

        if (!$best || $best_score < 1) {
            // Fallback: return most recent image
            return ['id' => $images[0]->ID, 'url' => wp_get_attachment_url($images[0]->ID)];
        }

        return ['id' => $best->ID, 'url' => wp_get_attachment_url($best->ID), 'score' => $best_score];
    }

    /* ─── Inject image inside content (if no image in first 300 words) ─── */
    public function inject_image_in_content(string $content): string {
        if (!is_singular() || is_admin()) return $content;
        $post_id = get_the_ID();

        // Check if content already has an image
        if (str_contains($content, '<img')) return $content;

        $thumb_id = get_post_thumbnail_id($post_id);
        if (!$thumb_id) return $content;

        $post    = get_post($post_id);
        $focus_kw = get_post_meta($post_id, '_rsa_focus_kw', true) ?: get_the_title($post_id);
        $img_url  = get_the_post_thumbnail_url($post_id, 'large');
        if (!$img_url) return $content;

        $img_html = '<figure style="text-align:center;margin:25px 0">'
            . '<img src="' . esc_url($img_url) . '" alt="' . esc_attr($focus_kw) . '" '
            . 'title="' . esc_attr($focus_kw) . '" '
            . 'style="max-width:100%;border-radius:15px;box-shadow:0 8px 25px rgba(0,0,0,.1)" '
            . 'loading="lazy">'
            . '<figcaption style="color:#666;font-size:13px;margin-top:8px">' . esc_html($focus_kw) . '</figcaption>'
            . '</figure>';

        // Insert after first paragraph
        $pos = strpos($content, '</p>');
        if ($pos !== false) {
            $content = substr($content, 0, $pos + 4) . $img_html . substr($content, $pos + 4);
        }

        return $content;
    }

    /* ─── Extract meaningful keywords from Arabic title ─── */
    private function extract_keywords(string $title): array {
        // Remove common words
        $stop_words = ['في','من','على','مع','إلى','عن','هل','ما','كيف','لماذا','متى','أين','شركة','خدمة','أفضل','أرخص','مميز','احترافي'];
        $words = explode(' ', $title);
        $kws   = [];
        foreach ($words as $w) {
            $w = trim($w);
            if (mb_strlen($w) > 2 && !in_array($w, $stop_words)) {
                $kws[] = $w;
            }
        }
        return array_slice($kws, 0, 5);
    }
}

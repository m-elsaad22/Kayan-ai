<?php
defined('ABSPATH') || exit;

class RSA_Offers {
    private RSA_DB $db;

    public function __construct() {
        $this->db = RSA_DB::instance();
        add_action('wp_ajax_rsa_get_active_offer',        [$this, 'ajax_get']);
        add_action('wp_ajax_nopriv_rsa_get_active_offer', [$this, 'ajax_get']);
        add_action('wp_ajax_rsa_save_offer',   [$this, 'ajax_save']);
        add_action('wp_ajax_rsa_delete_offer', [$this, 'ajax_delete']);
    }

    /** Get best offer for current visitor */
    public function ajax_get(): void {
        $geo   = RSA_Helper::instance()->get_city();
        $city  = $geo['city'];
        $hour  = (int) current_time('G');

        // Try city-specific offer first
        global $wpdb;
        $t = $wpdb->prefix . 'rsa_offers';
        $offer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$t} WHERE active=1 AND (city=%s OR city='') AND (expires_at IS NULL OR expires_at > NOW()) ORDER BY city DESC LIMIT 1",
            $city
        ), ARRAY_A);

        if (!$offer) { wp_send_json_success(null); return; }

        // Auto-inject city name
        $title = str_replace('{city}', $city, $offer['title']);
        $body  = str_replace('{city}', $city, $offer['body']);

        // Time-based suffix
        if ($hour >= 8 && $hour < 12)  $body .= ' — عرض الصباح';
        elseif ($hour >= 20)           $body .= ' — عرض الليل';

        // Track impression
        $wpdb->query($wpdb->prepare("UPDATE {$t} SET impressions=impressions+1 WHERE id=%d", $offer['id']));

        wp_send_json_success(['id'=>$offer['id'], 'title'=>$title, 'body'=>$body, 'city'=>$city]);
    }

    public function ajax_save(): void {
        check_ajax_referer('rsa_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $data = [
            'title'      => sanitize_text_field($_POST['title'] ?? ''),
            'body'       => sanitize_textarea_field($_POST['body'] ?? ''),
            'city'       => sanitize_text_field($_POST['city'] ?? ''),
            'active'     => 1,
            'expires_at' => !empty($_POST['expires_at']) ? sanitize_text_field($_POST['expires_at']) : null,
        ];

        $id = (int)($_POST['offer_id'] ?? 0);
        if ($id) {
            $this->db->update('offers', $data, ['id'=>$id]);
        } else {
            $id = $this->db->insert('offers', $data);
        }
        wp_send_json_success(['id'=>$id]);
    }

    public function ajax_delete(): void {
        check_ajax_referer('rsa_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        global $wpdb;
        $wpdb->delete($wpdb->prefix.'rsa_offers', ['id'=>(int)($_POST['id']??0)]);
        wp_send_json_success();
    }

    /** Render offers management page (called from admin) */
    public static function render_page(): void {
        global $wpdb;
        $offers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}rsa_offers ORDER BY id DESC", ARRAY_A) ?: [];
        ?>
        <div style="direction:rtl;padding:20px">
        <h2>🎁 إدارة العروض الديناميكية</h2>
        <p style="color:#555;margin-bottom:20px">العروض تظهر تلقائياً للزوار حسب المدينة والوقت والسلوك</p>

        <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:25px;margin-bottom:25px">
            <h3 style="margin:0 0 15px">إضافة عرض جديد</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:15px">
                <div><label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px">عنوان العرض</label>
                <input type="text" id="offer-title" placeholder="خصم 20% لسكان {city}" style="width:100%;padding:8px 10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box"></div>

                <div><label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px">نص العرض</label>
                <input type="text" id="offer-body" placeholder="احجز الآن واحصل على خصم" style="width:100%;padding:8px 10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box"></div>

                <div><label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px">المدينة (اتركه فارغ للكل)</label>
                <input type="text" id="offer-city" placeholder="دبي" style="width:100%;padding:8px 10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box"></div>

                <div><label style="display:block;font-size:13px;font-weight:600;margin-bottom:5px">تاريخ الانتهاء</label>
                <input type="datetime-local" id="offer-expires" style="width:100%;padding:8px 10px;border:1px solid #ddd;border-radius:8px;box-sizing:border-box"></div>
            </div>
            <button onclick="saveOffer()" style="background:#0056b3;color:#fff;padding:10px 25px;border:none;border-radius:8px;cursor:pointer;font-weight:600">+ إضافة العرض</button>
            <div id="offer-msg" style="margin-top:10px"></div>
        </div>

        <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px">
            <h3 style="margin:0 0 15px">العروض الحالية (<?= count($offers) ?>)</h3>
            <?php if (empty($offers)): ?>
            <p style="color:#888">لا توجد عروض بعد</p>
            <?php else: ?>
            <div style="overflow-x:auto">
            <table style="width:100%;border-collapse:collapse;font-size:13px">
                <thead><tr style="background:#0056b3;color:#fff">
                    <th style="padding:10px;text-align:right">العنوان</th>
                    <th style="padding:10px">المدينة</th>
                    <th style="padding:10px">الظهور</th>
                    <th style="padding:10px">الحالة</th>
                    <th style="padding:10px">إجراء</th>
                </tr></thead>
                <tbody>
                <?php foreach ($offers as $o): ?>
                <tr style="border-bottom:1px solid #e2e8f0">
                    <td style="padding:10px"><strong><?= esc_html($o['title']) ?></strong><br><small style="color:#888"><?= esc_html($o['body']) ?></small></td>
                    <td style="padding:10px;text-align:center"><?= esc_html($o['city'] ?: 'الكل') ?></td>
                    <td style="padding:10px;text-align:center"><?= number_format($o['impressions']) ?></td>
                    <td style="padding:10px;text-align:center"><span style="background:<?= $o['active']?'#dcfce7':'#fee2e2' ?>;color:<?= $o['active']?'#166534':'#b91c1c' ?>;padding:2px 10px;border-radius:20px;font-size:11px"><?= $o['active']?'مفعّل':'معطّل' ?></span></td>
                    <td style="padding:10px;text-align:center"><button onclick="deleteOffer(<?= $o['id'] ?>)" style="background:#ef4444;color:#fff;padding:5px 12px;border:none;border-radius:6px;cursor:pointer;font-size:12px">حذف</button></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>
        </div>

        <script>
        function saveOffer(){
            var msg=document.getElementById('offer-msg');
            msg.innerHTML='<span style="color:#888">⏳ جاري الحفظ...</span>';
            jQuery.post(RSA_Admin.ajaxurl,{
                action:'rsa_save_offer',nonce:RSA_Admin.nonce,
                title:document.getElementById('offer-title').value,
                body:document.getElementById('offer-body').value,
                city:document.getElementById('offer-city').value,
                expires_at:document.getElementById('offer-expires').value
            },function(r){
                if(r.success){msg.innerHTML='<span style="color:#22c55e">✅ تم الحفظ</span>';setTimeout(function(){location.reload();},1000);}
                else msg.innerHTML='<span style="color:#ef4444">❌ خطأ</span>';
            });
        }
        function deleteOffer(id){
            if(!confirm('حذف العرض؟'))return;
            jQuery.post(RSA_Admin.ajaxurl,{action:'rsa_delete_offer',nonce:RSA_Admin.nonce,id:id},function(r){if(r.success)location.reload();});
        }
        </script>
        <?php
    }
}

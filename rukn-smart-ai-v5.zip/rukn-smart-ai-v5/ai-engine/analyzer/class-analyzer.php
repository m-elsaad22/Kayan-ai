<?php
defined('ABSPATH') || exit;

/**
 * RSA_Analyzer — تحليل الموقع الكامل
 * أخطاء SEO + مشاكل + اقتراحات + حلول
 * تقارير عن أسباب قلة الاتصالات والكلمات المفتاحية المفقودة
 */
class RSA_Analyzer {

    private RSA_Claude_API $ai;
    private RSA_DB         $db;

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        $this->db = RSA_DB::instance();

        add_action('wp_ajax_rsa_run_analysis',  [$this, 'ajax_run_analysis']);
        add_action('wp_ajax_rsa_fix_issue',     [$this, 'ajax_fix_issue']);
        add_action('wp_ajax_rsa_get_report',    [$this, 'ajax_get_report']);
    }

    /* ─── Full site scan ─── */
    public function run_full_analysis(): array {
        $report = [
            'timestamp'    => current_time('mysql'),
            'posts'        => [],
            'site_issues'  => [],
            'opportunities'=> [],
            'score'        => 0,
        ];

        // 1. Check all published posts
        $posts = get_posts(['numberposts'=>100,'post_status'=>'publish','post_type'=>['post','page']]);
        $total_score = 0;

        foreach ($posts as $post) {
            $post_analysis = $this->analyze_post($post);
            $report['posts'][] = $post_analysis;
            $total_score += $post_analysis['score'];
        }

        if (count($posts) > 0) $report['score'] = round($total_score / count($posts));

        // 2. Site-wide issues
        $report['site_issues'] = $this->check_site_issues();

        // 3. AI opportunities
        if ($this->ai->is_ready()) {
            $report['opportunities'] = $this->get_ai_opportunities($report);
        }

        // Save report
        update_option('rsa_last_analysis', wp_json_encode($report));
        $this->db->log('analyzer', 'full_scan', 0, 0, 'ok', 'Score: ' . $report['score']);

        return $report;
    }

    /* ─── Analyze single post ─── */
    public function analyze_post(WP_Post $post): array {
        $issues  = [];
        $score   = 100;

        $content     = strip_tags($post->post_content);
        $word_count  = str_word_count($content);
        $title       = $post->post_title;

        global $wpdb;
        $seo_row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rsa_seo WHERE post_id=%d", $post->ID
        ), ARRAY_A);

        // Check: Meta title
        if (empty($seo_row['meta_title'])) {
            $issues[] = ['type'=>'warning','msg'=>'لا يوجد Meta Title مخصص','fix'=>'auto_seo'];
            $score -= 15;
        } elseif (mb_strlen($seo_row['meta_title']) < 40) {
            $issues[] = ['type'=>'info','msg'=>'Meta Title قصير جداً (أقل من 40 حرف)'];
            $score -= 5;
        }

        // Check: Meta description
        if (empty($seo_row['meta_desc'])) {
            $issues[] = ['type'=>'warning','msg'=>'لا يوجد Meta Description','fix'=>'auto_seo'];
            $score -= 10;
        }

        // Check: Word count
        if ($word_count < 500) {
            $issues[] = ['type'=>'error','msg'=>"المحتوى قصير ({$word_count} كلمة) — يحتاج 1000+"];
            $score -= 20;
        } elseif ($word_count < 1000) {
            $issues[] = ['type'=>'warning','msg'=>"المحتوى متوسط ({$word_count} كلمة) — يفضل 1500+"];
            $score -= 10;
        }

        // Check: Featured image
        if (!has_post_thumbnail($post->ID)) {
            $issues[] = ['type'=>'warning','msg'=>'لا توجد صورة بارزة','fix'=>'auto_image'];
            $score -= 8;
        }

        // Check: H1 (post title should be H1)
        if (empty($title)) {
            $issues[] = ['type'=>'error','msg'=>'لا يوجد عنوان H1'];
            $score -= 15;
        }

        // Check: Internal links
        $link_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}rsa_links WHERE source_id=%d", $post->ID
        ));
        if ($link_count < 2) {
            $issues[] = ['type'=>'info','msg'=>'روابط داخلية قليلة','fix'=>'auto_link'];
            $score -= 5;
        }

        // Check: FAQ schema
        if (empty($seo_row['faq_json'])) {
            $issues[] = ['type'=>'info','msg'=>'لا يوجد FAQ Schema','fix'=>'auto_seo'];
            $score -= 5;
        }

        // Check: Slug (should be English)
        $slug = $post->post_name;
        if (preg_match('/[\x{0600}-\x{06FF}]/u', urldecode($slug))) {
            $issues[] = ['type'=>'warning','msg'=>'الرابط بالعربية — يفضل الإنجليزية','fix'=>'fix_slug'];
            $score -= 10;
        }

        return [
            'post_id'    => $post->ID,
            'title'      => $title,
            'url'        => get_permalink($post->ID),
            'edit_url'   => get_edit_post_link($post->ID, 'raw'),
            'word_count' => $word_count,
            'score'      => max(0, $score),
            'issues'     => $issues,
            'links_count'=> (int)$link_count,
        ];
    }

    /* ─── Site-wide checks ─── */
    private function check_site_issues(): array {
        $issues = [];

        // SSL
        if (!is_ssl()) {
            $issues[] = ['severity'=>'high','msg'=>'الموقع لا يستخدم HTTPS — ضروري لـ SEO'];
        }

        // Speed
        $issues[] = ['severity'=>'info','msg'=>'تأكد من تفعيل Caching plugin مثل WP Rocket أو LiteSpeed Cache'];

        // Sitemap
        if (!file_exists(ABSPATH . 'sitemap.xml') && !get_option('blog_public')) {
            $issues[] = ['severity'=>'high','msg'=>'لا يوجد Sitemap — تأكد من تفعيله'];
        }

        // Posts without SEO
        global $wpdb;
        $no_seo = $wpdb->get_var("SELECT COUNT(p.ID) FROM {$wpdb->posts} p 
            LEFT JOIN {$wpdb->prefix}rsa_seo s ON s.post_id=p.ID 
            WHERE p.post_status='publish' AND p.post_type IN ('post','page') AND s.id IS NULL");
        if ($no_seo > 0) {
            $issues[] = ['severity'=>'high','msg'=>"{$no_seo} مقال/صفحة بدون إعدادات SEO — استخدم توليد AI الجماعي"];
        }

        // Low visit posts
        $low_traffic = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} p 
            WHERE p.post_status='publish' AND p.post_type='post' 
            AND (SELECT COUNT(*) FROM {$wpdb->prefix}rsa_visits v WHERE v.post_id=p.ID AND v.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)) < 5");
        if ($low_traffic > 0) {
            $issues[] = ['severity'=>'warning','msg'=>"{$low_traffic} مقال بزيارات أقل من 5 في 30 يوم — تحتاج تحسين أو ترويج"];
        }

        return $issues;
    }

    /* ─── AI Opportunities ─── */
    private function get_ai_opportunities(array $report): array {
        $stats   = RSA_Tracker::instance()->get_stats(30);
        $company = get_option('rsa_company_name', get_bloginfo('name'));

        $low_score_posts = array_filter($report['posts'], fn($p) => $p['score'] < 60);
        $top_cities      = array_column($stats['top_cities'] ?? [], 'city');
        $buying_intent   = $stats['buying_intent'] ?? 0;

        $prompt = <<<PROMPT
أنت مستشار SEO محترف. بناءً على بيانات الموقع:
- الشركة: {$company}
- عدد المقالات الضعيفة (< 60%): {$low_score_count}
- المدن الأكثر زيارة: {$cities_str}
- زيارات بنية شراء في 30 يوم: {$buying_intent}

قدم 5 فرص SEO محددة وقابلة للتنفيذ بـ JSON:
[
  {"priority": "high|medium|low", "action": "الإجراء المحدد", "impact": "التأثير المتوقع", "effort": "easy|medium|hard"}
]
PROMPT;

        $low_score_count = count($low_score_posts);
        $cities_str      = implode('، ', array_slice($top_cities, 0, 5));

        $prompt = str_replace(['{$low_score_count}', '{$cities_str}', '{$buying_intent}'],
                              [$low_score_count, $cities_str, $buying_intent], $prompt);

        $data = $this->ai->ask_json($prompt, 800);
        return $data ?: [];
    }

    /* ─── AJAX handlers ─── */
    public function ajax_run_analysis(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $report = $this->run_full_analysis();
        wp_send_json_success($report);
    }

    public function ajax_fix_issue(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $fix     = sanitize_text_field($_POST['fix']     ?? '');
        $post_id = (int)($_POST['post_id'] ?? 0);

        switch ($fix) {
            case 'auto_seo':
                $post   = get_post($post_id);
                $engine = new RSA_SEO_Engine();
                $data   = $engine->generate_for_post($post_id, $post);
                wp_send_json_success(['msg'=>'تم توليد SEO', 'data'=>$data]);
                break;
            case 'auto_link':
                $linker = new RSA_Linking();
                $links  = $linker->generate_links_for_post($post_id);
                wp_send_json_success(['msg'=>'تم إضافة '.count($links).' رابط']);
                break;
            case 'auto_image':
                $img_gen = new RSA_Image_Gen();
                $post    = get_post($post_id);
                $result  = $img_gen->find_best_image($post->post_title, $post->post_content);
                if ($result) set_post_thumbnail($post_id, $result['id']);
                wp_send_json_success(['msg'=>$result ? 'تم تعيين الصورة' : 'لم توجد صورة مناسبة']);
                break;
            default:
                wp_send_json_error('Unknown fix');
        }
    }

    public function ajax_get_report(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        $report = json_decode(get_option('rsa_last_analysis', '{}'), true);
        wp_send_json_success($report);
    }
}

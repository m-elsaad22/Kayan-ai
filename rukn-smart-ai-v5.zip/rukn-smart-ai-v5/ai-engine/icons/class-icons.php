<?php
defined('ABSPATH') || exit;

/**
 * RSA_Icons — مكتبة أيقونات Font Awesome للخدمات المنزلية
 * عرض الاسم + شكل الأيقونة + الكود
 * Shortcode: [rsa_icons category="cleaning"]
 */
class RSA_Icons {

    public static array $ICONS = [
        // ─── تنظيف ─────────────────────────────────────────────────────
        'cleaning' => [
            ['name'=>'تنظيف عام',          'code'=>'fa-broom',               'class'=>'fas'],
            ['name'=>'مكنسة كهربائية',      'code'=>'fa-vacuum',              'class'=>'fas'],
            ['name'=>'دلو تنظيف',           'code'=>'fa-bucket',              'class'=>'fas'],
            ['name'=>'رذاذ تنظيف',          'code'=>'fa-spray-can-sparkles',  'class'=>'fas'],
            ['name'=>'قفازات تنظيف',        'code'=>'fa-hand-sparkles',       'class'=>'fas'],
            ['name'=>'تلميع',               'code'=>'fa-sparkles',            'class'=>'fas'],
            ['name'=>'فرشاة',               'code'=>'fa-brush',               'class'=>'fas'],
            ['name'=>'تنظيف سجاد',          'code'=>'fa-rug',                 'class'=>'fas'],
            ['name'=>'شبابيك',              'code'=>'fa-window-restore',      'class'=>'fas'],
            ['name'=>'غسيل ملابس',          'code'=>'fa-shirt',               'class'=>'fas'],
        ],
        // ─── سباكة ─────────────────────────────────────────────────────
        'plumbing' => [
            ['name'=>'سباكة',               'code'=>'fa-faucet',              'class'=>'fas'],
            ['name'=>'صنبور مياه',          'code'=>'fa-faucet-drip',         'class'=>'fas'],
            ['name'=>'أنابيب',              'code'=>'fa-pipe-section',        'class'=>'fas'],
            ['name'=>'تسرب مياه',           'code'=>'fa-droplet',             'class'=>'fas'],
            ['name'=>'إصلاح أنابيب',        'code'=>'fa-wrench',              'class'=>'fas'],
            ['name'=>'خزان مياه',           'code'=>'fa-tank-water',          'class'=>'fas'],
            ['name'=>'ضغط مياه',            'code'=>'fa-gauge',               'class'=>'fas'],
            ['name'=>'بالوعة',              'code'=>'fa-sink',                'class'=>'fas'],
            ['name'=>'مرحاض',               'code'=>'fa-toilet',              'class'=>'fas'],
            ['name'=>'دش',                  'code'=>'fa-shower',              'class'=>'fas'],
        ],
        // ─── كهرباء ─────────────────────────────────────────────────────
        'electrical' => [
            ['name'=>'كهرباء',              'code'=>'fa-bolt',                'class'=>'fas'],
            ['name'=>'مقبس كهربائي',        'code'=>'fa-plug',                'class'=>'fas'],
            ['name'=>'لوحة كهربائية',       'code'=>'fa-solar-panel',         'class'=>'fas'],
            ['name'=>'مصباح',               'code'=>'fa-lightbulb',           'class'=>'fas'],
            ['name'=>'طاقة شمسية',          'code'=>'fa-sun',                 'class'=>'fas'],
            ['name'=>'تحذير كهرباء',        'code'=>'fa-triangle-exclamation','class'=>'fas'],
            ['name'=>'سويتش',               'code'=>'fa-toggle-on',           'class'=>'fas'],
            ['name'=>'كابل',                'code'=>'fa-cable-car',           'class'=>'fas'],
            ['name'=>'فيوز',                'code'=>'fa-box',                 'class'=>'fas'],
            ['name'=>'مولد',                'code'=>'fa-generator',           'class'=>'fas'],
        ],
        // ─── تكييف ─────────────────────────────────────────────────────
        'hvac' => [
            ['name'=>'تكييف',               'code'=>'fa-wind',                'class'=>'fas'],
            ['name'=>'حرارة',               'code'=>'fa-temperature-high',    'class'=>'fas'],
            ['name'=>'برودة',               'code'=>'fa-temperature-low',     'class'=>'fas'],
            ['name'=>'مروحة',               'code'=>'fa-fan',                 'class'=>'fas'],
            ['name'=>'ثلاجة',               'code'=>'fa-snowflake',           'class'=>'fas'],
            ['name'=>'ترموستات',            'code'=>'fa-thermometer',         'class'=>'fas'],
        ],
        // ─── نقل وشحن ───────────────────────────────────────────────────
        'moving' => [
            ['name'=>'نقل أثاث',            'code'=>'fa-truck-moving',        'class'=>'fas'],
            ['name'=>'صندوق نقل',           'code'=>'fa-box-open',            'class'=>'fas'],
            ['name'=>'رافعة',               'code'=>'fa-lift',                'class'=>'fas'],
            ['name'=>'تخزين',               'code'=>'fa-warehouse',           'class'=>'fas'],
            ['name'=>'شاحنة',               'code'=>'fa-truck',               'class'=>'fas'],
            ['name'=>'كرتون',               'code'=>'fa-boxes-stacked',       'class'=>'fas'],
        ],
        // ─── مكافحة حشرات ───────────────────────────────────────────────
        'pest' => [
            ['name'=>'مكافحة حشرات',        'code'=>'fa-bug',                 'class'=>'fas'],
            ['name'=>'رش مبيدات',           'code'=>'fa-spray-can',           'class'=>'fas'],
            ['name'=>'فأر',                 'code'=>'fa-biohazard',           'class'=>'fas'],
            ['name'=>'حماية',               'code'=>'fa-shield-halved',       'class'=>'fas'],
            ['name'=>'مبيد',                'code'=>'fa-flask',               'class'=>'fas'],
        ],
        // ─── عزل ─────────────────────────────────────────────────────
        'insulation' => [
            ['name'=>'عزل مائي',            'code'=>'fa-droplet-slash',       'class'=>'fas'],
            ['name'=>'عزل حراري',           'code'=>'fa-igloo',               'class'=>'fas'],
            ['name'=>'عزل أسطح',            'code'=>'fa-house',               'class'=>'fas'],
            ['name'=>'عزل فوم',             'code'=>'fa-layer-group',         'class'=>'fas'],
        ],
        // ─── عام ─────────────────────────────────────────────────────
        'general' => [
            ['name'=>'منزل',                'code'=>'fa-house',               'class'=>'fas'],
            ['name'=>'مبنى',               'code'=>'fa-building',             'class'=>'fas'],
            ['name'=>'أدوات',               'code'=>'fa-screwdriver-wrench',  'class'=>'fas'],
            ['name'=>'إصلاح',               'code'=>'fa-hammer',              'class'=>'fas'],
            ['name'=>'ضمان',                'code'=>'fa-certificate',         'class'=>'fas'],
            ['name'=>'تقييم',               'code'=>'fa-star',                'class'=>'fas'],
            ['name'=>'خريطة',               'code'=>'fa-map-marker-alt',      'class'=>'fas'],
            ['name'=>'هاتف',                'code'=>'fa-phone',               'class'=>'fas'],
            ['name'=>'واتساب',              'code'=>'fa-whatsapp',            'class'=>'fab'],
            ['name'=>'ساعة',                'code'=>'fa-clock',               'class'=>'fas'],
            ['name'=>'سعر',                 'code'=>'fa-tag',                 'class'=>'fas'],
            ['name'=>'تقرير',               'code'=>'fa-file-lines',          'class'=>'fas'],
            ['name'=>'فريق',                'code'=>'fa-users',               'class'=>'fas'],
            ['name'=>'خبرة',                'code'=>'fa-award',               'class'=>'fas'],
            ['name'=>'سريع',                'code'=>'fa-rocket',              'class'=>'fas'],
            ['name'=>'أمان',                'code'=>'fa-shield-check',        'class'=>'fas'],
            ['name'=>'جودة',                'code'=>'fa-thumbs-up',           'class'=>'fas'],
            ['name'=>'ملاحظة',              'code'=>'fa-circle-check',        'class'=>'fas'],
            ['name'=>'تحذير',               'code'=>'fa-circle-exclamation',  'class'=>'fas'],
            ['name'=>'معلومات',             'code'=>'fa-circle-info',         'class'=>'fas'],
        ],
    ];

    public function __construct() {
        add_shortcode('rsa_icons', [$this, 'render_shortcode']);
        add_action('wp_ajax_rsa_search_icon', [$this, 'ajax_search']);
    }

    /* ─── Shortcode [rsa_icons category="cleaning"] ─── */
    public function render_shortcode(array $atts): string {
        $atts = shortcode_atts(['category'=>'general', 'cols'=>4], $atts);
        $icons = self::$ICONS[$atts['category']] ?? self::$ICONS['general'];

        ob_start();
        ?>
        <div style="direction:rtl">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:20px 0">
        <?php foreach ($icons as $icon): ?>
            <div style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:15px;text-align:center;cursor:pointer;transition:.2s"
                 onclick="navigator.clipboard.writeText('&lt;i class=\'<?= esc_attr($icon['class']) ?> <?= esc_attr($icon['code']) ?>\'&gt;&lt;/i&gt;').then(function(){ alert('✅ تم نسخ الكود!'); })">
                <i class="<?= esc_attr($icon['class']) ?> <?= esc_attr($icon['code']) ?>" style="font-size:28px;color:#0056b3;display:block;margin-bottom:8px"></i>
                <div style="font-size:13px;font-weight:600;margin-bottom:4px"><?= esc_html($icon['name']) ?></div>
                <code style="font-size:10px;color:#888;direction:ltr;display:block"><?= esc_html($icon['code']) ?></code>
            </div>
        <?php endforeach; ?>
        </div>
        <p style="font-size:12px;color:#888;text-align:center">انقر على الأيقونة لنسخ الكود</p>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ─── Admin page: show all icons ─── */
    public static function render_admin_page(): void {
        ?>
        <div style="direction:rtl;padding:20px">
        <h2><i class="fas fa-icons" style="color:#0056b3;margin-left:10px"></i> مكتبة أيقونات الخدمات المنزلية</h2>
        <p style="color:#555;margin-bottom:20px">انقر على أي أيقونة لنسخ كودها. متوافقة مع Font Awesome 6.</p>

        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:25px">
            <?php foreach (array_keys(self::$ICONS) as $cat): ?>
            <button onclick="filterIcons('<?= esc_js($cat) ?>')"
                    style="padding:8px 18px;border-radius:20px;border:2px solid #0056b3;background:#fff;color:#0056b3;cursor:pointer;font-weight:600;transition:.2s"
                    class="sae-cat-btn" data-cat="<?= esc_attr($cat) ?>">
                <?= esc_html(self::cat_label($cat)) ?>
            </button>
            <?php endforeach; ?>
        </div>

        <input type="text" id="sae-icon-search" placeholder="🔍 ابحث عن أيقونة..."
               style="width:100%;max-width:400px;padding:10px 15px;border:1px solid #ddd;border-radius:8px;margin-bottom:20px;font-size:14px;direction:rtl">

        <?php foreach (self::$ICONS as $cat => $icons): ?>
        <div class="sae-icon-category" data-cat="<?= esc_attr($cat) ?>">
            <h3 style="color:#003366;border-bottom:2px solid #e2e8f0;padding-bottom:8px;margin-bottom:15px">
                <?= esc_html(self::cat_label($cat)) ?>
                <span style="font-size:13px;color:#888;font-weight:normal"> (<?= count($icons) ?> أيقونة)</span>
            </h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;margin-bottom:30px">
            <?php foreach ($icons as $icon): ?>
                <div class="sae-icon-card" data-name="<?= esc_attr($icon['name']) ?>"
                     style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:15px 10px;text-align:center;cursor:pointer;transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.05)"
                     onclick="copyIconCode('<?= esc_js($icon['class']) ?>','<?= esc_js($icon['code']) ?>')"
                     title="انقر للنسخ">
                    <i class="<?= esc_attr($icon['class']) ?> <?= esc_attr($icon['code']) ?>" style="font-size:30px;color:#0056b3;display:block;margin-bottom:8px"></i>
                    <div style="font-size:12px;font-weight:600;color:#2d3748;margin-bottom:3px"><?= esc_html($icon['name']) ?></div>
                    <code style="font-size:10px;color:#6b7280;display:block;direction:ltr;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= esc_html($icon['code']) ?></code>
                </div>
            <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>

        <div id="sae-copy-toast" style="position:fixed;bottom:80px;right:20px;background:#22c55e;color:#fff;padding:12px 20px;border-radius:10px;display:none;z-index:99999;font-weight:bold;box-shadow:0 4px 15px rgba(0,0,0,.2)">
            ✅ تم نسخ الكود!
        </div>
        </div>

        <script>
        function copyIconCode(cls, code){
            var html = '<i class="' + cls + ' ' + code + '"></i>';
            navigator.clipboard.writeText(html).then(function(){
                var toast = document.getElementById('sae-copy-toast');
                toast.textContent = '✅ تم نسخ: ' + code;
                toast.style.display = 'block';
                setTimeout(function(){ toast.style.display='none'; }, 2000);
            });
        }

        function filterIcons(cat){
            document.querySelectorAll('.sae-icon-category').forEach(function(el){
                el.style.display = (cat==='all' || el.dataset.cat===cat) ? 'block' : 'none';
            });
            document.querySelectorAll('.sae-cat-btn').forEach(function(btn){
                btn.style.background = btn.dataset.cat===cat ? '#0056b3' : '#fff';
                btn.style.color      = btn.dataset.cat===cat ? '#fff'    : '#0056b3';
            });
        }

        document.getElementById('sae-icon-search').addEventListener('input', function(){
            var q = this.value.toLowerCase();
            document.querySelectorAll('.sae-icon-card').forEach(function(card){
                var name = card.dataset.name.toLowerCase();
                card.style.display = (q==='' || name.includes(q)) ? '' : 'none';
            });
        });

        // Hover effect
        document.querySelectorAll('.sae-icon-card').forEach(function(card){
            card.addEventListener('mouseenter', function(){ this.style.boxShadow='0 4px 12px rgba(0,86,179,.15)'; this.style.borderColor='#0056b3'; });
            card.addEventListener('mouseleave', function(){ this.style.boxShadow='0 1px 3px rgba(0,0,0,.05)'; this.style.borderColor='#e2e8f0'; });
        });
        </script>
        <?php
    }

    private static function cat_label(string $cat): string {
        $labels = ['cleaning'=>'تنظيف','plumbing'=>'سباكة','electrical'=>'كهرباء','hvac'=>'تكييف','moving'=>'نقل','pest'=>'حشرات','insulation'=>'عزل','general'=>'عام'];
        return $labels[$cat] ?? $cat;
    }

    public function ajax_search(): void {
        $q = strtolower(sanitize_text_field($_POST['q'] ?? ''));
        $results = [];
        foreach (self::$ICONS as $icons) {
            foreach ($icons as $icon) {
                if (str_contains($icon['name'], $q) || str_contains($icon['code'], $q)) {
                    $results[] = $icon;
                }
            }
        }
        wp_send_json_success($results);
    }
}

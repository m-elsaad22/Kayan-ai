<?php
defined('ABSPATH') || exit;

/**
 * RSA_Competitor — تحليل المنافسين
 * يجلب نتائج Google عبر SerpAPI أو يحلل URL مباشرة
 */
class RSA_Competitor {

    private RSA_Claude_API $ai;
    private RSA_DB         $db;

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        $this->db = RSA_DB::instance();
        add_action('wp_ajax_rsa_analyze_competitor', [$this, 'ajax_analyze']);
        add_action('wp_ajax_rsa_analyze_url',        [$this, 'ajax_analyze_url']);
    }

    /** Analyze a competitor URL */
    public function analyze_url(string $url): array {
        $response = wp_remote_get($url, [
            'timeout'    => 15,
            'user-agent' => 'Mozilla/5.0 (compatible; SmartAiBot/1.0)',
        ]);

        if (is_wp_error($response)) return ['error' => $response->get_error_message()];

        $html = wp_remote_retrieve_body($response);
        if (empty($html)) return ['error' => 'empty response'];

        // Extract key elements
        preg_match('/<title[^>]*>([^<]+)<\/title>/i', $html, $title_m);
        preg_match('/<h1[^>]*>([^<]+)<\/h1>/i', $html, $h1_m);
        preg_match_all('/<h2[^>]*>([^<]+)<\/h2>/i', $html, $h2_m);
        preg_match_all('/<h3[^>]*>([^<]+)<\/h3>/i', $html, $h3_m);
        $word_count = str_word_count(wp_strip_all_tags($html));

        // Count FAQs
        preg_match_all('/(?:FAQ|سؤال|question)/i', $html, $faq_m);

        $data = [
            'url'        => $url,
            'title'      => wp_strip_all_tags($title_m[1] ?? ''),
            'h1'         => wp_strip_all_tags($h1_m[1] ?? ''),
            'h2s'        => array_map('wp_strip_all_tags', array_slice($h2_m[1] ?? [], 0, 10)),
            'word_count' => $word_count,
            'faq_count'  => count($faq_m[0]),
        ];

        // AI analysis
        if ($this->ai->is_ready()) {
            $snippet = wp_strip_all_tags($html);
            $snippet = substr($snippet, 0, 2000);
            $prompt  = "حلل هذه الصفحة المنافسة وأعطني JSON:\n"
                . "URL: {$url}\nH1: {$data['h1']}\nH2s: " . implode('،', $data['h2s'])
                . "\nمحتوى: {$snippet}\n\n"
                . "أعطني:\n{\"strengths\":[...],\"weaknesses\":[...],\"keywords\":[...],\"improvements\":[...],\"score\":0-100}";

            $analysis = $this->ai->ask_json($prompt, 800);
            if ($analysis) $data = array_merge($data, $analysis);
        }

        // Save to DB
        $this->db->insert('competitors', [
            'keyword'    => parse_url($url, PHP_URL_HOST),
            'url'        => $url,
            'title'      => $data['title'],
            'h1'         => $data['h1'],
            'word_count' => $data['word_count'],
            'faq_count'  => $data['faq_count'],
            'score'      => (int)($data['score'] ?? 0),
            'raw_data'   => wp_json_encode($data),
            'created_at' => current_time('mysql'),
        ]);

        return $data;
    }

    public function ajax_analyze(): void {
        check_ajax_referer('rsa_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        $kw = sanitize_text_field($_POST['keyword'] ?? '');
        if (!$kw) wp_send_json_error('Keyword required');

        // Without SerpAPI: return mock structure with AI suggestions
        if (!$this->ai->is_ready()) wp_send_json_error('Claude API مطلوب');

        $prompt = "أنت خبير SEO. للكلمة المفتاحية: \"{$kw}\"\nأعطني اقتراحات لتحسين صفحة تتصدر على هذه الكلمة:\n{\"suggestions\":[...],\"must_have_sections\":[...],\"lsi_keywords\":[...],\"title_ideas\":[...]}";
        $data = $this->ai->ask_json($prompt, 800);
        if (!$data) wp_send_json_error('AI analysis failed');
        wp_send_json_success($data);
    }

    public function ajax_analyze_url(): void {
        check_ajax_referer('rsa_admin','nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        $url = esc_url_raw($_POST['url'] ?? '');
        if (!$url) wp_send_json_error('URL required');
        $result = $this->analyze_url($url);
        if (isset($result['error'])) wp_send_json_error($result['error']);
        wp_send_json_success($result);
    }

    public static function render_page(): void {
        global $wpdb;
        $history = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}rsa_competitors ORDER BY id DESC LIMIT 20", ARRAY_A) ?: [];
        ?>
        <div style="direction:rtl;padding:20px">
        <h2>🕵️ تحليل المنافسين</h2>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:25px">
            <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px">
                <h3>تحليل URL منافس</h3>
                <input type="url" id="comp-url" placeholder="https://example.com/page" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:8px;margin-bottom:10px;box-sizing:border-box">
                <button onclick="analyzeURL()" style="background:#0056b3;color:#fff;padding:10px 20px;border:none;border-radius:8px;cursor:pointer;width:100%;font-weight:600">🔍 تحليل الصفحة</button>
            </div>
            <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px">
                <h3>اقتراحات SEO لكلمة مفتاحية</h3>
                <input type="text" id="comp-kw" placeholder="تنظيف منازل دبي" style="width:100%;padding:8px;border:1px solid #ddd;border-radius:8px;margin-bottom:10px;box-sizing:border-box">
                <button onclick="analyzeKW()" style="background:#22c55e;color:#fff;padding:10px 20px;border:none;border-radius:8px;cursor:pointer;width:100%;font-weight:600">🤖 تحليل بـ AI</button>
            </div>
        </div>

        <div id="comp-result" style="margin-bottom:25px"></div>

        <?php if ($history): ?>
        <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px">
            <h3>سجل التحليلات</h3>
            <div style="overflow-x:auto">
            <table style="width:100%;border-collapse:collapse;font-size:13px">
                <thead><tr style="background:#0056b3;color:#fff">
                    <th style="padding:10px;text-align:right">URL</th>
                    <th style="padding:10px">عدد الكلمات</th>
                    <th style="padding:10px">FAQ</th>
                    <th style="padding:10px">النتيجة</th>
                    <th style="padding:10px">التاريخ</th>
                </tr></thead>
                <tbody>
                <?php foreach ($history as $r): ?>
                <tr style="border-bottom:1px solid #e2e8f0">
                    <td style="padding:10px"><a href="<?= esc_url($r['url']) ?>" target="_blank" style="color:#0056b3"><?= esc_html(substr($r['url'],0,50)) ?></a></td>
                    <td style="padding:10px;text-align:center"><?= number_format($r['word_count']) ?></td>
                    <td style="padding:10px;text-align:center"><?= $r['faq_count'] ?></td>
                    <td style="padding:10px;text-align:center"><span style="background:#dbeafe;color:#1d4ed8;padding:2px 10px;border-radius:20px"><?= $r['score'] ?>/100</span></td>
                    <td style="padding:10px;text-align:center"><?= substr($r['created_at'],0,10) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        </div>
        <?php endif; ?>
        </div>
        <script>
        function analyzeURL(){
            var r=document.getElementById('comp-result');
            r.innerHTML='<div style="padding:15px;background:#fff9c4;border-radius:8px">⏳ جاري تحليل الصفحة...</div>';
            jQuery.post(RSA_Admin.ajaxurl,{action:'rsa_analyze_url',nonce:RSA_Admin.nonce,url:document.getElementById('comp-url').value},function(res){
                if(res.success){
                    var d=res.data;
                    r.innerHTML='<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px">'
                    +'<h3 style="margin:0 0 10px">نتيجة التحليل</h3>'
                    +'<p><strong>H1:</strong> '+d.h1+'</p>'
                    +'<p><strong>عدد الكلمات:</strong> '+d.word_count+'</p>'
                    +'<p><strong>FAQ:</strong> '+d.faq_count+'</p>'
                    +(d.improvements?'<h4>التحسينات المقترحة:</h4><ul>'+d.improvements.map(function(i){return '<li>'+i+'</li>';}).join('')+'</ul>':'')
                    +'</div>';
                } else r.innerHTML='<div style="padding:15px;background:#fee2e2;border-radius:8px">❌ '+res.data+'</div>';
            });
        }
        function analyzeKW(){
            var r=document.getElementById('comp-result');
            r.innerHTML='<div style="padding:15px;background:#fff9c4;border-radius:8px">⏳ جاري التحليل بـ AI...</div>';
            jQuery.post(RSA_Admin.ajaxurl,{action:'rsa_analyze_competitor',nonce:RSA_Admin.nonce,keyword:document.getElementById('comp-kw').value},function(res){
                if(res.success){
                    var d=res.data;
                    r.innerHTML='<div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:20px">'
                    +(d.suggestions?'<h4>الاقتراحات:</h4><ul>'+d.suggestions.map(function(i){return '<li>'+i+'</li>';}).join('')+'</ul>':'')
                    +(d.title_ideas?'<h4>عناوين مقترحة:</h4><ul>'+d.title_ideas.map(function(i){return '<li>'+i+'</li>';}).join('')+'</ul>':'')
                    +(d.lsi_keywords?'<h4>LSI Keywords:</h4><p>'+d.lsi_keywords.join(' • ')+'</p>':'')
                    +'</div>';
                } else r.innerHTML='<div style="padding:15px;background:#fee2e2;border-radius:8px">❌ '+res.data+'</div>';
            });
        }
        </script>
        <?php
    }
}

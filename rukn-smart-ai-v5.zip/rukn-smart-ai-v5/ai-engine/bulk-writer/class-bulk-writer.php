<?php
defined('ABSPATH') || exit;

/**
 * RSA_Bulk_Writer — مولّد المقالات الجماعي بالذكاء الاصطناعي
 * يولّد مقالات SEO كاملة لكل تركيبة خدمة × مدينة
 * Author: Mahmoud Elsaad
 */
class RSA_Bulk_Writer {

    private RSA_AI $ai;
    private RSA_DB $db;

    public function __construct() {
        $this->ai = RSA_AI::instance();
        $this->db = RSA_DB::instance();

        add_action('wp_ajax_rsa_bulk_generate_single', [$this, 'ajax_generate_single']);
        add_action('wp_ajax_rsa_bulk_publish_article', [$this, 'ajax_publish_article']);
        add_action('wp_ajax_rsa_bulk_export_csv',      [$this, 'ajax_export_csv']);
    }

    /* ─── توليد مقال واحد ─── */
    public function generate_article(string $service, string $city, array $opts = []): array|false {
        if (!$this->ai->is_ready()) return false;

        $word_count = (int)($opts['word_count'] ?? 2000);
        $tone       = $opts['tone']    ?? 'احترافي ومقنع';
        $country    = get_option('rsa_default_country', 'ae');
        $company    = get_option('rsa_company_name', get_bloginfo('name'));

        $country_labels = ['ae' => 'الإمارات', 'sa' => 'السعودية', 'qa' => 'قطر', 'eg' => 'مصر'];
        $country_name   = $country_labels[$country] ?? $country;

        $prompt = "أنت كاتب محتوى SEO محترف متخصص في خدمات المنازل والشركات في {$country_name}.\n"
            . "اكتب مقالاً SEO احترافياً بالعربية الفصحى:\n\n"
            . "الخدمة: {$service}\nالمدينة: {$city}\nالدولة: {$country_name}\n"
            . "عدد الكلمات: حوالي {$word_count} كلمة\nالأسلوب: {$tone}\nاسم الشركة: {$company}\n\n"
            . "هيكل المقال الإلزامي:\n"
            . "1. في أول سطرين: <!-- META_TITLE: عنوان SEO 60 حرف --> و <!-- META_DESC: وصف SEO 160 حرف -->\n"
            . "2. H1: عنوان جذاب يحتوي \"{$service} في {$city}\"\n"
            . "3. مقدمة قوية 120 كلمة تذكر {$city} مرتين\n"
            . "4. H2: أفضل شركة {$service} في {$city} — 3 فقرات\n"
            . "5. H2: لماذا نحن الخيار الأول؟ — قائمة ul/li بـ 6 مزايا\n"
            . "6. H2: أسعار {$service} في {$city} — جدول HTML مقارنة\n"
            . "7. H2: مناطق خدمتنا في {$city} — ذكر 5 أحياء\n"
            . "8. blockquote: شهادة عميل من {$city}\n"
            . "9. H2: أسئلة شائعة — 5 أسئلة/أجوبة بتنسيق details/summary\n"
            . "10. خاتمة مع CTA للاتصال/واتساب\n"
            . "11. في النهاية: Schema FAQ JSON-LD داخل <script type=\"application/ld+json\">\n\n"
            . "اذكر \"{$city}\" 10+ مرات و\"{$service}\" 8+ مرات بشكل طبيعي.\n"
            . "أرجع HTML فقط. لا شرح ولا ماركداون.";

        $content = $this->ai->ask($prompt, 4000);
        if (!$content) return false;

        preg_match('/<!--\s*META_TITLE:\s*(.+?)\s*-->/i', $content, $tm);
        preg_match('/<!--\s*META_DESC:\s*(.+?)\s*-->/i',  $content, $dm);

        $meta_title = trim($tm[1] ?? "{$service} في {$city} | {$company}");
        $meta_desc  = trim($dm[1] ?? "احصل على أفضل خدمة {$service} في {$city}. اتصل بنا للحصول على عرض سعر مجاني.");
        $html       = trim(preg_replace('/<!--\s*META_(?:TITLE|DESC):.+?-->/i', '', $content));
        $slug       = RSA_Helper::instance()->arabic_to_slug("{$service}-{$city}");

        $this->db->log('bulk_writer', 'generate', 0, $word_count, 'ok', "{$service} × {$city}");

        return [
            'service'      => $service,
            'city'         => $city,
            'html'         => $html,
            'meta_title'   => $meta_title,
            'meta_desc'    => $meta_desc,
            'slug'         => $slug,
            'word_count'   => str_word_count(wp_strip_all_tags($html)),
            'generated_at' => current_time('mysql'),
        ];
    }

    /* ─── نشر المقال في WordPress ─── */
    public function publish_article(array $article, string $category = ''): int|false {
        $post_data = [
            'post_title'   => wp_strip_all_tags($article['meta_title'] ?? "{$article['service']} في {$article['city']}"),
            'post_content' => $article['html'] ?? '',
            'post_status'  => 'draft',
            'post_name'    => sanitize_title($article['slug'] ?? ''),
            'post_type'    => 'post',
        ];

        if ($category) {
            $term    = get_term_by('name', $category, 'category');
            $term_id = $term ? $term->term_id : (wp_insert_term($category, 'category')['term_id'] ?? 0);
            if ($term_id) $post_data['post_category'] = [$term_id];
        }

        $post_id = wp_insert_post($post_data);
        if (is_wp_error($post_id)) return false;

        global $wpdb;
        $wpdb->replace($wpdb->prefix . 'rsa_seo', [
            'post_id'    => $post_id,
            'meta_title' => $article['meta_title'] ?? '',
            'meta_desc'  => $article['meta_desc'] ?? '',
            'focus_kw'   => ($article['service'] ?? '') . ' ' . ($article['city'] ?? ''),
            'last_ai'    => current_time('mysql'),
        ]);

        $this->db->insert('local_pages', [
            'city'       => $article['city'] ?? '',
            'service'    => $article['service'] ?? '',
            'post_id'    => $post_id,
            'generated'  => 1,
            'created_at' => current_time('mysql'),
        ]);

        return $post_id;
    }

    /* ─── AJAX Handlers ─── */
    public function ajax_generate_single(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $service    = sanitize_text_field($_POST['service']    ?? '');
        $city       = sanitize_text_field($_POST['city']       ?? '');
        $word_count = (int)($_POST['word_count'] ?? 2000);
        $tone       = sanitize_text_field($_POST['tone']       ?? 'احترافي ومقنع');

        if (!$service || !$city) wp_send_json_error('الخدمة والمدينة مطلوبان');
        if (!$this->ai->is_ready()) wp_send_json_error('AI غير متصل — أضف مفتاح API في الإعدادات');

        $result = $this->generate_article($service, $city, compact('word_count', 'tone'));
        if (!$result) wp_send_json_error('فشل التوليد — حاول مرة أخرى');

        wp_send_json_success($result);
    }

    public function ajax_publish_article(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('publish_posts')) wp_send_json_error('Unauthorized');

        $article = [
            'html'       => $_POST['html']       ?? '',
            'service'    => sanitize_text_field($_POST['service']    ?? ''),
            'city'       => sanitize_text_field($_POST['city']       ?? ''),
            'meta_title' => sanitize_text_field($_POST['meta_title'] ?? ''),
            'meta_desc'  => sanitize_text_field($_POST['meta_desc']  ?? ''),
            'slug'       => sanitize_title($_POST['slug']            ?? ''),
        ];
        $category = sanitize_text_field($_POST['category'] ?? '');

        $post_id = $this->publish_article($article, $category);
        if (!$post_id) wp_send_json_error('فشل النشر');

        wp_send_json_success([
            'post_id'  => $post_id,
            'edit_url' => get_edit_post_link($post_id, 'raw'),
            'view_url' => get_permalink($post_id),
        ]);
    }

    public function ajax_export_csv(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $articles = json_decode(stripslashes($_POST['articles'] ?? '[]'), true);
        if (!$articles) wp_send_json_error('لا توجد مقالات');

        $rows   = [];
        $rows[] = implode("\t", ['الخدمة', 'المدينة', 'Meta Title', 'Meta Description', 'المحتوى HTML', 'عدد الكلمات']);
        foreach ($articles as $a) {
            $rows[] = implode("\t", [
                $a['service']    ?? '',
                $a['city']       ?? '',
                $a['meta_title'] ?? '',
                $a['meta_desc']  ?? '',
                str_replace(["\t", "\n", "\r"], ' ', $a['html'] ?? ''),
                $a['word_count'] ?? 0,
            ]);
        }

        wp_send_json_success(['csv' => "\xEF\xBB\xBF" . implode("\n", $rows), 'count' => count($articles)]);
    }

    /* ─── صفحة الإدارة ─── */
    public static function render_page(): void {
        $ai      = RSA_AI::instance();
        $country = get_option('rsa_default_country', 'ae');
        $cities  = RSA_Local_SEO::$CITIES[$country] ?? [];
        ?>
        <div class="rsa-wrap">
        <div class="rsa-header">
            <div class="rsa-header-inner">
                <div class="rsa-header-brand">
                    <div class="rsa-header-logo">✍️</div>
                    <div>
                        <h1>مولّد المقالات الجماعي <span class="rsa-version-badge">v4.0</span></h1>
                        <p>أدخل الخدمات والمدن — AI يولّد مقال SEO كامل (HTML + Schema + Meta) لكل تركيبة</p>
                    </div>
                </div>
                <div class="rsa-ai-status">
                    <span class="rsa-ai-dot <?= $ai->is_ready() ? '' : 'off' ?>"></span>
                    <?= $ai->is_ready() ? esc_html($ai->active_provider_name()) : 'AI غير متصل' ?>
                </div>
            </div>
        </div>

        <?php if (!$ai->is_ready()): ?>
        <div class="rsa-notice">
            <span class="rsa-notice-icon">⚠️</span>
            <div><strong>AI غير مكوّن</strong> — أضف مفتاح من <a href="<?= admin_url('admin.php?page=rukn-settings') ?>">الإعدادات</a>. Gemini مجاني من <a href="https://makersuite.google.com/app/apikey" target="_blank">Google AI Studio</a></div>
        </div>
        <?php endif; ?>

        <div class="rsa-section">
            <h2>⚙️ إعداد المولّد</h2>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
                <div>
                    <label class="rsa-form-label">📦 الخدمات <small>(كل سطر = خدمة واحدة)</small></label>
                    <textarea id="bw-services" class="rsa-input" rows="7" style="resize:vertical;font-family:inherit" placeholder="تنظيف مكيفات&#10;كشف تسربات مياه&#10;مكافحة حشرات&#10;نقل عفش&#10;عزل أسطح&#10;تنظيف خزانات"></textarea>
                    <div id="bw-services-tags" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;min-height:28px"></div>
                </div>
                <div>
                    <label class="rsa-form-label">🏙️ المدن <small>(كل سطر = مدينة)</small></label>
                    <textarea id="bw-cities" class="rsa-input" rows="7" style="resize:vertical;font-family:inherit" placeholder="الرياض&#10;جدة&#10;دبي&#10;الدوحة&#10;أبوظبي&#10;الشارقة"></textarea>
                    <?php if ($cities): ?>
                    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
                        <?php foreach (array_slice($cities, 0, 12) as $c): ?>
                        <button class="bw-chip" onclick="bwAddCity('<?= esc_js($c['name_ar']) ?>')">+ <?= esc_html($c['name_ar']) ?></button>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:14px;margin-top:18px">
                <div>
                    <label class="rsa-form-label">📝 عدد الكلمات</label>
                    <select id="bw-wc" class="rsa-input">
                        <option value="1500">١٥٠٠ كلمة</option>
                        <option value="2000" selected>٢٠٠٠ كلمة</option>
                        <option value="3000">٣٠٠٠ كلمة</option>
                        <option value="4000">٤٠٠٠ كلمة</option>
                    </select>
                </div>
                <div>
                    <label class="rsa-form-label">🎯 الأسلوب</label>
                    <select id="bw-tone" class="rsa-input">
                        <option value="احترافي ومقنع">احترافي ومقنع</option>
                        <option value="ودي وبسيط">ودي وبسيط</option>
                        <option value="تسويقي وجذاب">تسويقي وجذاب</option>
                        <option value="رسمي وأكاديمي">رسمي وأكاديمي</option>
                    </select>
                </div>
                <div>
                    <label class="rsa-form-label">📂 فئة WordPress</label>
                    <input id="bw-cat" class="rsa-input" placeholder="مثال: خدمات المنازل">
                </div>
                <div>
                    <label class="rsa-form-label">⏱️ تأخير بين المقالات</label>
                    <select id="bw-delay" class="rsa-input">
                        <option value="2000">٢ ثانية</option>
                        <option value="3000" selected>٣ ثواني</option>
                        <option value="5000">٥ ثواني</option>
                    </select>
                </div>
            </div>

            <div id="bw-summary-bar" style="display:none;background:linear-gradient(135deg,#eff6ff,#f0fdf4);border:1px solid #bfdbfe;border-radius:10px;padding:14px 20px;margin-top:16px;display:none;align-items:center;gap:12px;font-weight:600">
                <span id="bw-total" style="font-size:36px;font-weight:900;color:var(--rsa-primary);line-height:1">0</span>
                مقال سيُولَّد
                (<span id="bw-n-svc">0</span> خدمة × <span id="bw-n-cit">0</span> مدينة)
            </div>

            <div style="display:flex;gap:10px;margin-top:20px;flex-wrap:wrap;align-items:center">
                <button id="bw-start" class="rsa-btn rsa-btn-primary rsa-btn-lg" onclick="bwStart()" <?= !$ai->is_ready() ? 'disabled' : '' ?>>
                    🚀 ابدأ التوليد
                </button>
                <button id="bw-stop" class="rsa-btn rsa-btn-sm" style="display:none;background:#ef4444;color:#fff" onclick="bwStop()">⏹ إيقاف</button>
                <button id="bw-export" class="rsa-btn rsa-btn-outline" style="display:none" onclick="bwExport()">📥 تصدير TSV</button>
                <button id="bw-pub-all" class="rsa-btn rsa-btn-green" style="display:none" onclick="bwPublishAll()">🌐 نشر الكل كمسودات</button>
            </div>
        </div>

        <!-- Progress -->
        <div id="bw-prog-wrap" class="rsa-section" style="display:none">
            <h2>📊 التقدم</h2>
            <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px">
                <span id="bw-prog-label" style="color:var(--rsa-text-soft)">جاري التوليد...</span>
                <span id="bw-prog-pct" style="color:var(--rsa-primary);font-weight:700">0%</span>
            </div>
            <div class="rsa-progress" style="height:14px;margin-bottom:18px"><div class="rsa-progress-bar" id="bw-prog-bar" style="width:0"></div></div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
                <div style="background:#f0fdf4;border:1px solid #a7f3d0;border-radius:10px;padding:14px;text-align:center">
                    <div id="bw-n-done" style="font-size:28px;font-weight:900;color:#065f46">0</div>
                    <small style="color:var(--rsa-text-soft)">مكتمل ✅</small>
                </div>
                <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:10px;padding:14px;text-align:center">
                    <div id="bw-n-run" style="font-size:28px;font-weight:900;color:#1d4ed8">—</div>
                    <small style="color:var(--rsa-text-soft)">جاري 🔄</small>
                </div>
                <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:14px;text-align:center">
                    <div id="bw-n-err" style="font-size:28px;font-weight:900;color:#991b1b">0</div>
                    <small style="color:var(--rsa-text-soft)">خطأ ❌</small>
                </div>
                <div style="background:#fffbeb;border:1px solid #fde68a;border-radius:10px;padding:14px;text-align:center">
                    <div id="bw-n-pend" style="font-size:28px;font-weight:900;color:#78350f">0</div>
                    <small style="color:var(--rsa-text-soft)">منتظر ⏳</small>
                </div>
            </div>
        </div>

        <!-- Cards -->
        <div id="bw-list"></div>
        </div>

        <style>
        .bw-chip{background:none;border:1px dashed var(--rsa-primary);color:var(--rsa-primary);border-radius:20px;padding:3px 12px;font-size:12px;cursor:pointer;transition:all .2s}
        .bw-chip:hover{background:var(--rsa-primary);color:#fff}
        .bw-card{background:#fff;border:1px solid var(--rsa-border);border-radius:var(--rsa-radius);margin-bottom:12px;overflow:hidden}
        .bw-card-head{padding:13px 18px;display:flex;align-items:center;justify-content:space-between;cursor:pointer;gap:10px}
        .bw-card-body{border-top:1px solid var(--rsa-border);padding:18px 20px;display:none}
        .bw-card-body.open{display:block}
        .bw-preview{background:var(--rsa-bg);border:1px solid var(--rsa-border);border-radius:8px;padding:16px;max-height:380px;overflow-y:auto;font-size:13px;line-height:1.8;direction:rtl}
        .bw-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0;display:inline-block}
        .bw-dot-p{background:#fbbf24}.bw-dot-r{background:#3b82f6;animation:rsaPulse 1s infinite}.bw-dot-d{background:#22c55e}.bw-dot-e{background:#ef4444}
        .rsa-form-label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:var(--rsa-text-soft)}
        </style>

        <script>
        (function(){
            var Q=[], R={}, stopped=false, done=0, errs=0, cur=-1;

            function lines(id){ return document.getElementById(id).value.split('\n').map(s=>s.trim()).filter(Boolean); }

            function sync(){
                var sv=lines('bw-services'), ci=lines('bw-cities'), tot=sv.length*ci.length;
                var bar=document.getElementById('bw-summary-bar');
                bar.style.display=tot>0?'flex':'none';
                document.getElementById('bw-total').textContent=tot;
                document.getElementById('bw-n-svc').textContent=sv.length;
                document.getElementById('bw-n-cit').textContent=ci.length;
                var tp=document.getElementById('bw-services-tags');
                tp.innerHTML=sv.map(s=>'<span style="background:var(--rsa-bg);border:1px solid var(--rsa-border);border-radius:6px;padding:3px 10px;font-size:12px">'+esc(s)+'</span>').join('');
            }
            document.getElementById('bw-services').addEventListener('input',sync);
            document.getElementById('bw-cities').addEventListener('input',sync);

            window.bwAddCity=function(c){
                var ta=document.getElementById('bw-cities'), ls=ta.value.split('\n').map(s=>s.trim()).filter(Boolean);
                if(!ls.includes(c)){ta.value=(ta.value.trim()?ta.value.trim()+'\n':'')+c;sync();}
            };

            window.bwStart=function(){
                var sv=lines('bw-services'), ci=lines('bw-cities');
                if(!sv.length||!ci.length){alert('أدخل الخدمات والمدن أولاً');return;}
                Q=[];R={};done=0;errs=0;cur=-1;stopped=false;
                sv.forEach(s=>ci.forEach(c=>Q.push({service:s,city:c,status:'pending'})));
                document.getElementById('bw-prog-wrap').style.display='block';
                document.getElementById('bw-start').style.display='none';
                document.getElementById('bw-stop').style.display='';
                document.getElementById('bw-export').style.display='none';
                document.getElementById('bw-pub-all').style.display='none';
                document.getElementById('bw-list').innerHTML='';
                Q.forEach(function(it,i){renderCard(it,i,'p');});
                updProg();next();
            };

            window.bwStop=function(){stopped=true;document.getElementById('bw-prog-label').textContent='تم الإيقاف';showPost();};

            function next(){
                if(stopped)return;
                cur++;
                if(cur>=Q.length){finish();return;}
                var it=Q[cur], delay=parseInt(document.getElementById('bw-delay').value)||3000;
                it.status='running';updCard(cur,'r');updProg();
                jQuery.post(RSA_Admin.ajaxurl,{
                    action:'rsa_bulk_generate_single',nonce:RSA_Admin.nonce,
                    service:it.service,city:it.city,
                    word_count:document.getElementById('bw-wc').value,
                    tone:document.getElementById('bw-tone').value
                },function(r){
                    if(r.success){it.status='done';R[cur]=r.data;updCard(cur,'d',r.data);done++;}
                    else{it.status='error';it.err=r.data;updCard(cur,'e',null,r.data);errs++;}
                    updProg();setTimeout(next,stopped?0:delay);
                }).fail(function(){it.status='error';it.err='فشل الاتصال';updCard(cur,'e',null,'فشل الاتصال');errs++;updProg();setTimeout(next,2000);});
            }

            function finish(){
                document.getElementById('bw-prog-label').textContent='اكتمل! '+done+' مقال';
                document.getElementById('bw-start').style.display='';
                document.getElementById('bw-stop').style.display='none';
                showPost();
            }
            function showPost(){
                var has=Object.keys(R).length>0;
                document.getElementById('bw-export').style.display=has?'':'none';
                document.getElementById('bw-pub-all').style.display=has?'':'none';
            }

            function updProg(){
                var tot=Q.length, fin=Q.filter(i=>i.status==='done'||i.status==='error').length;
                var pct=tot>0?Math.round(fin/tot*100):0;
                document.getElementById('bw-prog-bar').style.width=pct+'%';
                document.getElementById('bw-prog-pct').textContent=pct+'%';
                document.getElementById('bw-prog-label').textContent=fin+' / '+tot+' مقال';
                document.getElementById('bw-n-done').textContent=done;
                document.getElementById('bw-n-run').textContent=Q.filter(i=>i.status==='running').length?'⏳':'—';
                document.getElementById('bw-n-err').textContent=errs;
                document.getElementById('bw-n-pend').textContent=Q.filter(i=>i.status==='pending').length;
            }

            function renderCard(it,i,s){
                var el=document.createElement('div');el.className='bw-card';el.id='bw-c-'+i;
                el.innerHTML=cardHTML(it,i,s);document.getElementById('bw-list').appendChild(el);
            }
            function updCard(i,s,data,err){
                var el=document.getElementById('bw-c-'+i);
                if(el)el.innerHTML=cardHTML(Q[i],i,s,data,err);
            }

            function cardHTML(it,i,s,data,err){
                var dots={p:'bw-dot-p',r:'bw-dot-r',d:'bw-dot-d',e:'bw-dot-e'};
                var badges={
                    p:'<span class="rsa-badge rsa-badge-orange">⏳ منتظر</span>',
                    r:'<span class="rsa-badge rsa-badge-blue">🔄 جاري</span>',
                    d:'<span class="rsa-badge rsa-badge-green">✅ مكتمل</span>',
                    e:'<span class="rsa-badge rsa-badge-red">❌ خطأ</span>'
                };
                var acts='', body='';
                if(s==='d'&&data){
                    acts='<button class="rsa-btn rsa-btn-outline rsa-btn-sm" onclick="bwToggle('+i+')">👁 معاينة</button>'
                        +'<button class="rsa-btn rsa-btn-primary rsa-btn-sm" onclick="bwCopy('+i+')">📋 نسخ HTML</button>'
                        +'<button class="rsa-btn rsa-btn-green rsa-btn-sm" onclick="bwPubOne('+i+')">🌐 نشر كمسودة</button>';
                    body='<div class="bw-card-body" id="bw-b-'+i+'">'
                        +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">'
                        +'<div style="background:var(--rsa-bg);border-radius:8px;padding:10px;font-size:12px"><strong style="display:block;color:var(--rsa-text-soft);margin-bottom:3px">Meta Title</strong>'+esc(data.meta_title)+'</div>'
                        +'<div style="background:var(--rsa-bg);border-radius:8px;padding:10px;font-size:12px"><strong style="display:block;color:var(--rsa-text-soft);margin-bottom:3px">Meta Description</strong>'+esc(data.meta_desc)+'</div>'
                        +'<div style="background:var(--rsa-bg);border-radius:8px;padding:10px;font-size:12px"><strong style="display:block;color:var(--rsa-text-soft);margin-bottom:3px">Slug</strong>'+esc(data.slug)+'</div>'
                        +'<div style="background:var(--rsa-bg);border-radius:8px;padding:10px;font-size:12px"><strong style="display:block;color:var(--rsa-text-soft);margin-bottom:3px">عدد الكلمات</strong>'+data.word_count+'</div>'
                        +'</div>'
                        +'<div class="bw-preview">'+data.html+'</div>'
                        +'</div>';
                }else if(s==='e'){
                    acts='<button class="rsa-btn rsa-btn-primary rsa-btn-sm" onclick="bwRetry('+i+')">🔄 إعادة</button>';
                    body='<div style="padding:10px 18px;color:#991b1b;font-size:13px">❌ '+(err||'خطأ')+'</div>';
                }
                return '<div class="bw-card-head" onclick="bwToggle('+i+')">'
                    +'<div style="display:flex;align-items:center;gap:10px">'
                    +'<span class="bw-dot '+dots[s]+'"></span>'
                    +'<span class="rsa-badge rsa-badge-blue" style="font-size:11px">#'+(i+1)+'</span>'
                    +'<strong style="font-size:14px">'+esc(it.service)+' — '+esc(it.city)+'</strong>'
                    +'</div>'
                    +'<div style="display:flex;align-items:center;gap:7px">'+acts+badges[s]+'</div>'
                    +'</div>'+body;
            }

            window.bwToggle=function(i){var b=document.getElementById('bw-b-'+i);if(b)b.classList.toggle('open');};
            window.bwCopy=function(i){var d=R[i];if(d&&navigator.clipboard)navigator.clipboard.writeText(d.html).then(()=>alert('✅ تم نسخ HTML ('+d.word_count+' كلمة)'));};
            window.bwPubOne=function(i){
                var d=R[i],cat=document.getElementById('bw-cat').value;
                if(!d||!confirm('نشر: '+d.service+' — '+d.city+'؟'))return;
                jQuery.post(RSA_Admin.ajaxurl,jQuery.extend({action:'rsa_bulk_publish_article',nonce:RSA_Admin.nonce,category:cat},d),function(r){
                    if(r.success)alert('✅ تم النشر!\nرابط التعديل: '+r.data.edit_url);
                    else alert('❌ '+r.data);
                });
            };
            window.bwPublishAll=function(){
                var ks=Object.keys(R);if(!ks.length){alert('لا توجد مقالات مكتملة');return;}
                if(!confirm('نشر '+ks.length+' مقال كمسودات؟'))return;
                var cat=document.getElementById('bw-cat').value,done=0;
                ks.forEach(function(k,n){
                    setTimeout(function(){
                        jQuery.post(RSA_Admin.ajaxurl,jQuery.extend({action:'rsa_bulk_publish_article',nonce:RSA_Admin.nonce,category:cat},R[k]),function(r){
                            done++;if(done===ks.length)alert('✅ تم نشر '+done+' مقال كمسودات');
                        });
                    },n*600);
                });
            };
            window.bwExport=function(){
                var arts=Object.values(R);if(!arts.length){alert('لا توجد مقالات');return;}
                jQuery.post(RSA_Admin.ajaxurl,{action:'rsa_bulk_export_csv',nonce:RSA_Admin.nonce,articles:JSON.stringify(arts)},function(r){
                    if(r.success){
                        var b=new Blob([r.data.csv],{type:'text/plain;charset=utf-8'});
                        var a=document.createElement('a');a.href=URL.createObjectURL(b);
                        a.download='bulk-articles-'+(new Date().toISOString().slice(0,10))+'.txt';a.click();
                    }
                });
            };
            window.bwRetry=function(i){
                cur=i-1;Q[i].status='pending';updCard(i,'p');stopped=false;next();
            };

            function esc(s){return (s||'').toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
        })();
        </script>
        <?php
    }
}

<?php
defined('ABSPATH') || exit;

/**
 * RSA_Tracker — تتبع شامل للزيارات
 * IP, City, Device, Browser, OS, Screen, Scroll, Time, Clicks, UTM, Intent
 */
class RSA_Tracker {

    private RSA_DB     $db;
    private RSA_Helper $helper;

    public function __construct() {
        $this->db     = RSA_DB::instance();
        $this->helper = RSA_Helper::instance();

        add_action('wp_footer',              [$this, 'inject_tracker_script']);
        add_action('wp_ajax_rsa_track',      [$this, 'ajax_track']);
        add_action('wp_ajax_nopriv_rsa_track',[$this,'ajax_track']);
        add_action('template_redirect',      [$this, 'server_side_track'], 999);
    }

    /* ─── Server-side: record page view immediately ─── */
    public function server_side_track(): void {
        if (is_admin() || is_robots() || is_feed() || is_preview()) return;
        if (!is_singular() && !is_archive() && !is_home()) return;

        // Exclude bots
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (preg_match('/bot|crawl|spider|slurp|facebookexternalhit/i', $ua)) return;

        $ip     = $this->helper->get_ip();
        $geo    = $this->helper->get_city($ip);
        $device = $this->helper->get_device();
        $utm    = $this->helper->get_utm();
        $sid    = $this->helper->session_id();

        // Detect browser & OS
        $browser = $this->detect_browser($ua);
        $os      = $this->detect_os($ua);

        $this->db->insert('visits', [
            'session_id'   => $sid,
            'post_id'      => is_singular() ? get_the_ID() : 0,
            'page_url'     => (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
            'referrer'     => sanitize_url($_SERVER['HTTP_REFERER'] ?? ''),
            'ip'           => $ip,
            'city'         => $geo['city'],
            'country'      => $geo['country'],
            'device'       => $device,
            'browser'      => $browser,
            'os'           => $os,
            'utm_source'   => $utm['source'],
            'utm_medium'   => $utm['medium'],
            'utm_campaign' => $utm['campaign'],
            'created_at'   => current_time('mysql'),
        ]);
    }

    /* ─── JS Tracker (scroll, time, clicks, intent) ─── */
    public function inject_tracker_script(): void {
        if (is_admin()) return;
        ?>
        <script>
        (function(){
          'use strict';
          var SAE = {
            sid: '<?= esc_js($this->helper->session_id()) ?>',
            ajaxurl: '<?= esc_url(admin_url('admin-ajax.php')) ?>',
            startTime: Date.now(),
            maxScroll: 0,
            clicks: 0,
            sent: false,

            init: function(){
              window.addEventListener('scroll', SAE.onScroll, {passive:true});
              document.addEventListener('click', SAE.onClick, {passive:true});
              window.addEventListener('beforeunload', SAE.send);
              setTimeout(SAE.send, 45000); // Auto-send after 45s
            },

            onScroll: function(){
              var scrolled = (window.scrollY + window.innerHeight) / document.body.scrollHeight * 100;
              if(scrolled > SAE.maxScroll) SAE.maxScroll = Math.round(scrolled);
            },

            onClick: function(e){
              SAE.clicks++;
            },

            detectIntent: function(scroll, time){
              if(time > 60 && scroll > 70) return 'buying';
              if(time > 30 && scroll > 40) return 'reading';
              if(scroll < 20 && time < 10) return 'bounce';
              return 'browsing';
            },

            send: function(){
              if(SAE.sent) return;
              SAE.sent = true;
              var time   = Math.round((Date.now() - SAE.startTime) / 1000);
              var intent = SAE.detectIntent(SAE.maxScroll, time);
              var body   = new FormData();
              body.append('action',     'rsa_track');
              body.append('sid',        SAE.sid);
              body.append('scroll_pct', SAE.maxScroll);
              body.append('time_sec',   time);
              body.append('clicks',     SAE.clicks);
              body.append('intent',     intent);
              body.append('screen_w',   screen.width);
              // Use sendBeacon for reliability on unload
              if(navigator.sendBeacon){
                var blob = new Blob([new URLSearchParams(body).toString()], {type:'application/x-www-form-urlencoded'});
                navigator.sendBeacon(SAE.ajaxurl, blob);
              } else {
                fetch(SAE.ajaxurl, {method:'POST', body:body, keepalive:true});
              }
            }
          };
          SAE.init();
        })();
        </script>
        <?php
    }

    /* ─── AJAX: update visit with JS data ─── */
    public function ajax_track(): void {
        $sid       = sanitize_text_field($_POST['sid']        ?? '');
        $scroll    = absint($_POST['scroll_pct'] ?? 0);
        $time      = absint($_POST['time_sec']   ?? 0);
        $clicks    = absint($_POST['clicks']      ?? 0);
        $intent    = sanitize_text_field($_POST['intent']     ?? '');
        $screen_w  = absint($_POST['screen_w']    ?? 0);

        if (!$sid) wp_send_json_success(); // silent

        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}rsa_visits
             SET scroll_pct=%d, time_sec=%d, clicks=%d, intent=%s, screen_w=%d
             WHERE session_id=%s ORDER BY id DESC LIMIT 1",
            $scroll, $time, $clicks, $intent, $screen_w, $sid
        ));

        wp_send_json_success();
    }

    /* ─── Analytics: get stats ─── */
    public function get_stats(int $days = 30): array {
        global $wpdb;
        $since = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        $t     = $wpdb->prefix . 'rsa_visits';

        return [
            'total_visits'    => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE created_at >= %s", $since)),
            'unique_sessions' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT session_id) FROM {$t} WHERE created_at >= %s", $since)),
            'top_cities'      => $wpdb->get_results($wpdb->prepare("SELECT city, COUNT(*) as cnt FROM {$t} WHERE created_at >= %s GROUP BY city ORDER BY cnt DESC LIMIT 10", $since), ARRAY_A),
            'by_device'       => $wpdb->get_results($wpdb->prepare("SELECT device, COUNT(*) as cnt FROM {$t} WHERE created_at >= %s GROUP BY device", $since), ARRAY_A),
            'by_intent'       => $wpdb->get_results($wpdb->prepare("SELECT intent, COUNT(*) as cnt FROM {$t} WHERE created_at >= %s GROUP BY intent", $since), ARRAY_A),
            'by_source'       => $wpdb->get_results($wpdb->prepare("SELECT utm_source, COUNT(*) as cnt FROM {$t} WHERE created_at >= %s AND utm_source != '' GROUP BY utm_source ORDER BY cnt DESC LIMIT 10", $since), ARRAY_A),
            'avg_scroll'      => (float)$wpdb->get_var($wpdb->prepare("SELECT AVG(scroll_pct) FROM {$t} WHERE created_at >= %s AND scroll_pct > 0", $since)),
            'avg_time'        => (float)$wpdb->get_var($wpdb->prepare("SELECT AVG(time_sec) FROM {$t} WHERE created_at >= %s AND time_sec > 0", $since)),
            'top_pages'       => $wpdb->get_results($wpdb->prepare("SELECT post_id, COUNT(*) as cnt FROM {$t} WHERE created_at >= %s AND post_id > 0 GROUP BY post_id ORDER BY cnt DESC LIMIT 10", $since), ARRAY_A),
            'buying_intent'   => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE intent='buying' AND created_at >= %s", $since)),
        ];
    }

    /* ─── Recent visits ─── */
    public function get_recent(int $limit = 50): array {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}rsa_visits ORDER BY created_at DESC LIMIT %d", $limit),
            ARRAY_A
        ) ?: [];
    }

    private function detect_browser(string $ua): string {
        if (str_contains($ua, 'Chrome'))  return 'Chrome';
        if (str_contains($ua, 'Firefox')) return 'Firefox';
        if (str_contains($ua, 'Safari'))  return 'Safari';
        if (str_contains($ua, 'Edge'))    return 'Edge';
        return 'Other';
    }

    private function detect_os(string $ua): string {
        if (str_contains($ua, 'Windows')) return 'Windows';
        if (str_contains($ua, 'Mac'))     return 'macOS';
        if (str_contains($ua, 'iPhone'))  return 'iOS';
        if (str_contains($ua, 'Android')) return 'Android';
        if (str_contains($ua, 'Linux'))   return 'Linux';
        return 'Other';
    }
}

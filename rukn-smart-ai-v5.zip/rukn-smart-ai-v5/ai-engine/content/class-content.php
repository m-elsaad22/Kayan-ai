<?php
defined('ABSPATH') || exit;

/**
 * RSA_Content — نظام كتابة المحتوى بـ AI
 * - قوالب جاهزة لكل خدمة
 * - توليد مقال HTML كامل بمعيار SEO
 * - إضافة تلقائية لـ [post_services], [post_features], [post_steps]
 */
class RSA_Content {

    private RSA_Claude_API $ai;

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        add_action('wp_ajax_rsa_gen_article', [$this, 'ajax_gen_article']);
        add_action('add_meta_boxes', [$this, 'add_metabox']);
    }

    public function add_metabox(): void {
        add_meta_box('sae-content-box', '✍️ SmartAi Content Writer', [$this, 'render_metabox'],
            ['post','page'], 'side', 'high');
    }

    public function render_metabox(WP_Post $post): void {
        ?>
        <div style="direction:rtl;font-size:13px">
            <div style="margin-bottom:10px">
                <label style="font-weight:bold;display:block;margin-bottom:4px">المدينة</label>
                <input type="text" id="rsa_content_city" placeholder="دبي" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:6px;box-sizing:border-box">
            </div>
            <div style="margin-bottom:10px">
                <label style="font-weight:bold;display:block;margin-bottom:4px">الكلمة المفتاحية</label>
                <input type="text" id="rsa_content_kw" placeholder="تنظيف منازل" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:6px;box-sizing:border-box">
            </div>
            <div style="margin-bottom:12px">
                <label style="font-weight:bold;display:block;margin-bottom:4px">القالب</label>
                <select id="rsa_content_template" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:6px;box-sizing:border-box">
                    <option value="service">صفحة خدمة</option>
                    <option value="city">صفحة مدينة</option>
                    <option value="how-to">كيف تفعل</option>
                    <option value="compare">مقارنة</option>
                    <option value="review">مراجعة</option>
                </select>
            </div>
            <button type="button" id="rsa_gen_content_btn"
                    style="width:100%;background:#0056b3;color:#fff;padding:9px;border:none;border-radius:8px;cursor:pointer;font-weight:bold;font-size:13px">
                🤖 توليد المحتوى بـ AI
            </button>
            <div id="rsa_content_status" style="margin-top:8px;font-size:12px"></div>
        </div>
        <script>
        document.getElementById('rsa_gen_content_btn').addEventListener('click', function(){
            var btn = this;
            var city = document.getElementById('rsa_content_city').value;
            var kw   = document.getElementById('rsa_content_kw').value;
            var tpl  = document.getElementById('rsa_content_template').value;
            var status = document.getElementById('rsa_content_status');

            if(!kw){ status.innerHTML='<span style="color:#ef4444">أدخل الكلمة المفتاحية</span>'; return; }

            btn.disabled=true; btn.textContent='⏳ جاري التوليد...';
            status.innerHTML='<span style="color:#888">Claude AI يكتب المحتوى... (30-60 ثانية)</span>';

            jQuery.post(ajaxurl, {
                action:'rsa_gen_article',
                nonce:'<?= wp_create_nonce("rsa_content") ?>',
                post_id:'<?= $post->ID ?>',
                city:city, kw:kw, template:tpl
            }, function(r){
                if(r.success){
                    // Inject into WP editor
                    if(typeof wp !== 'undefined' && wp.data && wp.data.dispatch){
                        wp.data.dispatch('core/editor').editPost({content: r.data.content});
                        if(r.data.title) wp.data.dispatch('core/editor').editPost({title: r.data.title});
                    } else if(typeof tinymce !== 'undefined' && tinymce.get('content')){
                        tinymce.get('content').setContent(r.data.content);
                    }
                    status.innerHTML='<span style="color:#22c55e">✅ تم التوليد! راجع المحتوى وانشره.</span>';
                } else {
                    status.innerHTML='<span style="color:#ef4444">❌ '+(r.data||'خطأ في التوليد')+'</span>';
                }
                btn.disabled=false; btn.textContent='🤖 توليد المحتوى بـ AI';
            }).fail(function(){
                status.innerHTML='<span style="color:#ef4444">❌ خطأ في الاتصال</span>';
                btn.disabled=false; btn.textContent='🤖 توليد المحتوى بـ AI';
            });
        });
        </script>
        <?php
    }

    public function ajax_gen_article(): void {
        check_ajax_referer('rsa_content','nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $kw      = sanitize_text_field($_POST['kw']       ?? '');
        $city    = sanitize_text_field($_POST['city']     ?? '');
        $tpl     = sanitize_text_field($_POST['template'] ?? 'service');
        $post_id = (int)($_POST['post_id'] ?? 0);

        if (!$kw) wp_send_json_error('الكلمة المفتاحية مطلوبة');
        if (!$this->ai->is_ready()) wp_send_json_error('Claude API غير مفعّل — أضف مفتاح API في الإعدادات');

        $company = get_option('rsa_company_name', get_bloginfo('name'));
        $phone   = get_option('rsa_phone_number','');
        $wa      = get_option('rsa_whatsapp_number','');
        $city_str = $city ? "في {$city}" : '';

        $system = 'أنت كاتب محتوى SEO خبير. اكتب محتوى HTML فقط بدون أي شرح خارجي. لا تستخدم markdown. المحتوى باللغة العربية فقط.';

        $templates = [
            'service' => "اكتب مقال SEO احترافي عن خدمة: {$kw} {$city_str}\nالشركة: {$company}\nالطول: 800-1000 كلمة\nاشمل: H2, H3, قائمة مميزات, جدول أسعار تقريبي, FAQ, CTA\nأضف في النهاية: [post_services] [post_features] [post_steps]\nاستخدم Design System:\n- Hero box: background:#f0f7ff;border-right:6px solid #0056b3;padding:25px;border-radius:12px\n- Cards: display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px\n- CTA: background:linear-gradient(45deg,#003366,#0056b3);color:#fff;padding:25px;border-radius:12px;text-align:center\n- Phone CTA: <a href='tel:{$phone}'>",
            'city'    => "اكتب صفحة Local SEO لخدمة {$kw} في مدينة {$city}\nالشركة: {$company}\nاشمل: أحياء المدينة, مميزات الخدمة, FAQ محلي, تقييمات عملاء (وهمية), CTA\nأضف: [post_services]",
            'how-to'  => "اكتب مقال How-To احترافي: كيفية {$kw}\nخطوات مفصلة مع أيقونات Font Awesome\nأضف: [post_steps]",
            'compare' => "اكتب مقال مقارنة: {$kw} في {$city}\nجدول مقارنة + نتيجة + توصية\nأضف: [post_features]",
            'review'  => "اكتب مراجعة تفصيلية: {$kw}\nالإيجابيات والسلبيات, تقييم نجوم, ملخص",
        ];

        $prompt = $templates[$tpl] ?? $templates['service'];
        $prompt .= "\n\nالرقم: {$phone}\nواتساب: " . ($wa ? "https://wa.me/{$wa}" : '');

        $result = $this->ai->ask($prompt, 3000, $system);
        if (!$result) wp_send_json_error('فشل في التوليد — تحقق من مفتاح Claude API');

        // Generate title
        $title = $kw . ($city ? " في {$city}" : '') . ' | ' . $company;

        // Save to post
        if ($post_id) {
            wp_update_post(['ID'=>$post_id, 'post_content'=>$result]);
        }

        wp_send_json_success(['content'=>$result, 'title'=>$title]);
    }
}

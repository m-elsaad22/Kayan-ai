<?php
defined('ABSPATH') || exit;

/**
 * RSA_Linking — AI Internal Linking
 * - تحليل كل المقالات
 * - ربط تلقائي بالـ anchor text المناسب
 * - توزيع Link Juice
 * - ربط خارجي من مواقع معتمدة
 */
class RSA_Linking {

    private RSA_Claude_API $ai;
    private RSA_DB         $db;

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        $this->db = RSA_DB::instance();

        add_filter('the_content',              [$this, 'inject_internal_links'], 15);
        add_action('wp_ajax_rsa_build_links',  [$this, 'ajax_build_links']);
        add_action('wp_ajax_rsa_scan_all_links',[$this,'ajax_scan_all_links']);
    }

    /* ─── Inject links into content ─── */
    public function inject_internal_links(string $content): string {
        if (!is_singular() || is_admin()) return $content;

        $post_id = get_the_ID();
        $links   = $this->get_saved_links($post_id);
        if (empty($links)) return $content;

        $used = [];
        foreach ($links as $link) {
            $anchor  = $link['anchor_text'];
            $target  = $link['target_id'];
            $url     = get_permalink($target);
            if (!$url || isset($used[$anchor])) continue;

            // Only link first occurrence
            $html_link = '<a href="' . esc_url($url) . '" title="' . esc_attr($anchor) . '">' . esc_html($anchor) . '</a>';
            // Replace plain text anchor with link (not inside existing links)
            $pattern = '/(?<![>"\'])(' . preg_quote($anchor, '/') . ')(?![^<]*<\/a>)/u';
            $new     = preg_replace($pattern, $html_link, $content, 1);
            if ($new !== $content) {
                $content = $new;
                $used[$anchor] = true;
                // Track click (JS side)
            }
        }

        return $content;
    }

    /* ─── Generate links for a post using AI ─── */
    public function generate_links_for_post(int $post_id): array {
        $post       = get_post($post_id);
        $content    = strip_tags($post->post_content ?? '');
        $focus_kw   = get_post_meta($post_id, '_rsa_focus_kw', true);

        // Get all published posts (titles + IDs)
        $all_posts = get_posts(['numberposts'=>100,'post_status'=>'publish','post__not_in'=>[$post_id]]);
        if (empty($all_posts)) return [];

        $posts_list = '';
        foreach ($all_posts as $p) {
            $posts_list .= "ID:{$p->ID} | {$p->post_title}\n";
        }

        $prompt = <<<PROMPT
أنت خبير Internal Linking. المقال الحالي:
العنوان: {$post->post_title}
الكلمة المفتاحية: {$focus_kw}
المحتوى (أول 500 كلمة): {$content}

قائمة المقالات الأخرى:
{$posts_list}

اختر 3-5 مقالات مناسبة للربط الداخلي وأعطني JSON:
[
  {"target_id": ID_العدد, "anchor_text": "النص الرابط المناسب", "reason": "سبب الربط"},
  ...
]

الشروط:
- Anchor text يجب أن يكون موجوداً فعلاً في المحتوى
- لا تكرر نفس الصفحة
- ابتعد عن anchor text عام مثل "اضغط هنا"

أعطني JSON فقط.
PROMPT;

        $data = $this->ai->ask_json($prompt, 1000);
        if (empty($data)) return [];

        // Save to DB
        foreach ($data as $item) {
            $target = (int)($item['target_id'] ?? 0);
            $anchor = sanitize_text_field($item['anchor_text'] ?? '');
            if (!$target || !$anchor) continue;

            // Check if already exists
            global $wpdb;
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}rsa_links WHERE source_id=%d AND target_id=%d",
                $post_id, $target
            ));

            if (!$exists) {
                $this->db->insert('links', [
                    'source_id'   => $post_id,
                    'target_id'   => $target,
                    'anchor_text' => $anchor,
                    'position'    => 'content',
                    'auto_added'  => 1,
                    'created_at'  => current_time('mysql'),
                ]);
            }
        }

        $this->db->log('linking', 'generate', $post_id, 300);
        return $data;
    }

    /* ─── Get saved links for post ─── */
    private function get_saved_links(int $post_id): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rsa_links WHERE source_id=%d AND auto_added=1",
            $post_id
        ), ARRAY_A) ?: [];
    }

    /* ─── External links injection ─── */
    public function inject_external_links(string $content, array $allowed_domains): string {
        // Get external links configured in admin
        $external = get_option('rsa_external_links', []);
        if (empty($external)) return $content;

        foreach ($external as $item) {
            $anchor = $item['anchor']  ?? '';
            $url    = $item['url']     ?? '';
            $domain = parse_url($url, PHP_URL_HOST);

            if (!$anchor || !$url) continue;
            if (!empty($allowed_domains) && !in_array($domain, $allowed_domains)) continue;

            // Check anchor exists and not already linked
            if (!str_contains($content, $anchor)) continue;

            $html    = '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($anchor) . '</a>';
            $pattern = '/(?<![>"\'])(' . preg_quote($anchor, '/') . ')(?![^<]*<\/a>)/u';
            $content = preg_replace($pattern, $html, $content, 1);
        }

        return $content;
    }

    /* ─── AJAX: build links for post ─── */
    public function ajax_build_links(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $post_id = (int)($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error('No post ID');

        $links = $this->generate_links_for_post($post_id);
        wp_send_json_success(['count'=>count($links), 'links'=>$links]);
    }

    /* ─── AJAX: scan all posts ─── */
    public function ajax_scan_all_links(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');

        $posts = get_posts(['numberposts'=>50,'post_status'=>'publish']);
        $done  = 0;
        foreach ($posts as $post) {
            $this->generate_links_for_post($post->ID);
            $done++;
            sleep(1);
        }

        wp_send_json_success(['processed'=>$done]);
    }
}

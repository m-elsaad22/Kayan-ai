<?php
defined('ABSPATH') || exit;

class RSA_Intent {
    public function __construct() {
        add_action('wp_footer', [$this, 'inject']);
        add_action('wp_ajax_rsa_intent_action',        [$this, 'ajax']);
        add_action('wp_ajax_nopriv_rsa_intent_action', [$this, 'ajax']);
    }

    public function inject(): void {
        if (is_admin() || !is_singular()) return;
        $wa    = get_option('rsa_whatsapp_number','');
        $phone = get_option('rsa_phone_number','');
        $waurl = $wa ? "https://wa.me/{$wa}" : '#';
        $ajaxurl = esc_url(admin_url('admin-ajax.php'));
        $pid = (int)get_the_ID();
        ?>
<div id="sae-intent-box" style="display:none;position:fixed;bottom:90px;left:50%;transform:translateX(-50%);z-index:9985;max-width:340px;width:90%;direction:rtl"></div>
<script>
(function(){
  var t0=Date.now(),sc=0,det=false;
  window.addEventListener('scroll',function(){
    var p=(window.scrollY+window.innerHeight)/document.body.scrollHeight*100;
    if(p>sc)sc=Math.round(p);
    check();
  },{passive:true});
  function check(){
    if(det)return;
    var t=Math.round((Date.now()-t0)/1000);
    var intent=null;
    if(sc>=70&&t>=40)intent='buying';
    else if(sc<15&&t>=15)intent='bounce';
    if(!intent)return;
    det=true;show(intent);
    var fd=new FormData();fd.append('action','rsa_intent_action');fd.append('intent',intent);fd.append('post_id','<?= $pid ?>');
    navigator.sendBeacon?navigator.sendBeacon('<?= $ajaxurl ?>',fd):fetch('<?= $ajaxurl ?>',{method:'POST',body:fd});
  }
  function show(intent){
    var box=document.getElementById('sae-intent-box');if(!box)return;
    var h='';
    if(intent==='buying'){
      h='<div style="background:#fff;border-radius:16px;padding:20px;box-shadow:0 8px 30px rgba(0,0,0,.15);border-top:4px solid #22c55e">'
       +'<p style="font-size:13px;color:#64748b;margin:0 0 8px">💡 يبدو أنك مهتم</p>'
       +'<h4 style="margin:0 0 15px;color:#003366;font-size:16px">احصل على عرض سعر الآن</h4>'
       +'<div style="display:flex;gap:8px">'
       <?php if ($wa): ?>+'<a href="<?= esc_url($waurl) ?>" target="_blank" style="flex:1;background:#25d366;color:#fff;padding:10px;border-radius:10px;text-decoration:none;text-align:center;font-weight:bold;font-size:13px">واتساب</a>'<?php endif; ?>
       <?php if ($phone): ?>+'<a href="tel:<?= esc_attr($phone) ?>" style="flex:1;background:#0056b3;color:#fff;padding:10px;border-radius:10px;text-decoration:none;text-align:center;font-weight:bold;font-size:13px">اتصال</a>'<?php endif; ?>
       +'</div>'
       +'<button onclick="document.getElementById(\'sae-intent-box\').style.display=\'none\'" style="background:none;border:none;color:#94a3b8;font-size:12px;cursor:pointer;width:100%;margin-top:8px">إغلاق</button>'
       +'</div>';
    } else if(intent==='bounce'){
      h='<div style="background:#fff;border-radius:16px;padding:20px;box-shadow:0 8px 30px rgba(0,0,0,.15);border-top:4px solid #f59e0b">'
       +'<h4 style="margin:0 0 10px;color:#003366">⚡ عرض خاص قبل المغادرة</h4>'
       <?php if ($wa): ?>+'<a href="<?= esc_url($waurl) ?>" target="_blank" style="display:block;background:#25d366;color:#fff;padding:12px;border-radius:10px;text-decoration:none;text-align:center;font-weight:bold">تحدث معنا الآن</a>'<?php endif; ?>
       +'<button onclick="document.getElementById(\'sae-intent-box\').style.display=\'none\'" style="background:none;border:none;color:#94a3b8;font-size:12px;cursor:pointer;width:100%;margin-top:8px">إغلاق</button>'
       +'</div>';
    }
    if(h){box.innerHTML=h;box.style.display='block';setTimeout(function(){box.style.display='none';},12000);}
  }
})();
</script>
<?php
    }

    public function ajax(): void {
        RSA_DB::instance()->log('intent','detected_'.sanitize_text_field($_POST['intent']??''),(int)($_POST['post_id']??0));
        wp_send_json_success();
    }
}

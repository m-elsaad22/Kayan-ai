<?php
defined('ABSPATH') || exit;

/**
 * RSA_Schema — توليد Schema تلقائي بدون Plugin
 * LocalBusiness + FAQ + Service + Review + Breadcrumb
 */
class RSA_Schema {

    public function __construct() {
        add_action('wp_head', [$this, 'inject_schemas'], 2);
    }

    public function inject_schemas(): void {
        if (!is_singular()) {
            if (is_home() || is_front_page()) $this->org_schema();
            if (is_category() || is_tag())     $this->collection_schema();
            return;
        }

        $post_id = get_the_ID();
        $post    = get_post($post_id);

        $this->breadcrumb_schema($post_id);
        $this->article_schema($post);
        $this->local_business_schema($post_id);
        $this->faq_schema($post_id);
        $this->review_schema($post_id);
    }

    /* ─── Organisation (homepage) ─── */
    private function org_schema(): void {
        $schema = [
            '@context'  => 'https://schema.org',
            '@type'     => 'Organization',
            'name'      => get_option('rsa_company_name', get_bloginfo('name')),
            'url'       => home_url(),
            'logo'      => get_site_icon_url(),
            'telephone' => get_option('rsa_phone_number', ''),
            'sameAs'    => array_filter([
                get_option('rsa_facebook', ''),
                get_option('rsa_instagram', ''),
            ]),
        ];
        $this->output($schema);
    }

    /* ─── Breadcrumb ─── */
    public function breadcrumb_schema(int $post_id): void {
        $items = [
            ['@type'=>'ListItem','position'=>1,'name'=>'الرئيسية','item'=>home_url()],
        ];
        $cats = get_the_category($post_id);
        if ($cats) {
            $items[] = ['@type'=>'ListItem','position'=>2,'name'=>$cats[0]->name,'item'=>get_category_link($cats[0]->term_id)];
            $items[] = ['@type'=>'ListItem','position'=>3,'name'=>get_the_title($post_id),'item'=>get_permalink($post_id)];
        } else {
            $items[] = ['@type'=>'ListItem','position'=>2,'name'=>get_the_title($post_id),'item'=>get_permalink($post_id)];
        }

        $this->output([
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $items,
        ]);
    }

    /* ─── Article ─── */
    private function article_schema(WP_Post $post): void {
        $thumb = get_the_post_thumbnail_url($post->ID, 'large');
        $this->output([
            '@context'        => 'https://schema.org',
            '@type'           => 'Article',
            'headline'        => get_the_title($post->ID),
            'url'             => get_permalink($post->ID),
            'datePublished'   => get_the_date('c', $post->ID),
            'dateModified'    => get_the_modified_date('c', $post->ID),
            'image'           => $thumb ?: get_site_icon_url(),
            'author'          => ['@type'=>'Organization','name'=>get_option('rsa_company_name', get_bloginfo('name'))],
            'publisher'       => [
                '@type' => 'Organization',
                'name'  => get_option('rsa_company_name', get_bloginfo('name')),
                'logo'  => ['@type'=>'ImageObject','url'=>get_site_icon_url()],
            ],
            'wordCount'       => str_word_count(strip_tags($post->post_content)),
        ]);
    }

    /* ─── LocalBusiness (per post if has city meta) ─── */
    private function local_business_schema(int $post_id): void {
        $city    = get_post_meta($post_id, '_rsa_city', true);
        $service = get_post_meta($post_id, '_rsa_service', true);
        if (!$city) return;

        global $wpdb;
        $seo_row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rsa_seo WHERE post_id=%d", $post_id
        ), ARRAY_A);

        $this->output([
            '@context'    => 'https://schema.org',
            '@type'       => 'LocalBusiness',
            'name'        => get_option('rsa_company_name', get_bloginfo('name')),
            'description' => $seo_row['meta_desc'] ?? ($service ? "{$service} في {$city}" : ''),
            'url'         => get_permalink($post_id),
            'telephone'   => get_option('rsa_phone_number', ''),
            'areaServed'  => ['@type'=>'City','name'=>$city],
            'image'       => get_the_post_thumbnail_url($post_id, 'large') ?: get_site_icon_url(),
            'priceRange'  => '$$',
            'aggregateRating' => [
                '@type'       => 'AggregateRating',
                'ratingValue' => '4.9',
                'bestRating'  => '5',
                'reviewCount' => (string)(95 + ($post_id % 50)),
            ],
        ]);
    }

    /* ─── FAQ from SEO row ─── */
    private function faq_schema(int $post_id): void {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT faq_json FROM {$wpdb->prefix}rsa_seo WHERE post_id=%d", $post_id
        ), ARRAY_A);

        if (!$row || empty($row['faq_json'])) return;
        $faqs = json_decode($row['faq_json'], true);
        if (empty($faqs)) return;

        $entities = [];
        foreach ($faqs as $faq) {
            $q = $faq['question'] ?? $faq['q'] ?? '';
            $a = $faq['answer']   ?? $faq['a'] ?? '';
            if ($q && $a) {
                $entities[] = [
                    '@type' => 'Question',
                    'name'  => $q,
                    'acceptedAnswer' => ['@type'=>'Answer','text'=>$a],
                ];
            }
        }
        if ($entities) {
            $this->output(['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>$entities]);
        }
    }

    /* ─── Review aggregation (manual or from post meta) ─── */
    private function review_schema(int $post_id): void {
        $reviews = get_post_meta($post_id, '_rsa_reviews', true);
        if (!$reviews || !is_array($reviews)) return;

        $schema = [
            '@context' => 'https://schema.org',
            '@type'    => 'Product',
            'name'     => get_the_title($post_id),
            'review'   => [],
        ];

        foreach (array_slice($reviews, 0, 5) as $r) {
            $schema['review'][] = [
                '@type'         => 'Review',
                'reviewRating'  => ['@type'=>'Rating','ratingValue'=>$r['rating'] ?? 5],
                'author'        => ['@type'=>'Person','name'=>$r['author'] ?? 'عميل'],
                'reviewBody'    => $r['body'] ?? '',
            ];
        }

        if (!empty($schema['review'])) $this->output($schema);
    }

    private function collection_schema(): void {
        // Archive schema
    }

    private function output(array $schema): void {
        echo '<script type="application/ld+json">'
            . wp_json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            . '</script>' . "\n";
    }
}

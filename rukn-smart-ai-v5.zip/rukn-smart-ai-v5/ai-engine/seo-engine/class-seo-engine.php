<?php
defined('ABSPATH') || exit;

/**
 * RSA_SEO_Engine
 * - توليد Meta Title / Description تلقائي بـ Claude
 * - توليد LSI Keywords
 * - توليد FAQ Schema
 * - إعادة كتابة العناوين حسب الكلمة المفتاحية
 * - حقن Schema في الـ head
 */
class RSA_SEO_Engine {

    private RSA_Claude_API $ai;
    private RSA_DB         $db;

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        $this->db = RSA_DB::instance();

        // Hooks
        add_action('wp_head',           [$this, 'inject_meta'],         1);
        add_action('save_post',         [$this, 'generate_seo_on_save'], 20, 2);
        add_filter('document_title_parts', [$this, 'override_title']);
        add_action('wp_ajax_rsa_gen_seo', [$this, 'ajax_generate_seo']);

        // Metabox in editor
        add_action('add_meta_boxes', [$this, 'add_metabox']);
    }

    /* ─── Generate SEO on post save ─── */
    public function generate_seo_on_save(int $post_id, WP_Post $post): void {
        if (wp_is_post_revision($post_id) || $post->post_status !== 'publish') return;
        if (!in_array($post->post_type, ['post','page','خدمات','services'], true)) return;
        if (!$this->ai->is_ready()) return;

        // Skip if recently generated (< 24h)
        $existing = $this->get_seo_row($post_id);
        if ($existing && !empty($existing['last_ai'])) {
            $diff = time() - strtotime($existing['last_ai']);
            if ($diff < DAY_IN_SECONDS) return;
        }

        $this->generate_for_post($post_id, $post);
    }

    /* ─── Core generator ─── */
    public function generate_for_post(int $post_id, ?WP_Post $post = null): array {
        if (!$post) $post = get_post($post_id);
        $content  = strip_tags($post->post_content);
        $content  = RSA_Helper::instance()->trim_text($content, 300);
        $title    = $post->post_title;
        $company  = get_option('rsa_company_name', get_bloginfo('name'));

        $prompt = <<<PROMPT
أنت خبير SEO عربي. بناءً على العنوان والمحتوى التالي، أنشئ JSON يحتوي على:
1. meta_title: عنوان SEO مثالي (55-60 حرف) يتضمن الكلمة المفتاحية والمدينة إن وجدت + اسم الشركة
2. meta_desc: وصف SEO مقنع (150-160 حرف) يحتوي على CTA
3. focus_kw: الكلمة المفتاحية الرئيسية
4. lsi_keywords: مصفوفة من 8-12 كلمة مفتاحية LSI مرتبطة
5. faq: مصفوفة من 5 أسئلة وأجوبة حقيقية يبحث عنها الناس

العنوان: {$title}
اسم الشركة: {$company}
المحتوى: {$content}

أعطني JSON فقط بدون أي شرح.
PROMPT;

        $result = $this->ai->ask_cached($prompt, "seo_{$post_id}", DAY_IN_SECONDS);
        if (!$result) return [];

        $data = RSA_Helper::instance()->safe_json($result);
        if (empty($data)) return [];

        // Save to DB
        $row = [
            'post_id'     => $post_id,
            'meta_title'  => sanitize_text_field($data['meta_title']  ?? ''),
            'meta_desc'   => sanitize_textarea_field($data['meta_desc'] ?? ''),
            'focus_kw'    => sanitize_text_field($data['focus_kw']    ?? ''),
            'lsi_keywords'=> wp_json_encode($data['lsi_keywords']     ?? []),
            'faq_json'    => wp_json_encode($data['faq']              ?? []),
            'last_ai'     => current_time('mysql'),
        ];

        global $wpdb;
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}rsa_seo WHERE post_id=%d", $post_id
        ));

        if ($exists) {
            $wpdb->update("{$wpdb->prefix}rsa_seo", $row, ['post_id'=>$post_id]);
        } else {
            $wpdb->insert("{$wpdb->prefix}rsa_seo", $row);
        }

        $this->db->log('seo_engine', 'generate', $post_id, 500);
        return $data;
    }

    /* ─── Inject meta tags in <head> ─── */
    public function inject_meta(): void {
        if (!is_singular()) return;
        $post_id = get_the_ID();
        $row     = $this->get_seo_row($post_id);
        if (!$row) return;

        if (!empty($row['meta_title'])) {
            echo '<meta name="title" content="' . esc_attr($row['meta_title']) . '">' . "\n";
            echo '<meta property="og:title" content="' . esc_attr($row['meta_title']) . '">' . "\n";
        }
        if (!empty($row['meta_desc'])) {
            echo '<meta name="description" content="' . esc_attr($row['meta_desc']) . '">' . "\n";
            echo '<meta property="og:description" content="' . esc_attr($row['meta_desc']) . '">' . "\n";
        }

        // FAQ Schema
        $faq = json_decode($row['faq_json'] ?? '[]', true);
        if (!empty($faq)) {
            $schema = ['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>[]];
            foreach ($faq as $item) {
                $schema['mainEntity'][] = [
                    '@type' => 'Question',
                    'name'  => $item['question'] ?? $item['q'] ?? '',
                    'acceptedAnswer' => [
                        '@type' => 'Answer',
                        'text'  => $item['answer'] ?? $item['a'] ?? '',
                    ],
                ];
            }
            echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
        }
    }

    /* ─── Override document title ─── */
    public function override_title(array $parts): array {
        if (!is_singular()) return $parts;
        $row = $this->get_seo_row(get_the_ID());
        if ($row && !empty($row['meta_title'])) {
            $parts['title'] = $row['meta_title'];
            unset($parts['tagline'], $parts['site']);
        }
        return $parts;
    }

    /* ─── Metabox ─── */
    public function add_metabox(): void {
        add_meta_box('sae-seo-box', '🧠 SmartAi SEO Engine', [$this, 'render_metabox'],
            ['post','page'], 'normal', 'high');
    }

    public function render_metabox(WP_Post $post): void {
        $row = $this->get_seo_row($post->ID);
        $lsi = !empty($row['lsi_keywords']) ? implode(', ', json_decode($row['lsi_keywords'], true) ?: []) : '';
        $faq_count = !empty($row['faq_json']) ? count(json_decode($row['faq_json'], true) ?: []) : 0;
        ?>
        <div style="font-family:Arial;direction:rtl">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-bottom:15px">
                <div>
                    <label style="font-weight:bold;display:block;margin-bottom:5px">📌 Meta Title</label>
                    <input type="text" id="rsa_meta_title" name="rsa_meta_title"
                           value="<?= esc_attr($row['meta_title'] ?? '') ?>"
                           style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px"
                           maxlength="60" placeholder="العنوان SEO (55-60 حرف)">
                    <small id="rsa_title_count" style="color:#888">0/60</small>
                </div>
                <div>
                    <label style="font-weight:bold;display:block;margin-bottom:5px">🔑 الكلمة المفتاحية</label>
                    <input type="text" id="rsa_focus_kw" name="rsa_focus_kw"
                           value="<?= esc_attr($row['focus_kw'] ?? '') ?>"
                           style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px">
                </div>
            </div>
            <div style="margin-bottom:15px">
                <label style="font-weight:bold;display:block;margin-bottom:5px">📝 Meta Description</label>
                <textarea id="rsa_meta_desc" name="rsa_meta_desc" rows="3"
                          style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px"
                          maxlength="160"><?= esc_textarea($row['meta_desc'] ?? '') ?></textarea>
                <small id="rsa_desc_count" style="color:#888">0/160</small>
            </div>
            <?php if ($lsi): ?>
            <div style="background:#f0f7ff;padding:10px;border-radius:8px;margin-bottom:10px">
                <strong>📊 LSI Keywords:</strong><br>
                <span style="color:#555;font-size:13px"><?= esc_html($lsi) ?></span>
            </div>
            <?php endif; ?>
            <div style="display:flex;gap:10px;align-items:center">
                <button type="button" id="rsa_gen_seo_btn"
                        style="background:#0056b3;color:#fff;padding:10px 20px;border:none;border-radius:8px;cursor:pointer;font-size:14px">
                    🤖 توليد SEO بـ AI
                </button>
                <?php if ($faq_count): ?>
                <span style="background:#e8f5e9;color:#2e7d32;padding:5px 12px;border-radius:20px;font-size:13px">
                    ✅ <?= $faq_count ?> أسئلة FAQ جاهزة
                </span>
                <?php endif; ?>
                <?php if (!empty($row['last_ai'])): ?>
                <span style="color:#888;font-size:12px">آخر تحديث: <?= esc_html($row['last_ai']) ?></span>
                <?php endif; ?>
            </div>
            <div id="rsa_gen_status" style="margin-top:10px;display:none"></div>
        </div>
        <script>
        document.addEventListener('DOMContentLoaded', function(){
            var titleEl = document.getElementById('rsa_meta_title');
            var descEl  = document.getElementById('rsa_meta_desc');
            var tCount  = document.getElementById('rsa_title_count');
            var dCount  = document.getElementById('rsa_desc_count');

            function updateCount(el, counter, max){
                counter.textContent = el.value.length + '/' + max;
                counter.style.color = el.value.length > max ? '#d32f2f' : '#888';
            }
            if(titleEl){ titleEl.addEventListener('input',function(){ updateCount(titleEl,tCount,60); }); updateCount(titleEl,tCount,60); }
            if(descEl) { descEl.addEventListener('input', function(){ updateCount(descEl, dCount,160); }); updateCount(descEl, dCount,160); }

            var btn = document.getElementById('rsa_gen_seo_btn');
            if(btn){ btn.addEventListener('click', function(){
                btn.disabled = true;
                btn.textContent = '⏳ يتم التوليد...';
                var status = document.getElementById('rsa_gen_status');
                status.style.display = 'block';
                status.innerHTML = '<div style="padding:10px;background:#fff9c4;border-radius:6px">جاري الاتصال بـ Claude AI...</div>';

                fetch(ajaxurl, {
                    method:'POST',
                    headers:{'Content-Type':'application/x-www-form-urlencoded'},
                    body: 'action=rsa_gen_seo&post_id=<?= $post->ID ?>&nonce=<?= wp_create_nonce('rsa_seo') ?>'
                }).then(r=>r.json()).then(function(data){
                    if(data.success){
                        var d = data.data;
                        if(d.meta_title && titleEl) titleEl.value = d.meta_title;
                        if(d.meta_desc  && descEl)  descEl.value  = d.meta_desc;
                        if(d.focus_kw){
                            var kw = document.getElementById('rsa_focus_kw');
                            if(kw) kw.value = d.focus_kw;
                        }
                        updateCount(titleEl,tCount,60);
                        updateCount(descEl,dCount,160);
                        status.innerHTML = '<div style="padding:10px;background:#e8f5e9;border-radius:6px;color:#2e7d32">✅ تم التوليد! احفظ المقال لتطبيق التغييرات.</div>';
                    } else {
                        status.innerHTML = '<div style="padding:10px;background:#ffebee;border-radius:6px;color:#c62828">❌ ' + (data.data || 'خطأ في التوليد') + '</div>';
                    }
                    btn.disabled = false;
                    btn.textContent = '🤖 توليد SEO بـ AI';
                }).catch(function(){ 
                    status.innerHTML = '<div style="padding:10px;background:#ffebee;border-radius:6px">❌ خطأ في الاتصال</div>';
                    btn.disabled = false;
                    btn.textContent = '🤖 توليد SEO بـ AI';
                });
            });}
        });
        </script>
        <?php
    }

    /* ─── AJAX handler ─── */
    public function ajax_generate_seo(): void {
        check_ajax_referer('rsa_seo', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Unauthorized');

        $post_id = (int) ($_POST['post_id'] ?? 0);
        if (!$post_id) wp_send_json_error('No post ID');

        $post = get_post($post_id);
        if (!$post) wp_send_json_error('Post not found');

        $data = $this->generate_for_post($post_id, $post);
        if (empty($data)) wp_send_json_error('AI generation failed — check API key');

        wp_send_json_success($data);
    }

    /* ─── Save metabox data ─── */
    public function save_metabox(int $post_id): void {
        global $wpdb;
        $title = sanitize_text_field($_POST['rsa_meta_title'] ?? '');
        $desc  = sanitize_textarea_field($_POST['rsa_meta_desc'] ?? '');
        $kw    = sanitize_text_field($_POST['rsa_focus_kw'] ?? '');

        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}rsa_seo WHERE post_id=%d", $post_id));
        $data   = ['meta_title'=>$title,'meta_desc'=>$desc,'focus_kw'=>$kw,'post_id'=>$post_id];

        if ($exists) $wpdb->update("{$wpdb->prefix}rsa_seo", $data, ['post_id'=>$post_id]);
        else          $wpdb->insert("{$wpdb->prefix}rsa_seo", $data);
    }

    private function get_seo_row(int $post_id): array|null {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rsa_seo WHERE post_id=%d", $post_id
        ), ARRAY_A);
        return $row ?: null;
    }
}

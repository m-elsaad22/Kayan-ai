<?php
defined('ABSPATH') || exit;

/**
 * RSA_Conversion
 * - Popup ذكي حسب المدينة والوقت والسلوك
 * - CTA متغير حسب المدينة
 * - Sticky bar سفلي مع واتساب + اتصال
 * - Scarcity counter
 * - الإشعارات خلف أزرار الاتصال (لا تخفيها)
 */
class RSA_Conversion {

    private RSA_DB $db;

    public function __construct() {
        $this->db = RSA_DB::instance();

        add_action('wp_footer', [$this, 'render_sticky_bar']);
        add_action('wp_footer', [$this, 'render_popup_system']);
        add_action('wp_footer', [$this, 'render_notification_layer']);
        add_action('wp_head',   [$this, 'inject_conversion_css']);

        add_action('wp_ajax_rsa_get_offer',       [$this, 'ajax_get_offer']);
        add_action('wp_ajax_nopriv_rsa_get_offer',[$this, 'ajax_get_offer']);
        add_action('wp_ajax_rsa_track_cta',       [$this, 'ajax_track_cta']);
        add_action('wp_ajax_nopriv_rsa_track_cta',[$this,'ajax_track_cta']);
    }

    /* ─── Sticky bar (bottom) ─── */
    public function render_sticky_bar(): void {
        $phone    = get_option('rsa_phone_number', '');
        $whatsapp = get_option('rsa_whatsapp_number', '');
        if (!$phone && !$whatsapp) return;
        if (!get_option('rsa_conv_sticky_bar', 1)) return;

        $wa_link = $whatsapp ? "https://wa.me/{$whatsapp}" : '#';
        $company = get_option('rsa_company_name', 'نحن');
        ?>
        <div id="sae-sticky-bar" style="position:fixed;bottom:0;left:0;right:0;z-index:9990;background:#10314a;padding:10px 15px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;transform:translateY(100%);transition:transform .3s ease" aria-label="تواصل معنا">
            <span style="color:#fff;font-size:14px;font-weight:600"><i class="fas fa-headset" style="color:#fbbf24;margin-left:8px"></i>احجز خدمتك الآن — <span id="sae-city-cta">خدمة سريعة 24/7</span></span>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <?php if ($whatsapp): ?>
                <a href="<?= esc_url($wa_link) ?>" target="_blank" rel="noopener nofollow"
                   id="sae-wa-cta"
                   onclick="saeCTA('whatsapp')"
                   style="background:#25d366;color:#fff;padding:10px 20px;border-radius:50px;text-decoration:none;font-weight:bold;font-size:14px;display:flex;align-items:center;gap:6px">
                    <i class="fab fa-whatsapp"></i> واتساب
                </a>
                <?php endif; ?>
                <?php if ($phone): ?>
                <a href="tel:<?= esc_attr($phone) ?>"
                   id="sae-call-cta"
                   onclick="saeCTA('call')"
                   style="background:#0056b3;color:#fff;padding:10px 20px;border-radius:50px;text-decoration:none;font-weight:bold;font-size:14px;display:flex;align-items:center;gap:6px">
                    <i class="fas fa-phone"></i> اتصال
                </a>
                <?php endif; ?>
                <button onclick="document.getElementById('sae-sticky-bar').style.display='none'"
                        style="background:transparent;border:none;color:#fff;font-size:18px;cursor:pointer;padding:5px" aria-label="إغلاق">×</button>
            </div>
        </div>
        <script>
        // Show sticky bar after 3s
        setTimeout(function(){
            var bar = document.getElementById('sae-sticky-bar');
            if(bar) bar.style.transform = 'translateY(0)';
        }, 3000);

        // Update CTA based on city (from geo API result)
        fetch('<?= esc_url(admin_url('admin-ajax.php')) ?>?action=rsa_get_offer', {method:'GET'})
          .then(function(r){ return r.json(); })
          .then(function(d){
            if(d.success && d.data){
              var cityEl = document.getElementById('sae-city-cta');
              if(cityEl && d.data.city_cta) cityEl.textContent = d.data.city_cta;
              var waEl = document.getElementById('sae-wa-cta');
              if(waEl && d.data.wa_text) waEl.innerHTML = '<i class="fab fa-whatsapp"></i> ' + d.data.wa_text;
            }
          }).catch(function(){});

        function saeCTA(type){
          fetch('<?= esc_url(admin_url('admin-ajax.php')) ?>', {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            body:'action=rsa_track_cta&type='+type+'&post_id=<?= (int)get_the_ID() ?>'
          });
        }
        </script>
        <?php
    }

    /* ─── Notification layer (BEHIND buttons, z-index lower) ─── */
    public function render_notification_layer(): void {
        if (!get_option('rsa_conv_notifications', 1)) return;
        $offers = $this->db->get('offers', ['active'=>1], 'id DESC', 3);
        if (empty($offers)) return;
        ?>
        <div id="sae-notifications" style="position:fixed;bottom:80px;right:20px;z-index:9980;max-width:300px;pointer-events:none">
            <!-- Notifications appear here, z-index lower than sticky bar buttons -->
        </div>
        <script>
        // Show notification after 20s if user is still on page
        var saeNotifShown = false;
        setTimeout(function(){
            if(saeNotifShown) return;
            saeNotifShown = true;
            var container = document.getElementById('sae-notifications');
            if(!container) return;

            var offers = <?= wp_json_encode(array_map(function($o){ return ['title'=>$o['title'],'body'=>$o['body']]; }, $offers)) ?>;
            if(!offers.length) return;

            var offer = offers[0];
            var div = document.createElement('div');
            div.style.cssText = 'background:#fff;border-radius:12px;padding:15px;box-shadow:0 4px 20px rgba(0,0,0,.15);border-right:4px solid #0056b3;pointer-events:auto;animation:slideInRight .4s ease';
            div.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">' +
              '<div><strong style="color:#003366;font-size:14px">🎁 ' + offer.title + '</strong><p style="color:#555;font-size:12px;margin:5px 0 0">' + offer.body + '</p></div>' +
              '<button onclick="this.closest(\'div[style]\').remove()" style="background:none;border:none;color:#999;cursor:pointer;font-size:16px;flex-shrink:0">×</button>' +
              '</div>';
            container.appendChild(div);

            // Auto-remove after 8s
            setTimeout(function(){ if(div.parentNode) div.remove(); }, 8000);
        }, 20000);
        </script>
        <?php
    }

    /* ─── Popup system ─── */
    public function render_popup_system(): void {
        if (!get_option('rsa_conv_popups', 1)) return;
        $phone    = get_option('rsa_phone_number', '');
        $whatsapp = get_option('rsa_whatsapp_number', '');
        $wa_link  = $whatsapp ? "https://wa.me/{$whatsapp}" : '#';
        ?>
        <div id="sae-popup-overlay" style="display:none;position:fixed;inset:0;z-index:99990;background:rgba(0,0,0,.5);justify-content:center;align-items:center">
            <div id="sae-popup-box" style="background:#fff;border-radius:20px;padding:40px 30px;max-width:460px;width:90%;position:relative;text-align:center;direction:rtl">
                <button onclick="document.getElementById('sae-popup-overlay').style.display='none'"
                        style="position:absolute;top:15px;left:15px;background:none;border:none;font-size:22px;cursor:pointer;color:#999" aria-label="إغلاق">×</button>
                <div style="font-size:50px;margin-bottom:15px">🎯</div>
                <h3 id="sae-popup-title" style="color:#003366;margin-bottom:10px">عرض خاص لك</h3>
                <p id="sae-popup-body" style="color:#555;margin-bottom:25px">احجز الآن واحصل على أفضل سعر</p>
                <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
                    <?php if ($whatsapp): ?>
                    <a href="<?= esc_url($wa_link) ?>" target="_blank"
                       style="background:#25d366;color:#fff;padding:13px 30px;border-radius:50px;text-decoration:none;font-weight:bold">
                        <i class="fab fa-whatsapp"></i> واتساب الآن
                    </a>
                    <?php endif; ?>
                    <?php if ($phone): ?>
                    <a href="tel:<?= esc_attr($phone) ?>"
                       style="background:#0056b3;color:#fff;padding:13px 30px;border-radius:50px;text-decoration:none;font-weight:bold">
                        <i class="fas fa-phone"></i> اتصال
                    </a>
                    <?php endif; ?>
                </div>
                <p id="sae-scarcity" style="color:#d32f2f;font-size:13px;margin-top:15px;font-weight:bold"></p>
            </div>
        </div>
        <script>
        (function(){
          var popupShown = sessionStorage.getItem('rsa_popup_shown');
          if(popupShown) return;

          var triggers = {
            exit_intent: false,
            time_30: false,
            scroll_60: false
          };

          function showPopup(reason){
            if(sessionStorage.getItem('rsa_popup_shown')) return;
            sessionStorage.setItem('rsa_popup_shown', '1');
            var overlay = document.getElementById('sae-popup-overlay');
            if(!overlay) return;
            overlay.style.display = 'flex';

            // Dynamic scarcity
            var scarcity = document.getElementById('sae-scarcity');
            if(scarcity){
              var num = Math.floor(Math.random() * 5) + 2;
              scarcity.textContent = '⚡ ' + num + ' أشخاص يشاهدون هذا العرض الآن';
            }
          }

          // Trigger: 30 seconds
          setTimeout(function(){
            if(!triggers.time_30){ triggers.time_30=true; showPopup('time'); }
          }, 30000);

          // Trigger: scroll 60%
          window.addEventListener('scroll', function(){
            var pct = (window.scrollY + window.innerHeight) / document.body.scrollHeight * 100;
            if(pct >= 60 && !triggers.scroll_60){ triggers.scroll_60=true; showPopup('scroll'); }
          }, {passive:true});

          // Trigger: exit intent (desktop)
          document.addEventListener('mouseleave', function(e){
            if(e.clientY < 10 && !triggers.exit_intent){ triggers.exit_intent=true; showPopup('exit'); }
          });
        })();
        </script>
        <?php
    }

    /* ─── Dynamic offer via AJAX ─── */
    public function ajax_get_offer(): void {
        $helper = RSA_Helper::instance();
        $ip     = $helper->get_ip();
        $geo    = $helper->get_city($ip);
        $city   = $geo['city'];
        $hour   = (int) current_time('G');

        $city_cta = "خدمة سريعة في {$city}";
        $wa_text  = "واتساب — {$city}";

        // Time-based
        if ($hour >= 8 && $hour < 20) {
            $city_cta = "⚡ نصل إليك في {$city} خلال ساعة";
        } else {
            $city_cta = "📞 خدمة طوارئ 24/7 — {$city}";
        }

        wp_send_json_success([
            'city'     => $city,
            'city_cta' => $city_cta,
            'wa_text'  => $wa_text,
        ]);
    }

    /* ─── Track CTA clicks ─── */
    public function ajax_track_cta(): void {
        $type    = sanitize_text_field($_POST['type']    ?? '');
        $post_id = (int)($_POST['post_id'] ?? 0);
        $this->db->log('conversion', 'cta_click_' . $type, $post_id, 0, 'ok');
        wp_send_json_success();
    }

    /* ─── CSS ─── */
    public function inject_conversion_css(): void {
        echo '<style>
        @keyframes slideInRight{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
        #sae-sticky-bar{box-shadow:0 -4px 15px rgba(0,0,0,.2)}
        @media(max-width:480px){
            #sae-sticky-bar span:first-child{display:none}
            #sae-sticky-bar .sae-btns{width:100%;justify-content:center}
        }
        </style>' . "\n";
    }
}

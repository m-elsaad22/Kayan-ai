<?php
defined('ABSPATH') || exit;

/**
 * RSA_Auto_Slug
 * تحويل عنوان المقال العربي إلى رابط إنجليزي تلقائياً
 * مثال: "شركة تنظيف في دبي" → "cleaning-company-dubai"
 */
class RSA_Auto_Slug {

    private RSA_Claude_API $ai;

    public function __construct() {
        $this->ai = RSA_Claude_API::instance();
        add_filter('wp_insert_post_data', [$this, 'auto_slug'], 10, 2);
        add_action('wp_ajax_rsa_preview_slug', [$this, 'ajax_preview_slug']);
    }

    public function auto_slug(array $data, array $postarr): array {
        // Only for new posts or posts with empty/auto-generated slug
        if (!in_array($data['post_type'], ['post','page'], true)) return $data;
        if ($data['post_status'] === 'auto-draft') return $data;

        $title = $data['post_title'] ?? '';
        if (empty($title)) return $data;

        // Check if title is Arabic
        if (!$this->is_arabic($title)) return $data;

        // Check if slug was manually set (not auto-generated from Arabic)
        if (!empty($postarr['ID'])) {
            $existing = get_post_field('post_name', $postarr['ID']);
            if ($existing && !$this->is_arabic_encoded($existing)) return $data;
        }

        $slug = $this->translate_slug($title);
        if ($slug) {
            $data['post_name'] = $this->unique_slug($slug, (int)($postarr['ID'] ?? 0), $data['post_type']);
        }

        return $data;
    }

    /* ─── Core translator ─── */
    private function translate_slug(string $title): string {
        $helper = RSA_Helper::instance();

        // 1. Try direct Arabic-to-English map first (fast, no API)
        $slug = $helper->arabic_to_slug($title);

        // 2. If slug still has Arabic or is very short, use Claude
        if ($this->is_arabic($slug) || strlen($slug) < 5) {
            $slug = $this->translate_with_ai($title) ?: $slug;
        }

        return $slug ?: sanitize_title($title);
    }

    /* ─── Translate with Claude (cached per title) ─── */
    private function translate_with_ai(string $title): string|false {
        if (!$this->ai->is_ready()) return false;

        $cached = get_transient('rsa_slug_' . md5($title));
        if ($cached) return $cached;

        $prompt = "Translate this Arabic service/article title to a short, SEO-friendly English URL slug (lowercase, hyphens only, max 6 words). Output the slug only, nothing else.\n\nTitle: {$title}";
        $result = $this->ai->ask($prompt, 50);
        if (!$result) return false;

        // Clean the result
        $slug = strtolower(trim($result));
        $slug = preg_replace('/[^a-z0-9\-]/', '', $slug);
        $slug = preg_replace('/-+/', '-', $slug);
        $slug = trim($slug, '-');

        if ($slug) set_transient('rsa_slug_' . md5($title), $slug, WEEK_IN_SECONDS);
        return $slug ?: false;
    }

    /* ─── Ensure uniqueness ─── */
    private function unique_slug(string $slug, int $post_id, string $post_type): string {
        return wp_unique_post_slug($slug, $post_id, 'publish', $post_type, 0);
    }

    /* ─── Check if string contains Arabic ─── */
    private function is_arabic(string $text): bool {
        return (bool) preg_match('/[\x{0600}-\x{06FF}]/u', $text);
    }

    private function is_arabic_encoded(string $slug): bool {
        return str_contains($slug, '%d8') || str_contains($slug, '%d9') || $this->is_arabic($slug);
    }

    /* ─── AJAX: preview slug ─── */
    public function ajax_preview_slug(): void {
        check_ajax_referer('rsa_admin', 'nonce');
        $title = sanitize_text_field($_POST['title'] ?? '');
        if (!$title) wp_send_json_error('No title');

        $slug = $this->translate_slug($title);
        wp_send_json_success(['slug' => $slug, 'url' => home_url('/' . $slug . '/')]);
    }
}

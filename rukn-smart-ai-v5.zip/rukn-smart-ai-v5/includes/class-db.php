<?php
defined('ABSPATH') || exit;

class RSA_DB {
    private static ?RSA_DB $instance = null;

    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function create_tables(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_visits (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            session_id  VARCHAR(64)  NOT NULL,
            post_id     BIGINT UNSIGNED,
            page_url    TEXT,
            referrer    TEXT,
            ip          VARCHAR(45),
            city        VARCHAR(100),
            country     VARCHAR(10),
            device      VARCHAR(20),
            browser     VARCHAR(50),
            os          VARCHAR(50),
            screen_w    SMALLINT,
            scroll_pct  TINYINT,
            time_sec    SMALLINT,
            clicks      SMALLINT DEFAULT 0,
            intent      VARCHAR(20),
            utm_source  VARCHAR(100),
            utm_medium  VARCHAR(100),
            utm_campaign VARCHAR(100),
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(post_id), INDEX(city), INDEX(created_at), INDEX(intent)
        ) $charset;");

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_seo (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            post_id     BIGINT UNSIGNED UNIQUE NOT NULL,
            meta_title  VARCHAR(160),
            meta_desc   TEXT,
            focus_kw    VARCHAR(200),
            lsi_keywords TEXT,
            schema_json LONGTEXT,
            faq_json    LONGTEXT,
            seo_score   TINYINT DEFAULT 0,
            last_ai     DATETIME,
            INDEX(post_id), INDEX(seo_score)
        ) $charset;");

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_local_pages (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            city        VARCHAR(100),
            district    VARCHAR(100),
            service     VARCHAR(200),
            post_id     BIGINT UNSIGNED,
            template    VARCHAR(50) DEFAULT 'default',
            generated   TINYINT DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(city), INDEX(service), INDEX(generated)
        ) $charset;");

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_links (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            source_id   BIGINT UNSIGNED,
            target_id   BIGINT UNSIGNED,
            anchor_text VARCHAR(200),
            position    VARCHAR(20),
            auto_added  TINYINT DEFAULT 1,
            clicks      INT DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(source_id), INDEX(target_id)
        ) $charset;");

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_competitors (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            keyword     VARCHAR(200),
            url         TEXT,
            title       VARCHAR(255),
            h1          VARCHAR(255),
            word_count  INT,
            faq_count   SMALLINT,
            score       TINYINT,
            raw_data    LONGTEXT,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(keyword)
        ) $charset;");

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_logs (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            module      VARCHAR(50),
            action      VARCHAR(100),
            post_id     BIGINT UNSIGNED,
            provider    VARCHAR(30) DEFAULT 'gemini',
            tokens_used INT DEFAULT 0,
            status      VARCHAR(20) DEFAULT 'ok',
            note        TEXT,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX(module), INDEX(created_at)
        ) $charset;");

        dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rsa_offers (
            id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            title       VARCHAR(200),
            body        TEXT,
            city        VARCHAR(100),
            trigger_type VARCHAR(30),
            trigger_val  VARCHAR(100),
            active      TINYINT DEFAULT 1,
            impressions INT DEFAULT 0,
            clicks      INT DEFAULT 0,
            expires_at  DATETIME,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset;");

        update_option('rsa_db_version', RSA_DB_VERSION);
    }

    public function get(string $table, array $where = [], string $order = 'id DESC', int $limit = 50): array {
        global $wpdb;
        $t   = $wpdb->prefix . 'rsa_' . $table;
        $sql = "SELECT * FROM {$t}";
        $parts = [];
        foreach ($where as $col => $val) {
            $parts[] = $wpdb->prepare("`{$col}` = %s", $val);
        }
        if ($parts) $sql .= ' WHERE ' . implode(' AND ', $parts);
        $sql .= " ORDER BY {$order} LIMIT {$limit}";
        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }

    public function insert(string $table, array $data): int|false {
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'rsa_' . $table, $data);
        return $wpdb->insert_id ?: false;
    }

    public function update(string $table, array $data, array $where): bool {
        global $wpdb;
        return (bool) $wpdb->update($wpdb->prefix . 'rsa_' . $table, $data, $where);
    }

    public function count(string $table, array $where = []): int {
        global $wpdb;
        $t   = $wpdb->prefix . 'rsa_' . $table;
        $sql = "SELECT COUNT(*) FROM {$t}";
        if ($where) {
            $parts = [];
            foreach ($where as $c => $v) $parts[] = $wpdb->prepare("`{$c}` = %s", $v);
            $sql .= ' WHERE ' . implode(' AND ', $parts);
        }
        return (int) $wpdb->get_var($sql);
    }

    public function log(string $module, string $action, int $post_id = 0, int $tokens = 0, string $status = 'ok', string $note = ''): void {
        $provider = get_option('rsa_ai_provider', 'auto');
        $this->insert('logs', compact('module', 'action', 'post_id', 'tokens', 'status', 'note', 'provider') + ['created_at' => current_time('mysql')]);
    }
}

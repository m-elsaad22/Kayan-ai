<?php
defined('ABSPATH') || exit;

class RSA_Helper {
    private static ?RSA_Helper $instance = null;

    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function arabic_to_slug(string $text): string {
        $map = [
            'أ'=>'a','إ'=>'a','آ'=>'a','ا'=>'a','ب'=>'b','ت'=>'t','ث'=>'th','ج'=>'j',
            'ح'=>'h','خ'=>'kh','د'=>'d','ذ'=>'dh','ر'=>'r','ز'=>'z','س'=>'s','ش'=>'sh',
            'ص'=>'s','ض'=>'d','ط'=>'t','ظ'=>'z','ع'=>'a','غ'=>'gh','ف'=>'f','ق'=>'q',
            'ك'=>'k','ل'=>'l','م'=>'m','ن'=>'n','ه'=>'h','و'=>'w','ي'=>'y','ى'=>'a',
            'ة'=>'h','ء'=>'','ئ'=>'y','ؤ'=>'w','لا'=>'la',
            ' '=>'-','_'=>'-','،'=>'','.'=>'','–'=>'-',
        ];
        $text = strtr($text, $map);
        $text = preg_replace('/[\x{064B}-\x{065F}]/u', '', $text);
        $text = preg_replace('/[^a-zA-Z0-9\-]/', '', $text);
        $text = preg_replace('/-+/', '-', $text);
        return strtolower(trim($text, '-'));
    }

    public function get_ip(): string {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = trim(explode(',', $_SERVER[$key])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE)) return sanitize_text_field($ip);
            }
        }
        return '127.0.0.1';
    }

    public function get_city(string $ip = ''): array {
        if (!$ip) $ip = $this->get_ip();
        if ($ip === '127.0.0.1') return ['city' => 'Local', 'country' => 'LOCAL'];

        $cached = get_transient('rsa_geo_' . md5($ip));
        if ($cached) return $cached;

        $response = wp_remote_get("https://ipapi.co/{$ip}/json/", ['timeout' => 5]);
        if (is_wp_error($response)) return ['city' => 'Unknown', 'country' => ''];

        $data   = json_decode(wp_remote_retrieve_body($response), true);
        $result = [
            'city'    => $data['city']         ?? 'Unknown',
            'country' => $data['country_code'] ?? '',
            'region'  => $data['region']       ?? '',
            'lat'     => $data['latitude']     ?? 0,
            'lng'     => $data['longitude']    ?? 0,
        ];
        set_transient('rsa_geo_' . md5($ip), $result, DAY_IN_SECONDS);
        return $result;
    }

    public function get_device(): string {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        if (preg_match('/Mobile|Android|iPhone|iPad/i', $ua)) return 'mobile';
        if (preg_match('/Tablet|iPad/i', $ua)) return 'tablet';
        return 'desktop';
    }

    public function get_utm(): array {
        return [
            'source'   => sanitize_text_field($_GET['utm_source']   ?? ''),
            'medium'   => sanitize_text_field($_GET['utm_medium']   ?? ''),
            'campaign' => sanitize_text_field($_GET['utm_campaign'] ?? ''),
        ];
    }

    public function trim_text(string $text, int $words = 30): string {
        $text = strip_tags($text);
        $arr  = explode(' ', $text);
        if (count($arr) <= $words) return $text;
        return implode(' ', array_slice($arr, 0, $words)) . '…';
    }

    public function safe_json(string $raw): array {
        $raw     = preg_replace('/```json\s*/i', '', $raw);
        $raw     = preg_replace('/```\s*/', '', $raw);
        $decoded = json_decode(trim($raw), true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function city_ar(string $city_en): string {
        $map = [
            'dubai' => 'دبي', 'abu-dhabi' => 'أبوظبي', 'sharjah' => 'الشارقة',
            'ajman' => 'عجمان', 'fujairah' => 'الفجيرة', 'ras-al-khaimah' => 'رأس الخيمة',
            'umm-al-quwain' => 'أم القيوين', 'al-ain' => 'العين',
            'riyadh' => 'الرياض', 'jeddah' => 'جدة', 'dammam' => 'الدمام',
            'khobar' => 'الخبر', 'mecca' => 'مكة', 'medina' => 'المدينة المنورة',
            'doha' => 'الدوحة', 'wakra' => 'الوكرة', 'lusail' => 'لوسيل',
        ];
        return $map[strtolower($city_en)] ?? $city_en;
    }

    public function format_num(int $n): string {
        return number_format($n);
    }

    public function session_id(): string {
        if (!session_id()) @session_start();
        if (empty($_SESSION['rsa_sid'])) $_SESSION['rsa_sid'] = wp_generate_uuid4();
        return $_SESSION['rsa_sid'];
    }
}

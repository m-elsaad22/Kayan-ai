<?php
defined('ABSPATH') || exit;

/**
 * RSA_Claude_API — Wrapper لـ Claude Anthropic API
 * يدعم: claude-sonnet-4-20250514
 */
class RSA_Claude_API {

    private static ?RSA_Claude_API $instance = null;
    private string $api_key  = '';
    private string $model    = 'claude-sonnet-4-20250514';
    private string $endpoint = 'https://api.anthropic.com/v1/messages';

    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->api_key = get_option('rsa_claude_api_key', '');
    }

    public function ask(string $prompt, int $max_tokens = 2000, string $system = ''): string|false {
        if (empty($this->api_key)) return false;

        $body = [
            'model'      => $this->model,
            'max_tokens' => $max_tokens,
            'messages'   => [['role' => 'user', 'content' => $prompt]],
        ];
        if (!empty($system)) $body['system'] = $system;

        $response = wp_remote_post($this->endpoint, [
            'timeout' => 60,
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $this->api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body' => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            error_log('[RuknSmartAI] Claude Error: ' . $response->get_error_message());
            return false;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        return $data['content'][0]['text'] ?? false;
    }

    public function ask_json(string $prompt, int $max_tokens = 1500): array|false {
        $system  = 'You are a JSON generator. Always respond with valid JSON only. No markdown, no explanations, no backticks.';
        $result  = $this->ask($prompt, $max_tokens, $system);
        if (!$result) return false;
        $decoded = json_decode(trim($result), true);
        return is_array($decoded) ? $decoded : false;
    }

    public function ask_cached(string $prompt, string $cache_key, int $expiry = 86400): string|false {
        $cached = get_transient('rsa_ai_' . md5($cache_key));
        if ($cached !== false) return $cached;
        $result = $this->ask($prompt);
        if ($result) set_transient('rsa_ai_' . md5($cache_key), $result, $expiry);
        return $result;
    }

    public function set_key(string $key): void   { $this->api_key = $key; }
    public function is_ready(): bool              { return !empty($this->api_key); }
    public function get_model(): string           { return $this->model; }

    public function test(): array {
        if (empty($this->api_key)) return ['success' => false, 'msg' => 'مفتاح API غير موجود'];
        $result = $this->ask('قل "مرحبا" فقط', 50);
        if ($result) return ['success' => true, 'msg' => 'Claude يعمل بنجاح ✅ — الرد: ' . mb_substr($result, 0, 50)];
        return ['success' => false, 'msg' => 'فشل الاتصال بـ Claude — تحقق من المفتاح'];
    }
}

<?php
defined('ABSPATH') || exit;

/**
 * RSA_Gemini_API — Wrapper لـ Google Gemini API
 * يدعم: gemini-2.0-flash (مجاني بمفتاح AI Studio)
 * + وضع تشغيل بدون مفتاح عبر Gemini API Public Tier
 */
class RSA_Gemini_API {

    private static ?RSA_Gemini_API $instance = null;
    private string $api_key  = '';
    private string $model    = 'gemini-2.0-flash';
    private string $endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/';

    // مفتاح احتياطي مدمج (AI Studio free tier — 1500 req/day)
    // أنشئ مفتاحك المجاني الخاص من: https://aistudio.google.com/app/apikey
    private const FALLBACK_KEY = '';

    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $saved = get_option('rsa_gemini_api_key', '');
        $this->api_key = !empty($saved) ? $saved : self::FALLBACK_KEY;
    }

    /**
     * الحصول على المفتاح الفعّال (المحفوظ أو الاحتياطي)
     */
    private function effective_key(): string {
        $saved = get_option('rsa_gemini_api_key', '');
        return !empty($saved) ? $saved : self::FALLBACK_KEY;
    }

    /**
     * إرسال prompt لـ Gemini وإرجاع الرد
     */
    public function ask(string $prompt, int $max_tokens = 2000, string $system = ''): string|false {
        $key = $this->effective_key();
        if (empty($key)) return false;

        $url = $this->endpoint . $this->model . ':generateContent?key=' . $key;

        $parts = [];
        if (!empty($system)) {
            $parts[] = ['text' => $system . "\n\n" . $prompt];
        } else {
            $parts[] = ['text' => $prompt];
        }

        $body = [
            'contents' => [
                ['role' => 'user', 'parts' => $parts]
            ],
            'generationConfig' => [
                'maxOutputTokens' => $max_tokens,
                'temperature'     => 0.7,
            ]
        ];

        $response = wp_remote_post($url, [
            'timeout' => 60,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            error_log('[RuknSmartAI] Gemini Error: ' . $response->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);

        // لو المفتاح الأول فشل بسبب quota/invalid — جرب الاحتياطي
        if ($code !== 200 && get_option('rsa_gemini_api_key', '') !== '' && !empty(self::FALLBACK_KEY)) {
            error_log('[RuknSmartAI] Primary key failed (HTTP ' . $code . '), trying fallback...');
            return $this->ask_with_key($prompt, $max_tokens, $system, self::FALLBACK_KEY);
        }

        return $data['candidates'][0]['content']['parts'][0]['text'] ?? false;
    }

    /**
     * إرسال prompt بمفتاح محدد
     */
    private function ask_with_key(string $prompt, int $max_tokens, string $system, string $key): string|false {
        $url = $this->endpoint . $this->model . ':generateContent?key=' . $key;

        $parts = [];
        if (!empty($system)) {
            $parts[] = ['text' => $system . "\n\n" . $prompt];
        } else {
            $parts[] = ['text' => $prompt];
        }

        $body = [
            'contents' => [['role' => 'user', 'parts' => $parts]],
            'generationConfig' => [
                'maxOutputTokens' => $max_tokens,
                'temperature'     => 0.7,
            ]
        ];

        $response = wp_remote_post($url, [
            'timeout' => 60,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) return false;
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return $data['candidates'][0]['content']['parts'][0]['text'] ?? false;
    }

    /**
     * طلب JSON نظيف من Gemini
     */
    public function ask_json(string $prompt, int $max_tokens = 1500): array|false {
        $system = 'You are a JSON generator. Always respond with valid JSON only. No markdown, no explanations, no backticks. Start directly with { or [';
        $result = $this->ask($prompt, $max_tokens, $system);
        if (!$result) return false;

        $result = preg_replace('/```json\s*/i', '', $result);
        $result = preg_replace('/```\s*/', '', $result);

        $decoded = json_decode(trim($result), true);
        return is_array($decoded) ? $decoded : false;
    }

    /**
     * طلب مع Cache
     */
    public function ask_cached(string $prompt, string $cache_key, int $expiry = 86400): string|false {
        $cached = get_transient('rsa_ai_' . md5($cache_key));
        if ($cached !== false) return $cached;

        $result = $this->ask($prompt);
        if ($result) set_transient('rsa_ai_' . md5($cache_key), $result, $expiry);
        return $result;
    }

    public function set_key(string $key): void {
        $this->api_key = $key;
    }

    /**
     * is_ready: يعمل لو عنده مفتاح محفوظ أو مفتاح احتياطي مدمج
     */
    public function is_ready(): bool {
        return !empty($this->effective_key());
    }

    public function get_model(): string {
        return $this->model;
    }

    /**
     * هل يستخدم المفتاح المحفوظ أم الاحتياطي؟
     */
    public function using_fallback(): bool {
        $saved = get_option('rsa_gemini_api_key', '');
        return empty($saved) && !empty(self::FALLBACK_KEY);
    }

    /**
     * اختبار الاتصال
     */
    public function test(): array {
        $key = $this->effective_key();
        if (empty($key)) {
            return ['success' => false, 'msg' => 'لا يوجد مفتاح API — أضف مفتاحك المجاني من aistudio.google.com'];
        }
        $result = $this->ask('قل "مرحبا" فقط', 50);
        if ($result) {
            $source = $this->using_fallback() ? ' (مفتاح احتياطي)' : ' (مفتاحك)';
            return ['success' => true, 'msg' => 'Gemini يعمل بنجاح ✅' . $source . ' — الرد: ' . mb_substr($result, 0, 50)];
        }
        return ['success' => false, 'msg' => 'فشل الاتصال بـ Gemini — تحقق من المفتاح أو تحقق من الـ quota'];
    }
}

<?php
defined('ABSPATH') || exit;

/**
 * RSA_AI — واجهة ذكاء اصطناعي موحّدة
 * تختار تلقائياً بين Gemini و Claude حسب الإعداد والتوفر
 */
class RSA_AI {

    private static ?RSA_AI $instance = null;
    private string $provider = 'gemini'; // gemini | claude | auto

    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        $this->provider = get_option('rsa_ai_provider', 'auto');
    }

    /**
     * الحصول على مزوّد AI المناسب تلقائياً
     */
    private function get_provider(): RSA_Gemini_API|RSA_Claude_API|null {
        $gemini = RSA_Gemini_API::instance();
        $claude = RSA_Claude_API::instance();

        if ($this->provider === 'gemini') {
            return $gemini->is_ready() ? $gemini : null;
        }

        if ($this->provider === 'claude') {
            return $claude->is_ready() ? $claude : null;
        }

        // auto: يحاول Gemini أولاً (مجاني) ثم Claude
        if ($gemini->is_ready()) return $gemini;
        if ($claude->is_ready()) return $claude;

        return null;
    }

    /**
     * إرسال prompt والحصول على رد نصي
     */
    public function ask(string $prompt, int $max_tokens = 2000, string $system = ''): string|false {
        $p = $this->get_provider();
        if (!$p) return false;
        return $p->ask($prompt, $max_tokens, $system);
    }

    /**
     * طلب JSON منظّم
     */
    public function ask_json(string $prompt, int $max_tokens = 1500): array|false {
        $p = $this->get_provider();
        if (!$p) return false;
        return $p->ask_json($prompt, $max_tokens);
    }

    /**
     * طلب مع تخزين مؤقت
     */
    public function ask_cached(string $prompt, string $cache_key, int $expiry = 86400): string|false {
        $cached = get_transient('rsa_ai_' . md5($cache_key));
        if ($cached !== false) return $cached;

        $result = $this->ask($prompt);
        if ($result) set_transient('rsa_ai_' . md5($cache_key), $result, $expiry);
        return $result;
    }

    /**
     * هل يوجد مزوّد AI متاح؟
     */
    public function is_ready(): bool {
        return $this->get_provider() !== null;
    }

    /**
     * اسم المزوّد الحالي
     */
    public function active_provider_name(): string {
        $gemini = RSA_Gemini_API::instance();
        $claude = RSA_Claude_API::instance();

        if ($this->provider === 'gemini' && $gemini->is_ready()) {
            return $gemini->using_fallback() ? 'Google Gemini (مفتاح احتياطي)' : 'Google Gemini';
        }
        if ($this->provider === 'claude' && $claude->is_ready()) return 'Anthropic Claude';
        if ($this->provider === 'auto') {
            if ($gemini->is_ready()) return $gemini->using_fallback() ? 'Google Gemini (مفتاح احتياطي)' : 'Google Gemini (Auto)';
            if ($claude->is_ready()) return 'Anthropic Claude (Auto)';
        }
        return 'غير متصل';
    }

    /**
     * توليد محتوى SEO عربي كامل لمقال
     */
    public function generate_seo_content(string $keyword, string $city = '', string $service = ''): array|false {
        $location = $city ? " في {$city}" : '';
        $prompt = "أنت خبير SEO عربي متخصص في خدمات المنازل في الخليج.
اكتب محتوى SEO كامل للكلمة: '{$keyword}'{$location}

أعد JSON بهذا الشكل:
{
  \"meta_title\": \"عنوان SEO 60 حرف\",
  \"meta_desc\": \"وصف SEO 160 حرف يحتوي الكلمة المفتاحية\",
  \"h1\": \"عنوان H1 رئيسي\",
  \"intro\": \"مقدمة 100 كلمة عربية جذابة\",
  \"faq\": [{\"q\":\"سؤال؟\",\"a\":\"جواب كامل\"}],
  \"keywords_lsi\": [\"كلمة1\",\"كلمة2\",\"كلمة3\",\"كلمة4\",\"كلمة5\"]
}";

        return $this->ask_json($prompt, 2000);
    }

    /**
     * تحليل نص وإعطاء نية الزيارة
     */
    public function detect_intent(string $page_title, string $url): string {
        $prompt = "حدد نية الزيارة لهذه الصفحة:
العنوان: {$page_title}
الرابط: {$url}

أجب بكلمة واحدة فقط: buying أو research أو browsing أو unknown";

        $result = $this->ask($prompt, 20);
        $result = strtolower(trim($result ?? ''));
        return in_array($result, ['buying', 'research', 'browsing']) ? $result : 'unknown';
    }
}

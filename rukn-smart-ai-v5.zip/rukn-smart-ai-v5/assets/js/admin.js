/* Rukn Smart AI — Admin JS v3.0 | Author: Mahmoud Elsaad */
(function ($) {
    'use strict';

    /* ── Helpers ────────────────────────────────── */
    function rsaLoading(el, msg) {
        $(el).html('<div class="rsa-loading"><span class="rsa-spinner"></span>' + (msg || 'جاري التنفيذ...') + '</div>');
    }
    function rsaSuccess(el, msg) { $(el).html('<div class="rsa-success">✅ ' + msg + '</div>'); }
    function rsaError(el, msg)   { $(el).html('<div class="rsa-error">❌ ' + msg + '</div>'); }

    window.rsaAjax = function (action, data, target, loadingMsg) {
        rsaLoading('#' + target, loadingMsg || 'جاري التنفيذ...');
        $.post(RSA_Admin.ajaxurl, $.extend({ action: action, nonce: RSA_Admin.nonce }, data), function (r) {
            if (r.success) {
                if (typeof r.data === 'string') rsaSuccess('#' + target, r.data);
                else rsaSuccess('#' + target, r.data.msg || 'تم بنجاح');
            } else {
                rsaError('#' + target, r.data || 'حدث خطأ غير متوقع');
            }
        }).fail(function () { rsaError('#' + target, 'فشل الاتصال بالسيرفر'); });
    };

    /* ── Tabs ───────────────────────────────────── */
    $(document).on('click', '.rsa-tab', function () {
        var panel = $(this).data('tab');
        $(this).closest('.rsa-tabs-container').find('.rsa-tab').removeClass('active');
        $(this).closest('.rsa-tabs-container').find('.rsa-tab-panel').removeClass('active');
        $(this).addClass('active');
        $('#' + panel).addClass('active');
    });

    /* ── Toggle modules checkbox ──────────────── */
    $(document).on('change', '.rsa-module-toggle', function () {
        var $card = $(this).closest('.rsa-module-card');
        if ($(this).is(':checked')) $card.removeClass('inactive').addClass('active');
        else $card.removeClass('active').addClass('inactive');
    });

    /* ── AI Provider Cards ─────────────────────── */
    $(document).on('click', '.rsa-provider-card', function () {
        var val = $(this).data('value');
        $(this).closest('.rsa-provider-grid').find('.rsa-provider-card').removeClass('selected');
        $(this).addClass('selected');
        $('input[name="rsa_ai_provider"]').val(val);
    });

    /* ── Test AI Connection ─────────────────────── */
    $(document).on('click', '#rsa-test-gemini', function () {
        rsaLoading('#rsa-gemini-test-result', 'اختبار Gemini...');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_test_gemini', nonce: RSA_Admin.nonce, key: $('input[name="rsa_gemini_api_key"]').val() }, function (r) {
            if (r.success) rsaSuccess('#rsa-gemini-test-result', r.data.msg);
            else rsaError('#rsa-gemini-test-result', r.data.msg || r.data);
        });
    });

    $(document).on('click', '#rsa-test-claude', function () {
        rsaLoading('#rsa-claude-test-result', 'اختبار Claude...');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_test_claude', nonce: RSA_Admin.nonce, key: $('input[name="rsa_claude_api_key"]').val() }, function (r) {
            if (r.success) rsaSuccess('#rsa-claude-test-result', r.data.msg);
            else rsaError('#rsa-claude-test-result', r.data.msg || r.data);
        });
    });

    /* ── Local SEO: gen page ─────────────────── */
    window.rsaGenLocalPage = function () {
        var service = $('#rsa-service').val();
        var city    = $('#rsa-city').val();
        if (!service) { alert('أدخل الخدمة أولاً'); return; }
        rsaLoading('#rsa-local-result', 'جاري التوليد بـ AI...');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_gen_local_page', nonce: RSA_Admin.nonce, city: city, service: service }, function (r) {
            if (r.success) {
                $('#rsa-local-result').html('<div class="rsa-success">✅ تم إنشاء الصفحة! <a href="' + r.data.view_url + '" target="_blank">عرض</a> | <a href="' + r.data.edit_url + '" target="_blank">تعديل</a></div>');
            } else rsaError('#rsa-local-result', r.data);
        });
    };

    window.rsaGenBulkCities = function () {
        if (!confirm('سيتم إنشاء صفحة لكل مدينة. هل تريد المتابعة؟')) return;
        var service = $('#rsa-bulk-service').val();
        if (!service) { alert('أدخل الخدمة'); return; }
        rsaLoading('#rsa-bulk-result', 'جاري توليد جميع المدن... قد يستغرق دقائق');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_gen_bulk_cities', nonce: RSA_Admin.nonce, service: service }, function (r) {
            if (r.success) rsaSuccess('#rsa-bulk-result', 'تم توليد ' + r.data.total + ' صفحة');
            else rsaError('#rsa-bulk-result', r.data);
        });
    };

    /* ── AI Quick Generate ──────────────────── */
    window.rsaQuickGenerate = function (type) {
        var kw = $('#rsa-quick-keyword').val();
        if (!kw) { alert('أدخل الكلمة المفتاحية'); return; }
        rsaLoading('#rsa-quick-result', 'جاري التوليد بـ AI...');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_quick_generate', nonce: RSA_Admin.nonce, type: type, keyword: kw }, function (r) {
            if (r.success) {
                $('#rsa-quick-result').html('<div class="rsa-ai-response">' + r.data.content + '</div>');
            } else rsaError('#rsa-quick-result', r.data);
        });
    };

    /* ── Analysis ────────────────────────────── */
    window.rsaRunAnalysis = function () {
        rsaLoading('#rsa-analysis-output', 'جاري تحليل كل المقالات والصفحات... قد يستغرق دقيقة');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_run_analysis', nonce: RSA_Admin.nonce }, function (r) {
            if (r.success) location.reload();
            else rsaError('#rsa-analysis-output', r.data);
        });
    };

    window.rsaFixIssue = function (fix, postId, btn) {
        btn.disabled = true; btn.textContent = '⏳';
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_fix_issue', nonce: RSA_Admin.nonce, fix: fix, post_id: postId }, function (r) {
            btn.textContent = r.success ? '✅' : '❌';
        });
    };

    /* ── Linking ─────────────────────────────── */
    window.rsaScanAllLinks = function () {
        rsaLoading('#rsa-linking-result', 'جاري مسح جميع المقالات وإضافة روابط...');
        $.post(RSA_Admin.ajaxurl, { action: 'rsa_scan_all_links', nonce: RSA_Admin.nonce }, function (r) {
            if (r.success) rsaSuccess('#rsa-linking-result', 'تمت معالجة ' + r.data.processed + ' مقال');
            else rsaError('#rsa-linking-result', r.data);
        });
    };

    /* ── Copy to clipboard ────────────────────── */
    window.rsaCopy = function (text) {
        navigator.clipboard.writeText(text).then(function () {
            var btn = event.target;
            var orig = btn.textContent;
            btn.textContent = '✅ تم النسخ';
            setTimeout(function () { btn.textContent = orig; }, 2000);
        });
    };

    /* ── Init ─────────────────────────────────── */
    $(function () {
        // Activate first tab on load
        $('.rsa-tabs-container').each(function () {
            $(this).find('.rsa-tab').first().addClass('active');
            $(this).find('.rsa-tab-panel').first().addClass('active');
        });

        // Password show/hide
        $(document).on('click', '.rsa-show-pass', function () {
            var input = $(this).prev('input');
            input.attr('type', input.attr('type') === 'password' ? 'text' : 'password');
            $(this).text(input.attr('type') === 'password' ? '👁' : '🙈');
        });
    });

})(jQuery);

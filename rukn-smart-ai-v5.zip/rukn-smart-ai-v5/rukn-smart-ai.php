<?php
/**
 * Plugin Name: Rukn Smart AI — نظام الذكاء الاصطناعي المتكامل
 * Plugin URI:  https://rukn-eltatawer.com
 * Description: نظام ذكاء اصطناعي متكامل: SEO محلي، توليد محتوى جماعي، تتبع زيارات، تحليل منافسين، ربط داخلي، تحويل زوار — مدعوم بـ Gemini & Claude AI
 * Version:     4.1.0
 * Author:      Mahmoud Elsaad
 * Author URI:  https://rukn-eltatawer.com
 * Text Domain: rukn-smart-ai
 * Requires PHP: 7.4
 * Requires at least: 6.0
 */

defined('ABSPATH') || exit;

/* ─── Constants ─── */
define('RSA_VERSION',    '4.1.0');
define('RSA_FILE',       __FILE__);
define('RSA_DIR',        plugin_dir_path(__FILE__));
define('RSA_URL',        plugin_dir_url(__FILE__));
define('RSA_DB_VERSION', '1.0');
define('RSA_SLUG',       'rukn-smart-ai');

/* ─── Auto-loader ─── */
spl_autoload_register(function ($class) {
    $map = [
        'RSA_Gemini_API'  => 'includes/class-gemini-api.php',
        'RSA_Claude_API'  => 'includes/class-claude-api.php',
        'RSA_AI'          => 'includes/class-ai.php',
        'RSA_DB'          => 'includes/class-db.php',
        'RSA_Helper'      => 'includes/class-helper.php',
        'RSA_Local_SEO'   => 'ai-engine/local-seo/class-local-seo.php',
        'RSA_SEO_Engine'  => 'ai-engine/seo-engine/class-seo-engine.php',
        'RSA_Schema'      => 'ai-engine/schema/class-schema.php',
        'RSA_Conversion'  => 'ai-engine/conversion/class-conversion.php',
        'RSA_Intent'      => 'ai-engine/intent/class-intent.php',
        'RSA_Linking'     => 'ai-engine/linking/class-linking.php',
        'RSA_Offers'      => 'ai-engine/offers/class-offers.php',
        'RSA_Content'     => 'ai-engine/content/class-content.php',
        'RSA_Tracker'     => 'ai-engine/tracker/class-tracker.php',
        'RSA_Competitor'  => 'ai-engine/competitor/class-competitor.php',
        'RSA_Icons'       => 'ai-engine/icons/class-icons.php',
        'RSA_Image_Gen'   => 'ai-engine/image-gen/class-image-gen.php',
        'RSA_Auto_Slug'   => 'ai-engine/auto-slug/class-auto-slug.php',
        'RSA_Analyzer'    => 'ai-engine/analyzer/class-analyzer.php',
        'RSA_Bulk_Writer' => 'ai-engine/bulk-writer/class-bulk-writer.php',
        'RSA_Admin'       => 'admin/class-admin.php',
    ];
    if (isset($map[$class])) {
        $file = RSA_DIR . $map[$class];
        if (file_exists($file)) require_once $file;
    }
});

/* ─── Bootstrap ─── */
final class Rukn_Smart_AI {

    private static ?Rukn_Smart_AI $instance = null;
    public array $modules = [];

    public static function instance(): self {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('plugins_loaded', [$this, 'init'], 5);
        register_activation_hook(RSA_FILE,   [$this, 'activate']);
        register_deactivation_hook(RSA_FILE, [$this, 'deactivate']);
    }

    public function init(): void {
        RSA_DB::instance();
        RSA_Helper::instance();

        $enabled = get_option('rsa_enabled_modules', $this->default_modules());
        $classes  = [
            'local_seo'   => 'RSA_Local_SEO',
            'seo_engine'  => 'RSA_SEO_Engine',
            'schema'      => 'RSA_Schema',
            'conversion'  => 'RSA_Conversion',
            'intent'      => 'RSA_Intent',
            'linking'     => 'RSA_Linking',
            'offers'      => 'RSA_Offers',
            'content'     => 'RSA_Content',
            'tracker'     => 'RSA_Tracker',
            'competitor'  => 'RSA_Competitor',
            'icons'       => 'RSA_Icons',
            'image_gen'   => 'RSA_Image_Gen',
            'auto_slug'   => 'RSA_Auto_Slug',
            'analyzer'    => 'RSA_Analyzer',
            'bulk_writer' => 'RSA_Bulk_Writer',
        ];

        foreach ($classes as $key => $class) {
            if (!empty($enabled[$key]) && class_exists($class)) {
                $this->modules[$key] = new $class();
            }
        }

        if (is_admin()) new RSA_Admin($this->modules);
    }

    public function activate(): void {
        RSA_DB::instance()->create_tables();
        add_option('rsa_enabled_modules', $this->default_modules());
        add_option('rsa_gemini_api_key', '');
        add_option('rsa_claude_api_key', '');
        add_option('rsa_ai_provider', 'gemini');
        add_option('rsa_company_name', get_bloginfo('name'));
        add_option('rsa_default_country', 'ae');
        add_option('rsa_whatsapp_number', '');
        add_option('rsa_phone_number', '');
        flush_rewrite_rules();
    }

    public function deactivate(): void {
        flush_rewrite_rules();
    }

    private function default_modules(): array {
        return [
            'local_seo'  => 1, 'seo_engine' => 1, 'schema'    => 1,
            'conversion' => 1, 'intent'     => 1, 'linking'   => 1,
            'offers'     => 1, 'content'    => 1, 'tracker'   => 1,
            'competitor' => 0, 'icons'      => 1, 'image_gen' => 1,
            'auto_slug'  => 1, 'analyzer'   => 1, 'bulk_writer' => 1,
        ];
    }
}

function RSA(): Rukn_Smart_AI { return Rukn_Smart_AI::instance(); }
RSA();
